package com.lenovo.m2.buy.promotion.admin.remote.pay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayPointRulesApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayPointRules;
import com.lenovo.m2.hsbuy.service.pay.soa.PayPointRulesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * Created by jh on 2017/8/10.
 */
@Service
public class PayPointRulesApiImpl implements PayPointRulesApi {

    @Autowired
    @Qualifier(value = "payPointRulesService")
    private PayPointRulesService payPointRulesService;

    @Override
    public RemoteResult<PayPointRules> getPayPointRulesByfaId(String faId) {
        return payPointRulesService.getPayPointRulesByfaId(faId);
    }

    public PayPointRulesService getPayPointRulesService() {
        return payPointRulesService;
    }

    public void setPayPointRulesService(PayPointRulesService payPointRulesService) {
        this.payPointRulesService = payPointRulesService;
    }
}
