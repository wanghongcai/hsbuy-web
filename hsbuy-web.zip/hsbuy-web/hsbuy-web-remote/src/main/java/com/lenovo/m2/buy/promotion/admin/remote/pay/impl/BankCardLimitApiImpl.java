package com.lenovo.m2.buy.promotion.admin.remote.pay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.pay.BankCardLimitApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.BankCardLimit;
import com.lenovo.m2.hsbuy.service.pay.soa.BankCardLimitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by tianchuyang on 2017/1/17.
 */
@Service
public class BankCardLimitApiImpl implements BankCardLimitApi {


    @Autowired
    @Qualifier(value = "bankCardLimitService")
    private BankCardLimitService bankCardLimitService;

    @Override
    public RemoteResult<List<BankCardLimit>> queryBankCardLimitByParams(BankCardLimit hsBankDetail) {
        return bankCardLimitService.queryBankCardLimitsByParams(hsBankDetail);
    }

    @Override
    public RemoteResult<List<BankCardLimit>> queryAllBankCardLimits() {
        return bankCardLimitService.queryAllBankCardLimits();
    }

    public BankCardLimitService getBankCardLimitService() {
        return bankCardLimitService;
    }

    public void setBankCardLimitService(BankCardLimitService bankCardLimitService) {
        this.bankCardLimitService = bankCardLimitService;
    }
}
