package com.lenovo.m2.buy.promotion.admin.remote.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.BankCardLimit;

import java.util.List;

/**
 * Created by tianchuyang on 2017/1/17.
 */
public interface BankCardLimitApi {

    RemoteResult<List<BankCardLimit>> queryBankCardLimitByParams(BankCardLimit hsBankDetail);

    RemoteResult<List<BankCardLimit>> queryAllBankCardLimits();
}
