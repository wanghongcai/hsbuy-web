package com.lenovo.m2.buy.promotion.admin.remote.cerp;

import com.lenovo.m2.arch.framework.domain.Tenant;

/**
 * Created by wangrq1 on 2016/12/29.
 */
public interface CerpService {

    Tenant getTenantByShopId(Integer shopId);


}
