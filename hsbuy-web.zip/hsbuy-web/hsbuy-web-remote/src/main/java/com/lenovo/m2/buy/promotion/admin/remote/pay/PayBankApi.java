package com.lenovo.m2.buy.promotion.admin.remote.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.PayBank;

import java.util.List;

/**
 * Created by tianchuyang on 2017/1/17.
 */
public interface PayBankApi {

    RemoteResult<List<PayBank>> queryAllPayBanks();

    RemoteResult<PayBank> queryPayBankByParams(PayBank payBank);
}
