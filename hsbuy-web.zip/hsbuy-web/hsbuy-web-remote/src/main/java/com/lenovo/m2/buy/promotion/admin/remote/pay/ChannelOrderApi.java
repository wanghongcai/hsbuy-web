package com.lenovo.m2.buy.promotion.admin.remote.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.ChannelOrder;

import java.util.List;

/**
 * Created by MengQiang on 2016/2/22.
 */
public interface ChannelOrderApi {

    /**
     * 查询主单
     * @param orderMainCodeList
     * @param lenovoId
     * @returen list
     */
    public RemoteResult<List<ChannelOrder>> queryChannelOrderMainCodeList(List<String> orderMainCodeList, String lenovoId, String shopId);

    /**
     * 根据主单号查询对应的主单信息
     * @param orderMainCode
     * @param lenovoId
     * @return map
     */
    public RemoteResult<ChannelOrder> queryChannelOrderMainCodeDetail(String orderMainCode, String lenovoId, String shopId);

    /**
     * 根据主单号修改订单信息
     * @param channelOrder
     * @return
     */
    public RemoteResult<Integer> updateChannelOrderMainCodeDetail(ChannelOrder channelOrder);

    /**
     * 查询orderMainCode下所有子单
     * @param orderMainCode
     * @param lenovoId
     * @return
     */
    public RemoteResult<List<ChannelOrder>> queryChannelOrderCodeList(String orderMainCode, String lenovoId, int mainFlag, String shopId);

    /**
     * 查询子单信息
     * @param orderCode
     * @param lenovoId
     * @return
     */
    public RemoteResult<ChannelOrder> queryChannelOrderCodeDetail(String orderCode, String lenovoId, int mainFlag, String shopId);

    /**
     * 合并支付根据子单集合查询订单列表
     * @param orderCodeList
     * @param lenovoId
     * @param mainFlag
     * @return
     */
    public RemoteResult<List<ChannelOrder>> queryOrderCodeList(List<String> orderCodeList, String lenovoId, int mainFlag, String shopId);

    /**
     * 更新渠道订单状态
     * @param orderStatus
     * @param orderCode
     * @param mainFlag
     * @return
     */
    public RemoteResult<Integer> updateChannelOrderOrderStatus(int orderStatus, String orderCode, int mainFlag, String shopId);

    /**
     * 查询SMB支付订单
     * @param smbOrderCode
     * @param mainFlag
     * @param shopId
     * @return
     */
    public RemoteResult<ChannelOrder> querySmbChannelOrderDetail(String smbOrderCode, int mainFlag, String shopId);
}
