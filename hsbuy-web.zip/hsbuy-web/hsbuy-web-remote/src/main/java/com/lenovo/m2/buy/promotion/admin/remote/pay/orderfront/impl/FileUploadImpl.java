package com.lenovo.m2.buy.promotion.admin.remote.pay.orderfront.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.pay.orderfront.FileUpload;
import org.apache.log4j.Logger;

import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * Created by jh on 2016/1/11.
 */
public class FileUploadImpl implements FileUpload {
    public static Logger logger= Logger.getLogger(FileUploadImpl.class);

    /**
     * 传输文件逻辑
     * @param fileName
     * @param in
     * @return
     */
    public RemoteResult<Boolean> fileUpload(String fileName, InputStream in) {
        RemoteResult<Boolean> rs=new RemoteResult<Boolean>(false);
        try {
            logger.info("获取文件："+fileName);
            FileOutputStream out = new FileOutputStream(fileName);
            logger.info("创建文件："+fileName);
            int n = -1;
            byte[] b = new byte[10240];
            logger.info("开始读取："+fileName);
            while((n=in.read(b)) != -1){
                System.out.println(new String(b,0,n,"utf-8"));
                out.write(b, 0, n);
            }
            logger.info("读取完毕："+fileName);
            out.close();
            out.flush();
            in.close();
            rs.setSuccess(true);
        } catch (Exception e) {
            logger.info("异常："+e);
        }
        return rs;
    }
}
