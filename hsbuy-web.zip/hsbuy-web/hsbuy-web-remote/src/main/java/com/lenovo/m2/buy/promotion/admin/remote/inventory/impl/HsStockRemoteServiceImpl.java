package com.lenovo.m2.buy.promotion.admin.remote.inventory.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.inventory.HsStockRemoteService;
import com.lenovo.m2.hsbuy.bee.PromotionRoutedService;
import com.lenovo.m2.hsbuy.domain.inventory.HsStock;
import com.lenovo.m2.hsbuy.domain.inventory.HsWaterLevelStock;
import com.lenovo.m2.hsbuy.domain.ordercenter.BeeOrderApi;
import com.lenovo.m2.hsbuy.inventory.HsStockApiService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Created by yezhenyue on 2017/2/16.
 */
@Service("hsStockRemoteService")
public class HsStockRemoteServiceImpl implements HsStockRemoteService {
    @Autowired
    private HsStockApiService hsStockApiService;
    @Autowired
    private PromotionRoutedService promotionRoutedService;
    @Override
    public RemoteResult addHsWaterLevelStock(HsWaterLevelStock hsWaterLevelStock) {
        return hsStockApiService.addHsWaterLevelStock(hsWaterLevelStock);
    }

    @Override
    public RemoteResult updateHsWaterLevelStock(HsWaterLevelStock hsWaterLevelStock) {
        return hsStockApiService.updateHsWaterLevelStock(hsWaterLevelStock);
    }

    @Override
    public RemoteResult<PageModel2<HsWaterLevelStock>> getHsWaterLevelStockPage(PageQuery pageQuery, Map map) {
        return hsStockApiService.getHsWaterLevelStockPage(pageQuery,map);
    }

    @Override
    public RemoteResult<HsWaterLevelStock> getHsWaterLevelStockByFaid(String fxsNo) {
        return hsStockApiService.getHsWaterLevelStockByFaid(fxsNo);
    }

    @Override
    public RemoteResult<HsWaterLevelStock> getHsWaterLevelStockById(long id) {
        return hsStockApiService.getHsWaterLevelStockById(id);
    }

    @Override
    public RemoteResult<PageModel2<BeeOrderApi>> getBeeOrderPage(PageQuery pageQuery, Map map) {
        return promotionRoutedService.getBeeOrdersByOrderTime(pageQuery,map);
    }

    @Override
    public RemoteResult addHsOwnStock(HsStock hsStock) {
        return hsStockApiService.addHsOwnStock(hsStock);
    }

    @Override
    public RemoteResult updateHsOwnStock(HsStock hsStock) {
        return hsStockApiService.updateHsOwnStock(hsStock);
    }

    @Override
    public RemoteResult<HsStock> getHsOwnStock(String faid, String goodsCode, String productGroupNo) {
        return hsStockApiService.getHsOwnStock(faid,goodsCode,productGroupNo);
    }

    @Override
    public RemoteResult<HsStock> getHsOwnStockById(long stockId) {
        return hsStockApiService.getHsOwnStockById(stockId);
    }

    @Override
    public RemoteResult<PageModel2<HsStock>> getHsOwnStockPage(PageQuery pageQuery, Map map) {
        return hsStockApiService.getHsOwnStockPage(pageQuery,map);
    }
}
