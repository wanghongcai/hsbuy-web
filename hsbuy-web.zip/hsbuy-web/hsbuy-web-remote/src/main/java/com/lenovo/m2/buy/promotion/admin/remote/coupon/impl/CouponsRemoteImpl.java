package com.lenovo.m2.buy.promotion.admin.remote.coupon.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.coupon.CouponsRemote;
import com.lenovo.m2.couponV2.api.model.CouponsApi;
import com.lenovo.m2.couponV2.api.service.CouponsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Created by zhaocl1 on 2016/3/11.
 */
@Component("couponsRemote")
public class CouponsRemoteImpl implements CouponsRemote {

    @Autowired
    private CouponsService couponsService;

    @Override
    public RemoteResult<PageModel2<CouponsApi>> getCouponsInfoPage(PageQuery pageQuery, Map map) {
        return couponsService.getCouponsInfoPage(pageQuery,map);
    }

    @Override
    public RemoteResult<PageModel2<CouponsApi>> getExportCouponsInfoPage(PageQuery pageQuery, Map map) {
        return couponsService.getExportCouponsInfoPage(pageQuery,map);
    }

    @Override
    public RemoteResult getCouponsBySalescouponsId(long salescouponid) {
        return couponsService.getCouponsBySalescouponsId(salescouponid);
    }

    @Override
    public RemoteResult getCouponsBySalescouponsIdIsAppend(long salescouponid) {
        return couponsService.getCouponsBySalescouponsIdAndBatchNO(salescouponid);
    }

    @Override
    public RemoteResult<Boolean> toIncreaseCodes(long couponId, int count, String operator) {
        return couponsService.toIncreaseCodes(couponId,count,operator);
    }

    @Override
    public RemoteResult<CouponsApi> getTrueMacode(Long id,String itCode) {
        return couponsService.getTrueMacode(id,itCode);
    }
}
