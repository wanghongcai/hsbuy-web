package com.lenovo.m2.buy.promotion.admin.remote.coupon;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.CouponsApi;

import java.util.Map;

/**
 * Created by zhaocl1 on 2016/3/11.
 */
public interface CouponsRemote {
    /**
     * 获取优惠码列表
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<CouponsApi>> getCouponsInfoPage(PageQuery pageQuery, Map map);

    /**
     *获取导出export优惠码
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<CouponsApi>> getExportCouponsInfoPage(PageQuery pageQuery, Map map);

    /**
     * 根据批次主键查询优惠码
     * @param salescouponid
     * @return
     */
    public RemoteResult getCouponsBySalescouponsId(long salescouponid);

    /**
     * 根据批次主键查询追加的优惠码
     * @param salescouponid
     * @return
     */
    RemoteResult getCouponsBySalescouponsIdIsAppend(long salescouponid);

    /**
     * 追加优惠码数量
     * @param couponId 主表ID
     * @param count 追加的数量
     * @param operator 操作人
     * @return
     */
    RemoteResult<Boolean> toIncreaseCodes(long couponId, int count, String operator);

    /**
     * 获取真实的macode
     * @param id
     * @return
     */
    public RemoteResult<CouponsApi> getTrueMacode(Long id, String itCode);
}
