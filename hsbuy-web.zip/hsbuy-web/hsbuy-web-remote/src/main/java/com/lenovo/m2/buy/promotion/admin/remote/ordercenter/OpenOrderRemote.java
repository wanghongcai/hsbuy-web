package com.lenovo.m2.buy.promotion.admin.remote.ordercenter;

import com.lenovo.m2.arch.framework.domain.*;
import com.lenovo.m2.hsbuy.domain.inventory.HsStock;
import com.lenovo.m2.hsbuy.domain.order.OrderMain;
import com.lenovo.m2.hsbuy.domain.order.logistics.OpenPlatRequestForMsg;
import com.lenovo.m2.hsbuy.domain.order.logistics.RemoteLogistic;
import com.lenovo.m2.hsbuy.domain.order.logistics.SmbRequest;
import com.lenovo.m2.hsbuy.domain.order.logistics.TaskRequest;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderItem;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderMain;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.domain.order.mongo.PayRecords;
import com.lenovo.m2.hsbuy.domain.ordercenter.*;
import com.lenovo.m2.hsbuy.domain.throwengine.OrderItemHSVo;

import java.util.List;
import java.util.Map;

/**
 * Created by jh on 2016/9/9.
 */
public interface OpenOrderRemote {

    /**
     * 获取订单列表
     *
     * @param plat
     * @param pageQuery
     * @return
     */
    public RemoteResult<PageModel2<MongoOrderDetail>> getAllMongoOrderList(int plat, Map map, PageQuery pageQuery);

    /**
     * 获取mongodb详情
     *
     * @param tenant
     * @param orderCode
     * @return
     */
    RemoteResult<MongoOrderDetail> getMongoOrderDetail(Tenant tenant, String orderCode);

    /**
     * 获取惠商待审核订单（分页）
     *
     * @param pageQuery
     * @param filterMap
     * @param tenant
     * @return
     */
    RemoteResult<PageModel2<MongoOrderDetail>> getMongoOrderList(PageQuery pageQuery, Map<String, Object> filterMap, Tenant tenant);

    /**
     * 组装惠商审单详情页数据
     *
     * @param map    key：orderId
     * @param tenant
     * @return
     */
    RemoteResult<AuditOrderDetailResult> getMongoOrderDetail(Map<String, Object> map, Tenant tenant);

    RemoteResult auditOrderDetail(AuditOrderDetailRequest request, Tenant tenant);

    /**
     * 取消订单，供用户主动取消、扫单取消、订单后台管理业务人员取消使用
     *
     * @param orderCode
     * @param orderCode
     * @param type      取消类型
     * @return
     */
    RemoteResult cancelOrder(long orderCode, int type, Tenant tenant);


    RemoteResult saveItemsWareHouse(List<OrderItemHSVo> list);

    RemoteResult saveItemsWareHouseAndThrowOrder(OrderItemHSVo orderItem);

    RemoteResult getOrderItemsByOrderId(Long orderId);

    RemoteResult<PageModel2<PayRecords>> queryDownlinePayList(DownlinePayListParam downlinePayParam);

    /**
     * 惠商线下打款支付凭证上传
     *
     * @param payRecords
     * @return
     */
    RemoteResult savePayRecords(PayRecords payRecords);

    /**
     * 线下银行转账记录详情
     *
     * @param payId
     * @param tenant
     * @return
     */
    RemoteResult<PayRecordsDetailResult> payRecordsDetail(String payId, Tenant tenant);

    /**
     * 审核付款支付记录
     *
     * @param payRecords
     * @param tenant
     * @return
     */
    RemoteResult auditPaymentPayRecords(PayRecords payRecords, Tenant tenant);


    /**
     * 计算订单总价和应付金额等
     *
     * @param mOrderItemList
     * @return
     */
    RemoteResult<Map<String, Money>> calculateOrderPrices(MOrderMain mOrderMai, List<MOrderItem> mOrderItemList, Tenant tenant);

    /**
     * 获取库存地信息
     *
     * @param materialCode
     * @param faid
     * @param deatLike
     * @return
     */
    RemoteResult<List<HsStock>> getHsStocksByPcode(String materialCode, String faid, String deatLike);


    /**
     * 更新订单状态
     *
     * @param request
     * @param from
     * @return
     */
    RemoteResult syncOrderStatus(OrderStatusRequest request, int from);

    /**
     * 订单物流号推送
     *
     * @param smbRequest
     * @return
     */
    RemoteResult updateLogisticsCode(SmbRequest smbRequest);

    /**
     * 订单物流轨迹推送
     *
     * @param openPlatRequestForMsg
     * @return
     */
    RemoteResult updateLogisticsMessage(OpenPlatRequestForMsg openPlatRequestForMsg);

    RemoteResult<List<LogisticsPlatform>> getLogiInfo();


    /**
     * 根据订单号和物流单号获取物流轨迹
     *
     * @param orderCode
     * @param logisticsNo
     * @return
     */
    RemoteResult<List<OrderLogistics>> getLogisticTrack(String orderCode, String logisticsNo);
    /**
     * 获取物流与订单的关系
     *
     * @param orderCode
     * @return
     */
    RemoteResult<List<OrderLogistics>> getOrderLogisticsByOrderCenter(String orderCode);

    /**
     * 确认签收
     *
     * @param orderId
     * @param lenovoId
     * @param tenant
     * @return
     */
    RemoteResult updateOrderConfirm(String orderId, String lenovoId, Tenant tenant);

    RemoteResult<OrderMain> getOrderByOrderCode(String orderCode);



    /**
     * 直营、非直营发货接口
     *
     * @param remoteLogistic
     * @param oper           indirect、direct
     * @return
     */
    RemoteResult logisticsDelivery(RemoteLogistic remoteLogistic, String oper);


    /**
     * 惠商订单对账列表
     * @param pageQuery
     * @param map
     * @param tenant
     * @return
     */
    RemoteResult<PageModel2<OpenHSOrderReconciliationInfo>> getOpenHSReconciliationList(PageQuery pageQuery, Map<String, Object> map, Tenant tenant);

    /**
     * 惠商订单报表 查询分页
     * @param pageQuery
     * @param map
     * @param tenant
     * @return
     */

    RemoteResult<PageModel2<HSReportVo>> getOpenHSOrderReportList(PageQuery pageQuery,Map<String,Object> map,Tenant tenant);

    RemoteResult bogusPay(String orderCode) ;

    /**
     * 订阅kuaidi100
     * @param taskRequest
     * @return
     */
    public RemoteResult poll(TaskRequest taskRequest);

    /**
     * kuaidi100回调
     * @param param
     * @return
     */
    public RemoteResult callback(String param);

    /**
     * 分页查询CPS订单
     * @param cid
     * @param orderStartTime
     * @param orderEndTime
     * @return
     */
    public RemoteResult<Map<String,Object>> getCpsOrderInfoByPage(String cid, String orderNo, String orderStartTime, String orderEndTime,PageQuery pageQuery);

    /**
     * 提供业务导出CPS订单数据接口
     * @param cid
     * @param orderStartTime
     * @param orderEndTime
     * @return
     */
    public String exportOrderToExcel(String cid, String orderNo, String orderStartTime, String orderEndTime);
}