package com.lenovo.m2.buy.promotion.admin.remote.pay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayMailApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayMailAddress;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayMailInfo;
import com.lenovo.m2.hsbuy.service.pay.soa.PayMailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by mengqiang1 on 2016/3/24.
 */
@Service
public class PayMailApiImpl implements PayMailApi {

    @Autowired
    @Qualifier(value = "payMailService")
    private PayMailService payMailService;

    @Override
    public void sendRefundMail(PayMailInfo payMailInfo) {
        this.payMailService.sendMail(payMailInfo);
    }

    @Override
    public RemoteResult<List<PayMailAddress>> queryPayMailAddressList(String mailType) {
        return this.payMailService.queryPayMailAddressList(mailType);
    }

    public PayMailService getPayMailService() {
        return payMailService;
    }

    public void setPayMailService(PayMailService payMailService) {
        this.payMailService = payMailService;
    }

}
