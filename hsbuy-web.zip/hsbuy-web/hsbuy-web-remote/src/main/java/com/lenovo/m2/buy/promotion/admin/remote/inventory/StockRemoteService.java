package com.lenovo.m2.buy.promotion.admin.remote.inventory;

import com.lenovo.fis.model.FaBaseInfoes;
import com.lenovo.fis.model.GoodsMaterials;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.inventory.*;


import java.util.List;
import java.util.Map;

/**
 * Created by Jiazy on 15-6-19.
 * Add by yezhenyue on 2015/8/17.
 */
public interface StockRemoteService {


    List<GetStockInfoResult> getStockInfo(List<GetStockInfoParam> params,Tenant tenant);
    /**
     * 库存分页
     * @return
     */
    public RemoteResult<PageModel2<StockInfo>> getStockInfoPage(PageQuery pageQuery, Map map);


    /**
     * 活动库存分页
     * @return
     */
    public RemoteResult<PageModel2<StockInfo>> getActiveStockInfoPage(PageQuery pageQuery, Map map);


    public List<FaBaseInfo> getFaNameList();

    public RemoteResult<FaBaseInfo> getFaBaseInfoById(String faid);


    public GoodsMaterials getGoodInfo(String materialId);

    /**
     * 根据物料号和bu权限查询物料信息
     * @param materialNumber
     * @param buOwners
     * @return
     */
    public List<Map> getGoodInfoByBu(String materialNumber, List<String> buOwners);
    /**
     * 根据商品编码获取商品信息
     * @param productCode
     * @return
     */
    public List<Map> getProductsInfo(String productCode, String goodsCode, List<String> shopids, List<String> faIds);

    /**
     * 根据商品编码获取商品信息
     * @param productCode
     * @return
     */
    public List<Map> getProductsInfoByMaterialNumber(String productCode, List<String> shopids);


    /**
     * 获取fa列表
     * @return
     */
    public List<FaBaseInfoes> getFaList();

    /**
     * 创建库存
     * @param stockInfo
     * @return
     */
    public RemoteResult addStockInfo(StockInfo stockInfo, int type);/**


    /**
     * 通过 id 查找库存信息
     * @param stockInfo
     * @return
     */
    public RemoteResult<StockInfo> getStockInfoById(long stockInfo);




    /**
     * 修改 活动库存信息
     * @param param
     * @return
     */
    public RemoteResult updateActivityStock(StockInfoParam param, String operator);

    public RemoteResult addActivityStock(StockInfoParam param, String operator);

    //修改在线\mbg库存
    RemoteResult updateStockInfo(StockInfoParam param, String operator);



    /**
     * 获取库存订单分页信息
     * @return
     */
    public RemoteResult<PageModel2<OrderAndStock>> getOrderInfoPage(PageQuery pageQuery, Map map);


    /**
     * 分页查询库存日志信息
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<StockInfoLog>> getStockInfoLogPage(PageQuery pageQuery, Map map);


    public RemoteResult<List<StockInfo>> getStockInfoList(Map map);

    /**
     * 批量删除
     * @param list
     * @return
     */
    public int deleteByBatch(List<StockInfo> list);


    public List<StockInfo> checkStockExist(StockInfo stockInfo);

}
