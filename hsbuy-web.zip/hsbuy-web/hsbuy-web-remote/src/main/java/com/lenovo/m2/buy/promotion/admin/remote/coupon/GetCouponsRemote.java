package com.lenovo.m2.buy.promotion.admin.remote.coupon;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.AvailableSalescouponsApi;

import java.util.List;

/**
 * Created by fenglg1 on 2016/12/13.
 */
public interface GetCouponsRemote {

    /**
     * 保存选中的优惠券
     * @param salescouponsApiList
     * @return
     */
    public RemoteResult saveSelectedSalescoupons(List<AvailableSalescouponsApi> salescouponsApiList, Integer displayPosition);

    /**
     * 根据优惠券ID，将优惠券从可领取列表中删除
     * @param operator
     * @param couponId
     * @return
     */
    public RemoteResult deleteAvailableSalescoupons(String operator, String couponId, String displayPosition);

    /**
     * 清空可领取优惠券列表
     * @return
     */
    public RemoteResult deleteAllAvailableSalescoupons(String operator);
}
