package com.lenovo.m2.buy.promotion.admin.remote.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayPointRules;

/**
 * Created by jh on 2017/8/10.
 */
public interface PayPointRulesApi {

    RemoteResult<PayPointRules> getPayPointRulesByfaId(String faId);
}
