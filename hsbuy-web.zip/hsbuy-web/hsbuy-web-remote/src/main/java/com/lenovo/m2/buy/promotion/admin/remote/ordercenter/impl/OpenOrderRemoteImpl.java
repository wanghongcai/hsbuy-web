package com.lenovo.m2.buy.promotion.admin.remote.ordercenter.impl;

import com.lenovo.m2.arch.framework.domain.*;
import com.lenovo.m2.buy.promotion.admin.remote.ordercenter.OpenOrderRemote;
import com.lenovo.m2.hsbuy.common.middleware.RemoteResultFactory;
import com.lenovo.m2.hsbuy.common.middleware.ResultMessageEnum;
import com.lenovo.m2.hsbuy.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.domain.inventory.HsStock;
import com.lenovo.m2.hsbuy.domain.order.OrderItem;
import com.lenovo.m2.hsbuy.domain.order.OrderMain;
import com.lenovo.m2.hsbuy.domain.order.logistics.OpenPlatRequestForMsg;
import com.lenovo.m2.hsbuy.domain.order.logistics.RemoteLogistic;
import com.lenovo.m2.hsbuy.domain.order.logistics.SmbRequest;
import com.lenovo.m2.hsbuy.domain.order.logistics.TaskRequest;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderItem;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderMain;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.domain.order.mongo.PayRecords;
import com.lenovo.m2.hsbuy.domain.ordercenter.*;
import com.lenovo.m2.hsbuy.domain.throwengine.OrderItemHSVo;
import com.lenovo.m2.hsbuy.inventory.HsStockApiService;
import com.lenovo.m2.hsbuy.logistics.LogisticApiService;
import com.lenovo.m2.hsbuy.logistics.SmbLogisticsService;
import com.lenovo.m2.hsbuy.middleware.OrderMiddlewareService;
import com.lenovo.m2.hsbuy.ordercenter.OpenOrderService;
import com.lenovo.m2.hsbuy.purchase.NorderService;
import com.lenovo.m2.hsbuy.throwengine.HsOrderService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created by jh on 2016/9/9.
 */
@Component
public class OpenOrderRemoteImpl implements OpenOrderRemote {
    private static Logger LOGGER = Logger.getLogger(OpenOrderRemoteImpl.class);
    @Autowired
    private OpenOrderService orderOpenService;
    @Autowired
    private OrderMiddlewareService orderMiddlewareService;
    @Autowired
    private HsOrderService hsOrderService;
    @Autowired
    private HsStockApiService hsStockApiService;
    @Autowired
    private SmbLogisticsService smbLogisticsService;
    @Autowired
    private LogisticApiService logisticApiService;
    @Autowired
    private NorderService norderService;


    /**
     * 获取订单列表
     *
     * @param plat
     * @param map
     * @param pageQuery @return
     */
    @Override
    public RemoteResult<PageModel2<MongoOrderDetail>> getAllMongoOrderList(int plat, Map map, PageQuery pageQuery) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = orderOpenService.getAllMongoOrderList(plat, map, pageQuery);
            LOGGER.info("OpenOrderRemote getAllMongoOrderList=" + remoteResult);
            return remoteResult;
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getMongoOrderList error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa服务异常");
            return remoteResult;
        }
    }

    /**
     * 获取mongodb详情
     *
     * @param tenant
     * @param orderCode
     * @return
     */
    @Override
    public RemoteResult<MongoOrderDetail> getMongoOrderDetail(Tenant tenant, String orderCode) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = orderOpenService.getMongoOrderDetail(tenant, orderCode);
            return remoteResult;
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getMongoOrderList error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa服务异常");
            return remoteResult;
        }
    }

    @Override
    public RemoteResult<PageModel2<MongoOrderDetail>> getMongoOrderList(PageQuery pageQuery, Map<String, Object> filterMap, Tenant tenant) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = orderOpenService.getMongoOrderList(pageQuery, filterMap, tenant);
            return remoteResult;
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getMongoOrderList error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa服务异常");
            return remoteResult;
        }
    }

    @Override
    public RemoteResult<AuditOrderDetailResult> getMongoOrderDetail(Map<String, Object> map, Tenant tenant) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = orderOpenService.getMongoOrderDetail(map, tenant);
            return remoteResult;
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getMongoOrderDetail error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa服务异常");
            return remoteResult;
        }
    }

    @Override
    public RemoteResult auditOrderDetail(AuditOrderDetailRequest request, Tenant tenant) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = orderMiddlewareService.auditHsOrder(request.getOrder(), request.isPass(), tenant);
            return remoteResult;
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getMongoOrderDetail error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用中间件服务异常");
            return remoteResult;
        }
    }


    @Override
    public RemoteResult cancelOrder(long orderCode, int type, Tenant tenant) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = orderMiddlewareService.cancelOrder(orderCode, type, tenant.getShopId());
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote cancelOrder error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用中间件服务异常");
        }
        return remoteResult;
    }


    @Override
    public RemoteResult<List<OrderItem>> getOrderItemsByOrderId(Long orderId) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = hsOrderService.getOrderItemsByOrderId(orderId);
            return remoteResult;
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getOrderItemsByOrderId error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用getOrderItemsByOrderId服务异常");
            return remoteResult;
        }
    }

    @Override
    public RemoteResult saveItemsWareHouse(List<OrderItemHSVo> list) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            return hsOrderService.saveItemsWareHouse(list);
        } catch(Exception e) {
            remoteResult.setResultMsg("saveItemsWareHouse异常");
            LOGGER.error("saveItemsWareHouse 接口异常");
            return remoteResult;
        }
    }

    @Override
    public RemoteResult saveItemsWareHouseAndThrowOrder(OrderItemHSVo orderItemHSVo) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            hsOrderService.saveItemsWareHouseAndOrder(orderItemHSVo);
            remoteResult.setSuccess(true);
            remoteResult.setResultCode(ResultCode.SUCCESS);
            remoteResult.setResultMsg("正在执行抛单中...请稍候查看");
            return remoteResult;
        } catch(Exception e) {
            remoteResult.setResultMsg("saveItemsWareHouseAndThrowOrder异常");
            LOGGER.error("saveItemsWareHouseAndThrowOrder接口异常");
            return remoteResult;
        }
    }

    @Override
    public RemoteResult<PageModel2<PayRecords>> queryDownlinePayList(DownlinePayListParam downlinePayParam) {
        return orderOpenService.queryDownlinePayList(downlinePayParam);
    }

    /**
     * 惠商线下打款支付凭证上传
     *
     * @param payRecords
     * @return
     */
    @Override
    public RemoteResult savePayRecords(PayRecords payRecords) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            orderOpenService.saveMongoPayRecord(payRecords);
            remoteResult.setSuccess(true);
            remoteResult.setResultCode(ResultCode.SUCCESS);
            return remoteResult;
        } catch(Exception e) {
            remoteResult.setResultMsg("getOpenMongoSavePayRecords异常");
            LOGGER.error("getOpenMongoSavePayRecords接口异常");
            return remoteResult;
        }
    }


    /**
     * 线下银行转账记录详情
     *
     * @param payIdf
     **/
    @Override
    public RemoteResult<PayRecordsDetailResult> payRecordsDetail(String payId, Tenant tenant) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            return orderOpenService.payRecordsDetail(payId, tenant);
        } catch(Exception e) {
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa服务异常,请联系管理员");
            LOGGER.error("payRecordsDetail 调用soa 异常", e);
            return remoteResult;
        }
    }


    /**
     * 审核付款支付记录
     *
     * @param payRecords
     * @param tenant
     * @return
     */
    @Override
    public RemoteResult auditPaymentPayRecords(PayRecords payRecords, Tenant tenant) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            return orderOpenService.auditPaymentPayRecords(payRecords, tenant);
        } catch(Exception e) {
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa服务异常,请联系管理员");
            LOGGER.error("auditPaymentPayRecords 调用soa 异常", e);
            return remoteResult;
        }
    }

    /**
     * 计算订单总价和应付金额等
     *
     * @param mOrderMai
     * @param mOrderItemList
     * @param tenant
     * @return
     */
    @Override
    public RemoteResult<Map<String, Money>> calculateOrderPrices(MOrderMain mOrderMai, List<MOrderItem> mOrderItemList, Tenant tenant) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            return orderMiddlewareService.calculateOrderPrices(mOrderMai, mOrderItemList, tenant);
        } catch(Exception e) {
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa服务异常,请联系管理员");
            LOGGER.error("calculateOrderPrices 调用soa异常", e);
            return remoteResult;
        }
    }

    @Override
    public RemoteResult<List<HsStock>> getHsStocksByPcode(String materialCode, String faid, String deatLike) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = hsStockApiService.getHsStocksByPcode(materialCode, faid, deatLike);
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getHsStocksByPcode error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa异常");
            return remoteResult;
        }
        return remoteResult;
    }

    @Override
    public RemoteResult syncOrderStatus(OrderStatusRequest request, int from) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            ApiBaseResponse apiBaseResponse = orderOpenService.syncOrderStatus(request, from);
            return apiBaseResponse.toRemoteResult();
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getHsStocksByPcode error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa异常");
            return remoteResult;
        }
    }

    /**
     * 订单物流号推送
     *
     * @param smbRequest
     * @return
     */
    @Override
    public RemoteResult updateLogisticsCode(SmbRequest smbRequest) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = smbLogisticsService.updateLogisticsCode(smbRequest);
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getHsStocksByPcode error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa异常");
            return remoteResult;
        }
        return remoteResult;
    }

    /**
     * 订单物流轨迹推送
     *
     * @param openPlatRequestForMsg
     * @return
     */
    @Override
    public RemoteResult updateLogisticsMessage(OpenPlatRequestForMsg openPlatRequestForMsg) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = smbLogisticsService.updateLogisticsMessage(openPlatRequestForMsg);
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getHsStocksByPcode error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa异常");
            return remoteResult;
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<List<LogisticsPlatform>> getLogiInfo() {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = logisticApiService.getLogiInfo();
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getLogiInfo error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa异常");
            return remoteResult;
        }
        return remoteResult;
    }

    /**
     * 根据订单号和物流单号获取物流轨迹
     *
     * @param orderCode
     * @param logisticsNo
     * @return
     */
    @Override
    public RemoteResult<List<OrderLogistics>> getLogisticTrack(String orderCode, String logisticsNo) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = logisticApiService.getLogisticTrack(orderCode, logisticsNo);
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getLogisticTrack error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa异常");
            return remoteResult;
        }
        return remoteResult;
    }

    /**
     * 获取物流与订单的关系
     *
     * @param orderCode
     * @return
     */
    @Override
    public RemoteResult<List<OrderLogistics>> getOrderLogisticsByOrderCenter(String orderCode) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = logisticApiService.getOrderLogisticsByOrderCenter(orderCode);
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getOrderLogisticsByOrderCenter error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa异常");
            return remoteResult;
        }
        return remoteResult;
    }

    /**
     * 确认签收
     *
     * @param orderId
     * @param lenovoId
     * @param tenant
     * @return
     */
    @Override
    public RemoteResult updateOrderConfirm(String orderId, String lenovoId, Tenant tenant) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = orderOpenService.updateOrderConfirm(orderId, lenovoId, tenant);
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote updateOrderConfirm error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa异常");
            return remoteResult;
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<OrderMain> getOrderByOrderCode(String orderCode) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = orderOpenService.getOrderByOrderCode(orderCode);
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote getOrderByOrderCode error:", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("调用soa异常");
            return remoteResult;
        }
        return remoteResult;
    }

    @Override
    public RemoteResult logisticsDelivery(RemoteLogistic remoteLogistic, String oper) {
        try {
            RemoteResult remoteResult = logisticApiService.logisticsDelivery(remoteLogistic, oper);
            if (remoteResult.isSuccess()) {
                remoteResult.setResultMsg("保存成功");
            }
            return remoteResult;
        } catch(Exception e) {
            LOGGER.error(" logisticsDelivery type=" + oper + ", remoteLogistic=" + JsonUtil.toJson(remoteLogistic), e);
            return RemoteResultFactory.getErrorResult(ResultMessageEnum.ERROR, "调用soa异常");
        }
    }


    /**
     * 惠商订单对账列表
     *
     * @param pageQuery
     * @param map
     * @param tenant
     * @return
     */
    @Override
    public RemoteResult<PageModel2<OpenHSOrderReconciliationInfo>> getOpenHSReconciliationList(PageQuery pageQuery, Map<String, Object> map, Tenant tenant) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            return orderOpenService.getOpenHSOrderReconciliationPage(pageQuery, map, tenant);
        } catch(Exception e) {
            remoteResult.setResultMsg("soa异常");
            return remoteResult;
        }
    }

    /**
     * 惠商订单报表 查询分页
     *
     * @param pageQuery
     * @param map
     * @param tenant
     * @return
     */
    @Override
    public RemoteResult<PageModel2<HSReportVo>> getOpenHSOrderReportList(PageQuery pageQuery, Map<String, Object> map, Tenant tenant) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = orderOpenService.getOpenHSOrderReportList(pageQuery, map, tenant);
        } catch(Exception e) {
            remoteResult.setResultMsg("getOpenHSOrderReportList 异常");
            LOGGER.info("getOpenHSOrderReportList 异常" + e.toString());
            return remoteResult;
        }
        return remoteResult;
    }

    @Override
    public RemoteResult bogusPay(String orderCode) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = orderMiddlewareService.bogusPay(orderCode);
        } catch(Exception e) {
            remoteResult.setResultMsg("bogusPay 异常");
            LOGGER.info("bogusPay 异常" + e.toString());
            return remoteResult;
        }
        return remoteResult;
    }

    /**
     * 订阅kuaidi100
     *
     * @param taskRequest
     * @return
     */
    @Override
    public RemoteResult poll(TaskRequest taskRequest) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = logisticApiService.poll(taskRequest);
        } catch(Exception e) {
            remoteResult.setResultMsg("poll 异常");
            LOGGER.info("callback 异常" + e.toString());
            return remoteResult;
        }
        return remoteResult;
    }

    /**
     * kuaidi100回调
     *
     * @param param
     * @return
     */
    @Override
    public RemoteResult callback(String param) {
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            remoteResult = logisticApiService.callback(param);
        } catch(Exception e) {
            remoteResult.setResultMsg("callback 异常");
            LOGGER.info("callback 异常" + e.toString());
            return remoteResult;
        }
        return remoteResult;
    }


    public RemoteResult<Map<String,Object>> getCpsOrderInfoByPage(String cid, String orderNo, String orderStartTime, String orderEndTime,PageQuery pageQuery){
        return norderService.getCpsOrderByOrderParams(cid,orderNo,orderStartTime,orderEndTime,pageQuery);
    }

    public String exportOrderToExcel(String cid,String orderNo, String orderStartTime, String orderEndTime){
        return norderService.getImportOrderByOrderParams(cid,orderNo,orderStartTime,orderEndTime);
    }
}
