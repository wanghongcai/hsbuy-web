package com.lenovo.m2.buy.promotion.admin.remote.inventory.impl;

import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import com.lenovo.b2c.goods.api.NewGoodsService;
import com.lenovo.common.base.PageMap;
import com.lenovo.fis.model.FaBaseInfoes;
import com.lenovo.fis.model.GoodsMaterials;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;

import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.remote.inventory.StockRemoteService;
import com.lenovo.m2.hsbuy.domain.inventory.*;
import com.lenovo.m2.hsbuy.inventory.StockAdminApiService;
import com.lenovo.m2.hsbuy.inventory.StockFrontApiService;
import com.lenovo.m2.hsbuy.inventory.StockPortApiService;
import com.lenovo.shop.admin.api.FaBaseInfoesService;
import com.lenovo.shop.goods.api.GoodsMaterialsService;
import com.lenovo.shop.goods.api.ProductInfoesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service("stockRemoteService")
public class StockRemoteServiceImpl implements StockRemoteService {
    private static final Logger LOGGER = LoggerFactory.getLogger(StockRemoteServiceImpl.class);
    @Autowired
    private StockAdminApiService stockAdminApiService;
    @Autowired
    private NewGoodsService newGoodsService;
    @Autowired
    private GoodsMaterialsService goodsMaterialsService;
    @Autowired
    private FaBaseInfoesService faBaseInfoesService;
    @Autowired
    private ProductInfoesService productInfoesService;
    @Autowired
    private StockPortApiService stockPortApiService;


    @Override
    public RemoteResult<PageModel2<StockInfo>> getStockInfoPage(PageQuery pageQuery, Map map) {
        RemoteResult<PageModel2<StockInfo>> page = stockAdminApiService.getStockInfoPage(pageQuery, map);
        return page;
    }


    @Override
    public RemoteResult<PageModel2<StockInfo>> getActiveStockInfoPage(PageQuery pageQuery, Map map) {
        RemoteResult<PageModel2<StockInfo>> page = stockAdminApiService.getActiveStockInfoPage(pageQuery, map);
        return page;
    }

    @Override
    public List<FaBaseInfo> getFaNameList() {
        List<FaBaseInfoes> infoesList = faBaseInfoesService.queryAll();
        List<FaBaseInfo> baseInfoList = new ArrayList<FaBaseInfo>();
        for (FaBaseInfoes infoes : infoesList) {
            FaBaseInfo faBaseInfo = new FaBaseInfo();
            faBaseInfo.setName(infoes.getFaName());
            faBaseInfo.setType(infoes.getFaType());
            faBaseInfo.setId(infoes.getId());
            baseInfoList.add(faBaseInfo);
        }
        return baseInfoList;
    }

    @Override
    public RemoteResult<FaBaseInfo> getFaBaseInfoById(String faid) {
        return stockAdminApiService.getFaBaseInfoById(faid);
    }

    @Override
    public GoodsMaterials getGoodInfo(String materialId) {
        return goodsMaterialsService.getMaterialByNumber(materialId);
    }

    @Override
    public List<Map> getGoodInfoByBu(String materialNumber, List<String> buOwners) {
        String bus;
        if (buOwners == null || buOwners.size() == 0) {
            return null;
        }
        StringBuilder builder = new StringBuilder();
        for (String bu : buOwners) {
            builder.append(bu);
            builder.append(",");
        }
        builder.deleteCharAt(builder.length() - 1);
        bus = builder.toString();
        Map mapParam = Maps.newHashMap();
        mapParam.put("buOwner", bus);
        PageMap pageMap = new PageMap();
        pageMap.setSelectParams(mapParam);
        PageMap pageMapResult = productInfoesService.selectProductInfoes(null, null, materialNumber, pageMap);
        if (pageMapResult != null && (pageMapResult.getPageList() != null && pageMapResult.getPageList().size() > 0)) {
            return (List<Map>) pageMapResult.getPageList();
        }
        return null;
    }


    @Override
    public List<Map> getProductsInfo(String productCode, String goodsCode, List<String> shopids, List<String> faIds) {
        Map mapParam = Maps.newHashMap();
        if (!Strings.isNullOrEmpty(productCode)) mapParam.put("code", productCode);
        if (!Strings.isNullOrEmpty(goodsCode)) mapParam.put("materialNumber", goodsCode);
        if (shopids != null) mapParam.put("mallTypes", shopids);
        if (faIds != null) mapParam.put("faIds", faIds);
        PageMap pageMap = new PageMap();
        pageMap.setSelectParams(mapParam);

        PageMap pageMapResult = newGoodsService.pageQuery(pageMap);
        if (pageMapResult != null && (pageMapResult.getPageList() != null && pageMapResult.getPageList().size() > 0)) {
            return (List<Map>) pageMapResult.getPageList();
        }
        return null;
    }

    @Override
    public List<Map> getProductsInfoByMaterialNumber(String materialNumber, List<String> shopids) {
        Map mapParam = Maps.newHashMap();
        mapParam.put("materialNumber", materialNumber);
        if (shopids != null) mapParam.put("mallTypes", shopids);
        PageMap pageMap = new PageMap();
        pageMap.setSelectParams(mapParam);

        PageMap pageMapResult = newGoodsService.pageQuery(pageMap);
        if (pageMapResult != null && (pageMapResult.getPageList() != null && pageMapResult.getPageList().size() > 0)) {
            return (List<Map>) pageMapResult.getPageList();
        }
        return null;
    }

    @Override
    public List<FaBaseInfoes> getFaList() {
        return faBaseInfoesService.queryAll();
    }

    @Override
    public RemoteResult addStockInfo(StockInfo stockInfo, int type) {
        return stockAdminApiService.addStockInfo(stockInfo, type);
    }


    @Override
    public RemoteResult<StockInfo> getStockInfoById(long stockInfo) {
        return stockAdminApiService.getStockInfoById(stockInfo);
    }

    @Override
    public RemoteResult updateActivityStock(StockInfoParam param, String operator) {
        return stockAdminApiService.operateActivityStock(param, operator);
    }

    @Override
    public RemoteResult addActivityStock(StockInfoParam param, String operator) {
        return stockAdminApiService.addActivityStock(param, operator);
    }

    @Override
    public RemoteResult updateStockInfo(StockInfoParam param, String operator) {
        return stockAdminApiService.updateStockInfo(param, operator);
    }


    @Override
    public RemoteResult<PageModel2<OrderAndStock>> getOrderInfoPage(PageQuery pageQuery, Map map) {
        RemoteResult<PageModel2<OrderAndStock>> page = stockAdminApiService.getOrderInfoPage(pageQuery, map);
        return page;
    }


    @Override
    public RemoteResult<PageModel2<StockInfoLog>> getStockInfoLogPage(PageQuery pageQuery, Map map) {
        RemoteResult<PageModel2<StockInfoLog>> page = stockAdminApiService.getStockInfoLogPage(pageQuery, map);
        return page;
    }


    @Override
    public RemoteResult<List<StockInfo>> getStockInfoList(Map map) {
        return stockAdminApiService.getStockInfoList(map);
    }

    @Override
    public int deleteByBatch(List<StockInfo> list) {
        return stockAdminApiService.deleteByBatch(list);
    }


    @Override
    public List<StockInfo> checkStockExist(StockInfo stockInfo) {
        return stockAdminApiService.checkStockExist(stockInfo);
    }

    @Override
    public List<GetStockInfoResult> getStockInfo(List<GetStockInfoParam> params,Tenant tenant) {
        List<GetStockInfoResult> list=null;
        try {
            RemoteResult remoteResult =stockPortApiService.getGlobalStockInfo(params, tenant);
            if(remoteResult.isSuccess()){
                Object object=remoteResult.getT();
                if(object!=null){
                    list=(List<GetStockInfoResult>)object;
                }
            }
        }catch (Exception e){
            LOGGER.error(e.getMessage(),e);
        }
        return list;
    }
}
