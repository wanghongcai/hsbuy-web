package com.lenovo.m2.buy.promotion.admin.remote.pay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.pay.MerchantPayPlatApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.service.pay.soa.MerchantPayPlatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * Created by yangjj7 on 2015/5/2.
 */
@Service
public class MerchantPayPlatApiImpl implements MerchantPayPlatApi {

    @Autowired
    @Qualifier(value = "merchantPayPlatService")
    private MerchantPayPlatService merchantPayPlatService;

    @Override
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatByMerchantId(String s, int i) {
        RemoteResult<MerchantPayPlatView> viewRemoteResult = merchantPayPlatService.getMerchantPayPlatByMerchantId(s,i);
        return viewRemoteResult;
    }

    @Override
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatById(long merchantId) {
        RemoteResult<MerchantPayPlatView> viewRemoteResult = merchantPayPlatService.getMerchantPayPlatById(merchantId);
        return viewRemoteResult;

    }

    @Override
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatByMerchId(String merchId) {
        return merchantPayPlatService.getMerchantPayPlatByMerchId(merchId);
    }

    @Override
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatByAccountType(String faId, int payType, Integer accountType) {
        return merchantPayPlatService.getMerchantPayPlatByAccountType(faId,payType,accountType);
    }


    public MerchantPayPlatService getMerchantPayPlatService() {
        return merchantPayPlatService;
    }

    public void setMerchantPayPlatService(MerchantPayPlatService merchantPayPlatService) {
        this.merchantPayPlatService = merchantPayPlatService;
    }
}
