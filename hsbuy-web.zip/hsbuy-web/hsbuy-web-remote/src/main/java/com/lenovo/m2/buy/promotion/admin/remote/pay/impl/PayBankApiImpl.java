package com.lenovo.m2.buy.promotion.admin.remote.pay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayBankApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.PayBank;
import com.lenovo.m2.hsbuy.service.pay.soa.PayBankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by tianchuyang on 2017/1/17.
 */
@Service
public class PayBankApiImpl implements PayBankApi {

    @Autowired
    @Qualifier(value = "payBankService")
    private PayBankService payBankService;

    @Override
    public RemoteResult<List<PayBank>> queryAllPayBanks() {
        return payBankService.queryAllPayBanks();
    }

    @Override
    public RemoteResult<PayBank> queryPayBankByParams(PayBank payBank) {
        return payBankService.queryPayBanksByParams(payBank);
    }

    public PayBankService getPayBankService() {
        return payBankService;
    }

    public void setPayBankService(PayBankService payBankService) {
        this.payBankService = payBankService;
    }
}
