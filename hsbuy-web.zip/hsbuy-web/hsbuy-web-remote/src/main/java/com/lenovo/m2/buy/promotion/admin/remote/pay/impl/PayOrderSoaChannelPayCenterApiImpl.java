package com.lenovo.m2.buy.promotion.admin.remote.pay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderSoaChannelPayCenterApi;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.baseInfo.PayAccountVo;
import com.lenovo.m2.hsbuy.service.pay.ordersoa.ChannelPayCenterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * Created by MengQiang on 2016/10/17.
 */
@Service
public class PayOrderSoaChannelPayCenterApiImpl implements PayOrderSoaChannelPayCenterApi {

    @Autowired
    @Qualifier(value = "channelPayCenterService")
    private ChannelPayCenterService payOrderSoaChannelPayCenterService;

    @Override
    public RemoteResult<String> updateChannelOrderPayStatus(Tenant tenant, String outTradeNo, String lenovoId, PayAccountVo payAccountVo, String orderType, boolean isOutMerchant) {
        return payOrderSoaChannelPayCenterService.updateChannelOrderPayStatus(tenant, outTradeNo, lenovoId,payAccountVo,orderType,isOutMerchant);
    }

    public ChannelPayCenterService getPayOrderSoaChannelPayCenterService() {
        return payOrderSoaChannelPayCenterService;
    }

    public void setPayOrderSoaChannelPayCenterService(ChannelPayCenterService payOrderSoaChannelPayCenterService) {
        this.payOrderSoaChannelPayCenterService = payOrderSoaChannelPayCenterService;
    }

}