package com.lenovo.m2.buy.promotion.admin.remote.pay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.remote.pay.CancelOrderApi;
import com.lenovo.m2.hsbuy.service.pay.soa.CancelOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * Created by mengqiang1 on 2016/8/1.
 */
@Service
public class CancelOrderApiImpl implements CancelOrderApi {

    @Autowired
    @Qualifier(value = "cancelOrderService")
    private CancelOrderService cancelOrderService;

    @Override
    public RemoteResult<String> orderCancel(String orderCode, Tenant tenant, String lenovoId) {
        return cancelOrderService.orderCancel(orderCode, tenant, lenovoId);
    }

    public CancelOrderService getCancelOrderService() {
        return cancelOrderService;
    }

    public void setCancelOrderService(CancelOrderService cancelOrderService) {
        this.cancelOrderService = cancelOrderService;
    }


}
