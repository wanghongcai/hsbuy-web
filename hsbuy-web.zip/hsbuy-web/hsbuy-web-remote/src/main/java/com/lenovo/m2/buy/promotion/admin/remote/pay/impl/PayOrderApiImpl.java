package com.lenovo.m2.buy.promotion.admin.remote.pay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.PayOrderView;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import com.lenovo.m2.hsbuy.service.pay.soa.PayOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by caoxd2 on 2015/5/1.
 */
@Service
public class PayOrderApiImpl implements PayOrderApi {


    @Autowired
    @Qualifier(value = "payOrderService")
    private PayOrderService payOrderService;


    @Override
    public RemoteResult<String> savePayOrder(PayOrderView payOrder) {
        RemoteResult<String> remoteResult = null;
        String isSuccess = "";
        int tryNumber = 0;
        while (isSuccess.equals("") && tryNumber < 3){
            remoteResult = payOrderService.savePayOrder(payOrder);
            isSuccess = remoteResult.getT();
            tryNumber++;
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<Boolean> updateOrderPayState(String orderCode, String wxPayCode, String userId, int merchtFlag, int tradeState, int payType) {
        RemoteResult<Boolean> remoteResult = null;
        boolean isSuccess = false;
        int tryNumber = 0;
        while (!isSuccess && tryNumber < 3){
            remoteResult = payOrderService.updateOrderPayState(orderCode,wxPayCode, userId,merchtFlag, tradeState,payType);
            isSuccess = remoteResult.getT();
            tryNumber++;
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<Boolean> updateMerchantNotifyState(String orderCode, String userId, String transactionId, int merchantFlag) {
        RemoteResult<Boolean> remoteResult = null;
        boolean isSuccess = false;
        int tryNumber = 0;
        while (!isSuccess && tryNumber < 3){
            remoteResult = payOrderService.updateMerchantNotifyState(orderCode, userId, transactionId, merchantFlag);
            isSuccess = remoteResult.getT();
            tryNumber++;
        }
        return remoteResult;
    }
    @Override
    public RemoteResult<Boolean> updateAliPayNotifyState(String orderCode, String userId, String transactionId, int merchantFlag, String notifyId, int tradeState, String bankSeqNo, int payType) {
        RemoteResult<Boolean> remoteResult = null;
        boolean isSuccess = false;
        int tryNumber = 0;
        while (!isSuccess && tryNumber < 3){
            remoteResult = payOrderService.updateAliPayNotifyState(orderCode, userId, transactionId, merchantFlag, notifyId, tradeState, bankSeqNo, payType);
            isSuccess = remoteResult.getT();
            tryNumber++;
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<Boolean> updateAliIphonePayNotifyState(String orderCode, String transactionId, int merchantFlag, String notifyId, int tradeState, String bankSeqNo, int payType) {
        RemoteResult<Boolean> remoteResult = null;
        boolean isSuccess = false;
        int tryNumber = 0;
        while (!isSuccess && tryNumber < 3){
            remoteResult = payOrderService.updateAliIphonePayNotifyState(orderCode, transactionId, merchantFlag, notifyId, tradeState, bankSeqNo,payType);
            isSuccess = remoteResult.getT();
            tryNumber++;
        }
        return remoteResult;
    }




    @Override
    public RemoteResult<PayOrderView> queryPayOrderDetail(String orderCode, String userId, String payCode) {
        RemoteResult<PayOrderView> remoteResult = null;
        boolean isSuccess = false;
        int tryNumber = 0;
        while (!isSuccess && tryNumber < 3){
            remoteResult = payOrderService.queryPayOrderDetail(orderCode, userId, payCode);
            isSuccess = remoteResult.getResultCode().equals("success");
            tryNumber++;
        }
        return remoteResult;
    }

    @Override
    public int getPayOrderByOutTradeNo(String orderCode){

      return  payOrderService.getPayOrderByOutTradeNo(orderCode);

    }

    @Override
    public Integer getOrderStatus(String orderCode, String userId) {

        Integer status = payOrderService.getOrderStatus(orderCode,userId);
//        System.out.println("status service"+status);

        return  status;
    }

    @Override
    public PayOrder getTwoStatus(String key_id) {
        return payOrderService.getTwoStatus(key_id);
    }

    @Override
    public PayOrder getPayOrderById(String orderCode) {
        return payOrderService.getPayOrderById(orderCode);  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public PayOrder getPayOrderByPrimaryId(long payOrderId) {
        return payOrderService.getPayOrderByPrimaryId(payOrderId);
    }

    @Override
    public Map<String,Map<String,Object>> getRefundInfo(List<String> orders) {
        return payOrderService.getRefundInfo(orders);
    }

    @Override
    public int getStatusByOrderCode(String orderCode) {
        return payOrderService.getStatusByOrderCode(orderCode);
    }

    @Override
    public RemoteResult<List<PayOrder>> getOrderListByOrderCode(String orderCode) {
        return payOrderService.getOrderListByOrderCode(orderCode);
    }

    @Override
    public RemoteResult<List<PayOrder>> getOrderListByPayType(String ordercode, Integer payType) {
        return payOrderService.getOrderListByPayType(ordercode , payType);
    }

    @Override
    public int updatePayBankByID(String keyId, String defaultbank) {
        return this.payOrderService.updatePayBankByID(keyId ,defaultbank,null);
    }

    @Override
    public void updateFqInfo(String id, String hbfqNum, String fqRate, String fqRatePro, String plat, String shopId, String terminal) {
        this.payOrderService.updateFqInfo(id, hbfqNum, fqRate, fqRatePro, plat, shopId, terminal);
    }

    @Override
    public PayOrder getPayOrderByTransactionId(String transation_id) {
        return this.payOrderService.getPayOrderByTransactionId(transation_id);
    }

    @Override
    public RemoteResult<Integer> updateCmbPayNotifyState(String orderPrimaryId, String lenovoId, String trade_no, int merchantFlag, String notifyId, int tradeState, String bankSeqNo, int payType, int trade_state) {
        return this.payOrderService.updateCmbPayNotifyState(orderPrimaryId,lenovoId,trade_no,merchantFlag,notifyId,tradeState,bankSeqNo,payType,trade_state);
    }

    @Override
    public void updatePayOrderShopIdTerminal(String id, String plat, String shopId, String terminal) {
        this.payOrderService.updatePayOrderShopIdTerminal(id, plat, shopId, terminal);
    }

    @Override
    public RemoteResult<Integer> updatePayOrderCreateTime(String orderPrimaryId, String lenovoId, Date createDate) {
        return this.payOrderService.updatePayOrderCreateTime(orderPrimaryId, lenovoId, createDate);
    }

    public PayOrderService getPayOrderService() {
        return payOrderService;
    }

    public void setPayOrderService(PayOrderService payOrderService) {
        this.payOrderService = payOrderService;
    }


    @Override
    public RemoteResult<Integer> updatePingAnPayNotifyState(String orderPrimaryId, String lenovoId, String trade_no, int merchantFlag, int tradeState, int payType) {
        return this.payOrderService.updatePingAnPayNotifyState(orderPrimaryId,lenovoId,trade_no,merchantFlag,tradeState,payType);
    }
}
