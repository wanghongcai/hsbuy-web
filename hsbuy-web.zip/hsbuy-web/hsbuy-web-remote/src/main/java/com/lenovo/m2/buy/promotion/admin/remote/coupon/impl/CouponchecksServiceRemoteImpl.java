package com.lenovo.m2.buy.promotion.admin.remote.coupon.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.coupon.CouponchecksServiceRemote;
import com.lenovo.m2.couponV2.api.model.CouponchecksApi;
import com.lenovo.m2.couponV2.api.service.CouponchecksService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2016/2/19.
 */
@Component("couponchecksServiceRemote")
public class CouponchecksServiceRemoteImpl implements CouponchecksServiceRemote {
    @Autowired
    CouponchecksService couponchecksService;
    @Override
    public RemoteResult<PageModel2<CouponchecksApi>> getCouponsCheckInfoPage(PageQuery pageQuery, Map<String, Object> conditionMap) {
        return couponchecksService.getCouponchecksInfoPage(pageQuery,conditionMap);
    }

    @Override
    public RemoteResult<Boolean> updateCouponchecksBatch(List<CouponchecksApi> list) {
        return couponchecksService.updateCouponchecksBatch(list);
    }

    @Override
    public RemoteResult<Boolean> updateCouponSecondchecksBatch(List<CouponchecksApi> list) {
        return couponchecksService.updateCouponSecondchecksBatch(list);
    }

    @Override
    public RemoteResult<Boolean> checkCouponByCondition(CouponchecksApi couponchecksApi) {
        return couponchecksService.checkCouponByCondition(couponchecksApi);
    }

    @Override
    public RemoteResult<CouponchecksApi> queryCouponCheckById(long id) {
        return couponchecksService.queryCouponCheckById(id);
    }
}
