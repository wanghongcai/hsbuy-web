package com.lenovo.m2.buy.promotion.admin.remote.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;

/**
 * DUBBO调用取消逻辑
 * Created by mengqiang1 on 2016/8/1.
 */
public interface CancelOrderApi {

    /**
     * 调用DUBBO取消逻辑
     * @param orderCode
     * @param tenant
     * @param lenovoId
     * @return
     */
    public RemoteResult<String> orderCancel(String orderCode, Tenant tenant, String lenovoId);
}
