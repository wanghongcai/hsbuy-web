package com.lenovo.m2.buy.promotion.admin.remote.coupon;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.CouponchecksApi;

import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2016/2/19.
 */
public interface CouponchecksServiceRemote {
    RemoteResult<PageModel2<CouponchecksApi>> getCouponsCheckInfoPage(PageQuery pageQuery, Map<String, Object> conditionMap);
    /**
     * 批量审核
     * @param list
     * @return
     */
    RemoteResult<Boolean> updateCouponchecksBatch(List<CouponchecksApi> list);

    /**
     * 二次批量审核
     * @param list
     * @return
     */
    RemoteResult<Boolean> updateCouponSecondchecksBatch(List<CouponchecksApi> list);

    /**
     * 根据条件审核单条
     * @param couponchecksApi
     * @return
     */
    RemoteResult<Boolean> checkCouponByCondition(CouponchecksApi couponchecksApi);

    RemoteResult<CouponchecksApi> queryCouponCheckById(long id);
}
