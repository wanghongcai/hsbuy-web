package com.lenovo.m2.buy.promotion.admin.remote.ordererp;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;

import java.util.List;

public interface ERPOrderRemoteService {
    RemoteResult<List<MongoOrderDetail>> getMongoOrderList4ERP(String faCode, String paidTimeStart, String paidTimeEnd);
}
