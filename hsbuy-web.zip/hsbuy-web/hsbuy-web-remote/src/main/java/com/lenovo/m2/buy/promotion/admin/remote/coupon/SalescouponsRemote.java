package com.lenovo.m2.buy.promotion.admin.remote.coupon;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.couponV2.api.model.MemberVo;
import com.lenovo.m2.couponV2.api.model.SalescouponsApi;
import com.lenovo.m2.couponV2.api.model.ShowInfo;

import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2015/8/26.
 */
public interface SalescouponsRemote {

    /**
     * 获取优惠卷列表
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<SalescouponsApi>> getSalescouponsInfoPage(PageQuery pageQuery, Map map);

    /**
     * 保存优惠券
     * @param salescouponsApi
     * @return
     */
    public RemoteResult insertSalescoupons(SalescouponsApi salescouponsApi);

    /**
     * 查看优惠券
     * @param salescouponsApi
     * @return
     */
    public RemoteResult<SalescouponsApi> getSalescoupons(SalescouponsApi salescouponsApi);

    /**
     * 删除优惠券信息
     * @param salescouponsApi
     * @return
     */
    public RemoteResult<Boolean> delSalescoupons(SalescouponsApi salescouponsApi);

    /**
     * 更新优惠券
     * @param salescouponsApi
     * @return
     */
    public RemoteResult editSalescoupons(SalescouponsApi salescouponsApi);

    /**
     * 根据主键ids，批量查询
     * @param map
     * @return
     */
    public RemoteResult<List<SalescouponsApi>> getSalescouponsList(Map map);

    /**
     * 只更新优惠券主表
     * @param salescouponsApi
     * @return
     */
    public RemoteResult editSalescouponsOnly(SalescouponsApi salescouponsApi);

    /**
     * @param list
     * @return
     */
    RemoteResult<Boolean> submitToCheckBatch(List<SalescouponsApi> list);

    /**
     * 给指定用户发券
     * @param couponid
     * @param list
     * @return
     */
    RemoteResult<Boolean> sendCouponsToMember(Long couponid, List<MemberVo> list, String itCode);

    /**
     * 向redis中删除数据
     * @return
     */
//    public RemoteResult deleteSalescoupons4redis(SalescouponsApi salescouponsApi);

    /**
     * 根据优惠券id更新通知无效次数
     * @param id
     * @return
     */
    public RemoteResult updateNoticeInvalidCount(Long id);

    /**
     * 根据id查询优惠券
     * @param map
     * @return
     */
    public RemoteResult<List<SalescouponsApi>> getSalescouponsforIds(Map map);

    /**
     * 获取优惠券最大发放张数
     * @param id
     * @return
     */
    public RemoteResult getSalesCouponsMaxNumber(Long id);

    /**
     * 获取优惠券使用数量
     * @param map
     * @return
     */
    public RemoteResult getSalesCouponsNumbersForId(Map map);


    /**
     * 获取优惠券使用数量
     * @param map
     * @return
     */
    public RemoteResult getSalesNumbersManagerment(Map map);

    /**
     * 获取可领取优惠券
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<SalescouponsApi>> getAvailableSalescouponsInfoPage(PageQuery pageQuery, Map map);

    /**
     * 获取满足领取条件的所有优惠券
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<SalescouponsApi>> getAllAvailableSalescouponsInfoPage(PageQuery pageQuery, Map map);

    /**
     * 获取UseScope下所有有效的优惠券
     * @param tenant
     * @param useScope
     * @return
     */
    public RemoteResult<List<SalescouponsApi>> getSalescouponsByUseScope(Tenant tenant, int useScope, String couponId, String couponName);

    /**
     * 根据主键ID查询优惠券
     * @param id
     * @return
     */
    public RemoteResult<SalescouponsApi> getSalescouponsById(Long id);
    public RemoteResult<List<ShowInfo>> getShowPositionInfo(Integer shopId);
}
