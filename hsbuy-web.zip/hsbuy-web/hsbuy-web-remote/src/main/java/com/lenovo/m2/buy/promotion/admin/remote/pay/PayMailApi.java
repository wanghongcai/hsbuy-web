package com.lenovo.m2.buy.promotion.admin.remote.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayMailAddress;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayMailInfo;

import java.util.List;

/**
 * 支付邮件服务
 * Created by mengqiang1 on 2016/3/24.
 */
public interface PayMailApi {

    /**
     * 发送邮件
     * @param payMailInfo
     */
    public void sendRefundMail(PayMailInfo payMailInfo);

    /**
     * 根据邮件类型获取邮件地址
     * @param mailType
     * @return
     */
    public RemoteResult<List<PayMailAddress>> queryPayMailAddressList(String mailType);
}
