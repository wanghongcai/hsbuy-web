package com.lenovo.m2.buy.promotion.admin.remote.coupon.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.buy.promotion.admin.remote.coupon.SalescouponsRemote;
import com.lenovo.m2.couponV2.api.model.MemberVo;
import com.lenovo.m2.couponV2.api.model.SalescouponsApi;
import com.lenovo.m2.couponV2.api.model.ShowInfo;
import com.lenovo.m2.couponV2.api.service.SalescouponsService;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created by zhaocl1 on 2015/8/26.
 */
@Component("salescouponsRemote")
public class SalescouponsRemoteImpl implements SalescouponsRemote {
    private static final Logger log = Logger.getLogger(SalescouponsRemoteImpl.class);
    @Autowired
    private SalescouponsService salescouponsService;

    @Override
    public RemoteResult<PageModel2<SalescouponsApi>> getSalescouponsInfoPage(PageQuery pageQuery, Map map) {
        return salescouponsService.getSalescouponsInfoPage(pageQuery, map);
    }

    @Override
    public RemoteResult insertSalescoupons(SalescouponsApi salescouponsApi) {
        return salescouponsService.insertSalescoupons(salescouponsApi);
    }

    @Override
    public RemoteResult<SalescouponsApi> getSalescoupons(SalescouponsApi salescouponsApi) {
        return salescouponsService.getSalescoupons(salescouponsApi);
    }

    @Override
    public RemoteResult<Boolean> delSalescoupons(SalescouponsApi salescouponsApi) {
        return salescouponsService.delSalescoupons(salescouponsApi);
    }

    @Override
    public RemoteResult editSalescoupons(SalescouponsApi salescouponsApi) {
        RemoteResult result = new RemoteResult(false);
        try {
            result =  salescouponsService.editSalescoupons(salescouponsApi);
        } catch (Exception e) {
            log.error("编辑时出现异常！" + ExceptionUtil.getStackTrace(e));
        }
        return result;
    }

    @Override
    public RemoteResult<List<SalescouponsApi>> getSalescouponsList(Map map) {
        return salescouponsService.getSalescouponsList(map);
    }

    @Override
    public RemoteResult editSalescouponsOnly(SalescouponsApi salescouponsApi) {
        return salescouponsService.editSalescouponsOnly(salescouponsApi);
    }

    @Override
    public RemoteResult<Boolean> submitToCheckBatch(List<SalescouponsApi> list) {
        return salescouponsService.submitToCheckBatch(list);
    }

    @Override
    public RemoteResult<Boolean> sendCouponsToMember(Long couponid, List<MemberVo> list,String itCode) {
        return salescouponsService.sendCouponsToMember(couponid,list,itCode);
    }

//    @Override
//    public RemoteResult deleteSalescoupons4redis(SalescouponsApi salescouponsApi) {
//        return salescouponsService.deleteSalescoupons4redis(salescouponsApi);
//    }

    @Override
    public RemoteResult updateNoticeInvalidCount(Long id) {
        return salescouponsService.updateNoticeInvalidCount(id);
    }

    /**
     * 根据id查询优惠券
     * @param map
     * @return
     */
    public RemoteResult<List<SalescouponsApi>> getSalescouponsforIds(Map map){
        return salescouponsService.getSalescouponsforIds(map);
    }

    @Override
    public RemoteResult getSalesCouponsMaxNumber(Long id) {
        return salescouponsService.getSalesCouponsMaxNumber(id);
    }

    @Override
    public RemoteResult getSalesCouponsNumbersForId(Map map) {
        return salescouponsService.getSalesCouponsNumbersForId(map);
    }

    @Override
    public RemoteResult getSalesNumbersManagerment(Map map) {
        return salescouponsService.getSalesNumbersManagerment(map);
    }

    @Override
    public RemoteResult<PageModel2<SalescouponsApi>> getAvailableSalescouponsInfoPage(PageQuery pageQuery, Map map) {
        return salescouponsService.getAvailableSalescouponsInfoPage(pageQuery, map);
    }

    @Override
    public RemoteResult<PageModel2<SalescouponsApi>> getAllAvailableSalescouponsInfoPage(PageQuery pageQuery, Map map) {
        return salescouponsService.getAllAvailableSalescouponsInfopage(pageQuery, map);
    }

    @Override
    public RemoteResult<List<SalescouponsApi>> getSalescouponsByUseScope(Tenant tenant, int useScope, String couponId, String couponName) {
        Long id = null;
        if(StringUtils.isNotEmpty(couponId)){
            id = Long.valueOf(couponId);
        }
        return salescouponsService.getSalescouponsByUseScope(tenant, useScope, id, couponName);
    }

    @Override
    public RemoteResult<SalescouponsApi> getSalescouponsById(Long id) {
        return salescouponsService.getSalescouponsById(id);
    }

    @Override
    public RemoteResult<List<ShowInfo>> getShowPositionInfo(Integer shopId) {
        Tenant tenant = new Tenant();
        tenant.setShopId(shopId);
        return salescouponsService.getShowInfoByShopId(tenant);
    }
}
