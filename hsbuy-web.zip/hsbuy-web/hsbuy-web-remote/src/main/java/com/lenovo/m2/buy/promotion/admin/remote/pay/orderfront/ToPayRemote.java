package com.lenovo.m2.buy.promotion.admin.remote.pay.orderfront;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

/**
 * Created by lj on 2016/10/11.
 */
public interface ToPayRemote {

    public RemoteResult<String> getPayUrl(String shopId);
}
