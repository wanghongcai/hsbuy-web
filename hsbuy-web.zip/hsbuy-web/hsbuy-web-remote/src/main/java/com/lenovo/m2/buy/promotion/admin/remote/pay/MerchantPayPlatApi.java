package com.lenovo.m2.buy.promotion.admin.remote.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;

/**
 * Created by yangjj7 on 2015/5/2.
 */
public interface MerchantPayPlatApi {
    /**
     * 查询商户与三方支付平台
     * @param merchantId
     * @param payType
     * @return
     */
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatByMerchantId(String merchantId, int payType);

    /**
     * 查询Id查找商户平台信息

     */
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatById(long Merchant);


    /**
     *
     * @param merchId
     * @return
     */
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatByMerchId(String merchId);

    /**
     *
     * @param faId
     * @param payType
     * @param accountType 账户类型 1:B2C/2:B2B
     * @return
     */
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatByAccountType(String faId, int payType, Integer accountType);
}
