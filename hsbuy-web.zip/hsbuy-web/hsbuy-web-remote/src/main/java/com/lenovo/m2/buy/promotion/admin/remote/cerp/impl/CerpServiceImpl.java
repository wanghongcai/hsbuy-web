package com.lenovo.m2.buy.promotion.admin.remote.cerp.impl;

import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.remote.cerp.CerpService;
import com.lenovo.m2.buy.promotion.admin.soa.utils.CustomizedPropertyConfigurer;
import com.lenovo.m2.buy.promotion.admin.soa.utils.HttpUtil;
import com.lenovo.m2.buy.promotion.admin.soa.utils.JsonUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Created by wangrq1 on 2016/12/29.
 */
@Service
public class CerpServiceImpl implements CerpService{

    private static Logger log = LoggerFactory.getLogger(CerpServiceImpl.class);


    @Override
    public Tenant getTenantByShopId(Integer shopId) {
         String cerpUrl = CustomizedPropertyConfigurer.getContextProperty("query.cerp.url");
        String url = String.format("%s&shopid=%s", cerpUrl, shopId);
        String res = HttpUtil.getStr(url);
        log.info("cerp get tenant info res={}", res);
        if(StringUtils.isEmpty(res)){
            log.warn("cerp get tenant info is null, url ={}", url);
            return  null;
        }
        Map map = JsonUtil.fromJson(res, Map.class);
        if(map == null || map.size() == 0){
            log.warn("cerp get tenant info is null, url ={}", url);
            return  null;
        }
        String ret = String.valueOf(map.get("ret"));
        if(!"0".equals(ret)){
            log.warn("获取tenant info failed, shopId={}", shopId);
            return  null;
        }

        Map obj = (Map)map.get("obj");
        if(obj == null || obj.size() == 0){
            log.warn("tenant info is null, shopId={}", shopId);
            return  null;
        }

        Tenant t = new Tenant();
        t.setShopId(Integer.parseInt(String.valueOf(obj.get("shopid"))));
        t.setNationalName(String.valueOf(obj.get("countryName")));
        t.setNationalCode(String.valueOf(obj.get("countryCode")));
        t.setCurrencyCode(String.valueOf(obj.get("currencyCode")));
        t.setLanguage(String.valueOf(obj.get("language")));
        t.setTimeZone(String.valueOf(obj.get("countryTimeZone")));

        return t;
    }




    public static void main(String[] args){


        System.out.println(new CerpServiceImpl().getTenantByShopId(1));

    }
}
