package com.lenovo.m2.buy.promotion.admin.remote.pay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.pay.ChannelOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.ChannelOrder;
import com.lenovo.m2.hsbuy.service.pay.soa.ChannelOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by MengQiang on 2016/2/22.
 */
@Service
public class ChannelOrderApiImpl implements ChannelOrderApi {

    @Autowired
    @Qualifier(value = "soaChannelOrderService")
    private ChannelOrderService channelOrderService;

    @Override
    public RemoteResult<List<ChannelOrder>> queryChannelOrderMainCodeList(List<String> orderMainCodeList, String lenovoId, String shopId) {
        return channelOrderService.queryChannelOrderMainCodeList(orderMainCodeList,lenovoId,shopId);
    }

    @Override
    public RemoteResult<ChannelOrder> queryChannelOrderMainCodeDetail(String orderMainCode, String lenovoId, String shopId) {
        return channelOrderService.queryChannelOrderMainCodeDetail(orderMainCode,lenovoId,shopId);
    }

    @Override
    public RemoteResult<Integer> updateChannelOrderMainCodeDetail(ChannelOrder channelOrder) {
        return channelOrderService.updateChannelOrderMainCodeDetail(channelOrder);
    }

    @Override
    public RemoteResult<List<ChannelOrder>> queryChannelOrderCodeList(String orderMainCode, String lenovoId, int mainFlag, String shopId) {
        return channelOrderService.queryChannelOrderCodeList(orderMainCode,lenovoId,mainFlag,shopId);
    }

    @Override
    public RemoteResult<ChannelOrder> queryChannelOrderCodeDetail(String orderCode, String lenovoId, int mainFlag, String shopId){
        return channelOrderService.queryChannelOrderCodeDetail(orderCode, lenovoId, mainFlag,shopId);
    }

    @Override
    public RemoteResult<List<ChannelOrder>> queryOrderCodeList(List<String> orderCodeList, String lenovoId, int mainFlag, String shopId) {
        return channelOrderService.queryOrderCodeList(orderCodeList, lenovoId, mainFlag,shopId);
    }

    @Override
    public RemoteResult<Integer> updateChannelOrderOrderStatus(int orderStatus, String orderCode, int mainFlag, String shopId) {
        return channelOrderService.updateChannelOrderOrderStatus(orderStatus, orderCode, mainFlag,shopId);
    }

    @Override
    public RemoteResult<ChannelOrder> querySmbChannelOrderDetail(String smbOrderCode, int mainFlag, String shopId) {
        return channelOrderService.querySmbChannelOrderDetail(smbOrderCode,mainFlag,shopId);
    }


    public ChannelOrderService getChannelOrderService() {
        return channelOrderService;
    }

    public void setChannelOrderService(ChannelOrderService channelOrderService) {
        this.channelOrderService = channelOrderService;
    }

}
