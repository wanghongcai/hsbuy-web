package com.lenovo.m2.buy.promotion.admin.remote.pay.orderfront;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

import java.io.InputStream;

/**
 * Created by jh on 2016/1/11.
 */
public interface FileUpload {

    public RemoteResult<Boolean> fileUpload(String fileName, InputStream in);
}
