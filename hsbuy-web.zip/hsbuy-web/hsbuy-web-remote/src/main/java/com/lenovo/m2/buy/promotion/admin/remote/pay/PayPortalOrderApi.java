package com.lenovo.m2.buy.promotion.admin.remote.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;

import java.util.List;

/**
 * 支付前置订单
 * Created by MengQiang on 2016/9/13.
 */
public interface PayPortalOrderApi {

    /**
     * delete
     */
    public RemoteResult<Integer> deleteByPrimaryKey(Integer id);

    /**
     * Insert
     */
    public RemoteResult<Integer> insert(PayPortalOrder payPortalOrder);

    /**
     * insert
     */
    public RemoteResult<Integer> insertSelective(PayPortalOrder payPortalOrder);


    /**
     * selectByPrimaryKey
     */
    public RemoteResult<PayPortalOrder> selectByPrimaryKey(Integer id);

    /**
     * update
     */
    public RemoteResult<Integer> updateByPrimaryKeySelective(PayPortalOrder payPortalOrder);

    /**
     * update
     */
    public RemoteResult<Integer> updateByPrimaryKey(PayPortalOrder payPortalOrder);

    /**
     *
     * @param payPortalOrder
     * @return PrimaryId
     */
    public RemoteResult<Long> insertReturnPrimaryId(PayPortalOrder payPortalOrder);

    public RemoteResult<List<PayPortalOrder>> queryPayPortalOrderListByOutTradeNoList(List<String> outTradeNoList, String lenovoId, Tenant tenant);

    public RemoteResult<Boolean> saveOrUpdatePayPortalOrderList(List<PayPortalOrder> savePayPortalOrderList, List<PayPortalOrder> updatePayPortalOrderList);

    public RemoteResult<Integer> updatePayPortalOrderPayStatus(PayPortalOrder updatePayPortalOrder);

    public RemoteResult<PayPortalOrder> queryPayPortalOrderByOutTradeNo(String outTradeNo, String lenovoId, Tenant tenant);


    public RemoteResult<Integer> updatePayPortalOrderOrderStatus(String outTradeNo, Tenant tenant, String orderStatus);

    public RemoteResult<PayPortalOrder> queryPayPortalOrderByShowTradeNo(String showTradeNo, String lenovoId, Tenant tenant);

    public void testPath(String path);
}
