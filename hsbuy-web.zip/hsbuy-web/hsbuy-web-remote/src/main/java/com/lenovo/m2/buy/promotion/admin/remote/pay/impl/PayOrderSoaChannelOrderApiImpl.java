package com.lenovo.m2.buy.promotion.admin.remote.pay.impl;

import com.lenovo.m2.hsbuy.service.pay.ordersoa.ChannelOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * Created by MengQiang on 2016/10/12.
 */
@Service
public class PayOrderSoaChannelOrderApiImpl {


    @Autowired
    @Qualifier(value = "ordersoaChannelOrderService")
    private ChannelOrderService payOrderSoaChannelOrderService;

    public ChannelOrderService getPayOrderSoaChannelOrderService() {
        return payOrderSoaChannelOrderService;
    }

    public void setPayOrderSoaChannelOrderService(ChannelOrderService payOrderSoaChannelOrderService) {
        this.payOrderSoaChannelOrderService = payOrderSoaChannelOrderService;
    }
}
