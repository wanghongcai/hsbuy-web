package com.lenovo.m2.buy.promotion.admin.remote.pay.orderfront.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.common.pay.orderfront.util.PayConstant;
import com.lenovo.m2.buy.promotion.admin.remote.pay.orderfront.ToPayRemote;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

/**
 * Created by jh on 2016/1/11.
 */
@Service
public class ToPayRemoteImpl implements ToPayRemote {
    public static Logger logger= Logger.getLogger(ToPayRemoteImpl.class);
    private   String payUrl;
    private   String smbUrl;

    public  void setPayUrl(String payUrl) {
        this.payUrl = payUrl;
    }

    public void setSmbUrl(String smbUrl) {
        this.smbUrl = smbUrl;
    }

    /**
     * 获取支付路径
     * @return
     */
    @Override
    public RemoteResult<String> getPayUrl(String shopId) {
        RemoteResult<String> rs=new RemoteResult<String>(false);
        if(PayConstant.SHOPID_SMB.equals(shopId)){
           logger.equals("smb订单支付");
            rs.setT(smbUrl);
        }else{
            rs.setT(payUrl);
        }

        return rs;
    }
}
