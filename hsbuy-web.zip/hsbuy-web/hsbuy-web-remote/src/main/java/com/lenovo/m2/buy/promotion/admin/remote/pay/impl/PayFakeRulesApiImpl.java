package com.lenovo.m2.buy.promotion.admin.remote.pay.impl;


import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayFakeRulesApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayFakeRules;
import com.lenovo.m2.hsbuy.service.pay.soa.PayFakeRulesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by mengqiang1 on 2016/5/6.
 */
@Service
public class PayFakeRulesApiImpl implements PayFakeRulesApi {

    @Autowired
    @Qualifier(value = "payFakeRulesService")
    private PayFakeRulesService payFakeRulesService;

    @Override
    public RemoteResult<Map<String, Integer>> pushFakePay(PayFakeRules payFake) throws Exception {
        return payFakeRulesService.pushFakePay(payFake);
    }

    @Override
    public RemoteResult<Map<String, Integer>> updateFakePay(PayFakeRules payFake) {
        return payFakeRulesService.updateFakePay(payFake);
    }

    @Override
    public RemoteResult<List<PayFakeRules>> queryFakePayList(String lenovoId) {
        return payFakeRulesService.queryFakePayList(lenovoId);
    }

    public PayFakeRulesService getPayFakeRulesService() {
        return payFakeRulesService;
    }

    public void setPayFakeRulesService(PayFakeRulesService payFakeRulesService) {
        this.payFakeRulesService = payFakeRulesService;
    }
}
