package com.lenovo.m2.buy.promotion.admin.remote.coupon.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.coupon.GetCouponsRemote;
import com.lenovo.m2.couponV2.api.dubboModel.DisplayPositionEnum;
import com.lenovo.m2.couponV2.api.model.AvailableSalescouponsApi;
import com.lenovo.m2.couponV2.api.service.AvailableSalescouponsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by fenglg1 on 2016/12/13.
 */
@Component("getCouponsRemote")
public class GetCouponsRemoteImpl implements GetCouponsRemote {

    @Autowired
    private AvailableSalescouponsService availableSalescouponsService;

    @Override
    public RemoteResult saveSelectedSalescoupons(List<AvailableSalescouponsApi> salescouponsApiList,Integer displayPosition) {
    	DisplayPositionEnum en = null;
    	if(null != displayPosition){
    		if(DisplayPositionEnum.USER_CENTER.getCode().equals(String.valueOf(displayPosition))){
    			en = DisplayPositionEnum.USER_CENTER; 
    		}else if(DisplayPositionEnum.XIAO_XIN.getCode().equals(String.valueOf(displayPosition))){
    			en = DisplayPositionEnum.XIAO_XIN; 
    		}
    	}
        return availableSalescouponsService.saveAvailableSalescoupons(salescouponsApiList, en);
    }

    @Override
    public RemoteResult deleteAvailableSalescoupons(String operator, String couponId,String displayPosition) {
        return availableSalescouponsService.deleteAvailableSalescoupons(operator, Long.valueOf(couponId),displayPosition);
    }

    @Override
    public RemoteResult deleteAllAvailableSalescoupons(String operator) {
        return availableSalescouponsService.deleteAllSelectedAvailableSalescoupons(operator);
    }
}
