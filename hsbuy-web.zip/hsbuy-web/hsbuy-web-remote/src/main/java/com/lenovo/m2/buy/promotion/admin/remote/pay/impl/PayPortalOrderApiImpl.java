package com.lenovo.m2.buy.promotion.admin.remote.pay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayPortalOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.service.pay.soa.PayPortalOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 支付服务前置订单处理
 * Created by MengQiang on 2016/9/13.
 */
@Service
public class PayPortalOrderApiImpl implements PayPortalOrderApi {

    @Autowired
    @Qualifier(value = "payPortalOrderService")
    private PayPortalOrderService payPortalOrderService;

    @Override
    public RemoteResult<Integer> deleteByPrimaryKey(Integer primaryKey) {
        return payPortalOrderService.deleteByPrimaryKey(primaryKey);
    }

    @Override
    public RemoteResult<Integer> insert(PayPortalOrder payPortalOrder) {
        return payPortalOrderService.insert(payPortalOrder);
    }

    @Override
    public RemoteResult<Integer> insertSelective(PayPortalOrder payPortalOrder) {
        return payPortalOrderService.insertSelective(payPortalOrder);
    }

    @Override
    public RemoteResult<PayPortalOrder> selectByPrimaryKey(Integer primaryKey) {
        return payPortalOrderService.selectByPrimaryKey(primaryKey);
    }

    @Override
    public RemoteResult<Integer> updateByPrimaryKeySelective(PayPortalOrder payPortalOrder) {
        return payPortalOrderService.updateByPrimaryKeySelective(payPortalOrder);
    }

    @Override
    public RemoteResult<Integer> updateByPrimaryKey(PayPortalOrder payPortalOrder) {
        return payPortalOrderService.updateByPrimaryKey(payPortalOrder);
    }

    @Override
    public RemoteResult<Long> insertReturnPrimaryId(PayPortalOrder payPortalOrder) {
        return payPortalOrderService.insertReturnPrimaryId(payPortalOrder);
    }

    @Override
    public RemoteResult<List<PayPortalOrder>> queryPayPortalOrderListByOutTradeNoList(List<String> outTradeNoList, String lenovoId, Tenant tenant) {
        return payPortalOrderService.queryPayPortalOrderListByOutTradeNoList(outTradeNoList, lenovoId, tenant);
    }

    @Override
    public RemoteResult<Boolean> saveOrUpdatePayPortalOrderList(List<PayPortalOrder> savePayPortalOrderList, List<PayPortalOrder> updatePayPortalOrderList) {
        return payPortalOrderService.saveOrUpdatePayPortalOrderList(savePayPortalOrderList, updatePayPortalOrderList);
    }

    @Override
    public RemoteResult<Integer> updatePayPortalOrderPayStatus(PayPortalOrder updatePayPortalOrder) {
        return payPortalOrderService.updatePayPortalOrderPayStatus(updatePayPortalOrder);
    }

    @Override
    public RemoteResult<PayPortalOrder> queryPayPortalOrderByOutTradeNo(String outTradeNo, String lenovoId, Tenant tenant) {
        return payPortalOrderService.queryPayPortalOrderByOutTradeNo(outTradeNo, lenovoId, tenant);
    }



    @Override
    public RemoteResult<Integer> updatePayPortalOrderOrderStatus(String outTradeNo, Tenant tenant, String orderStatus) {
        return payPortalOrderService.updatePayPortalOrderOrderStatus(outTradeNo, tenant, orderStatus);
    }

    @Override
    public RemoteResult<PayPortalOrder> queryPayPortalOrderByShowTradeNo(String showTradeNo, String lenovoId, Tenant tenant) {
        return payPortalOrderService.queryPayPortalOrderByShowTradeNo(showTradeNo, lenovoId, tenant);
    }

    @Override
    public void testPath(String path) {
        payPortalOrderService.testPath(path);
    }

    public PayPortalOrderService getPayPortalOrderService() {
        return payPortalOrderService;
    }

    public void setPayPortalOrderService(PayPortalOrderService payPortalOrderService) {
        this.payPortalOrderService = payPortalOrderService;
    }
}
