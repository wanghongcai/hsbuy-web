package com.lenovo.m2.buy.promotion.admin.remote.ordererp.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.ordererp.ERPOrderRemoteService;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.ordererp.ERPOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ERPOrderRemoteServiceImpl implements ERPOrderRemoteService {

    @Autowired
    private ERPOrderService erpOrderService;

    @Override
    public RemoteResult<List<MongoOrderDetail>> getMongoOrderList4ERP(String faCode, String paidTimeStart, String paidTimeEnd) {
        return erpOrderService.getMongoOrderList4ERP(faCode, paidTimeStart, paidTimeEnd);
    }
}
