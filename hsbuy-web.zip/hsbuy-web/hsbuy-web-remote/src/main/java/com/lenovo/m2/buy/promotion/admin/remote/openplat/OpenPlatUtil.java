package com.lenovo.m2.buy.promotion.admin.remote.openplat;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Created by wangrq1 on 2016/7/21.
 */
@Service
public class OpenPlatUtil {
	
	private static Logger log = LoggerFactory.getLogger(OpenPlatUtil.class);

//    private String   url ="http://open.docker.lenovouat.cn/router/json.jhtm";   //旧uat api接口调用
    private String url ="http://open.lenovouat.cn/router/json.jhtm";    //新uat api接口调用
    	//http://promotion.lenovouat.com/api/getPromotion.jhtm?terminal=1&shopId=1&gcode=70016
    private String appKey ="testadmin";

    private String secretKey ="testadmin";

    public OpenPlatUtil(){}

    public OpenPlatUtil(String url, String appKey, String secretKey){
        this.url = url;
        this.appKey = appKey;
        this.secretKey = secretKey;
    }



    public String invokeOpenPlat(String method, String param) throws RuntimeException {
    	
        OpenPlatReq req = new OpenPlatReq(method, param, appKey, secretKey);
        
        String reqBody = req.getPostBody(); //格式
        
        log.info("url={},req body={}", url, req.getPostBody());
        String platRes =  HttpUtil.executeHttpPost(url, req.getPostBody());
        Map map = JsonUtil.fromJson(platRes, Map.class);
        //get {result={lenovo_seckillActivity_get_response={resultMsg=null, createTime=null, t={createTime=2017-04-07 16:10:15, isReservation=0, status=0, seckillStartTime=2017-04-07 16:09:49, createBy=wuzy9, id=834, isDisplayReservation=1, seckillEndTime=2017-04-07 16:15:51, checkStatus=2, terminal=15, shopId=1, markeTable=1, activityType=2, activityName=APP 看看秒杀}, resultCode=0, success=true, lastModifyTime=null, version=0}, status=200}, resultCode=0, code=0, msg=操作成功, success=true}
        Object success = map.get("success");
        if("true".equals(String.valueOf(success))){
            Map obj = (Map)map.get("result");
            Object res = obj.get(String.format("%s_response", method.replaceAll("\\.", "_")));
            log.info("unpack res={}", res);
            return JsonUtil.toJson(res);
        }else{
        	log.info("invoke openplat failed, res={}", platRes);
            throw new BusinessException(GlobalErrorMessage.ERROR_INVOKE_OPEN_PLAT);
        }

    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }
}
