package com.lenovo.m2.buy.promotion.admin.remote.pay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayChannelBankApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.PayChannelBank;
import com.lenovo.m2.hsbuy.service.pay.soa.PayChannelBankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

//import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by tianchuyang on 2017/1/17.
 */
@Service
public class PayChannelBankApiImpl implements PayChannelBankApi {

    @Autowired
    @Qualifier(value = "payChannelBankService")
    private PayChannelBankService payChannelBankService;

    @Override
    public RemoteResult<PayChannelBank> queryPayChannelBankByParams(Integer payplatId, Integer bankCode, Integer accountType, Integer cardType) {
        return payChannelBankService.queryPayChannelBanksByParams(payplatId,bankCode,accountType,cardType);
    }

    @Override
    public RemoteResult<List<PayChannelBank>> queryPayChannelBanksByParams(PayChannelBank payChannelBank) {
        return payChannelBankService.queryPayChannelBanksByParams(payChannelBank);
    }

    @Override
    public RemoteResult<List<PayChannelBank>> queryAllPayChannelBanks() {
        return payChannelBankService.queryAllPayChannelBanks();
    }

    public PayChannelBankService getPayChannelBankService() {
        return payChannelBankService;
    }

    public void setPayChannelBankService(PayChannelBankService payChannelBankService) {
        this.payChannelBankService = payChannelBankService;
    }
}
