package com.lenovo.m2.buy.promotion.admin.remote.coupon.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.coupon.UsergroupcouponrelRemote;
import com.lenovo.m2.couponV2.api.model.UsergroupcouponrelApi;
import com.lenovo.m2.couponV2.api.service.UsergroupcouponrelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by zhaocl1 on 2015/9/15.
 */
@Component("usergroupcouponrelRemote")
public class UsergroupcouponrelRemoteImpl implements UsergroupcouponrelRemote {

    @Autowired
    private UsergroupcouponrelService usergroupcouponrelService;

    @Override
    public RemoteResult insertBatch(List<UsergroupcouponrelApi> list) {
        return usergroupcouponrelService.insertBatch(list);
    }
}
