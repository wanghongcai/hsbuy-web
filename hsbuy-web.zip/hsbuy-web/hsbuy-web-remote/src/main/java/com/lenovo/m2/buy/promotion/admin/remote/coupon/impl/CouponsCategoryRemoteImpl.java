package com.lenovo.m2.buy.promotion.admin.remote.coupon.impl;


import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.coupon.CouponsCategoryRemote;
import com.lenovo.m2.couponV2.api.model.CouponsCategoryApi;
import com.lenovo.m2.couponV2.api.service.CouponsCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Created by zhaocl1 on 2015/8/26.
 */
@Component("couponsCategoryRemote")
public class CouponsCategoryRemoteImpl implements CouponsCategoryRemote {

    @Autowired
    private CouponsCategoryService couponsCategoryService;

    @Override
    public RemoteResult<CouponsCategoryApi> getCouponsCategory(String s) {
        return couponsCategoryService.getCouponsCategory(s);
    }

    @Override
    public RemoteResult<PageModel2<CouponsCategoryApi>> getCouponsCategoryInfoPage(PageQuery pageQuery, Map map) {
        return couponsCategoryService.getCouponsCategoryInfoPage(pageQuery, map);
    }

    @Override
    public RemoteResult<Integer> insertCouponsCategory(CouponsCategoryApi couponsCategoryApi) {
        return couponsCategoryService.insertCouponsCategory(couponsCategoryApi);
    }

    @Override
    public RemoteResult<Boolean> delCouponsCategory(CouponsCategoryApi couponsCategoryApi) {
        return couponsCategoryService.delCouponsCategory(couponsCategoryApi);
    }

    @Override
    public RemoteResult<Boolean> editCouponsCategory(CouponsCategoryApi couponsCategoryApi) {
        return couponsCategoryService.editCouponsCategory(couponsCategoryApi);
    }

    @Override
    public RemoteResult<Boolean> disableCouponCategoryById(int id) {
        return couponsCategoryService.disableCouponCategoryById(id);
    }
}
