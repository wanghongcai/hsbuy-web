package com.lenovo.m2.buy.promotion.admin.remote.coupon.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.coupon.MemberCouponServiceRemote;
import com.lenovo.m2.couponV2.api.model.CouponReportApi;
import com.lenovo.m2.couponV2.api.model.MembercouponrelsApi;
import com.lenovo.m2.couponV2.api.service.CouponReportService;
import com.lenovo.m2.couponV2.api.service.MemberCounponrelsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2016/1/21.
 */
@Component("memberCouponServiceRemote")
public class MemberCouponServiceRemoteImpl implements MemberCouponServiceRemote {
    @Autowired
    MemberCounponrelsService memberCounponrelsService;
    @Autowired
    CouponReportService couponReportService;

    @Override
    public RemoteResult<PageModel2<MembercouponrelsApi>> getMemberCouponsInfoPage(PageQuery pageQuery, Map map) {
        return memberCounponrelsService.getMemberCouponrelsPage(pageQuery,map);
    }

    @Override
    public RemoteResult<Boolean> disableMemberCouponById(long id) {
        return memberCounponrelsService.disableMemberCouponById(id);
    }

    @Override
    public RemoteResult<Boolean> disableMemberCouponByIdandLenovoId(long id, String lenovoId) {
        return memberCounponrelsService.disableMemberCouponByIdandLenovoId(id,lenovoId);
    }

    @Override
    public RemoteResult<MembercouponrelsApi> queryMemberCouponById(long id) {
        return memberCounponrelsService.queryMemberCouponById(id);
    }

    @Override
    public RemoteResult insertBatchMembercouponrels(List<MembercouponrelsApi> list) {
        return memberCounponrelsService.insertBatchMembercouponrels(list);
    }

    @Override
    public RemoteResult<PageModel2<CouponReportApi>> getMemberCouponsReportInfoPage(PageQuery pageQuery, Map map) {
        return couponReportService.getCouponReportInfoPage(pageQuery, map);
    }

    @Override
    public RemoteResult<PageModel2<CouponReportApi>> getCouponsAndOrderIdInfoPage(PageQuery pageQuery, Map map) {
        return couponReportService.getCouponAndOrderIdInfoPage(pageQuery, map);
    }

    @Override
    public RemoteResult<List<MembercouponrelsApi>> getMemberCouponsBySalesCouponId(Long salesCouponId) {
        return memberCounponrelsService.getMemberCouponRelBySalesCouponId(salesCouponId);
    }
}
