package com.lenovo.m2.buy.promotion.admin.remote.coupon;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.couponV2.api.model.CouponReportApi;
import com.lenovo.m2.couponV2.api.model.MembercouponrelsApi;

import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2016/1/21.
 */
public interface MemberCouponServiceRemote {
    /**
     * 获取用户优惠卷列表
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<MembercouponrelsApi>> getMemberCouponsInfoPage(PageQuery pageQuery, Map map);

    /**
     * 根据主键id禁用用户优惠券
     * @param id
     * @return
     */
    RemoteResult<Boolean> disableMemberCouponById(long id);
    RemoteResult<Boolean> disableMemberCouponByIdandLenovoId(long id, String lenovoId);
    RemoteResult<MembercouponrelsApi> queryMemberCouponById(long id);

    /**
     * 批量插入用户优惠券
     * @param list
     * @return
     */
    public RemoteResult insertBatchMembercouponrels(List<MembercouponrelsApi> list);

    /**
     * 根据优惠券ID和状态查询优惠券的使用情况
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<CouponReportApi>> getMemberCouponsReportInfoPage(PageQuery pageQuery, Map map);

    /**
     * 根据优惠券ID查询已使用优惠券和订单号
     * @param pageQuery
     * @param map
     * @return
     */
    public RemoteResult<PageModel2<CouponReportApi>> getCouponsAndOrderIdInfoPage(PageQuery pageQuery, Map map);

    public RemoteResult<List<MembercouponrelsApi>> getMemberCouponsBySalesCouponId(Long salesCouponId);

}
