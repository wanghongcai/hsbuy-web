package com.lenovo.m2.buy.promotion.admin.remote.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.PayChannelBank;

import java.util.List;

/**
 * Created by tianchuyang on 2017/1/17.
 */
public interface PayChannelBankApi {

    RemoteResult<PayChannelBank> queryPayChannelBankByParams(Integer payplatId, Integer bankCode, Integer accountType, Integer cardType);

    RemoteResult<List<PayChannelBank>> queryPayChannelBanksByParams(PayChannelBank payChannelBank);

    RemoteResult<List<PayChannelBank>> queryAllPayChannelBanks();
}
