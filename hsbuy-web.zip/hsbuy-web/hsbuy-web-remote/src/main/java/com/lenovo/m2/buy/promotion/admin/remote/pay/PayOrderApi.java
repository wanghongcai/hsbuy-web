package com.lenovo.m2.buy.promotion.admin.remote.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.PayOrderView;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by caoxd2 on 2015/5/1.
 */
public interface PayOrderApi {
    /**
     * 保存支付订单接口
     * @param payOrder
     * @return
     */
    public RemoteResult<String> savePayOrder(PayOrderView payOrder);

    /**
     * 更新支付订单状态接口
     * @param orderCode
     * @param userId
     * @param wxFlag
     * @param tradeState
     * @return
     */
    public RemoteResult<Boolean> updateOrderPayState(String orderCode, String wxPayCode, String userId, int wxFlag, int tradeState, int payType);

    /**
     * 更新商家状态接口
     * @param orderCode
     * @param userId
     * @param transactionId
     * @param merchantFlag
     * @return
     */
    public RemoteResult<Boolean> updateMerchantNotifyState(String orderCode, String userId, String transactionId, int merchantFlag);

    /**
     * 更新商家状态新增支付宝订单接口
     * @param orderPrimaryId 支付平台订单唯一标识
     * @param lenovoId
     * @param trade_no
     * @param merchantFlag
     * @param notifyId
     * @param tradeState
     * @param bankSeqNo
     * @param payType
     * @return
     */
    public RemoteResult<Boolean> updateAliPayNotifyState(String orderPrimaryId, String lenovoId, String trade_no, int merchantFlag, String notifyId, int tradeState, String bankSeqNo, int payType);



    /**
     * 更新商家状态新增支付宝订单接口(手机专用)
     * @param orderCode
     * @param
     * @param transactionId
     * @param merchantFlag
     * @return
     */
    public RemoteResult<Boolean> updateAliIphonePayNotifyState(String orderCode, String transactionId, int merchantFlag, String notifyId, int tradeState, String bankSeqNo, int payType);

    /**
     * 查询支付订单详情接口
     * @param orderCode
     * @param userId
     * @param payCode
     * @return
     */
    public RemoteResult<PayOrderView> queryPayOrderDetail(String orderCode, String userId, String payCode);
    /**
     * 根据订单号查询商户ID
     * @param orderCode
     *
     * @return
     */
    public int getPayOrderByOutTradeNo(String orderCode);

    /**
     * 获取订单的状态
     * @param orderCode
     * @param userId
     * @return
     */
    public Integer getOrderStatus(String orderCode, String userId);

    /**
     * 获取trade_state,merchant_flag
     *
     * @param key_id
     * @return
     */
    public PayOrder getTwoStatus(String key_id);

    /**
     * 通过订单号获取支付订单信息
     * @param orderCode
     * @return
     */
    public PayOrder getPayOrderById(String orderCode);

    /**
     * 通过支付单号获取支付订单信息
     * @param payOrderId
     * @return
     */
    public PayOrder getPayOrderByPrimaryId(long payOrderId);


    public Map<String,Map<String,Object>> getRefundInfo(List<String> orders);

    public int getStatusByOrderCode(String orderCode);

    public RemoteResult<List<PayOrder>> getOrderListByOrderCode(String orderCode);

    public RemoteResult<List<PayOrder>> getOrderListByPayType(String ordercode, Integer payType);

    public int updatePayBankByID(String keyId, String defaultbank);

    public void updateFqInfo(String id, String hbfqNum, String fqRate, String fqRatePro, String plat, String shopId, String terminal);

    public PayOrder getPayOrderByTransactionId(String transation_id);

    public RemoteResult<Integer> updateCmbPayNotifyState(String orderPrimaryId, String lenovoId, String trade_no, int merchantFlag, String notifyId, int tradeState, String bankSeqNo, int payType, int trade_state);

    public RemoteResult<Integer> updatePingAnPayNotifyState(String orderPrimaryId, String lenovoId, String trade_no, int merchantFlag, int tradeState, int payType);

    public void updatePayOrderShopIdTerminal(String id, String plat, String shopId, String terminal);

    public RemoteResult<Integer> updatePayOrderCreateTime(String orderPrimaryId, String lenovoId, Date createDate);
}
