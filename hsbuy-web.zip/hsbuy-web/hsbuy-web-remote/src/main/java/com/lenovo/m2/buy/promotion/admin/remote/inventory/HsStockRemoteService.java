package com.lenovo.m2.buy.promotion.admin.remote.inventory;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.inventory.HsStock;
import com.lenovo.m2.hsbuy.domain.inventory.HsWaterLevelStock;
import com.lenovo.m2.hsbuy.domain.ordercenter.BeeOrderApi;

import java.util.Map;

/**
 * Created by yezhenyue on 2017/2/16.
 */
public interface HsStockRemoteService {
    /**
     * 新增惠商库存水位
     * @param hsWaterLevelStock
     * @return
     */
    RemoteResult addHsWaterLevelStock(HsWaterLevelStock hsWaterLevelStock);

    /**
     * 修改惠商库存水位
     * @param hsWaterLevelStock
     * @return
     */
    RemoteResult updateHsWaterLevelStock(HsWaterLevelStock hsWaterLevelStock);

    /**
     * 分页查询水位库存
     * @param pageQuery
     * @param map
     * @return
     */
    RemoteResult<PageModel2<HsWaterLevelStock>> getHsWaterLevelStockPage(PageQuery pageQuery, Map map);

    /**
     * 根据faid查询水位库存
     * @param faid
     * @return
     */
    RemoteResult<HsWaterLevelStock> getHsWaterLevelStockByFaid(String faid);
    /**
     * 根据id查询水位库存
     * @param id
     * @return
     */
    RemoteResult<HsWaterLevelStock> getHsWaterLevelStockById(long id);

    /**
     * 获取小蜜蜂订单数据
     * @param pageQuery
     * @param map
     * @return
     */
    RemoteResult<PageModel2<BeeOrderApi>> getBeeOrderPage(PageQuery pageQuery, Map map);

    /**
     * 新建自有库存
     * @param hsStock
     * @return
     */
    RemoteResult addHsOwnStock(HsStock hsStock);

    /**
     * 修改自有库存
     * @param hsStock
     * @return
     */
    RemoteResult updateHsOwnStock(HsStock hsStock);

    /**
     * 查询自有库存
     * @param faid
     * @param goodsCode
     * @param productGroupNo
     * @return
     */
    RemoteResult<HsStock> getHsOwnStock(String faid, String goodsCode, String productGroupNo);

    /**
     * 根据主键查询自有库存
     * @param stockId
     * @return
     */
    RemoteResult<HsStock> getHsOwnStockById(long stockId);
    /**
     * 分页查询自有库存
     * @param pageQuery
     * @param map
     * @return
     */
    RemoteResult<PageModel2<HsStock>> getHsOwnStockPage(PageQuery pageQuery, Map map);
}
