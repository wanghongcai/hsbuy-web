package com.lenovo.m2.buy.promotion.admin.remote.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.baseInfo.PayAccountVo;

/**
 * Created by MengQiang on 2016/10/17.
 */
public interface PayOrderSoaChannelPayCenterApi {

    public RemoteResult<String> updateChannelOrderPayStatus(Tenant tenant, String outTradeNo, String lenovoId, PayAccountVo payAccountVo, String orderType, boolean isOutMerchant);
}
