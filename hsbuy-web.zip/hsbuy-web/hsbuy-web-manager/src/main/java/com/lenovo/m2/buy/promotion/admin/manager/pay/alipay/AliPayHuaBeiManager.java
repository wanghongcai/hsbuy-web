package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

import javax.servlet.http.HttpServletRequest;

/**
 * 支付宝花呗分期Manager
 * Created by MengQiang on 2016/1/4.
 */
public interface AliPayHuaBeiManager {

    /**
     * 去支付
     * @param request
     * @return
     */
    public RemoteResult<String> toFqPay(HttpServletRequest request);

    /**
     * 更新订单状态
     * @param payOrder
     * @param merchantPayPlatView
     * @param gmtPayment
     * @param tradeNo
     * @param notifyId
     * @return
     */
    public RemoteResult<String> callUpdate(PayOrder payOrder, MerchantPayPlatView merchantPayPlatView, String gmtPayment, String tradeNo, String notifyId, String outChannelType, String outChannelAmount);

    /**
     * 查询mongoOrder信息
     * @param request
     * @return
     */
    public  RemoteResult<PayPortalOrder> getPayPortalOrder(HttpServletRequest request);
}
