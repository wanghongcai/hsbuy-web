package com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

import java.io.IOException;
import java.util.Map;

/**
 * Created by caoxd2 on 2015/5/24.
 */
public interface CommonCallBackManager {

    /**
     * 根据支付类型和平台判断跳转中间件还是老商城逻辑
     * @param merchantPayPlatView  商户支付数据
     * @param platformCode   支付平台
     * @param signature    签名
     * @param orderCode    商城订单号
     * @param payOrderCode  交易订单号
     * @param payDatetime   支付时间
     * @param payment      支付类型
     * @param lenovoId     id
     * @param payTransactionNo  交易号
     * @return
     */
    public RemoteResult<String> payCallback(MerchantPayPlatView merchantPayPlatView, int platformCode, String signature, String orderCode, String payOrderCode, String payDatetime, String payment, String lenovoId, String payTransactionNo, PayOrder payOrder) throws Exception;


//    RemoteResult<String> updateChannelOrderForOutPay(PayOrder payOrder, String payType);

    /**
     * 取消支付宝交易
     * @param orderCode
     * @param faid
     * @param payType
     * @return
     * @throws IOException
     */
    public String cancelPayOrderForAli(String orderCode, String faid, String payType) throws IOException;

    /**
     * 根据支付宝通知支付平台ID获取原支付订单
     * @param id
     * @return
     */
    public PayOrder getPayOrderById(String id);

    /**
     * 根据ID查询支付平台信息
     * @param id
     * @return
     */
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatById(long id);

    /**
     * 更新通知状态
     * @param id
     * @param u_id
     * @param tradeNo
     * @param merchantFlag
     * @param notifyId
     * @param tradeSuccess
     * @param bankSeq
     * @param payType
     */
    public void updatePayNotifyState(Long id, String u_id, String tradeNo, int merchantFlag, String notifyId, int tradeSuccess, String bankSeq, int payType);

    /**
     * 根据Transaction获取原支付记录
     * @param transation_id
     * @return
     */
    public PayOrder getPayOrderByTransationId(String transation_id);

    /**
     * Call Middle Ware New
     * @param payPortalOrder channelOrder
     * @param payOrder payOrder
     * @param merchantPayPlatView merchantPayPlatView
     * @return RemoteResult
     */
    public RemoteResult<String> paidCallback(PayPortalOrder payPortalOrder, PayOrder payOrder, MerchantPayPlatView merchantPayPlatView, Map<String, String> paraMap);

    /**
     * Common Out Pay
     * @param payOrder
     * @param merchantPayPlatView
     * @param paraMap
     * @param commonParam
     * @return
     */
    public RemoteResult<String> callOutUpdate(PayOrder payOrder, MerchantPayPlatView merchantPayPlatView, Map<String, String> paraMap, Map<String, Object> commonParam);
}
