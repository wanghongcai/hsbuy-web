package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.HttpUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayConfig;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayNotify;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipaySubmit;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.XMLParser;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayTradeQueryManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.MerchantPayPlatManager;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by MengQiang on 2015/11/18.
 */
@Service
public class AliPayTradeQueryManagerImpl implements AliPayTradeQueryManager {
    private final Logger logger = Logger.getLogger(this.getClass());

    @Autowired
    private MerchantPayPlatManager merchantPayPlatManager;

    @Override
    public RemoteResult<Map<String, Object>> aliPayTradeQuery(PayOrder payOrder) {
        RemoteResult<Map<String, Object>> returnResult = new RemoteResult<Map<String, Object>>();
        RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult = new RemoteResult<MerchantPayPlatView>();
        Map<String, Object> orderInfoMap = new HashMap<String, Object>();
        try {
            //获取订单支付平台信息
            merchantPayPlatViewRemoteResult = merchantPayPlatManager.getMerchantPayPlatById(payOrder.getMerchant_id());
            if (merchantPayPlatViewRemoteResult.isSuccess()) {
                logger.info("查询支付宝支付平台信息成功==>" + merchantPayPlatViewRemoteResult.getT());
            } else {
                returnResult.setSuccess(false);
                returnResult.setResultMsg("查询支付宝支付订单平台信息失败");
                return returnResult;
            }
            logger.info("待查询支付宝交易信息==>" + payOrder);
            orderInfoMap = this.getTradeInfo(payOrder, merchantPayPlatViewRemoteResult.getT());
            logger.info("查询支付宝交易信息返回封装Map==>" + orderInfoMap);
            //支付宝返回交易标识，T代表成功 F代表失败
            if ("T".equals(orderInfoMap.get("is_success"))) {
                //验证签名
                boolean flag = this.checkSign(orderInfoMap, merchantPayPlatViewRemoteResult.getT());
                logger.info("支付平台订单==>" + payOrder.getId() + ",验证查询签名==>" + flag);
                if (flag) {
                    //处理查询成功，并且验签成功 TRADE_SUCCESS
                    returnResult.setSuccess(true);
                    returnResult.setResultMsg("查询成功");
                    returnResult.setT(orderInfoMap);
                } else {
                    //验签失败
                    logger.info("支付平台订单==>" + payOrder.getId() + "查询支付宝交易，验签失败");
                    returnResult.setSuccess(false);
                    returnResult.setResultMsg("验证签名失败");
                }
            } else if ("F".equals(orderInfoMap.get("is_success"))) {
                logger.info("支付平台订单==>" + payOrder.getId() + "查询失败，失败原因==>" + orderInfoMap.get("error"));
                returnResult.setSuccess(false);
                returnResult.setResultMsg((String) orderInfoMap.get("error"));
            } else {
                logger.info("支付平台订单==>" + payOrder.getId() + "支付宝反馈异常");
                returnResult.setSuccess(false);
                returnResult.setResultMsg("支付宝反馈异常");
            }
        } catch (Exception e) {
            logger.error("查询支付宝交易异常" ,e);
            returnResult.setSuccess(false);
            returnResult.setResultMsg("查询支付宝交易异常");
        }
        return returnResult;
    }

    /**
     * 验证签名
     *
     * @param resultMap
     * @param merchantPayPlatView
     * @return
     */
    private boolean checkSign(Map<String, Object> resultMap, MerchantPayPlatView merchantPayPlatView) {
        Map<String, String> checkMap = new HashMap<String, String>();
        for (Map.Entry<String, Object> entry : resultMap.entrySet()) {
            if (entry.getValue() == null || "is_success".equals(entry.getKey()) || "request".equals(entry.getKey()) || "response".equals(entry.getKey())) {
                continue;
            } else {
                checkMap.put(entry.getKey(), (String) entry.getValue());
            }
        }
        return AlipayNotify.getSignVeryfy(checkMap, checkMap.get("sign"), true, merchantPayPlatView.getSignKey());
    }

    /**
     * 调用支付宝接口查询交易
     *
     * @param payOrder
     * @param merchantPayPlatView
     * @return
     */
    private Map<String, Object> getTradeInfo(PayOrder payOrder, MerchantPayPlatView merchantPayPlatView) {
        Map<String, Object> propMap = PropertiesHelper.loadToMap("ali_pay.properties");
        String ALIPAY_GATEWAY_NEW = (String) propMap.get("ALIPAY_GATEWAY_NEW");
        StringBuffer stringBuffer = new StringBuffer();
        Map<String, String> sParaTemp = new HashMap<String, String>();
        sParaTemp.put("service", "single_trade_query");
        sParaTemp.put("partner", merchantPayPlatView.getMechId());
        sParaTemp.put("_input_charset", AlipayConfig.input_charset);
        //支付宝交易号
        //sParaTemp.put("trade_no", payOrder.getTransation_id());
        sParaTemp.put("out_trade_no", payOrder.getId().toString());
        String sign = AlipaySubmit.buildRequestMysign(sParaTemp, merchantPayPlatView.getSignKey());
        sParaTemp.put("sign", sign);
        sParaTemp.put("sign_type", AlipayConfig.sign_type);
        //logger.info("支付宝查询请求参数==>" + sParaTemp);
        stringBuffer.append(ALIPAY_GATEWAY_NEW).append("?");
        List<String> keys = new ArrayList<String>(sParaTemp.keySet());
        for (int i = 0; i < keys.size(); i++) {
            String key = keys.get(i);
            String value = sParaTemp.get(key);
            if (i == 0) {
                stringBuffer.append(key).append("=").append(value);
            } else {
                stringBuffer.append("&").append(key).append("=").append(value);
            }
        }
        logger.info("支付宝查询请求URL==>" + stringBuffer.toString());
        HttpGet post = new HttpGet(stringBuffer.toString());
        HttpResponse httpResponse = null;
        Map<String, Object> resultMap = new HashMap<String, Object>();
        BufferedReader bufferedReader = null;
        InputStreamReader content = null;
        try {
            httpResponse = HttpUtil.executeProxy(post);
            content = new InputStreamReader(httpResponse.getEntity().getContent());
            //logger.info("content==>" + content);
            bufferedReader = new BufferedReader(content);
            StringBuffer responseBuffer = new StringBuffer();
            String line = "";
            // 获取系统分行标准
            String NL = System.getProperty("line.separator");
            while ((line = bufferedReader.readLine()) != null) {
                responseBuffer.append(line + NL);
            }
            String responseStr = responseBuffer.toString();
            logger.info("支付宝返回交易详情==>" + responseStr);
            resultMap = XMLParser.getMapFromXML(responseStr);
            if ("T".equals(resultMap.get("is_success"))) {
                this.getMapFromXML(resultMap, responseStr);
            }
        } catch (Exception e) {
            logger.info("HTTP调用支付宝接口查询交易详情失败==>" + e);
            resultMap.put("is_success", "F");
            resultMap.put("error", "调用HTTP接口查询交易失败");
        } finally {
            try {
                bufferedReader.close();
                content.close();
            } catch (IOException e) {
                logger.error("文件流关闭失败",e);
            } finally {
                bufferedReader = null;
                content = null;
            }
        }
        return resultMap;
    }

    /**
     * 解析查询接口返回XML报文
     *
     * @param resultMap
     * @param responseStr
     */
    private void getMapFromXML(Map<String, Object> resultMap, String responseStr) {
        Document doc = null;
        try {
            doc = DocumentHelper.parseText(responseStr);
        } catch (DocumentException e) {
            e.printStackTrace();
        }
        Element rootElement = doc.getRootElement();
        List<Element> elements = rootElement.elements();
        List<Element> tradeElements = null;
        for (Element element : elements) {
            if ("response".equals(element.getName())) {
                Element trade = element.element("trade");
                tradeElements = trade.elements();
            }
        }
        if (tradeElements != null && tradeElements.size() > 0) {
            for (Element element : tradeElements) {
                resultMap.put(element.getName(), element.getTextTrim());
            }
        }
    }
}
