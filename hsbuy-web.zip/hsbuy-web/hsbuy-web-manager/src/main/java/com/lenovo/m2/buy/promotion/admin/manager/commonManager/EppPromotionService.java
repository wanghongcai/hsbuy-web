package com.lenovo.m2.buy.promotion.admin.manager.commonManager;

import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.SalesGoodsPromotionRoles;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.SessionUser;
import com.lenovo.m2.buy.promotion.admin.soa.utils.BaseInfo;

/**
 * Created by luqian on 2015-11-12.
 */
public interface EppPromotionService {



	BaseInfo update(Tenant tenant, SalesGoodsPromotionRoles role, String details, String groups, String groupName, SessionUser user);


}
