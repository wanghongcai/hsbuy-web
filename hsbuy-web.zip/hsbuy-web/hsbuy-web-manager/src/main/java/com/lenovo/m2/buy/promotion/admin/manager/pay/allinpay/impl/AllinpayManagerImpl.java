package com.lenovo.m2.buy.promotion.admin.manager.pay.allinpay.impl;

import com.allinpay.ets.client.PaymentResult;
import com.allinpay.ets.client.RequestOrder;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.LePayConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.LePayUtil;
import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;
import com.lenovo.m2.buy.promotion.admin.domain.pay.alipay.AllinpayModel;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.allinpay.AllinpayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonPayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.CashierManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayChannelBankApi;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.PayChannelBank;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import com.lenovo.m2.hsbuy.service.pay.soa.PayOrderService;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 支付宝WAP直连
 * Created by zhangqy10 on 2016/9/1.
 */
@Service
public class AllinpayManagerImpl implements AllinpayManager {
    private final Logger LOGGER = Logger.getLogger(this.getClass());

    @Autowired
    private CommonPayManager commonPayManager;
    @Autowired
    private CommonCallBackManager commonCallBackManager;
    @Autowired
    private AliPayCommonManager aliPayCommonManager;
    @Autowired
    private CashierManager cashierManager;
    @Autowired
    private PayOrderApi payOrderApi;
    @Autowired
    private CommonManager commonManager;
    @Autowired
    private PayPortalOrderManager payPortalOrderManager;
    @Autowired
    private PayChannelBankApi payChannelBankApi;
    @Autowired
    private PayOrderService payOrderService; // 为记录是B2C/B2B渠道支付

    @Override
    public RemoteResult<String> toPay(HttpServletRequest request) {

        RemoteResult<String> returnResult = new RemoteResult<String>();
        AllinpayModel allinpayModel = (AllinpayModel) BaseModel.getModel(request);
        String tradeInfo = request.getParameter("trade_info");
        boolean isTest = aliPayCommonManager.isTestPay("isAllinPayTest");

        Map<String, String> tradeMap = null;
        try {
            tradeMap = LePayUtil.parseTradeInfo(tradeInfo);
        } catch (Exception e) {
            LOGGER.info("AllinpayManagerImpl nvoke toUmPay parseTradeInfo error!Exception :" + e);
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "错误的支付请求参数");
            return returnResult;
        }
        // 直连网银
        String accountType = tradeMap.get("account_type");
        String bankType = tradeMap.get("bank_type");
        String bankNo = tradeMap.get("bank_code");
        String cardType = tradeMap.get("card_type");
        String lenovoId = tradeMap.get("lenovo_id");
        //公共参数
        String orderCode = allinpayModel.getOrderMainCode();
        String payType = allinpayModel.getPayType();
        String merchantCode = allinpayModel.getMerchantCode();
        String shopId = allinpayModel.getShopId();
        String terminal = allinpayModel.getTerminal();

        if (StringUtils.isEmpty(orderCode) || StringUtils.isEmpty(payType) || StringUtils.isEmpty(merchantCode) || StringUtils.isEmpty(shopId) || StringUtils.isEmpty(terminal) || StringUtils.isEmpty(lenovoId)) {
            LOGGER.info("Invoke toPay parms error," +
                    "orderCode [" + orderCode + "],payType [" + payType + "],merchantCode [" + merchantCode + "],shopId [" + shopId + "],terminal [" + terminal + "],lenovoId [" + lenovoId + "]");
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "错误的支付请求参数");
            return returnResult;
        }

        // 是否直连网银
        if (PeakConstant.PAY_TYPE_ALLINPAY.equals(payType) && StringUtils.isNotEmpty(accountType) && StringUtils.isNotEmpty(bankNo) && StringUtils.isNotEmpty(cardType)) {
            LOGGER.info("Is Allinpay Direct E-Bank,payType [" + payType + "],accountType [" + accountType + "],bankNo [" + bankNo + "],cardType [" + cardType + "]");
            if (isTest){
                allinpayModel.setBankCode("vbank");  // 用于测试
            }else {
                RemoteResult<PayChannelBank> hsPayplatBankRemoteResult = payChannelBankApi.queryPayChannelBankByParams(Integer.parseInt(payType), Integer.parseInt(bankNo), Integer.parseInt(bankType), null);
                if (hsPayplatBankRemoteResult.isSuccess()) {
                    String payCode = hsPayplatBankRemoteResult.getT().getPayCode();
                    LOGGER.info("通联支付直连网银获取到银行代码:" + payCode);
                    allinpayModel.setBankCode(payCode);
                } else {
                    LOGGER.info("通联支付直连网银数据查询失败！");
                    CommonMethod.getRemoteResult(returnResult, "", false, "400", "银行数据查询失败");
                    return returnResult;
                }
            }
            allinpayModel.setAccountType(accountType);
            allinpayModel.setBankNo(bankNo);
            allinpayModel.setCardType(cardType);
        }

        try {
            Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
            RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByShowTradeNo(orderCode, null, tenant);
            PayPortalOrder payPortalOrder = null;
            if (payPortalOrderRemoteResult.isSuccess()) {
                payPortalOrder = payPortalOrderRemoteResult.getT();
                if (payPortalOrder == null || payPortalOrder.getOutTradeNo() == null) {
                    LOGGER.info("Invoke queryChannelOrderCodeDetail Get PayPortalOrder IS NULL，orderMainCode [" + orderCode + "]");
                    CommonMethod.getRemoteResult(returnResult, "", false, "400", "未查到支付订单数据");
                    return returnResult;
                }
            }else {
                LOGGER.info("PingAn Pay Get payPortalOrder Fail, outTradeNo[" + orderCode + "]");
                CommonMethod.getRemoteResult(returnResult, "", false, "400", "未查到支付订单数据");
                return returnResult;
            }

            String currencyCode = payPortalOrder.getCurrencyCode();
            RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult = null;
            MerchantPayPlatView merchantPayPlatView = null;
            try {
                if (PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(payPortalOrder.getPayStatus()))) {
                    LOGGER.info("Check PayPortalOrder Already PAY, OrderMainCode [" + orderCode + "]");
                    CommonMethod.getRemoteResult(returnResult, "", false, "400", "订单已支付，请到订单列表页确认");
                    return returnResult;
                }
                if (PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(payPortalOrder.getOrderStatus()))) {
                    LOGGER.info("Check PayPortalOrder OrderStatus FAIL, OrderMainCode [" + orderCode + "]");
                    CommonMethod.getRemoteResult(returnResult, "", false, "400", "订单已失效，请到订单列表页确认");
                    return returnResult;
                }
                merchantPayPlatViewRemoteResult = commonPayManager.getMerchantPayPlatByAccountType(payPortalOrder.getFaId(), payType,Integer.parseInt(accountType));
                if (merchantPayPlatViewRemoteResult != null && merchantPayPlatViewRemoteResult.isSuccess()) {
                    merchantPayPlatView = merchantPayPlatViewRemoteResult.getT();
                    if (merchantPayPlatView == null || merchantPayPlatView.getId() <= 0) {
                        LOGGER.info("getMerchantPayPlat FAIL，FaId [" + payPortalOrder.getFaId() + "]");
                        CommonMethod.getRemoteResult(returnResult, "", false, "400", "商户信息查询失败");
                        return returnResult;
                    }
                    LOGGER.info("MerchantPayPlat INFO [" + merchantPayPlatView + "]");
                } else {
                    LOGGER.info("Get MerchantPayPlat FAIL，OrderMainCode [" + orderCode + "]");
                    CommonMethod.getRemoteResult(returnResult, "", false, "400", "商户信息查询失败");
                    return returnResult;
                }
            } catch (Exception e) {
                LOGGER.error("通联支付异常!Exception :" + e);
                CommonMethod.getRemoteResult(returnResult, "", false, "400", "支付服务异常");
                return returnResult;
            }
            String bodyHtml = null;
            String orderPrimaryId = null;
            RemoteResult<String> savePayOrderResult;
            RemoteResult<List<PayOrder>> orderListResult = aliPayCommonManager.getOrderListByPayType(orderCode, Integer.parseInt(payType));
            if (orderListResult.isSuccess() && orderListResult.getT().size() > 0) {
                orderPrimaryId = String.valueOf(orderListResult.getT().get(0).getId());
                LOGGER.info("Allinpay Pay PayOrder Already EXIST，OrderPrimaryID [" + orderPrimaryId + "]");
                for (PayOrder payOrder : orderListResult.getT()) {
                    payOrderApi.updatePayOrderShopIdTerminal(String.valueOf(payOrder.getId()),allinpayModel.getPlat(), allinpayModel.getShopId(),allinpayModel.getTerminal());
                }
            } else {
                savePayOrderResult = commonManager.savePayOrder(lenovoId, allinpayModel.getPlat(), payType, orderCode, String.valueOf(payPortalOrder.getTotalFee().getAmount()),
                        payPortalOrder.getSubject(), "0", 0, "0", merchantCode, bankNo, shopId, terminal, merchantPayPlatView, currencyCode);
                if (!savePayOrderResult.isSuccess()) {
                    LOGGER.warn("Save PayOrder FAIL, OrderMainCode [" + orderCode + "]");
                    CommonMethod.getRemoteResult(returnResult, "", false, "400", "保存订单信息失败");
                    return returnResult;
                }
                LOGGER.info("Save PayOrder SUCCESS, OrderMainCode [" + orderCode + "]");
                orderPrimaryId = savePayOrderResult.getT();
                LOGGER.info("Allinpay Pay PayOrder NOT EXIST, New OrderPrimaryID [" + orderPrimaryId + "]");
            }
            if (StringUtils.isEmpty(accountType)){
                accountType = "0";
            }
            int flag = payOrderService.updatePayBankByID(orderPrimaryId,bankNo,Integer.parseInt(accountType));
            if (flag <1){
                LOGGER.info("execute updatePayBankByID failure!");
            }
            // 扩展参数
            bodyHtml = buildAllinpayPlatHtml(allinpayModel, orderPrimaryId, payPortalOrder.getSubject(), payPortalOrder, merchantPayPlatView, payType, lenovoId,isTest,bankType);
            if (StringUtils.isNotEmpty(bodyHtml)) {
                CommonMethod.getRemoteResult(returnResult, bodyHtml, true, "200", "构建请求HTML成功");
                return returnResult;
            } else {
                CommonMethod.getRemoteResult(returnResult, bodyHtml, false, "400", "构建请求HTML失败");
                return returnResult;
            }
        } catch (Exception e) {
            LOGGER.info("保存订单或构建HTML表单异常!Exception :" + e);
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "支付服务异常");
            return returnResult;
        }
    }

    private String buildAllinpayPlatHtml(AllinpayModel allinpayModel, String orderPrimaryId, String productName, PayPortalOrder payPortalOrder, MerchantPayPlatView merchantPayPlatView, String payType, String lenovoId,boolean isTest,String bankType) {
        String returnStr = null;
        String url = "";
        try {
            LOGGER.info("Invoke buildAllinpayPlatHtml OrderPrimaryId[" + orderPrimaryId + "],ProductName[" + productName + "],PayPortalOrder[" + payPortalOrder + "],merchantPayPlatView[" + merchantPayPlatView + "]");
            LinkedHashMap<String, String> postMap = new LinkedHashMap<String, String>();
            postMap.put("inputCharset", "1");//utf8
            postMap.put("pickupUrl", merchantPayPlatView.getOutCallBackUrl());//同步回调
            postMap.put("receiveUrl", merchantPayPlatView.getOutNotifyUrl());//异步回调
            String version = aliPayCommonManager.getAliPropValue("allinpay_version");
            if (StringUtils.isEmpty(version)){
                version = LePayConstant.ALLINPAY_VERSION;
            }
            postMap.put("version", version);//没有特殊需求，默认1.0
            postMap.put("signType", "1");//签名类型，商户用使用MD5算法验签上送订单，通联交易结果通知使用证书签名
            postMap.put("merchantId", merchantPayPlatView.getMechId());
            if (StringUtils.isNotEmpty(payPortalOrder.getMemberCode())) {
                postMap.put("payerName", payPortalOrder.getMemberCode());//付款人姓名
            }
            postMap.put("orderNo", orderPrimaryId);//商户订单号
            BigDecimal bigDecimal1 = payPortalOrder.getTotalFee().getAmount();
            BigDecimal bigDecimal2 = new BigDecimal(Double.valueOf(100));
            postMap.put("orderAmount", String.valueOf(bigDecimal1.multiply(bigDecimal2).longValue()));//订单金额
            postMap.put("orderCurrency", "0");//币种 CNY
            postMap.put("orderDatetime", LePayUtil.getDate());//商户提交订单时间
            String subject = LePayUtil.replaceSpecStr(payPortalOrder.getSubject());
            if (subject.length() > 60) {
                subject = subject.substring(0,60);
            }
            postMap.put("productName", subject);//商品名称
            if (PeakConstant.PAY_TYPE_ALLINPAY_AUTH_PAY.equals(payType)) {  // 认证支付
                if (isTest){
                    url = aliPayCommonManager.getAliPropValue("allinpay_auth_pay_uat");
                }else {
                    url = aliPayCommonManager.getAliPropValue("allinpay_auth_pay_pro");
                }
                postMap.put("ext1", "支持借记卡和信用卡的认证支付");// 回调原样返回
                postMap.put("payType", "27");//支持借记卡和信用卡的认证支付
                postMap.put("ext2", PeakConstant.TERMINAL_WAP);// 用户字段
            } else if (PeakConstant.PAY_TYPE_ALLINPAY.equals(payType) && PeakConstant.TERMINAL_PC.equals(allinpayModel.getTerminal())) {
                // 直连网银
                if (StringUtils.isNotEmpty(allinpayModel.getBankNo()) && StringUtils.isNotEmpty(allinpayModel.getAccountType())) {
                    if (String.valueOf(PeakConstant.BANK_TYPE_B2C).equals(bankType)){  // B2C
                        if (LePayConstant.CARD_TYPE_DEBIT.equals(Integer.parseInt(allinpayModel.getCardType()))){
                            postMap.put("payType", LePayConstant.ALLINPAY_B2C_D); // 借记卡
                        }else {
                            postMap.put("payType", LePayConstant.ALLINPAY_B2C_C); // 信用卡
                        }
                    }else {// B2B
                        postMap.put("payType", LePayConstant.ALLINPAY_B2B); // B2B网银
                    }
                    postMap.put("issuerId", allinpayModel.getBankCode());  // 发卡机构代码
                } else {  // 非直连
                    postMap.put("payType", "4");//选择支持的支付类型：企业网银支付
                }
                if (isTest){
                    url = aliPayCommonManager.getAliPropValue("allinpay_gateway_pay_uat");
                }else {
                    url = aliPayCommonManager.getAliPropValue("allinpay_gateway_pay_pro");
                }
                postMap.put("ext2", PeakConstant.TERMINAL_PC);//商品名称
            } else if (PeakConstant.PAY_TYPE_ALLINPAY_SHORTCUT.equals(payType)) {
                postMap.put("payType", "33");//选择支持的支付类型： 手机网页H5快捷支付
                postMap.put("ext2", PeakConstant.TERMINAL_WAP);//商品名称
                String userId = getUserId(merchantPayPlatView, lenovoId);
                if (StringUtils.isNotEmpty(userId)) {
                    postMap.put("ext1", "<USER>" + userId + "</USER>");
                }
                url = aliPayCommonManager.getAliPropValue("allinpay_h5_shortcut_pro");
            } else {
                LOGGER.info("Unable to resolve current payType! payType=" + payType);
                return null;
            }

            RequestOrder requestOrder = getRequestOrder(postMap, merchantPayPlatView);
            LOGGER.info("通联payType=" + payType + ",签名明文:" + requestOrder.getSrc());
            postMap.put("signMsg", requestOrder.doSign());//签名串
            returnStr = LePayUtil.buildRequestFrom(postMap, url, "post");
        } catch (Exception e) {
            LOGGER.info("通联支付要素构建异常!Exception :" + e);
            return null;
        }
        return returnStr;
    }

    private RequestOrder getRequestOrder(Map<String, String> postMap, MerchantPayPlatView merchantPayPlatView) {
        RequestOrder requestOrder = new RequestOrder();
        requestOrder.setInputCharset(Integer.parseInt(postMap.get("inputCharset")));
        requestOrder.setPickupUrl(postMap.get("pickupUrl"));
        requestOrder.setReceiveUrl(postMap.get("receiveUrl"));
        requestOrder.setVersion(postMap.get("version"));
        requestOrder.setSignType(Integer.parseInt(postMap.get("signType")));
        requestOrder.setMerchantId(merchantPayPlatView.getMechId());
        if (StringUtils.isNotEmpty(postMap.get("payerName"))) {
            requestOrder.setPayerName(postMap.get("payerName"));
        }
        requestOrder.setOrderNo(postMap.get("orderNo"));
        requestOrder.setOrderAmount(Long.valueOf(postMap.get("orderAmount")));
        requestOrder.setOrderCurrency(postMap.get("orderCurrency"));
        requestOrder.setOrderDatetime(postMap.get("orderDatetime"));
        requestOrder.setProductName(postMap.get("productName"));
        if (StringUtils.isNotEmpty(postMap.get("ext1"))) {
            requestOrder.setExt1(postMap.get("ext1"));
        }
        if (StringUtils.isNotEmpty(postMap.get("ext2"))) {
            requestOrder.setExt2(postMap.get("ext2"));
        }
        requestOrder.setPayType(Integer.parseInt(postMap.get("payType")));
        requestOrder.setIssuerId(postMap.get("issuerId"));
        requestOrder.setKey(merchantPayPlatView.getSignKey()); //key为MD5密钥，密钥是在通联支付网关会员服务网站上设置。

        return requestOrder;
    }

    public boolean verifyNotify(HttpServletRequest request, MerchantPayPlatView merchantPayPlatView,String certPath) {

        String merchantId = request.getParameter("merchantId");
        String version = request.getParameter("version");
        String language = request.getParameter("language");
        String signType = request.getParameter("signType");
        String payType = request.getParameter("payType");
        String issuerId = request.getParameter("issuerId");
        String paymentOrderId = request.getParameter("paymentOrderId");
        String orderNo = request.getParameter("orderNo");
        String orderDatetime = request.getParameter("orderDatetime");
        String orderAmount = request.getParameter("orderAmount");
        String payDatetime = request.getParameter("payDatetime");
        String payAmount = request.getParameter("payAmount");
        String ext1 = request.getParameter("ext1");
        String ext2 = request.getParameter("ext2");
        String payResult = request.getParameter("payResult");
        String errorCode = request.getParameter("errorCode");
        String returnDatetime = request.getParameter("returnDatetime");
        String signMsg = request.getParameter("signMsg");

        //验签是商户为了验证接收到的报文数据确实是支付网关发送的。
        //构造订单结果对象，验证签名。
        PaymentResult paymentResult = new PaymentResult();
        if (StringUtils.isNotEmpty(merchantId)) {
            paymentResult.setMerchantId(merchantId);
        }
        if (StringUtils.isNotEmpty(version)) {
            paymentResult.setVersion(version);
        }
        if (StringUtils.isNotEmpty(language)) {
            paymentResult.setLanguage(language);
        }
        if (StringUtils.isNotEmpty(signType)) {
            paymentResult.setSignType(signType);
        }
        if (StringUtils.isNotEmpty(payType)) {
            paymentResult.setPayType(payType);
        }
        if (StringUtils.isNotEmpty(issuerId)) {
            paymentResult.setIssuerId(issuerId);
        }
        if (StringUtils.isNotEmpty(paymentOrderId)) {
            paymentResult.setPaymentOrderId(paymentOrderId);
        }
        if (StringUtils.isNotEmpty(orderNo)) {
            paymentResult.setOrderNo(orderNo);
        }
        if (StringUtils.isNotEmpty(orderDatetime)) {
            paymentResult.setOrderDatetime(orderDatetime);
        }
        if (StringUtils.isNotEmpty(orderAmount)) {
            paymentResult.setOrderAmount(orderAmount);
        }
        if (StringUtils.isNotEmpty(payDatetime)) {
            paymentResult.setPayDatetime(payDatetime);
        }
        if (StringUtils.isNotEmpty(payAmount)) {
            paymentResult.setPayAmount(payAmount);
        }
        if (StringUtils.isNotEmpty(ext1)) {
            paymentResult.setExt1(ext1);
        }
        if (StringUtils.isNotEmpty(ext2)) {
            paymentResult.setExt2(ext2);
        }
        if (StringUtils.isNotEmpty(payResult)) {
            paymentResult.setPayResult(payResult);
        }
        if (StringUtils.isNotEmpty(errorCode)) {
            paymentResult.setErrorCode(errorCode);
        }
        if (StringUtils.isNotEmpty(payDatetime)) {
            paymentResult.setReturnDatetime(returnDatetime);
        }

        //signMsg为服务器端返回的签名值。
        paymentResult.setSignMsg(signMsg);
        //signType为"1"时，必须设置证书路径。
        paymentResult.setCertPath(certPath);

        //验证签名：返回true代表验签成功；否则验签失败。
        return paymentResult.verify();
    }

    /**
     * 校验订单状态，防止重复通知
     *
     * @param payOrder payOrder
     * @return boolean
     */
    private boolean checkStatus(PayOrder payOrder) {
        boolean flag = false;
        if (null != payOrder.getMerchant_flag() && null != payOrder.getTrade_state() && payOrder.getMerchant_flag() == 1 && payOrder.getTrade_state() == 1) {
            flag = true;
        }
        return flag;
    }

    /**
     * 获取UserID
     *
     * @param merchantPayPlatView
     * @param lenovoId
     * @return
     */
    public String getUserId(MerchantPayPlatView merchantPayPlatView, String lenovoId) {
        Map<String, String> registerMap = new LinkedHashMap<String, String>();
        registerMap.put("signType", "0");
        registerMap.put("merchantId", merchantPayPlatView.getMechId());
        registerMap.put("partnerUserId", lenovoId.toLowerCase());
        registerMap.put("key", merchantPayPlatView.getSignKey());
        StringBuffer sb = new StringBuffer();
        for (Map.Entry<String, String> entry : registerMap.entrySet()) {
            sb.append("&" + entry.getKey()).append("=").append(entry.getValue());
        }
        sb.append("&");
        System.out.println(sb.toString());
        String signMsg = LePayUtil.MD5Encode(sb.toString());
        registerMap.put("signMsg", signMsg);
        String result = null;
        try {
            String url = aliPayCommonManager.getAliPropValue("allinpay_user_register_pro");
            result = LePayUtil.sendHttpPost(url, registerMap);
        } catch (Exception e) {
            LOGGER.info("Allinpay H5 shortcut Pay getUserId Error!Exception :" + e);
        }
        String userId = LePayUtil.jsonToMap(result).get("userId");
        return userId;
    }
}
