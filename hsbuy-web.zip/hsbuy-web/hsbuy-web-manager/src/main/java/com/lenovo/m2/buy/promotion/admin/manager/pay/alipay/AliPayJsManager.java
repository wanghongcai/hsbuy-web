package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.manager.GenericManager;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by zhanglijun on 2015/5/21.
 */
public interface AliPayJsManager extends GenericManager<PayOrder, Long> {

    /**
     *更新支付订单
     * @param lenovoId
     * @param trade_no
     * @param gmt_payment
     * @param merchantCode
     * @param payType
     */
    public RemoteResult<String> callUpdate(String lenovoId, String orderPrimaryId, String trade_no, String gmt_payment, String merchantCode, String payType, MerchantPayPlatView merchantPayPlatView, String notifyId, String buyer_email);

    /**
     * 支付宝即时业务Manager
     * @param request
     * @return
     */
    public RemoteResult toAliJsPay(HttpServletRequest request);

}
