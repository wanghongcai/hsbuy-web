package com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.PayPointRulesManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayPointRulesApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayPointRules;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by jh on 2017/8/10.
 */
@Service
public class PayPointRulesManagerImpl implements PayPointRulesManager {
    private final Logger logger = Logger.getLogger(this.getClass());
    @Autowired
    private PayPointRulesApi payPointRulesApi;

    @Override
    public RemoteResult<PayPointRules> getPayPointRulesByfaId(String faId) {
        return payPointRulesApi.getPayPointRulesByfaId(faId);
    }

    public PayPointRulesApi getPayPointRulesApi() {
        return payPointRulesApi;
    }

    public void setPayPointRulesApi(PayPointRulesApi payPointRulesApi) {
        this.payPointRulesApi = payPointRulesApi;
    }
}
