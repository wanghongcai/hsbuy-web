package com.lenovo.m2.buy.promotion.admin.manager.pay.wxpay.impl;


import com.alibaba.dubbo.common.utils.StringUtils;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.JacksonUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PayConfig;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.ReturnCode;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.*;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.wxpay.WxPayCommonManager;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import com.lenovo.m2.buy.promotion.admin.domain.pay.order.MongoOrder;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by luqian on 2015-07-22.
 */
@Service
public class WxPayCommonManagerImpl implements WxPayCommonManager {
    Logger logger = Logger.getLogger(this.getClass());
    @Autowired
    private AliPayCommonManager aliPayCommonManager;
    @Autowired
    private CommonManager commonManager;

    public Map<String, Object> sendHttpPost(String url, String realm) {
        logger.info("post-url" + url);
        Map<String, Object> paramMap = new HashMap<String, Object>();
        if ("weixin.lenovo.com.cn".equals(realm)) {
            paramMap.put("realm", realm);
            realm = JacksonUtil.toJson(paramMap);
        }
        logger.info("param=" + realm);
        Map<String, Object> orderMap = null;
        try {
            String json = HttpClientUtil.executeHttpPost(url, realm);
            logger.info("微信支付post请求返回json=" + json);
            orderMap = JacksonUtil.toObjectMap(json);
        } catch (Exception e) {
            logger.info("微信支付post请求返回的信息异常" + e);
        }
        return orderMap;
    }

    @Override
    public RemoteResult<MongoOrder> getMchOrderInfo(String orderCode, String lenovoId, String plat, String merchantOrderUrl) {
        RemoteResult<MongoOrder> returnResult = new RemoteResult<MongoOrder>();
        returnResult.setSuccess(true);
        MongoOrder mongoOrder = null;
        returnResult.setT(mongoOrder);
        if (mongoOrder == null || mongoOrder.getOrderCode() == null) {
            logger.warn("查询支付订单信息异常");
            returnResult.setSuccess(false);
            returnResult.setResultCode("30003");
            returnResult.setResultMsg("查询支付订单信息异常");
            return returnResult;
        }
        if (aliPayCommonManager.checkPay(String.valueOf(mongoOrder.getPayStatus()))) {
            logger.info(mongoOrder.getPayStatus());
            returnResult.setSuccess(false);
            returnResult.setResultCode("30004");
            returnResult.setResultMsg("订单已支付");
            return returnResult;
        }
        if (aliPayCommonManager.checkOrderStatus(mongoOrder.getOrderStatus())) {
            logger.info("订单状态：" + mongoOrder.getPayStatus());
            returnResult.setSuccess(false);
            returnResult.setResultCode("30005");
            returnResult.setResultMsg("订单已失效");
            return returnResult;
        }
        return returnResult;
    }

    public static Map<String, Object> sendHttpPosts(String url, String realm) {
        System.out.println("post--url==" + url);
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("realm", realm);
        String param = JacksonUtil.toJson(paramMap);
        Map<String, Object> orderMap = null;
        try {
            String json = HttpClientUtil.executeHttpPost(url, param);
            orderMap = JacksonUtil.toObjectMap(json);
            Map<String, Object> map = (Map<String, Object>) orderMap.get("data");
            System.out.println(map.get("access_token"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderMap;
    }

    public String getAccessToken() {
        Map<String, Object> wxResourceMap = PropertiesHelper.loadToMap("wx_pay.properties");
        String getAccessTokenUrl = (String) wxResourceMap.get("getAccessTokenUrl");
        String realm = (String) wxResourceMap.get("realm");
        logger.info("getAccessTokenUrl" + getAccessTokenUrl + "----" + "realm" + realm);
        Map<String, Object> authResult = sendHttpPost(getAccessTokenUrl, realm);
        Map<String, String> map = (Map<String, String>) authResult.get("data");
        String accessToken = map.get("access_token");
        return accessToken;
    }

    public String sendLenovoCashierJson(MerchantPayPlatView merchantPayPlatView, String proName, String total_fee, String accessTokrn, String createIp, String orderCode, String openid, String wxPayType, String productCode, int isGetOrderCode, String proNum) {
        Map<String, String> sParaTemp = new HashMap<String, String>();
        if (isGetOrderCode == 0) {
            sParaTemp.put("appid", merchantPayPlatView.getAppId());
            sParaTemp.put("mch_id", merchantPayPlatView.getMechId());
            sParaTemp.put("key", merchantPayPlatView.getSignKey());
            sParaTemp.put("body", proName);
            sParaTemp.put("total_fee", total_fee);
            sParaTemp.put("spbill_create_ip", createIp);
            if (PeakConstant.PLAT_PC.equals(wxPayType)) {
                sParaTemp.put("trade_type", "NATIVE");
                sParaTemp.put("product_id", productCode);
                sParaTemp.put("device_info", "WEB");
            } else {
                sParaTemp.put("trade_type", "JSAPI");
                sParaTemp.put("openid", openid);
            }
            sParaTemp.put("paymentType", "Wx");
            sParaTemp.put("access_token", accessTokrn);
            sParaTemp.put("out_trade_no", orderCode);
        } else {
            sParaTemp.put("body", proName);
            sParaTemp.put("total_fee", total_fee);
            sParaTemp.put("source_from", "weixin");
            sParaTemp.put("goods_num", proNum);
            sParaTemp.put("product_id", productCode);
            sParaTemp.put("access_token", accessTokrn);
            sParaTemp.put("local_callback_url", "http://qas-pay.fm365.com/pay.jhtm");
        }

        return JacksonUtil.toJson(sParaTemp);
    }

    @Override
    public Boolean wxPayWay(HttpServletRequest request) {
        String paymentTypeCode = request.getParameter("paymentTypeCode");
        String plat = request.getParameter("plat");
        String lenovoId = request.getParameter("lenovoId");
        String shopId = request.getParameter("shopId");
        String terminal = request.getParameter("terminal");
        Boolean flag = false;
        logger.info("校验微信支付入参:paymentTypeCode[" + paymentTypeCode + "],plat[" + plat + "],lenovoId[" + lenovoId + "],shopId[" + shopId + "],terminal[" + terminal + "]");
        if (Util.isNull(paymentTypeCode)) {
            flag = true;
        }
        return flag;
    }


    public Map<String, Object> getOrderCode(MerchantPayPlatView merchantPayPlatView, String productName, String total_fee, String accessTokrn, String createIp, String orderCode, String openid, String plat, String productCode, int isGetOrderCode, String proNum) {
        Map<String, Object> resouceMap = PayConfig.loadToMap();
        String createOrderUrl = (String) resouceMap.get("createOrderUrl");
        String getOrderCodeJosn = sendLenovoCashierJson(merchantPayPlatView, productName, total_fee, accessTokrn, createIp, orderCode, openid, plat, productCode, PeakConstant.GETORDERCODE_TRUE, proNum);
        Map<String, Object> returnMap = sendHttpPost(createOrderUrl, getOrderCodeJosn);
        System.out.println("returnMap=" + returnMap);
        return returnMap;
    }

    @Override
    public RemoteResult<Map<String, Object>> getMWebUrl(MerchantPayPlatView merchantPayPlatView, PayPortalOrder payPortalOrder, Map<String, Object> resouceMap, String orderMainCode, String merchantCode, String os, String payType, String lenovoId, String strClientIP, String productName, String shopId, String terminal) {
        return null;
    }

    public RemoteResult<Map<String, Object>> getCodeUrl(MerchantPayPlatView merchantPayPlatView, PayPortalOrder payPortalOrder, Map<String, Object> resouceMap, String orderId, String merchantCode, String os, String payType, String lenovoId, String spbillCreateIp, String productName, String shopId, String terminal) {
        RemoteResult<Map<String, Object>> result = new RemoteResult<Map<String, Object>>();
        result.setSuccess(true);
        String wx_notify_url = merchantPayPlatView.getOutNotifyUrl();
        String wx_appid = merchantPayPlatView.getAppId();
        String wx_mch_id = merchantPayPlatView.getMechId();
        if (payPortalOrder == null || payPortalOrder.getOutTradeNo() == null) {
            logger.warn("查询支付订单信息异常");
            result.setSuccess(false);
            result.setResultCode("30003");
            result.setResultMsg("查询支付订单信息异常");
            return result;
        }
        if (PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(payPortalOrder.getPayStatus()))) {
            logger.info("Check PayPortalOrder Already PAY, outTradeNo [" + payPortalOrder.getOutTradeNo() + "]");
            result.setSuccess(false);
            result.setResultCode("30008");
            result.setResultMsg("订单已支付");
            return result;
        }
        if (PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(payPortalOrder.getOrderStatus()))) {
            logger.info("Check PayPortalOrder OrderStatus FAIL, outTradeNo [" + payPortalOrder.getOutTradeNo() + "]");
            result.setSuccess(false);
            result.setResultCode("30009");
            result.setResultMsg("订单已失效");
            return result;
        }
        String total_fee = Util.getMoney(String.valueOf(payPortalOrder.getTotalFee().getAmount()));
        String payOrderTotalFee = String.valueOf(payPortalOrder.getTotalFee().getAmount());
        String currencyCode = payPortalOrder.getCurrencyCode();
        logger.info("订单金额==>" + total_fee);

        RemoteResult<List<PayOrder>> orderListResult = new RemoteResult<List<PayOrder>>();
        String orderPrimaryId;
        try {
            orderListResult = aliPayCommonManager.getOrderListByPayType(orderId, Integer.parseInt(payType));
        } catch (Exception e) {
            logger.error("Check WeChat Native/H5 PayOrder Exist FAIL，OrderMainCode[" + orderId + "]");
        }
        if (orderListResult != null && orderListResult.isSuccess() && orderListResult.getT().size() > 0) {
            orderPrimaryId = String.valueOf(orderListResult.getT().get(0).getId());
            logger.info("Check WeChat Native/H5 PayOrder ALREADY EXIST ,orderPrimaryId[" + orderPrimaryId + "]");
        } else {
            RemoteResult<String> remoteResult = commonManager.savePayOrder(lenovoId,os,payType,orderId,payOrderTotalFee,productName,"",0,"",merchantCode,"",shopId,terminal,merchantPayPlatView,currencyCode);
            if (!remoteResult.isSuccess()) {
                logger.warn("Save WeChat Native/H5 PayOrder FAIL");
                result.setSuccess(false);
                result.setResultCode("30004");
                result.setResultMsg("保存订单信息失败");
                return result;
            }
            orderPrimaryId = remoteResult.getT().toString();
            logger.info("Save WeChat Native/H5 PayOrder SUCCESS, orderPrimaryId[" + orderPrimaryId + "]");
        }
        StringBuffer attachBuffer = new StringBuffer();
        if(StringUtils.isNotEmpty(lenovoId)){
            attachBuffer.append("lenovoId=" + lenovoId + ",");
        }
        if(StringUtils.isNotEmpty(shopId)){
            attachBuffer.append("shopId=" + shopId);
        }
        logger.info("请求参数body==>" + productName);
        String nonce_str = Util.get_nonce_str();
        String spbill_create_ip = spbillCreateIp;
        String notify_url = wx_notify_url + "data=" + payPortalOrder.getFaId() + "," + payType;
        logger.info("微信扫码/H5支付，异步回调支付平台URL==>" + notify_url);
        logger.info("appId==>" + wx_appid);
        logger.info("mechId==>" + wx_mch_id);
        String trade_type;
        if(PeakConstant.PAY_TYPE_WECHAT.equals(payType)){
            trade_type = "NATIVE";
        }else if(PeakConstant.PAY_TYPE_WECHAT_H5.equals(payType)){
            trade_type = "MWEB";
        }else if (PeakConstant.PAY_TYPE_WECHAT_APPLET.equals(payType)){
            trade_type = "JSAPI";
        } else{
            trade_type = "NATIVE";
        }
        String attach = attachBuffer.toString();
        Map<String, Object> packageParams = new HashMap<String, Object>();
        packageParams.put("appid", wx_appid);
        packageParams.put("mch_id", wx_mch_id);
        packageParams.put("nonce_str", nonce_str);
        packageParams.put("body", productName);
        packageParams.put("attach", attach);
        packageParams.put("out_trade_no", orderPrimaryId);
        packageParams.put("total_fee", total_fee);
        packageParams.put("spbill_create_ip", spbill_create_ip);
        packageParams.put("notify_url", notify_url);
        packageParams.put("trade_type", trade_type);
        String sign = Signature.getSign(packageParams, merchantPayPlatView.getSignKey());
        logger.info("微信扫码/H5支付签名SIGN==>" + sign);
        StringBuffer sb = new StringBuffer();
        sb.append("<xml>");
        sb.append(" <appid>" + wx_appid + "</appid>");
        sb.append(" <mch_id>" + wx_mch_id + "</mch_id>");
        sb.append(" <nonce_str>" + nonce_str + "</nonce_str>");
        sb.append(" <body>" + productName + "</body>");
        sb.append(" <attach>" + attach + "</attach>");
        sb.append(" <out_trade_no>" + orderPrimaryId + "</out_trade_no>");
        sb.append(" <total_fee>" + total_fee + "</total_fee>");
        sb.append(" <spbill_create_ip>" + spbill_create_ip + "</spbill_create_ip>");
        sb.append(" <notify_url>" + notify_url + "</notify_url>");
        sb.append(" <trade_type>" + trade_type + "</trade_type>");
        sb.append(" <sign>" + sign + "</sign>");
        sb.append("</xml>");
        logger.info("微信扫码支付/H5报文==>" + sb);
        byte[] resultBytes = null;
        try {
            String wx_unifyUrl = (String) resouceMap.get("wx_unifyUrl");
            logger.info("微信扫码支付/H5生成二维码目标URL==>" + wx_unifyUrl);
            long startTime = System.currentTimeMillis();
            logger.info("HTTPS调用微信统一支付接口开始");
            resultBytes = HttpsUtil.post(wx_unifyUrl, sb.toString(), "UTF-8");
            logger.info("HTTPS调用微信统一支付接口结束,耗时[" + (System.currentTimeMillis() - startTime) + "]毫秒!");
        } catch (Exception e) {
            logger.error("微信扫码支付/H5 HTTP请求异常==>", e);
            result.setSuccess(false);
            result.setResultCode(ReturnCode.CodeFail.getCode());
            result.setResultMsg("调用微信服务异常");
            return result;
        }
        String resultStr = new String(resultBytes);
        logger.info("微信扫码支付/H5 生成二维码返回字符串==>" + resultStr);
        Map reslutMap = null;
        try {
            reslutMap = XMLParser.getMapFromXML(resultStr);
            logger.info("解析后MAP==>" + reslutMap);
            result.setT(reslutMap);
            if ("FAIL".equals(reslutMap.get("return_code"))) {
                result.setSuccess(false);
                result.setResultCode(ReturnCode.CodeFail.getCode());
                result.setResultMsg((String) reslutMap.get("return_msg"));
                return result;
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.info("微信扫码支付解析返回字符串XML报文失败==>" + e.getMessage());
            result.setSuccess(false);
            result.setResultCode(ReturnCode.CodeFail.getCode());
            result.setResultMsg(ReturnCode.CodeFail.getMessage());
            return result;
        }
        return result;
    }

    /**
     * 将微信返回的信息封装成map
     */
    @Override
    public Map<String, String> parseXmlForPay(HttpServletRequest request) throws Exception {
        Map<String, String> map = new HashMap<String, String>();
        InputStream inputStream = request.getInputStream();
        SAXReader reader = new SAXReader();
        Document document = reader.read(inputStream);
        Element root = document.getRootElement();
        logger.info("微信支付异步回调参数==>" + root);
        List<Element> elementList = root.elements();
        String value = "";
        for (Element e : elementList) {
            value = e.getText();
            if ("total_fee".equals(e.getName())) {
                value = AmountUtils.changeF2Y(e.getText());
                logger.info("微信返回金额totalFee==>" + value);
                map.put(e.getName(), value);
                continue;
            }
            map.put(e.getName(), value);
            logger.info(e.getName() + "==>" + e.getText());
        }
        return map;
    }
}
