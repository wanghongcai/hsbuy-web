package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.framework.manager.impl.GenericManagerImpl;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.JacksonUtil;
import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.ReturnCode;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayConfig;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipaySubmit;
import com.lenovo.m2.buy.promotion.admin.domain.pay.alipay.AliPayFqModel;
import com.lenovo.m2.buy.promotion.admin.domain.pay.wxpay.PayOrder;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayFqManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.MerchantPayPlatManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.service.pay.soa.MerchantPayPlatService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by MengQiang on 2015/5/19.
 */
@Service
public class AliPayFqManagerImpl extends GenericManagerImpl<PayOrder, Long> implements AliPayFqManager {
    private final Logger logger = Logger.getLogger(this.getClass());

    @Autowired
    private AliPayCommonManager aliPayCommonManager;
    @Autowired
    private MerchantPayPlatManager merchantPayPlatManager;
    @Autowired
    private MerchantPayPlatService merchantPayPlatService;
    @Autowired
    private PayOrderApi payOrderApi;
    @Autowired
    private CommonManager commonManager;
    @Autowired
    private PayPortalOrderManager payPortalOrderManager;

    @Override
    public RemoteResult toAliFqPay(HttpServletRequest request) {
        RemoteResult<String> returnResult = new RemoteResult<String>();
        returnResult.setSuccess(true);
        AliPayFqModel model = (AliPayFqModel) BaseModel.getModel(request);
        String orderMainCode = model.getOrderMainCode();
        String merchantCode = model.getMerchantCode();
        logger.info("merchantCode--->" + merchantCode);
        String payType = model.getPayType();
        String lenovoId = model.getLenovoId();
        String defaultbank = model.getDefaultbank();
        String plat = model.getPlat();
        logger.info("订单号：" + orderMainCode + "  商户号:" + merchantCode + "  支付类型:" + payType + "  lenovoId:" + lenovoId);
        String shopId= model.getShopId();
        logger.info("shopId==>" + shopId);
        String terminal = model.getTerminal();
        logger.info("terminal==>" + terminal);
        Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(orderMainCode, lenovoId, tenant);
        PayPortalOrder payPortalOrder;
        if(payPortalOrderRemoteResult.isSuccess()){
            payPortalOrder = payPortalOrderRemoteResult.getT();
            if(payPortalOrder == null||payPortalOrder.getOutTradeNo() == null){
                logger.warn("查询支付订单信息异常");
                CommonMethod.getRemoteResult(returnResult, "", false, "400", "未查到订单信息");
                return returnResult;
            }
        } else {
            logger.info("Invoke queryChannelOrderCodeDetail Get PayPortalOrder IS NULL，orderMainCode [" + orderMainCode + "]");
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "未查到订单信息");
            return returnResult;
        }
        if("1".equals(payPortalOrder.getPaymentWay())){
            commonManager.getLedgerFAID(payPortalOrder);
        }
        StringBuffer sb = new StringBuffer();
        sb.append("faid=" + payPortalOrder.getFaId() + ",");
        sb.append("payType=" + payType + ",");
        sb.append("lenovoId=" + lenovoId);
        String extra_common_param = "";
        try {
            extra_common_param = URLEncoder.encode(sb.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            logger.error("支付宝回传数据Encode异常",e);
            returnResult.setSuccess(false);
            returnResult.setResultCode("30001");
            returnResult.setResultMsg("支付宝回传数据Encode异常");
            return returnResult;
        }
        logger.info("extra_common_param--->" + extra_common_param);
        if(PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(payPortalOrder.getPayStatus()))){
            logger.info("Check PayPortalOrder Already PAY, OrderMainCode [" + orderMainCode + "]");
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "订单已支付，请到订单列表页确认");
            return returnResult;
        }
        if(PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(payPortalOrder.getOrderStatus()))){
            logger.info("Check PayPortalOrder OrderStatus FAIL, OrderMainCode [" + orderMainCode + "]");
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "订单已失效，请到订单列表页确认");
            return returnResult;
        }
        MerchantPayPlatView merchantPayPlatView = null;
        RemoteResult<MerchantPayPlatView> remoteResult = aliPayCommonManager.getMerchantPayPlatView(payPortalOrder.getFaId(), payType);
        if (remoteResult.isSuccess()) {
            merchantPayPlatView = remoteResult.getT();
            logger.info(remoteResult.isSuccess());
            logger.info(merchantPayPlatView.toString());
        } else {
            logger.info("未查询到平台信息");
            returnResult.setSuccess(false);
            returnResult.setResultCode("30002");
            returnResult.setResultMsg("查询商户平台信息异常");
            return returnResult;
        }
        String totalFee = String.valueOf(payPortalOrder.getTotalFee().getAmount());//支付金额,单位（元）
        String currencyCode = payPortalOrder.getCurrencyCode();
        String prodName = CommonMethod.getProductName(payPortalOrder.getSubject());
        String bodyHtml = null;
        try {
            RemoteResult<String> rr = commonManager.savePayOrder(lenovoId,plat,payType,orderMainCode,totalFee,prodName,"",0,"",merchantCode,"",shopId,terminal,merchantPayPlatView,currencyCode);
            String orderID = rr.getT().toString();
            bodyHtml = this.getFqPcHtml(defaultbank,orderID, prodName, totalFee, extra_common_param, merchantPayPlatView);
            bodyHtml = "<html>" + "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>支付宝订单请求</title></head>" + "<body>"
                    + bodyHtml + "</body></html>";
        }catch(Exception e){
            logger.error("保存订单或构建HTML表单异常",e);
            returnResult.setSuccess(false);
            returnResult.setResultCode("30004");
            returnResult.setResultMsg("支付平台处理订单信息异常");
            return returnResult;
        }
        logger.info(bodyHtml);
        if (bodyHtml == null || "".equals(bodyHtml)) {
            logger.warn("构建支付HTML失败");
            returnResult.setSuccess(false);
            returnResult.setResultCode("30005");
            returnResult.setResultMsg("构建请求HTML失败");
        }
        returnResult.setT(bodyHtml);
        return returnResult;
    }


    public String getFqPcHtml(String defaultbank, String ordercode, String prodName, String _total_fee, String extra_common_param, MerchantPayPlatView merchantPayPlatView) {
        Map<String, String> sParaTemp = new HashMap<String, String>();
        // 支付类型
        String payment_type = "1";
        String body = "";
        sParaTemp.put("service", "create_direct_pay_by_user");
        sParaTemp.put("partner", merchantPayPlatView.getMechId());
        sParaTemp.put("_input_charset", AlipayConfig.input_charset);
        sParaTemp.put("payment_type", payment_type);
        //TODO 适配互联网专区
        String outNotifyUrl =merchantPayPlatView.getOutNotifyUrl();
        outNotifyUrl = CommonMethod.getHlwzqUrl(outNotifyUrl);
        sParaTemp.put("notify_url", outNotifyUrl);
        sParaTemp.put("return_url", merchantPayPlatView.getOutCallBackUrl());
        sParaTemp.put("seller_email", merchantPayPlatView.getAppId());
        sParaTemp.put("out_trade_no", ordercode);
        sParaTemp.put("subject", prodName);
        sParaTemp.put("total_fee", _total_fee);
        sParaTemp.put("body", body);
        sParaTemp.put("paymethod", "CCIP");
        sParaTemp.put("default_login", "Y");
        sParaTemp.put("defaultbank", defaultbank);
        sParaTemp.put("extra_common_param", extra_common_param);
        String sHtmlText = AlipaySubmit.buildRequest(sParaTemp, "get", "确认", merchantPayPlatView.getSignKey());
        return sHtmlText;
    }


    @Override
    public RemoteResult<Map<String, Object>> callUpdate(String lenovoId, String out_trade_no, String trade_no, String gmt_payment, String merchantCode, String payType, MerchantPayPlatView merchantPayPlatView, String notifyId) {
        RemoteResult<Map<String, Object>> result = new RemoteResult<Map<String, Object>>();
        result.setSuccess(false);
        int tryNumber = 0;
        Map<String, Object> stringtomap = null;
        boolean flag = aliPayCommonManager.checkStatus(out_trade_no);
        com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder payOrder=null;
        //TODO 修改主订单信息
//        ChannelOrder channelOrder = new ChannelOrder();
        if (!flag){
            if (out_trade_no.trim().length()== 10){
                payOrder = payOrderApi.getTwoStatus(out_trade_no);
            }else{
                payOrder =payOrderApi.getPayOrderById(out_trade_no);
                out_trade_no=payOrder.getId().toString();
            }
            String orderNO = payOrder.getOut_trade_no();
//            //设置主单号
//            channelOrder.setOrderCode(orderNO);
//            //设置LenovoID
//            channelOrder.setLenovoId(lenovoId);
//            channelOrder.setPayment(Integer.parseInt(PeakConstant.PAY_TYPE_ALFQ));
//            channelOrder.setTransationId(String.valueOf(payOrder.getId()));
//            channelOrder.setPayStatus(1);
//            channelOrder.setShopId(payOrder.getShop_id());
//            channelOrder.setPayTime(DateUtil.formatDate(new Date(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
            payOrderApi.updateAliPayNotifyState(out_trade_no,lenovoId,trade_no,PeakConstant.MFLAG_REPEAT,notifyId,PeakConstant.TRADE_SUCCESS,null, Integer.parseInt(PeakConstant.PAY_TYPE_ALFQ));
            PayPortalOrder updatePayPortalOrder = CommonMethod.buildUpdatePayPortalOrder(String.valueOf(payOrder.getId()), payOrder.getOut_trade_no(), payOrder.getU_id(), Integer.parseInt(PeakConstant.PAY_TYPE_ALFQ), PeakConstant.PAY_STATUS_ALREADY_PAID, payOrder.getShop_id() ,new Date());
            try{
                RemoteResult<Integer> updatePayPortalOrderResult = payPortalOrderManager.updatePayPortalOrderPayStatus(updatePayPortalOrder);
                if (updatePayPortalOrderResult.isSuccess()) {
                    logger.info("Update PayPortalOrder SUCCESS，outTradeNo[" + payOrder.getOut_trade_no() + "]");
                } else {
                    logger.info("Update PayPortalOrder FAIL，outTradeNo[" + payOrder.getOut_trade_no() + "]");
                }
            }catch(Exception e){
                logger.info("更新渠道订单失败 ，订单号==>" + out_trade_no, e);
            }
            try {
                String signature = aliPayCommonManager.getSignature(out_trade_no, trade_no, orderNO, gmt_payment, PeakConstant.PAYMENT_ALI, lenovoId);
                String updateOrder ="payOrderCode=" + trade_no + "&orderCode=" + orderNO + "&payDatetime=" + gmt_payment + "&payment="+ PeakConstant.PAYMENT_ALI + "&lenovoId=" + lenovoId +"&signature=" + signature+ "&orderPrimaryId="+out_trade_no;
                logger.info("更新订单：" + updateOrder);
                //payment 0 招商银行, 1支付宝, 4支付宝直连支付,2银联支付
                String firstRemoteStr = aliPayCommonManager.updateRemoteOrder(merchantPayPlatView,trade_no,orderNO,gmt_payment,lenovoId,PeakConstant.PAYMENT_ALI,signature,out_trade_no);
                if(!(("").equals(firstRemoteStr))){
                    logger.info("更新订单状态返回信息：" + firstRemoteStr.trim());
                }
                if (!(("").equals(firstRemoteStr))&&"success".equalsIgnoreCase(firstRemoteStr.trim())) {
                    payOrderApi.updateAliPayNotifyState(out_trade_no, lenovoId, trade_no, PeakConstant.MFLAG_SUCC, notifyId, PeakConstant.TRADE_SUCCESS, null, Integer.parseInt(PeakConstant.PAY_TYPE_ALFQ));
                    result.setSuccess(true);
                }else{
                    stringtomap = JacksonUtil.toObjectMap(firstRemoteStr);
                    log.warn("回调客户服务器返回的数据----------------->" + stringtomap);
                    logger.info("-------服务器异常-------");
                    Iterator iter = stringtomap.entrySet().iterator();
                    while (iter.hasNext()) {
                        Map.Entry entry = (Map.Entry) iter.next();
                        logger.warn("异常码：" + entry.getKey() + "  异常信息：" + entry.getValue());
                        if ("500".equals(entry.getKey())) {
                            Boolean isSuccess = true;
                            while (isSuccess && tryNumber < 3) {
                                String secondRemoteStr = aliPayCommonManager.updateRemoteOrder(merchantPayPlatView, trade_no, orderNO, gmt_payment, lenovoId, PeakConstant.PAYMENT_ALI,signature,out_trade_no);
                                if(!(("").equals(secondRemoteStr))){
                                    logger.info("更新订单状态服务器异常后二次更新返回信息：" + secondRemoteStr.trim());
                                }
                                if (!(("").equals(secondRemoteStr)) && "success".equalsIgnoreCase(secondRemoteStr.trim())) {
                                    payOrderApi.updateAliPayNotifyState(out_trade_no, lenovoId, trade_no, PeakConstant.MFLAG_SUCC, notifyId, PeakConstant.TRADE_SUCCESS, null, Integer.parseInt(PeakConstant.PAY_TYPE_ALFQ));
                                    result.setSuccess(true);
                                    isSuccess = false;
                                } else {
                                    tryNumber++;
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                result.setSuccess(false);
                result.setResultCode(ReturnCode.InNotifyFail.getCode());
                result.setResultMsg(ReturnCode.InNotifyFail.getMessage());
                logger.error("分期支付回调订单状态更新异常--->" + e.getMessage());
                payOrderApi.updateAliPayNotifyState(out_trade_no,lenovoId,trade_no,PeakConstant.MFLAG_REPEAT,notifyId,PeakConstant.TRADE_SUCCESS,null, Integer.parseInt(PeakConstant.PAY_TYPE_ALFQ));
            }
        }else{
            result.setSuccess(true);
        }
        return result;
    }
}
