package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

import javax.servlet.http.HttpServletRequest;

/**
 * 支付宝WAP直连接口
 * Created by MengQiang on 2016/9/1.
 */
public interface AliPayDirectWapManager {

    /**
     * 去支付
     * @param request request
     * @return RemoteResult<String>
     */
    public RemoteResult<String> toDirectWapPay(HttpServletRequest request);

    /**
     * 异步回调通知
     * @param payOrder payOrder
     * @param merchantPayPlatView merchantPayPlatView
     * @param gmtPayment gmtPayment
     * @param tradeNo tradeNo
     * @param notifyId notifyId
     * @return RemoteResult<String>
     */
    public RemoteResult<String> callUpdate(PayOrder payOrder, MerchantPayPlatView merchantPayPlatView, String gmtPayment, String tradeNo, String notifyId, String outChannelType, String outChannelAmount);
}
