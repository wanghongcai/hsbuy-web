package com.lenovo.m2.buy.promotion.admin.manager.pay.wxpay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.domain.pay.order.MongoOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by luqian on 2015-07-22.
 */
public interface WxPayCommonManager {

    public Map<String,Object> sendHttpPost(String url, String realm);

    public RemoteResult<MongoOrder> getMchOrderInfo(String orderCode, String lenovoId, String plat, String merchantOrderUrl);

    public String getAccessToken();

    public String sendLenovoCashierJson(MerchantPayPlatView merchantPayPlatView, String proName, String total_fee, String accessTokrn, String createIp, String orderCode, String openid, String plat, String productCode, int isGetOrderCode, String proNum);

    public Boolean wxPayWay(HttpServletRequest request);

    public Map<String,Object> getOrderCode(MerchantPayPlatView merchantPayPlatView, String proName, String total_fee, String accessTokrn, String createIp, String orderCode, String openid, String plat, String productCode, int isGetOrderCode, String proNum);

    public RemoteResult<Map<String,Object>> getMWebUrl(MerchantPayPlatView merchantPayPlatView, PayPortalOrder payPortalOrder, Map<String, Object> resouceMap, String orderMainCode, String merchantCode, String os, String payType, String lenovoId, String strClientIP, String productName, String shopId, String terminal);
    //TODO 修改成参数为ChannelOrder
    public RemoteResult<Map<String, Object>> getCodeUrl(MerchantPayPlatView merchantPayPlatView, PayPortalOrder payPortalOrder, Map<String, Object> resouceMap, String orderId, String merchantCode, String os, String payType, String lenovoId, String spbillCreateIp, String productName, String shopId, String terminal);

    public Map<String, String> parseXmlForPay(HttpServletRequest request)throws Exception;



}
