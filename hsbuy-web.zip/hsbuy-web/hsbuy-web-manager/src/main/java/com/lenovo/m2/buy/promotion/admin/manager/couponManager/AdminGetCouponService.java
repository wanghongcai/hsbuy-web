package com.lenovo.m2.buy.promotion.admin.manager.couponManager;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

/**
 * Created by fenglg1 on 2016/12/13.
 */
public interface AdminGetCouponService {

    /**
     * 保存选中的优惠券Id到可领取优惠券列表中
     * @param createBy
     * @param salescouponsIds
     * @return
     */
    public RemoteResult saveAvailableSalescoupons(String createBy, String[] salescouponsIds, Integer displayPosition);

    /**
     * 根据优惠券ID，将优惠券从可领取列表中删除
     * @param operator
     * @param couponId
     * @return
     */
    public RemoteResult deleteAvailableSalescoupons(String operator, String couponId, String displayPosition);

    /**
     * 清空可领取的优惠券列表
     * @param operator
     * @return
     */
    public RemoteResult deleteAllAvailableSalescoupons(String operator);

}
