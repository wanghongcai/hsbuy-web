package com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.MerchantPayPlatManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.CashierManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.OrderSupportPayType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Create For Cashier
 * 收银台Manager实现类
 * Created by mengqiang1 on 2015/8/21.
 */
@Service
public class CashierManagerImpl implements CashierManager{

    @Autowired
    private PayOrderApi payOrderApi;

    @Autowired
    private MerchantPayPlatManager merchantPayPlatManager;

    @Override
    public RemoteResult<List<OrderSupportPayType>> getOrderSupportPayTypeList(String FAID) {
        return merchantPayPlatManager.getOrderSupportPayTypeList(FAID);
    }

    @Override
    public RemoteResult<List<OrderSupportPayType>> getOrderSupportPayTypeListByFaIDPayment(String faId, int payment) {
        RemoteResult<List<OrderSupportPayType>> returnResult = new RemoteResult<List<OrderSupportPayType>>();
        List<Integer> payTypeList = new ArrayList<Integer>();
        if(payment == 0){
            payTypeList.add(0);
        }else if(payment == 1){
            payTypeList.add(1);
            payTypeList.add(2);
            payTypeList.add(3);
            payTypeList.add(4);
            payTypeList.add(5);
            payTypeList.add(6);
            payTypeList.add(11);
        }else if(payment == 7){
            payTypeList.add(7);
        }else if(payment == 16){
            payTypeList.add(9);
        }else if(payment == 17){
            payTypeList.add(10);
        }else if(payment == 20){
            payTypeList.add(20);
        }else{
            returnResult.setSuccess(false);
            return returnResult;
        }
        return merchantPayPlatManager.getOrderSupportPayTypeListByFaIDPayment(faId, payTypeList);
    }

    @Override
    public int getStatusByOrderCode(String orderCode) {
        return payOrderApi.getStatusByOrderCode(orderCode);
    }
}
