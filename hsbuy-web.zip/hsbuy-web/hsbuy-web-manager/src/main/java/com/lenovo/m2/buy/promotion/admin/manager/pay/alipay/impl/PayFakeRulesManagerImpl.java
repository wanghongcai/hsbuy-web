package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.PayFakeRulesManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayFakeRulesApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayFakeRules;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by mengqiang1 on 2016/5/6.
 */
@Service
public class PayFakeRulesManagerImpl implements PayFakeRulesManager {
    private final Logger logger = Logger.getLogger(this.getClass());
    @Autowired
    private PayFakeRulesApi payFakeRulesApi;

    @Override
    public RemoteResult<Map<String, Integer>> pushFakePay(PayFakeRules payFake) throws Exception {
        return payFakeRulesApi.pushFakePay(payFake);
    }

    @Override
    public RemoteResult<Map<String, Integer>> updateFakePay(PayFakeRules payFake) {
        return payFakeRulesApi.updateFakePay(payFake);
    }

    @Override
    public RemoteResult<List<PayFakeRules>> queryFakePayList(String lenovoId) {
        return payFakeRulesApi.queryFakePayList(lenovoId);
    }

    public PayFakeRulesApi getPayFakeRulesApi() {
        return payFakeRulesApi;
    }

    public void setPayFakeRulesApi(PayFakeRulesApi payFakeRulesApi) {
        this.payFakeRulesApi = payFakeRulesApi;
    }
}
