package com.lenovo.m2.buy.promotion.admin.manager.pay.wxpay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.manager.GenericManager;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * Created by yangjj7 on 2015/4/21.
 */
public interface WxPayManager extends GenericManager<PayOrder, Long> {

    public String getOpenId(String code, String wxGetOpenIdUrl, String wxGrantType, String wxAppid, String wxSecret);

    public RemoteResult<Map<String,Object>> getPrepayId(String wx_unifyUrl, String wx_notify_url, String wx_appid, String wx_mch_id, String wx_trade_type, String orderCode, String openid, String spbill_create_ip, String attach, String total_fee, String body, String userId, String merchantCode, int payType, String signKey);

    public Map<String,Object> careatWxParm(String wx_appid, String prepayId, String merchantCode, Map map, String signKey);

    public RemoteResult<Map<String,Object>> callUpdate(String userId, String orderCode, String wxPayCode, String time_end, String merchantCode, String payType, String orderPrimaryId, String shopId, String terminal);

   public RemoteResult<Map<String,Object>> orderQuery(String orderId, String lenovoId, String merchantCode, String os, String payType, String spbillCreateIp);
   public  RemoteResult<Map<String,Object>> getCodeUrl(String orderId, String merchantCode, String os, String payType, String lenovoId, String spbillCreateIp);
    public RemoteResult getOrderStatus(String orderMainCode, String merchantCode, String lenovoId);
    public  RemoteResult<Map<String,Object>> toWxPay(HttpServletRequest request);

    RemoteResult<Map<String, Object>> buildAppletPayData(HttpServletRequest request, HttpServletResponse response, Map<String, Object> resultMap);

    public RemoteResult<Map<String,Object>> toWxPayAuth(HttpServletRequest request, HttpServletResponse response);
    public RemoteResult<String> getWeixinToken(HttpServletRequest request, HttpServletResponse response);
    public RemoteResult<String> getWeixinTicket(HttpServletRequest request, HttpServletResponse response);
    /**
     * 构建商城app微信支付数据
     * @param resultMap
     * @return
     */
    public RemoteResult buildAppPayData(HttpServletRequest request, HttpServletResponse response, Map<String, Object> resultMap);

    /**
     *安全漏洞检测
     * @param callback
     * @param orderId
     * @param merchantCode
     * @param lenovoId
     * @return
     */
    public boolean xssEncode(String callback, String orderId, String merchantCode, String lenovoId);


}
