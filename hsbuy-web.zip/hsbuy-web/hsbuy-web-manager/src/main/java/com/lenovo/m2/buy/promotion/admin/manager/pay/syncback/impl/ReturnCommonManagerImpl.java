package com.lenovo.m2.buy.promotion.admin.manager.pay.syncback.impl;

import com.lenovo.m2.buy.promotion.admin.manager.pay.syncback.ReturnCommonManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created For Return CallBack
 * 同步回调Manager实现类
 * Created by MengQiang on 2015/8/28.
 */
@Service
public class ReturnCommonManagerImpl implements ReturnCommonManager {
    @Autowired
    private PayOrderApi payOrderApi;
    @Override
    public PayOrder getPayOrderByPrimaryId(long payOrderId) {
        return payOrderApi.getPayOrderByPrimaryId(payOrderId);
    }

    public PayOrderApi getPayOrderApi() {
        return payOrderApi;
    }

    public void setPayOrderApi(PayOrderApi payOrderApi) {
        this.payOrderApi = payOrderApi;
    }

}
