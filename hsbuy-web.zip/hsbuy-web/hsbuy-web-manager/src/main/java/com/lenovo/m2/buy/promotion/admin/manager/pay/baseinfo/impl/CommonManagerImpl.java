package com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.impl;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.ReturnCode;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.Util;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.ChannelOrderApi;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.ChannelOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.PayOrderView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Created by MengQiang on 2016/2/22.
 */
@Service
public class CommonManagerImpl implements CommonManager {

    private final Logger logger = Logger.getLogger(this.getClass());

    @Autowired
    private ChannelOrderApi channelOrderApi;

    @Autowired
    private PayOrderApi payOrderApi;

    @Override
    public RemoteResult<List<ChannelOrder>> queryChannelOrderMainCodeList(List<String> orderMainCodeList, String lenovoId, String shopId) {
//        return channelOrderApi.queryChannelOrderMainCodeList(orderMainCodeList, lenovoId);
        int flag = 1;
        RemoteResult<List<ChannelOrder>> channelOrderListRemoteResult = channelOrderApi.queryChannelOrderMainCodeList(orderMainCodeList, lenovoId,shopId);
        try {
            while (flag < 11 && !channelOrderListRemoteResult.isSuccess()) {
                logger.info(orderMainCodeList + "Invoke queryChannelOrderMainCodeList , ReTry Time -->" + flag);
                Thread.sleep(100);
                channelOrderListRemoteResult = channelOrderApi.queryChannelOrderMainCodeList(orderMainCodeList, lenovoId,shopId);
                flag++;
            }
        } catch (Exception e) {
            channelOrderListRemoteResult.setSuccess(false);
            logger.info("Invoke queryChannelOrderMainCodeList Exception", e);
        }
        return channelOrderListRemoteResult;
    }

    @Override
    public RemoteResult<ChannelOrder> queryChannelOrderMainCodeDetail(String orderMainCode, String lenovoId, String shopId) {
//        return channelOrderApi.queryChannelOrderMainCodeDetail(orderMainCode, lenovoId);
        int flag = 1;
        RemoteResult<ChannelOrder> channelOrderRemoteResult = channelOrderApi.queryChannelOrderMainCodeDetail(orderMainCode, lenovoId,shopId);
        try {
            while (flag < 11 && !channelOrderRemoteResult.isSuccess()) {
                logger.info(orderMainCode + "Invoke queryChannelOrderMainCodeDetail ,ReTry Time -->" + flag);
                Thread.sleep(100);
                channelOrderRemoteResult = channelOrderApi.queryChannelOrderMainCodeDetail(orderMainCode, lenovoId,shopId);
                flag++;
            }
        } catch (Exception e) {
            channelOrderRemoteResult.setSuccess(false);
            logger.info("Invoke queryChannelOrderMainCodeDetail Exception", e);
        }
        return channelOrderRemoteResult;
    }

    @Override
    public RemoteResult<Integer> updateChannelOrderMainCodeDetail(ChannelOrder channelOrder) {
        return channelOrderApi.updateChannelOrderMainCodeDetail(channelOrder);
    }

    @Override
    public RemoteResult<List<ChannelOrder>> queryChannelOrderCodeList(String orderMainCode, String lenovoId, int mainFlag, String shopId) {
//        return channelOrderApi.queryChannelOrderCodeList(orderMainCode, lenovoId, mainFlag);
        int flag = 1;
        RemoteResult<List<ChannelOrder>> channelOrderListRemoteResult = channelOrderApi.queryChannelOrderCodeList(orderMainCode, lenovoId, mainFlag,shopId);
        try {
            while (flag < 11 && !channelOrderListRemoteResult.isSuccess()) {
                logger.info(orderMainCode + " Invoke queryChannelOrderCodeList ,ReTry Time -->" + flag);
                Thread.sleep(100);
                channelOrderListRemoteResult = channelOrderApi.queryChannelOrderCodeList(orderMainCode, lenovoId, mainFlag,shopId);
                flag++;
            }
        } catch (Exception e) {
            channelOrderListRemoteResult.setSuccess(false);
            logger.info("Invoke queryChannelOrderCodeList Exception", e);
        }
        return channelOrderListRemoteResult;
    }

    @Override
    public RemoteResult<ChannelOrder> queryChannelOrderCodeDetail(String orderCode, String lenovoId, int mainFlag, String shopId) {
//        return channelOrderApi.queryChannelOrderCodeDetail(orderCode, lenovoId, mainFlag);
        int flag = 1;
        RemoteResult<ChannelOrder> channelOrderRemoteResult = channelOrderApi.queryChannelOrderCodeDetail(orderCode, lenovoId, mainFlag,shopId);
        try {
            while (flag < 11 && !channelOrderRemoteResult.isSuccess()) {
                logger.info(orderCode + "Invoke queryChannelOrderCodeDetail ,ReTry Time -->" + flag);
                Thread.sleep(100);
                channelOrderRemoteResult = channelOrderApi.queryChannelOrderCodeDetail(orderCode, lenovoId, mainFlag,shopId);
                flag++;
            }
        } catch (Exception e) {
            channelOrderRemoteResult.setSuccess(false);
            logger.info("Invoke queryChannelOrderCodeDetail Exception", e);
        }
        return channelOrderRemoteResult;
    }

    @Override
    public RemoteResult<ChannelOrder> querySmbChannelOrderDetail(String smbOrderCode, int mainFlag, String shopId) {
        int flag = 1;
        RemoteResult<ChannelOrder> channelOrderRemoteResult = channelOrderApi.querySmbChannelOrderDetail(smbOrderCode, mainFlag,shopId);
        try {
            while (flag < 11 && !channelOrderRemoteResult.isSuccess()) {
                logger.info(smbOrderCode + "Invoke querySmbChannelOrderDetail ,ReTry Time -->" + flag);
                Thread.sleep(100);
                channelOrderRemoteResult = channelOrderApi.querySmbChannelOrderDetail(smbOrderCode, mainFlag,shopId);
                flag++;
            }
        } catch (Exception e) {
            channelOrderRemoteResult.setSuccess(false);
            logger.info("Invoke querySmbChannelOrderDetail Exception", e);
        }
        return channelOrderRemoteResult;
    }

    @Override
    public String getLedgerFAID(ChannelOrder channelOrder) {
        Map<String, Object> paySwitchMap = new HashMap<String, Object>();
        try {
            paySwitchMap = PropertiesHelper.loadToMap("pay_switch.properties");
            channelOrder.setOrderFaId(PeakConstant.LEDGERFAID);
            channelOrder.setOrderFaName(PeakConstant.LEDGERFANAME);
        } catch (Exception paySwitchEx) {
            logger.error("获取PAY_SWITCH配置异常", paySwitchEx);
            paySwitchMap.put("LEDGERFA_ONE", "7ef1d628-5bd3-4651-9530-793678cc02af");
            channelOrder.setOrderFaId("7ef1d628-5bd3-4651-9530-793678cc02af");
            channelOrder.setOrderFaName("联想(上海)电子科技有限公司");
        }
        return (String) paySwitchMap.get("LEDGERFAID_ONE");
    }

    @Override
    public String getLedgerFAID(PayPortalOrder payPortalOrder) {
        Map<String, Object> paySwitchMap = new HashMap<String, Object>();
        try {
            paySwitchMap = PropertiesHelper.loadToMap("pay_switch.properties");
            payPortalOrder.setFaId(PeakConstant.LEDGERFAID);
            payPortalOrder.setFaName(PeakConstant.LEDGERFANAME);
        } catch (Exception paySwitchEx) {
            logger.error("获取PAY_SWITCH配置异常", paySwitchEx);
            paySwitchMap.put("LEDGERFA_ONE", "7ef1d628-5bd3-4651-9530-793678cc02af");
            payPortalOrder.setFaId("7ef1d628-5bd3-4651-9530-793678cc02af");
            payPortalOrder.setFaName("联想(上海)电子科技有限公司");
        }
        return (String) paySwitchMap.get("LEDGERFAID_ONE");
    }

    @Override
    public RemoteResult<List<ChannelOrder>> queryOrderCodeList(List<String> orderCodeList, String lenovoId, int mainFlag, String shopId) {
//        return channelOrderApi.queryOrderCodeList(orderCodeList, lenovoId, mainFlag);
        int flag = 1;
        RemoteResult<List<ChannelOrder>> channelOrderListRemoteResult = channelOrderApi.queryOrderCodeList(orderCodeList, lenovoId, mainFlag,shopId);
        try {
            while (flag < 11 && !channelOrderListRemoteResult.isSuccess()) {
                logger.info(orderCodeList + "Invoke queryOrderCodeList ,ReTry Time -->" + flag);
                Thread.sleep(100);
                channelOrderListRemoteResult = channelOrderApi.queryOrderCodeList(orderCodeList, lenovoId, mainFlag,shopId);
                flag++;
            }
        } catch (Exception e) {
            channelOrderListRemoteResult.setSuccess(false);
            logger.info("Invoke queryOrderCodeList Exception", e);
        }
        return channelOrderListRemoteResult;
    }

    @Override
    public RemoteResult<Integer> updateChannelOrderOrderStatus(int orderStatus, String orderCode, int mainFlag, String shopId) {
        return channelOrderApi.updateChannelOrderOrderStatus(orderStatus, orderCode, mainFlag,shopId);
    }


    @Override
    public RemoteResult<List<PayOrder>> getPayOrderListByPayType(String orderCode, Integer payType) {
        return payOrderApi.getOrderListByPayType(orderCode , payType);
    }
    @Override
    public RemoteResult<String> savePayOrder(String lenovoId, String plat, String payType, String orderMainCode, String total_fee, String prodName, String fqRate, int fqNum, String fqCode, String merchantCode, String pay_bank, String shopId, String terminal, MerchantPayPlatView merchantPayPlatView, String currencyCode) {
        logger.info("Invoke SavePayOrder lenovoId[" + lenovoId + "],plat[" + plat + "],payType[" + payType + "],orderMainCode[" + orderMainCode + "],total_fee["
                + total_fee + "],prodName[" + prodName + "],fqRate[" + fqRate + "],fqNum[" + fqNum + "],fqCode[" + fqCode + "],merchantCode["
                + merchantCode + "],pay_bank[" + pay_bank + "],shopId[" + shopId + "],terminal[" + terminal + "],merchant_id["
                + merchantPayPlatView.getId() + "],currencyCode[" + currencyCode + "]");
        RemoteResult<String> remoteResult = new RemoteResult<String>();
        try {
            PayOrderView payOrderView = getPayOrderView(lenovoId, plat, payType, orderMainCode, total_fee, prodName, fqRate, fqNum, fqCode, merchantCode, pay_bank, shopId, terminal, merchantPayPlatView, currencyCode);
            remoteResult = payOrderApi.savePayOrder(payOrderView);
            remoteResult.setSuccess(true);
            remoteResult.setResultCode(ReturnCode.Success.getCode());
        } catch (Exception e) {
            logger.info("保存支付订单异常", e);
            remoteResult.setSuccess(false);
        }
        logger.info("SavePayOrder Finish ,RemoteResult[" + remoteResult + "]");
        return remoteResult;
    }



    private PayOrderView getPayOrderView(String lenovoId, String plat, String payType, String orderMainCode, String total_fee, String prodName, String fqRate, int fqNum, String fqCode, String merchantCode, String pay_bank, String shopId, String terminal, MerchantPayPlatView merchantPayPlatView, String currencyCode) {
        PayOrderView payOrderView = new PayOrderView();
        payOrderView.setU_id(lenovoId);
        if(StringUtils.isNotEmpty(plat)){
            payOrderView.setOs(Integer.parseInt(plat));
        }else{
            payOrderView.setOs(Integer.parseInt(shopId));
        }
        payOrderView.setMerchant_id(merchantPayPlatView.getId());
        payOrderView.setPay_type(Integer.parseInt(payType));
        payOrderView.setOut_trade_no(orderMainCode);
        payOrderView.setTrade_state(0);
        payOrderView.setMerchant_flag(PeakConstant.MFLAG_NOT);
        payOrderView.setTotal_fee(Integer.parseInt(Util.getMoney(total_fee)));
        payOrderView.setPay_money(new Money(total_fee, currencyCode));
        payOrderView.setCurrencyCode(currencyCode);
        payOrderView.setBody(prodName);
        payOrderView.setTime_start(new Date());
        payOrderView.setVersion(PeakConstant.VERSION_ONE);
        payOrderView.setFq_rate(fqRate);
        payOrderView.setFq_num(fqNum);
        payOrderView.setFq_code(fqCode);
        payOrderView.setMerchant_plat(merchantCode);
        payOrderView.setPay_bank(pay_bank);
        payOrderView.setShop_id(shopId);
        payOrderView.setTerminal(terminal);
        return payOrderView;
    }


    public ChannelOrderApi getChannelOrderApi() {
        return channelOrderApi;
    }

    public void setChannelOrderApi(ChannelOrderApi channelOrderApi) {
        this.channelOrderApi = channelOrderApi;
    }

}
