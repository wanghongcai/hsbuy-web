package com.lenovo.m2.buy.promotion.admin.manager.pay.outpay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.outpay.PayChannel;

import java.math.BigDecimal;

/**
 * Created by tianchuyang on 2017/1/10.
 */
public interface PayChannelManager {

    /**
     * 获取惠商支付路由支持的银行列表
     * @param faId 商户唯一标识
     * @param billAmount 订单总额
     * @param accountType 账户类型
     * @return
     */

    PayChannel getPayChannel(String faId, String shopId, BigDecimal billAmount, String accountType, String outTradeNo, String lenovoId) throws Exception;

}
