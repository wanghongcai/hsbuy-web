package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

/**
 * 支付宝取消交易处理
 * Created by MengQiang on 2016/4/11.
 */
public interface AliPayTradeCancelManager {
    /**
     * 支付宝取消交易
     * @param payOrder
     * @return
     */
    public RemoteResult<String> aliPayTradeCancel(PayOrder payOrder);
}
