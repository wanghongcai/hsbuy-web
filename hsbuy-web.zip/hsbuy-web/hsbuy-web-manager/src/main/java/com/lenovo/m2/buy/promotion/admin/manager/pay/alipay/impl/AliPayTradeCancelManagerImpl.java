package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.HttpUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayConfig;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipaySubmit;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.XMLParser;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayTradeCancelManager;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import com.lenovo.m2.hsbuy.service.pay.soa.MerchantPayPlatService;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/**
 * 支付宝退货处理逻辑实现类
 * Created by MengQiang on 2016/4/11.
 */
@Service
public class AliPayTradeCancelManagerImpl implements AliPayTradeCancelManager {
    private final Logger logger = Logger.getLogger(this.getClass());
    @Autowired
    private MerchantPayPlatService merchantPayPlatService;
    @Override
    public RemoteResult<String> aliPayTradeCancel(PayOrder payOrder) {
        RemoteResult<String> returnResult = new RemoteResult<String>();
        try{
            logger.info("支付宝待取消订单==>" + payOrder.toString());
            RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult = merchantPayPlatService.getMerchantPayPlatById(payOrder.getMerchant_id());
            if(merchantPayPlatViewRemoteResult.isSuccess()){
                logger.info("查询支付宝支付平台信息成功");
            }else{
                returnResult.setSuccess(false);
                returnResult.setResultMsg("查询支付宝支付订单平台信息失败");
                return returnResult;
            }
            Map<String, Object> orderCancelMap = this.getTradeCancel(payOrder, merchantPayPlatViewRemoteResult.getT());
            if("T".equals(orderCancelMap.get("is_success"))){
                returnResult.setSuccess(true);
                returnResult.setT("支付宝交易取消成功");
            }else if("F".equals(orderCancelMap.get("is_success"))){
                returnResult.setSuccess(false);
                returnResult.setT((String) orderCancelMap.get("error"));
            }else{
                returnResult.setSuccess(false);
                returnResult.setT("处理退货失败");
            }
        }catch(Exception e){
            returnResult.setSuccess(false);
            returnResult.setT("取消处理异常");
        }
        return returnResult;
    }

    private Map<String, Object> getTradeCancel(PayOrder payOrder, MerchantPayPlatView merchantPayPlatView) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        Map<String, Object> propMap = PropertiesHelper.loadToMap("ali_pay.properties");
        String ALIPAY_GATEWAY_NEW = (String) propMap.get("ALIPAY_GATEWAY_NEW");
        StringBuffer sb = new StringBuffer();
        Map<String, String> sParaTemp = new HashMap<String, String>();
        sParaTemp.put("service", "close_trade");
        sParaTemp.put("partner", merchantPayPlatView.getMechId());
        sParaTemp.put("_input_charset", AlipayConfig.input_charset);
        sParaTemp.put("out_order_no", String.valueOf(payOrder.getId()));
        String sign = AlipaySubmit.buildRequestMysign(sParaTemp, merchantPayPlatView.getSignKey());
        sb.append("?sign=" + sign);
        sb.append("&_input_charset=utf-8");
        sb.append("&sign_type=MD5");
        sb.append("&service=close_trade");
        sb.append("&out_order_no=" + String.valueOf(payOrder.getId()));
        sb.append("&partner=" + merchantPayPlatView.getMechId());
        logger.info("请求参数==>" + sb.toString());
        HttpGet post = new HttpGet(ALIPAY_GATEWAY_NEW + sb.toString());
        HttpResponse httpResponse = null;
        String cancelResult;
        BufferedReader bufferedReader = null;
        InputStreamReader content = null;
        try {
            httpResponse = HttpUtil.executeProxy(post);
            content = new InputStreamReader(httpResponse.getEntity().getContent());
            bufferedReader = new BufferedReader(content);
            StringBuffer tempBuffer = new StringBuffer();
            String line = "";
            // 获取系统分行标准
            String NL = System.getProperty("line.separator");
            while ((line = bufferedReader.readLine()) != null) {
                tempBuffer.append(line + NL);
            }
            cancelResult = tempBuffer.toString();
            logger.info("支付宝取消订单返回==>" + cancelResult);
            resultMap = XMLParser.getMapFromXML(cancelResult);
        } catch (Exception e) {
            logger.info("HTTP请求支付宝取消订单失败", e);
            resultMap.put("is_success", "F");
            resultMap.put("error", "调用HTTP接口取消交易失败");
        }finally {
            try {
                bufferedReader.close();
                content.close();
            } catch (IOException e) {
                logger.error("文件流关闭失败");
            } finally {
                bufferedReader = null;
                content = null;
            }
        }
        return resultMap;
    }
}
