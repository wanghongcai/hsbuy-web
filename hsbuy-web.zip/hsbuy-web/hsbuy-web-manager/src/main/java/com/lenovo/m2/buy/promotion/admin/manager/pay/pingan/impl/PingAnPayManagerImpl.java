package com.lenovo.m2.buy.promotion.admin.manager.pay.pingan.impl;

import com.ecc.emp.data.KeyedCollection;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.framework.manager.impl.GenericManagerImpl;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.*;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.DateUtil;
import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;
import com.lenovo.m2.buy.promotion.admin.domain.pay.pingAnPay.PingAnPayModel;
import com.lenovo.m2.buy.promotion.admin.domain.pay.pingAnPay.PingAnPayReq;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonPayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.pingan.PingAnPayManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayChannelBankApi;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.PayChannelBank;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import com.lenovo.m2.hsbuy.service.pay.soa.PayOrderService;
import com.sdb.payclient.core.PayclientInterfaceUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 平安银行直连业务处理
 * created by qixin on 2016/11/03.
 */
@Service
public class PingAnPayManagerImpl extends GenericManagerImpl<PayOrder, Long> implements PingAnPayManager {

    private static final String DIRECT_BANK_URL="https://ebank.sdb.com.cn/khpayment/khPayment_bank.do";
    private static final String DIRECT_BANK_URL_TEST="https://testebank.sdb.com.cn/khpayment/khPayment_bank.do";
    private static final String PINGAN_GATEWAY_URL="https://ebank.sdb.com.cn/corporbank/khPayment.do";
    private static final String PINGAN_WAP_URL="https://ebank.sdb.com.cn/corporbank/khPayment_wapQuickPay.do";

    private final Logger LOGGER = Logger.getLogger(this.getClass());
    @Autowired
    private CommonPayManager commonPayManager;
    @Autowired
    private AliPayCommonManager aliPayCommonManager;
    @Autowired
    private PayOrderApi payOrderApi;
    @Autowired
    private CommonManager commonManager;
    @Autowired
    private PayPortalOrderManager payPortalOrderManager;
    @Autowired
    private CommonCallBackManager commonCallBackManager;
    @Autowired
    private PayChannelBankApi payChannelBankApi;
    @Autowired
    private PayOrderService payOrderService; // 为记录是B2C/B2B渠道支付

    @Override
    public RemoteResult toPay(HttpServletRequest request) {
        RemoteResult<String> returnResult = new RemoteResult<String>();
        returnResult.setSuccess(true);
        PingAnPayModel model = (PingAnPayModel) BaseModel.getModel(request);

        String tradeInfo = request.getParameter("trade_info");
        boolean isTest = aliPayCommonManager.isTestPay("isPingAnTest");
        Map<String,String> tradeMap = null;
        try {
            tradeMap = LePayUtil.parseTradeInfo(tradeInfo);
        } catch (Exception e) {
            LOGGER.info("PingAnPayManagerImpl Invoke toPay parms error!cause by:"+e);
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "错误的支付请求参数");
            return returnResult;
        }
        // 直连网银
        String accountType = tradeMap.get("account_type");
        String bankType = tradeMap.get("bank_type");
        String bankNo = tradeMap.get("bank_code");
        String cardType = tradeMap.get("card_type");
        String lenovoId = tradeMap.get("lenovo_id");

        String orderMainCode = model.getOrderMainCode();
        String merchantCode = model.getMerchantCode();
        String payType = model.getPayType();
        String plat = model.getPlat();
        String shopId = model.getShopId();
        String terminal = model.getTerminal();
        String strClientIP = request.getRemoteAddr();
        // 验证基本参数
        if (org.apache.commons.lang.StringUtils.isEmpty(orderMainCode) || org.apache.commons.lang.StringUtils.isEmpty(payType) || org.apache.commons.lang.StringUtils.isEmpty(merchantCode) || org.apache.commons.lang.StringUtils.isEmpty(shopId) || org.apache.commons.lang.StringUtils.isEmpty(terminal) || org.apache.commons.lang.StringUtils.isEmpty(lenovoId)) {
            LOGGER.info("Invoke toPay parms error," +
                    "orderCode [" + orderMainCode + "],payType [" + payType + "],merchantCode [" + merchantCode + "],shopId [" + shopId + "],terminal [" + terminal + "],lenovoId ["+lenovoId+"]");
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "错误的支付请求参数");
            return returnResult;
        }

        // 是否直连网银
        String payCode = null;
        if (PeakConstant.PAY_TYPE_PINGAN.equals(payType) && StringUtils.isNotEmpty(accountType) && StringUtils.isNotEmpty(bankNo) && StringUtils.isNotEmpty(cardType)){
            LOGGER.info("Is PingAnPay Direct E-Bank,payType [" + payType + "],accountType [" + accountType + "],bankNo [" + bankNo + "],cardType [" + cardType + "]");
            if (isTest){
                if (LePayConstant.ACCOUNT_TYPE_B2C.equals(Integer.parseInt(accountType))){
//                    model.setPlantId("1000000008");
                    model.setPlantId("1000000009");
                    model.setBankCode("09");
                }else if (LePayConstant.ACCOUNT_TYPE_B2B.equals((Integer.parseInt(accountType)))){
//                    model.setPlantId("1000000001");
                    model.setPlantId("1000000009");
                    model.setBankCode("700");
                }else {
                    LOGGER.info("平安直连网银交易类型错误! accountType="+accountType);
                    CommonMethod.getRemoteResult(returnResult, "", false, "404", "错误的支付请求参数");
                    return returnResult;
                }
            }else {
                RemoteResult<PayChannelBank> hsPayplatBankRemoteResult = payChannelBankApi.queryPayChannelBankByParams(Integer.parseInt(payType), Integer.parseInt(bankNo), Integer.parseInt(bankType), Integer.parseInt(cardType));
                if (hsPayplatBankRemoteResult.isSuccess()){
                    payCode = hsPayplatBankRemoteResult.getT().getPayCode();
                    if (StringUtils.isNotEmpty(payCode)){
                        model.setBankCode(payCode);
                    }
                    if (payCode.startsWith("B")){
                        model.setPlantId(LePayConstant.PINGAN_B2B_B);
                    }
                }else {
                    LOGGER.info("平安支付直连网银数据查询失败！");
                    CommonMethod.getRemoteResult(returnResult, "", false, "400", "银行数据查询失败");
                    return returnResult;
                }
                if (String.valueOf(PeakConstant.BANK_TYPE_B2C).equals(bankType)){
                    model.setPlantId(LePayConstant.PINGAN_B2C);
                }else if (String.valueOf(PeakConstant.BANK_TYPE_B2B).equals(bankType)){
                    if (payCode.startsWith("B")){
                        model.setPlantId(LePayConstant.PINGAN_B2B_B);
                    }else {
                        model.setPlantId(LePayConstant.PINGAN_B2B);
                    }
                }else {
                    LOGGER.info("平安直连网银交易类型错误! accountType="+accountType);
                    CommonMethod.getRemoteResult(returnResult, "", false, "404", "错误的支付请求参数");
                    return returnResult;
                }
            }
            model.setAccountType(accountType);
            model.setBankNo(bankNo);
            model.setCardType(cardType);
        }

        Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
        LOGGER.info("平安支付!outTradeNo[" + orderMainCode + "],merchantCode" + merchantCode + "],payType[" + payType + "],lenovoId[" + lenovoId + "],plat[" + plat + "],shopId[" + shopId + "],terminal[" + terminal + "],strClientIP[" + strClientIP + "]");
        //查询前置订单表
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(orderMainCode, lenovoId, tenant);
        PayPortalOrder payPortalOrder;
        if (payPortalOrderRemoteResult.isSuccess()) {
            payPortalOrder = payPortalOrderRemoteResult.getT();
            if (payPortalOrder == null || payPortalOrder.getOutTradeNo() == null) {
                LOGGER.info("PingAn Pay Get payPortalOrder Fail, outTradeNo[" + orderMainCode + "]");
                CommonMethod.getRemoteResult(returnResult, "", false, "400", "未查到支付订单数据");
                return returnResult;
            }
        } else {
            LOGGER.info("PingAn Pay Get payPortalOrder Fail, outTradeNo[" + orderMainCode + "]");
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "未查到支付订单数据");
            return returnResult;
        }

        RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult = null;
        MerchantPayPlatView merchantPayPlatView = null;
        try {
            if (PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(payPortalOrder.getPayStatus()))) {
                LOGGER.info("PayPortalOrder ALREADY PAID ,outTradeNo[" + orderMainCode + "]");
                CommonMethod.getRemoteResult(returnResult,"",false,"400","订单已支付，请到订单列表页确认!。");
                return returnResult;
            }
            if (PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(payPortalOrder.getOrderStatus()))) {
                LOGGER.info("PayPortalOrder Order Status INVALID, outTradeNo[" + orderMainCode + "]");
                CommonMethod.getRemoteResult(returnResult,"",false,"400","订单已失效，请到订单列表页确认!");
                return returnResult;
            }
            merchantPayPlatViewRemoteResult = commonPayManager.getMerchantPayPlatByAccountType(payPortalOrder.getFaId(),payType,Integer.parseInt(accountType));
            if (merchantPayPlatViewRemoteResult != null && merchantPayPlatViewRemoteResult.isSuccess()) {
                merchantPayPlatView = merchantPayPlatViewRemoteResult.getT();
                if (merchantPayPlatView == null || merchantPayPlatView.getId() <= 0) {
                    LOGGER.info("getMerchantPayPlat FAIL，FaId [" + payPortalOrder.getFaId() + "]");
                    CommonMethod.getRemoteResult(returnResult, "", false, "400", "商户信息查询失败");
                    return returnResult;
                }
                LOGGER.info("MerchantPayPlatView[" + merchantPayPlatView + "],OrderMainCode[" + orderMainCode + "]");
            } else {
                LOGGER.info("查询支付平台信息失败，订单号[" + orderMainCode + "]");
                CommonMethod.getRemoteResult(returnResult, "", false, "400", "商户信息查询失败");
                return returnResult;
            }
        } catch (Exception e) {
            LOGGER.info("平安银行支付异常 error!cause by:"+e);
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "支付服务异常");
            return returnResult;
        }
        String currencyCode = payPortalOrder.getCurrencyCode();
        String orderPrimaryId = null;
        try {
            RemoteResult<String> savePayOrderResult;
            RemoteResult<List<PayOrder>> orderListResult = aliPayCommonManager.getOrderListByPayType(orderMainCode, Integer.parseInt(payType));
            if (orderListResult.isSuccess() && orderListResult.getT().size() > 0) {
                orderPrimaryId = String.valueOf(orderListResult.getT().get(0).getId());
                LOGGER.info("Union mobile pay PayOrder Already EXIST，OrderPrimaryID [" + orderPrimaryId + "]");
                for (PayOrder payOrder : orderListResult.getT()) {
                    payOrderApi.updatePayOrderShopIdTerminal(String.valueOf(payOrder.getId()),model.getPlat(), model.getShopId(),model.getTerminal());
                }
                LOGGER.info("批量更新orderListResult完成. orderListResult[" + orderListResult + "]");
            } else {
                savePayOrderResult = commonManager.savePayOrder(lenovoId, model.getPlat(), payType, orderMainCode, String.valueOf(payPortalOrder.getTotalFee().getAmount()),
                        payPortalOrder.getSubject(), "0", 0, "0", merchantCode, bankNo, shopId, terminal, merchantPayPlatView,currencyCode);
                if (!savePayOrderResult.isSuccess()) {
                    LOGGER.warn("Union mobile pay Save PayOrder FAIL, OrderMainCode [" + orderMainCode + "]");
                    CommonMethod.getRemoteResult(returnResult, "", false, "400", "保存订单信息失败");
                    return returnResult;
                }
                LOGGER.info("Save PayOrder SUCCESS, OrderMainCode [" + orderMainCode + "]");
                orderPrimaryId = savePayOrderResult.getT();
                LOGGER.info("UmPay PayOrder NOT EXIST, New OrderPrimaryID [" + orderPrimaryId + "]");
            }
            if (org.apache.commons.lang.StringUtils.isEmpty(accountType)){
                accountType = "0";
            }
            int flag = payOrderService.updatePayBankByID(orderPrimaryId,bankNo,Integer.parseInt(accountType));
            if (flag <1){
                LOGGER.info("execute updatePayBankByID failure!");
            }
            // 扩展参数
        } catch (Exception e) {
            LOGGER.info("平安支付发生error!cause by:"+e);
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "支付平台订单处理失败");
            return returnResult;
        }
        String orderValidTime = aliPayCommonManager.getAliPropValue("order_valid_time");  // 订单有效时间
        String orderDate = DateUtil.date2String(new Date(),"yyyyMMdd");
        PingAnPayReq pingAnPayReq = this.payInvoke(merchantPayPlatView, orderDate,payPortalOrder,orderValidTime);

        String bodyHtml = null;
        String url = "";
        StringBuffer remark = new StringBuffer();
        remark.append(orderPrimaryId).append("PARTITION");
        try {
            if (PeakConstant.PAY_TYPE_PINGAN.equals(payType)) {
                // 网银直连
                if (StringUtils.isNotEmpty(model.getBankNo()) && StringUtils.isNotEmpty(model.getAccountType())){
                    if (isTest){
                        url = aliPayCommonManager.getAliPropValue("pingan_direct_bank_uat");
                    }else {
                        url = aliPayCommonManager.getAliPropValue("pingan_direct_bank_pro");
                    }
                    pingAnPayReq.setPlantId(model.getPlantId());
                    pingAnPayReq.setPlantBankId(model.getBankCode());
                }else { // 非直连
                    if (isTest){
                        url = aliPayCommonManager.getAliPropValue("pingan_gateway_pay_uat");
                    }else {
                        url = aliPayCommonManager.getAliPropValue("pingan_gateway_pay_pro");
                    }
                }
                pingAnPayReq.setRemark(remark.append(PeakConstant.TERMINAL_PC).toString());
                bodyHtml = this.buildDirectHtml(url, pingAnPayReq);
                bodyHtml = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"><title>平安PC支付</title></head><body>"
                        + bodyHtml + "</body></html>";
            } else if (PeakConstant.PAY_TYPE_PINGAN_WAP.equals(payType)){
                if (isTest){
                    url = aliPayCommonManager.getAliPropValue("pingan_wap_pay_uat");
                }else {
                    url = aliPayCommonManager.getAliPropValue("pingan_wap_pay_pro");
                }
                pingAnPayReq.setRemark(remark.append(PeakConstant.TERMINAL_WAP).toString());
                bodyHtml = this.buildDirectHtml(url, pingAnPayReq);
                bodyHtml = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"><title>平安WAP支付</title></head><body>"
                        + bodyHtml + "</body></html>";
            }else {
                LOGGER.info("Unable to resolve current payType! payType="+payType);
                return null;
            }
            if (StringUtils.isNotEmpty(bodyHtml)) {
                CommonMethod.getRemoteResult(returnResult, bodyHtml, true, "200", "支付网页生成成功");
                return returnResult;
            } else {
                CommonMethod.getRemoteResult(returnResult, bodyHtml, false, "400", "支付网页生成失败");
                return returnResult;
            }
        } catch (Exception e) {
            LOGGER.info("构建平安银行直连HTML请求报文失败 error!cause by:"+e);
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "支付服务异常");
            return returnResult;
        }
    }

    /**
     * 拼装form表单数据提交到跨行支付网关
     * @param url
     * @param pingAnPayReq
     * @return
     */
    private String buildDirectHtml(String url, PingAnPayReq pingAnPayReq) {
        KeyedCollection keyedCollection=getInputOrig(pingAnPayReq);
        Map<String,String> resutlMap=getSigner(keyedCollection);
        StringBuffer buffer = new StringBuffer();
        if(null!=resutlMap) {
            buffer.append("<form id=\"paydirsubmit\" action=\"" + url + "\" method=\"post\">")
                    .append("<input type=\"hidden\" name=\"orig\" value=\"" + resutlMap.get("orig") + "\"/>")
                    .append("<input type=\"hidden\" name=\"sign\" value=\"" + resutlMap.get("sign") + "\"/>")
                    .append("<input type=\"hidden\" name=\"returnurl\" value=\"" + pingAnPayReq.getReturnUrl() + "\"/>")
                    .append("<input type=\"hidden\" name=\"NOTIFYURL\" value=\"" + pingAnPayReq.getNotifyUrl() + "\"/>")
                    .append("<input type=\"submit\" value=\"提交\" style=\"display:none;\"></form>" +
                            "<script>document.forms['paydirsubmit'].submit();</script>");
        }else{
            log.info("平安银行获取支付签名失败!====>keyedCollection="+keyedCollection);
        }
        return buffer.toString();
    }

    /**
     *
     * @param merchantPayPlatView
     * @param payPortalOrder
     * @param validtime
     * @return
     */
    private PingAnPayReq payInvoke(MerchantPayPlatView merchantPayPlatView, String orderDate,PayPortalOrder payPortalOrder,String validtime) {
        PingAnPayReq pingAnPayReq = new PingAnPayReq();
        pingAnPayReq.setMasterId(merchantPayPlatView.getMechId());//商户号
        //设置订单号 格式为 商户号加8号日期+8位流水
        //流水号 截取后八位，uat为90  domain为20
        String millis = String.valueOf(System.currentTimeMillis());

        String subOrderPrimaryId = millis.substring(millis.length()-8,millis.length());
        String orderId=merchantPayPlatView.getMechId()+orderDate+subOrderPrimaryId;
        pingAnPayReq.setOrderId(orderId);//订单号
        pingAnPayReq.setCurrency("RMB");//币种，目前只支持RMB
        pingAnPayReq.setAmount(String.valueOf(payPortalOrder.getTotalFee().getAmount()));
        pingAnPayReq.setObjectName(payPortalOrder.getSubject());//订单款项描述（商户自定）

        // 准备第二个模板，将提取后的日期数字变为指定的格式
        String format = "yyyyMMddHHmmss" ;
        SimpleDateFormat sdf = new SimpleDateFormat(format);        // 实例化模板对象
        pingAnPayReq.setPaydate(sdf.format(payPortalOrder.getOrderTime()));//下单时间，YYYYMMDDHHMMSS
        if (StringUtils.isEmpty(validtime)){
            pingAnPayReq.setValidtime(validtime);
        }else {
            pingAnPayReq.setValidtime("0");//订单有效期(毫秒)，0 不生效
        }
        pingAnPayReq.setNotifyUrl(merchantPayPlatView.getOutNotifyUrl());
        pingAnPayReq.setReturnUrl(merchantPayPlatView.getOutCallBackUrl());
        pingAnPayReq.setSuccess(true);
        LOGGER.info("平安直连支付，请求参数：" + pingAnPayReq.toString());
        return pingAnPayReq;
    }


    //生成包含原始订单信息的KeyedCollection
    private KeyedCollection getInputOrig(PingAnPayReq pingAnPayReq){
        KeyedCollection inputOrig = new KeyedCollection("inputOrig");
        inputOrig.put("masterId",pingAnPayReq.getMasterId());  //商户号，注意生产环境上要替换成商户自己的生产商户号
        inputOrig.put("orderId",pingAnPayReq.getOrderId());  //订单号，严格遵守格式：商户号+8位日期YYYYMMDD+8位流水
        inputOrig.put("currency","RMB");  //币种，目前只支持RMB
        inputOrig.put("amount",pingAnPayReq.getAmount());  //订单金额，12整数，2小数
        inputOrig.put("paydate",pingAnPayReq.getPaydate());  //下单时间，YYYYMMDDHHMMSS
        String subject = LePayUtil.replaceSpecStr(pingAnPayReq.getObjectName());
        if (subject.length() > 60) {
            subject = subject.substring(0,60);
        }
        inputOrig.put("objectName",subject);  //订单款项描述（商户自定）
        inputOrig.put("validtime",pingAnPayReq.getValidtime());  //订单有效期(秒)，0不生效
        inputOrig.put("remark",pingAnPayReq.getRemark());  // 用户自定义字段
        if (StringUtils.isNotEmpty(pingAnPayReq.getPlantId()) && StringUtils.isNotEmpty(pingAnPayReq.getPlantBankId())){
            inputOrig.put("plantId", pingAnPayReq.getPlantId());
            inputOrig.put("plantBankId", pingAnPayReq.getPlantBankId());
        }
        return inputOrig;
    }

    //组装特定的业务对象结构化数据
    private Map<String,String> getSigner(KeyedCollection keyedCollection){
        Map<String,String> resultMap=new HashMap<String,String>();
        try {
            //建立客户端实例
            PayclientInterfaceUtil util = new PayclientInterfaceUtil();
            //创建业务对象结构化送数据
            KeyedCollection signDataput = new KeyedCollection("signDataput");
            //原始数据
            String orig="";
            //签名数据
            String sign="";
            String encoding = "GBK";
            //签名
            signDataput = util.getSignData(keyedCollection);
            log.info("---签名结果---"+signDataput);
            orig = (String)signDataput.getDataValue("orig");  //获取原始数据
            log.info("---原始数据---"+orig);
            sign = (String)signDataput.getDataValue("sign");  //获取签名数据
            log.info("---签名数据---"+sign);
            orig = PayclientInterfaceUtil.Base64Encode(orig,encoding);  //原始数据先做Base64Encode转码
            orig = java.net.URLEncoder.encode(orig, encoding);  //Base64Encode转码后原始数据,再做URL转码
            log.info("---Base64Encode转码URL转码后原始数据---"+orig);
            resultMap.put("orig",orig);

            sign = PayclientInterfaceUtil.Base64Encode(sign,encoding);  //签名数据先做Base64Encode转码
            sign = java.net.URLEncoder.encode(sign, encoding);  //Base64Encode转码后签名数据,再做URL转码
            resultMap.put("sign",sign);
            log.info("---Base64Encode转码URL转码后签名数据---" + sign);
        } catch (Exception e) {
            log.info("---平安支付数据签名转码错误!cause by:",e);
        }
        return resultMap;
    }

    @Override
    public RemoteResult<String> callUpdate(PayOrder payOrder, MerchantPayPlatView merchantPayPlatView, String tradeNo, Map<String, Object> paraMap) {
        RemoteResult<String> returnResult = new RemoteResult<String>();
        if (LePayUtil.isPaidPayOrder(payOrder)) {
            log.info("订单已支付，流水号==>" + payOrder.getId());
            CommonMethod.getRemoteResult(returnResult, "", true, "200", "SUCCESS");
            return returnResult;
        } else {
            try {
                commonCallBackManager.updatePayNotifyState(payOrder.getId(), payOrder.getU_id(), tradeNo, PeakConstant.MFLAG_REPEAT, null, PeakConstant.TRADE_SUCCESS, "", payOrder.getPay_type());
                log.info("Call Update PayOrder, OrderPrimaryId[" + payOrder.getId() + "],TransactionId[" + tradeNo + "]");
            } catch (Exception e) {
                log.info("Call Update PayOrder Exception, OrderPrimaryId[" + payOrder.getId() + "] error!cause by:"+e);
            }
            try {
                PayPortalOrder updatePayPortalOrder = CommonMethod.buildUpdatePayPortalOrder(String.valueOf(payOrder.getId()), payOrder.getOut_trade_no(), payOrder.getU_id(), payOrder.getPay_type(), PeakConstant.PAY_STATUS_ALREADY_PAID, payOrder.getShop_id(), new Date());
                RemoteResult<Integer> updatePayPortalOrderResult = payPortalOrderManager.updatePayPortalOrderPayStatus(updatePayPortalOrder);
                if (updatePayPortalOrderResult.isSuccess()) {
                    log.info("Update PayPortalOrder SUCCESS，outTradeNo[" + payOrder.getOut_trade_no() + "]");
                    CommonMethod.getRemoteResult(returnResult, "", true, "200", "SUCCESS");
                } else {
                    log.info("Update PayPortalOrder FAIL，outTradeNo[" + payOrder.getOut_trade_no() + "]");
                }
            } catch (Exception e) {
                log.info("Call Update ChannelOrder Exception, OrderPrimaryId[" + payOrder.getId() + "] error!cause by:"+e);
            }
        }
        return returnResult;
    }
}
