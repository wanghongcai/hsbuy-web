package com.lenovo.m2.buy.promotion.admin.manager.pay.allinpay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;

import javax.servlet.http.HttpServletRequest;

/**
 * 通联支付接口
 * Created by zhangqy10 on 2016/11/1.
 */
public interface AllinpayManager {

    /**
     * 去支付
     * @param request request
     * @return RemoteResult<String>
     */
    public RemoteResult<String> toPay(HttpServletRequest request);

    /**
     * 异步回调验证签名
     * @param request
     * @param merchantPayPlatView
     * @return
     */
    public boolean verifyNotify(HttpServletRequest request, MerchantPayPlatView merchantPayPlatView, String certPath);
}
