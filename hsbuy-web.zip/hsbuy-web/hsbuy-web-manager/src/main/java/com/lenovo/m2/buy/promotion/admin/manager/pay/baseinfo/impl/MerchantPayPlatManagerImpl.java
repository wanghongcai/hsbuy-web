package com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.MerchantPayPlatManager;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.FakeRule;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.OrderSupportPayType;
import com.lenovo.m2.hsbuy.service.pay.soa.MerchantPayPlatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by yangjj7 on 2015/5/2.
 */
@Service
public class MerchantPayPlatManagerImpl implements MerchantPayPlatManager {

    @Autowired
    private MerchantPayPlatService merchantPayPlatService;


    @Override
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatByMerchantId(String merchantId, int payType) {

        return merchantPayPlatService.getMerchantPayPlatByMerchantId(merchantId,payType);
    }

    @Override
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatForWeChat(String merchantId, int payType, String shopId) {
        return merchantPayPlatService.getMerchantPayPlatForWeChat(merchantId,payType,shopId);
    }


    @Override
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatById(long merchantId) {

        return merchantPayPlatService.getMerchantPayPlatById(merchantId);
    }

    @Override
    public RemoteResult<List<OrderSupportPayType>> getOrderSupportPayTypeList(String FAID) {
        return merchantPayPlatService.getOrderSupportPayTypeList(FAID);
    }

    @Override
    public RemoteResult<List<FakeRule>> getMerchantPayPlatByGroupBy() {
        return merchantPayPlatService.getMerchantPayPlatByGroupBy();
    }

    @Override
    public RemoteResult<List<OrderSupportPayType>> getOrderSupportPayTypeListByFaIDPayment(String faId, List<Integer> payTypeList) {
        return merchantPayPlatService.getOrderSupportPayTypeListByFaIDPayment(faId, payTypeList);
    }
}
