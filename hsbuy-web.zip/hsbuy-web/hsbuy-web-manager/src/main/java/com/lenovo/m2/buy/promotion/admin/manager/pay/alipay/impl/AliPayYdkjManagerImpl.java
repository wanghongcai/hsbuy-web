package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.impl;

import com.alibaba.fastjson.JSON;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.ReturnCode;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.*;
import com.lenovo.m2.buy.promotion.admin.domain.pay.alipay.DirectTradeCreateRes;
import com.lenovo.m2.buy.promotion.admin.manager.pay.PayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by caoxd2 on 2015/7/15.
 */
@Service
public class AliPayYdkjManagerImpl implements PayManager {

    private static final Logger logger = Logger.getLogger(AliPayYdkjManagerImpl.class);

    private static final String configFilePath = "ali_ydkj.properties";

    private static final String requestUrl = "http://wappaygw.alipay.com/service/rest.htm";

    @Autowired
    private AliPayCommonManager aliPayCommonManager;

    @Autowired
    private PayOrderApi payOrderApi;

    @Autowired
    private CommonManager commonManager;


    @Override
    public boolean isParamValid(RemoteResult<String> romoteResult, HttpServletRequest request) {
        boolean returnResult = true;
        String orderMainCode = request.getParameter("orderMainCode");

        if(StringUtils.isBlank(orderMainCode)){
            String errorMsg = "订单号不能为空";
            logger.warn(errorMsg);
            CommonMethod.getRemoteResult(romoteResult, errorMsg, false, ReturnCode.PayParamError.getCode(), ReturnCode.PayParamError.getMessage());
            returnResult = false;
        }
        return returnResult;
    }

    @Override
    public RemoteResult<String> prepareForPay(HttpServletRequest request) {
        logger.warn("支付宝移动快捷支付请求参数：" + JSON.toJSONString(request.getParameterMap()));
        RemoteResult<String> remoteResult = new RemoteResult<String>();
        try{
            if(isParamValid(remoteResult,request)){
                BaseModel baseModel = (BaseModel) BaseModel.getModel(request);
                PayPortalOrder payPortalOrder = aliPayCommonManager.getPayPortalOrderInfo(baseModel.getOrderMainCode(), baseModel.getLenovoId(), baseModel.getPlat(), aliPayCommonManager.getAliPropValue(baseModel.getMerchantCode()), baseModel.getShopId());
                if(PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(payPortalOrder.getPayStatus()))){
                    logger.info("Check PayPortalOrder Already PAY, OrderMainCode [" + baseModel.getOrderMainCode() + "]");
                    CommonMethod.getRemoteResult(remoteResult, "", false, "400", "订单已支付，请到订单列表页确认");
                    return remoteResult;
                }
                if(PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(payPortalOrder.getOrderStatus()))){
                    logger.info("Check PayPortalOrder OrderStatus FAIL, OrderMainCode [" + baseModel.getOrderMainCode() + "]");
                    CommonMethod.getRemoteResult(remoteResult, "", false, "400", "订单已失效，请到订单列表页确认");
                    return remoteResult;
                }
                RemoteResult<MerchantPayPlatView> merchantResultInfo = aliPayCommonManager.getMerchantPayPlatView(payPortalOrder.getFaId(),baseModel.getPayType());
                if(merchantResultInfo.isSuccess()) {
                    MerchantPayPlatView merchantPayPlatView = merchantResultInfo.getT();
                    Map<String, String> reqParams = prepareTradeRequestParamsMap(request,baseModel,payPortalOrder,merchantPayPlatView);
                    String signAlgo = AlipayConfig.sign_type;
                    String reqUrl = requestUrl;
                    /** 获取商户MD5 key */
                    String key = merchantPayPlatView.getSignKey();
                    String sign = sign(reqParams, signAlgo, key);
                    reqParams.put("sign", sign);
                    try {
                        remoteResult = send(reqParams, reqUrl,merchantPayPlatView);
                    } catch (Exception e1) {
                        logger.error("移动快捷支付的过程中出现异常：", e1);
                    }
                    DirectTradeCreateRes directTradeCreateRes = null;
                    XMapUtil.register(DirectTradeCreateRes.class);
                    try {
                        directTradeCreateRes = (DirectTradeCreateRes) XMapUtil
                                .load(new ByteArrayInputStream(remoteResult.getT().getBytes("UTF-8")));
                    } catch (Exception e) {
                        logger.error("解析移动快捷支付xml的过程中出现异常：",e);
                    }
                    /** 开放平台返回的内容中取出request_token */
                    String requestToken = directTradeCreateRes.getRequestToken();
                    Map<String, String> authParams = prepareAuthParamsMap(merchantPayPlatView,
                            requestToken);
                    /** 对调用授权请求数据签名 */
                    String authSign = sign(authParams, signAlgo, key);
                    authParams.put("sign", authSign);
                    String redirectURL = "";
                    try {
                        redirectURL = getRedirectUrl(authParams, reqUrl);
                        System.out.println("redirectURL:" + redirectURL);
                    } catch (Exception e) {
                        logger.error("获取移动快捷支付重定向URL的过程中出现异常：",e);
                    }
                    if (StringUtil.isNotBlank(redirectURL)) {
                        remoteResult.setSuccess(true);
                        remoteResult.setT(redirectURL);
                    }
                }
            }
        }catch(Exception ex){
            logger.error("移动快捷支付组装参数的过程中出现异常：",ex);
        }

        logger.warn("移动快捷支付返回结果：" + remoteResult);
        return remoteResult;
    }

    @Override
    public void payCallback(HttpServletRequest request, HttpServletResponse response) {

    }

    @Override
    public void syncCallback(int plat, HttpServletResponse response) {

    }

    /**
     * 准备alipay.wap.trade.create.direct服务的参数
     *
     * @param request
     * @return 请求参数map
     * @throws UnsupportedEncodingException
     */
    private Map<String, String> prepareTradeRequestParamsMap(
            HttpServletRequest request,BaseModel baseModel,PayPortalOrder payPortalOrder,MerchantPayPlatView merchantPayPlatView) throws UnsupportedEncodingException {
        Map<String, String> requestParams = new HashMap<String, String>();
        String cashierCode=request.getParameter("cashierCode");
        String out_user=baseModel.getLenovoId();
        if(StringUtils.isBlank(out_user)){
            out_user="";
        }
        request.setCharacterEncoding("utf-8");
        String subject =  CommonMethod.getProductName(payPortalOrder.getSubject());
        String currencyCode = payPortalOrder.getCurrencyCode();
        String totalFee = String.valueOf(payPortalOrder.getTotalFee().getAmount());
        String payTransactionId = null;
        RemoteResult<String> savePayOrderResult = new RemoteResult<String>();
        RemoteResult<List<PayOrder>> orderListResult = aliPayCommonManager.getOrderListByPayType(payPortalOrder.getOutTradeNo(), Integer.parseInt(baseModel.getPayType()));
        if(orderListResult.isSuccess() && orderListResult.getT().size() > 0){
            payTransactionId = String.valueOf(orderListResult.getT().get(0).getId());
            logger.info("支付宝移动快捷支付类型交易已存在，ID==>" + payTransactionId);
        }else{
            savePayOrderResult = aliPayCommonManager.savePayOrder(baseModel.getPlat(),payPortalOrder.getOutTradeNo(),baseModel.getMerchantCode(),baseModel.getPayType(),baseModel.getLenovoId(),merchantPayPlatView, String.valueOf(payPortalOrder.getTotalFee().getAmount()),subject,currencyCode);
            logger.info("保存订单成功");
            payTransactionId = savePayOrderResult.getT();
            logger.info("查询支付宝移动快捷支付类型交易不存在，新建记录ID==>" + payTransactionId);
        }
        String sellerAccountName = merchantPayPlatView.getAppId();
        String notifyUrl = merchantPayPlatView.getOutNotifyUrl();
        notifyUrl = CommonMethod.getHlwzqUrl(notifyUrl);
        String callbackUrl = merchantPayPlatView.getOutCallBackUrl();
        StringBuilder reqData = new StringBuilder();
        reqData.append("<direct_trade_create_req>").append("<subject>"+ subject+"</subject>");
        reqData.append("<out_trade_no>" + payTransactionId + "</out_trade_no>");//
        reqData.append("<total_fee>" + totalFee+ "</total_fee>");
        reqData.append("<seller_account_name>" + sellerAccountName+ "</seller_account_name>");
        reqData.append("<notify_url>" + notifyUrl+ "</notify_url>");
        reqData.append("<call_back_url>" + callbackUrl+ "</call_back_url>");
        reqData.append("<out_user>" + out_user+ "</out_user>");
        /**如果cashierCode不为空就组装此参数*/
        if (StringUtils.isNotBlank(cashierCode)) {
            reqData.append("<cashier_code>" + cashierCode+ "</cashier_code>");
        }
        reqData.append("</direct_trade_create_req>");
        requestParams.put("req_data", reqData.toString());
        requestParams.put("req_id", System.currentTimeMillis() + "");
        requestParams.putAll(prepareCommonParams(merchantPayPlatView));
        return requestParams;
    }

    /**
     * 准备通用参数
     *
     * @param merchantPayPlatView
     * @return 通用参数map
     */
    private Map<String, String> prepareCommonParams(MerchantPayPlatView merchantPayPlatView) {
        Map<String, String> commonParams = new HashMap<String, String>();
        commonParams.put("service", "alipay.wap.trade.create.direct");
        commonParams.put("sec_id", AlipayConfig.sign_type);
        commonParams.put("partner", merchantPayPlatView.getMechId());
        commonParams.put("format", "xml");
        commonParams.put("v", "2.0");
        return commonParams;
    }

    /**
     * 对参数进行签名
     * @param reqParams 待签名参数
     * @param signAlgo 签名类型
     * @param key MD5校验码
     * @return 返回签名结果
     */
    private String sign(Map<String, String> reqParams, String signAlgo,
                        String key) {

        String signData = ParameterUtil.getSignData(reqParams);

        String sign = "";
        try {
            sign = MD5Signature.sign(signData, key);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return sign;
    }

    /**
     * 获取请求数据
     * @param reqParams 请求参数map
     * @param reqUrl 请求url
     * @return 返回请求结果数据
     * @throws Exception
     */
    private RemoteResult<String> send(Map<String, String> reqParams, String reqUrl, MerchantPayPlatView merchantPayPlatView) throws Exception {
        String response = "";
        String invokeUrl = reqUrl;
        URL serverUrl = new URL(invokeUrl);
        HttpURLConnection conn = (HttpURLConnection) serverUrl.openConnection();

        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.connect();
        String params = ParameterUtil.mapToUrl(reqParams);
        conn.getOutputStream().write(params.getBytes());

        InputStream is = conn.getInputStream();

        BufferedReader in = new BufferedReader(new InputStreamReader(is));
        StringBuffer buffer = new StringBuffer();
        String line = "";
        while ((line = in.readLine()) != null) {
            buffer.append(line);
        }
        response = URLDecoder.decode(buffer.toString(), "utf-8");
        conn.disconnect();
        in.close();
        return praseResult(response,merchantPayPlatView);
    }

    /**
     * 解析支付宝返回的结果
     * @param response
     * @return
     * @throws Exception
     */
    private RemoteResult<String> praseResult(String response, MerchantPayPlatView merchantPayPlatView)
            throws Exception {
        RemoteResult<String> result = new RemoteResult<String>();

        HashMap<String, String> resMap = new HashMap<String, String>();
        String v = ParameterUtil.getParameter(response, "v");
        String service = ParameterUtil.getParameter(response, "service");
        String partner = ParameterUtil.getParameter(response, "partner");
        String sign = ParameterUtil.getParameter(response, "sign");
        String reqId = ParameterUtil.getParameter(response, "req_id");
        resMap.put("v", v);
        resMap.put("service", service);
        resMap.put("partner", partner);
        resMap.put("sec_id", AlipayConfig.sign_type);
        resMap.put("req_id", reqId);

        if (response.contains("<err>")) {
            result.setT(response);
            result.setSuccess(false);

            /** 转换错误信息 */
            logger.info("移动快捷支付出现异常：" + response);
        } else {
            String businessResult = ParameterUtil.getParameter(response, "res_data");
            result.setT(businessResult);
            result.setSuccess(true);
            resMap.put("res_data", businessResult);
            /** 获取待签名数据 */
            String verifyData = ParameterUtil.getSignData(resMap);
            /** 对待签名数据验签名 */
            boolean verified = MD5Signature.verify(verifyData, sign,
                    merchantPayPlatView.getSignKey());
            if (!verified) {
                logger.error("移动快捷支付验签失败：" + verifyData + " sign is " + sign);
                throw new Exception("验证签名失败");
            }
        }

        return result;
    }

    /**
     * 准备alipay.wap.auth.authAndExecute服务的参数
     *
     * @param merchantPayPlatView
     * @param requestToken
     * @return 返回授权接口参数map
     */
    private Map<String, String> prepareAuthParamsMap(
            MerchantPayPlatView merchantPayPlatView, String requestToken) {
        Map<String, String> requestParams = new HashMap<String, String>();
        StringBuilder reqData = new StringBuilder();
        reqData.append("<auth_and_execute_req><request_token>"+requestToken+"</request_token>")
                .append("</auth_and_execute_req>");
        requestParams.put("req_data", reqData.toString());
        requestParams.putAll(prepareCommonParams(merchantPayPlatView));
        requestParams.put("service", "alipay.wap.auth.authAndExecute");
        return requestParams;
    }

    /**
     * 调用alipay.wap.auth.authAndExecute服务的时候需要跳转到支付宝的页面，组装跳转url
     * @param reqParams
     * @param reqUrl 请求url
     * @return 返回组装好的url字符串
     * @throws Exception
     */
    private String getRedirectUrl(Map<String, String> reqParams, String reqUrl)
            throws Exception {
        String redirectUrl = reqUrl + "?";
        redirectUrl = redirectUrl + ParameterUtil.mapToUrl(reqParams);
        return redirectUrl;
    }
}
