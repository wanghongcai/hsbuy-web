package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.manager.GenericManager;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * Created by zhanglijun on 2015/5/23.
 */
public interface AliPaySjManager  extends GenericManager<PayOrder, Long> {




    /**
     * 获取订单信息
     * @param orderId
     * @param lenovoId
     * @param merchantOrderUrl
     * @return
     */
    public Map<String,Object> getMchOrderInfo(String orderId, String lenovoId, String merchantOrderUrl);

    /**
     * 构建支付宝手机支付请求

     * @return
     */
    public String getPsnSjHtml(String partner, String seller_email, String key,
                               String orderNum, String prodName, String _total_fee, int plat,
                               long expire, String notify_url, String call_back_url)throws Exception;

    /**
     *更新支付订单
     * @param lenovoId
     * @param key_id
     * @param trade_no
     * @param gmt_payment
     * @param merchantCode
     * @param payType
     */
    public RemoteResult<Map<String,Object>> callUpdate(String lenovoId, String key_id, String trade_no, String gmt_payment, String merchantCode, String payType, MerchantPayPlatView merchantPayPlatView);


    /**
     * 支付宝手机即时业务Manager
     * @param request
     * @return
     */
    public RemoteResult toAliSjPay(HttpServletRequest request);

    public RemoteResult toAliSjPayWxAlipay(HttpServletRequest request, Map<String, Object> wxmap) ;


}
