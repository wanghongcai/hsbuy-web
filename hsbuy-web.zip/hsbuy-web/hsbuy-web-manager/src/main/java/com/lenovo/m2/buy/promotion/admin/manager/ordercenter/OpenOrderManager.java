package com.lenovo.m2.buy.promotion.admin.manager.ordercenter;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.domain.ordercenter.ThrowWareHouseListParam;
import com.lenovo.m2.buy.promotion.admin.domain.ordercenter.ThrowWareHouseResult;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.domain.order.mongo.PayRecords;
import com.lenovo.m2.hsbuy.domain.ordercenter.AuditOrderDetailRequest;
import com.lenovo.m2.hsbuy.domain.ordercenter.AuditOrderDetailResult;
import com.lenovo.m2.hsbuy.domain.ordercenter.DownlinePayListParam;
import com.lenovo.m2.hsbuy.domain.throwengine.OrderItemHSVo;

import java.util.List;
import java.util.Map;

/**
 * Created by jh on 2016/9/9.
 */
public interface OpenOrderManager {

    /**
     * 获取惠商待审核订单（分页）
     *
     * @param pageQuery
     * @param filterMap
     * @param tenant
     * @return
     */
    RemoteResult<PageModel2<MongoOrderDetail>> getMongoOrderList(PageQuery pageQuery, Map<String, Object> filterMap, Tenant tenant);

    /**
     * 组装惠商审单详情页数据
     *
     * @param map    key：orderId
     * @param tenant
     * @return
     */
    RemoteResult<AuditOrderDetailResult> getMongoOrderDetail(Map<String, Object> map, Tenant tenant);

    /**
     * 惠商审单
     *
     * @param request
     * @param tenant
     * @return
     */
    RemoteResult auditOrderDetail(AuditOrderDetailRequest request, Tenant tenant);

    /**
     * 获取惠商抛单列表
     *
     * @param param
     * @return
     */
    RemoteResult<ThrowWareHouseResult> getHSThrowList(ThrowWareHouseListParam param);


    RemoteResult saveItemsWareHouse(List<OrderItemHSVo> list, int shopId);

    RemoteResult saveItemsWareHouseAndThrowOrder(OrderItemHSVo orderItem);

    RemoteResult<PageModel2<PayRecords>> queryDownlinePayList(DownlinePayListParam downlinePayParam);
}
