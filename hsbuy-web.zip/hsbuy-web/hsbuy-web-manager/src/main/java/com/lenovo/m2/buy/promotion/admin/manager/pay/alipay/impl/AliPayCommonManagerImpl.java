package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.impl;

import com.alibaba.fastjson.JSON;
import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.LePayConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.ReturnCode;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.Signature;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.Util;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.MerchantPayPlatManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.PayOrderView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import com.lenovo.m2.arch.tool.util.StringParse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * Created by MengQiang on 2015/5/22.
 */
@Service
public class AliPayCommonManagerImpl implements AliPayCommonManager {
    private final Logger logger = Logger.getLogger(this.getClass());

    @Autowired
    private PayOrderApi payOrderApi;
    @Autowired
    private MerchantPayPlatManager merchantPayPlatManager;

    @Autowired
    private CommonCallBackManager commonCallBackManager;

    @Autowired
    private CommonManager commonManager;


    @Autowired
    private PayPortalOrderManager payPortalOrderManager;

    @Override
    public RemoteResult<String> savePayOrder(String os, String orderMainCode, String merchantCode, String payType, String lenovoId, MerchantPayPlatView merchantPayPlatView, String _total_fee, String prodName, String currencyCode) {

        return  this.savePayOrder( os,  orderMainCode,  merchantCode,  payType,  lenovoId,  merchantPayPlatView, _total_fee, prodName,"",0,"","",currencyCode);
        }
    public RemoteResult<String> savePayOrder(String os, String orderMainCode, String merchantCode, String payType, String lenovoId, MerchantPayPlatView merchantPayPlatView, String _total_fee, String prodName, String fqRate, int fqNum, String fqCode, String pay_bank, String currencyCode){
        RemoteResult<String> remoteResult = new RemoteResult<String>();
        try {
            PayOrderView orderView = getPayOrderView(os, orderMainCode, merchantCode, payType, lenovoId, merchantPayPlatView, _total_fee,prodName);
            //***************************//
            orderView.setFq_rate(fqRate);
            orderView.setFq_num(fqNum);
            orderView.setFq_code(fqCode);
            orderView.setPay_bank(pay_bank);
            orderView.setPay_money(new Money(_total_fee, currencyCode));
            orderView.setCurrencyCode(currencyCode);
            //**************************//
            remoteResult = payOrderApi.savePayOrder(orderView);
            remoteResult.setSuccess(true);
            remoteResult.setResultCode(ReturnCode.Success.getCode());
            logger.info("<--------保存支付订单信息---------->" + remoteResult.getT());
        } catch (Exception e) {
            logger.error("保存支付订单失败！", e);
            remoteResult.setSuccess(false);
            remoteResult.setResultCode(ReturnCode.PayParamError.getCode());
            remoteResult.setResultCode(ReturnCode.PayParamError.getMessage());
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatView(String merchantCode, String payType) {
        RemoteResult<MerchantPayPlatView> remoteResult = new RemoteResult<MerchantPayPlatView>();
        logger.info(" 商户号:" + merchantCode + "  支付类型:" + payType);
        if (merchantCode == null || payType == null) {
            logger.info("merchantCode or payType is null!");
            return null;
        }
        try{
            remoteResult = merchantPayPlatManager.getMerchantPayPlatByMerchantId(merchantCode, StringParse.parseInt(payType));
        }catch(Exception e){
            logger.error("查询商户平台信息异常",e);
            remoteResult.setSuccess(false);
            return remoteResult;
        }
        return remoteResult;
    }

    @Override
    public boolean checkPay(String payStatus) {
        //正向逻辑,true为已支付,false为未支付
        return "1".equals(payStatus)?true:false;
    }

    @Override
    public boolean checkOrderStatus(String orderStatus) {
        //正向逻辑,true已失效,false未失效
        return "1".equals(orderStatus)?true:false;
    }

    @Override
    public String getAliPropValue(String key) {
        String value = "";
        InputStream inputStream = null;
        try {
            inputStream = AliPayCommonManagerImpl.class.getClassLoader().getResourceAsStream("ali_pay.properties");
            Properties prop = new Properties();
            prop.load(inputStream);
            value = prop.getProperty(key);
            logger.info("prop->"+ value);
        } catch (IOException e) {
            logger.error("获取查询订单URL失败",e);
        } finally {
            try {
                inputStream.close();
            } catch (IOException e) {
                inputStream = null;
            }
        }
        return value;
    }

    /**
     * 是否是测试支付
     * @param key
     * @return
     */
    @Override
    public boolean isTestPay(String key){
        String testTag = "";
        try {
            testTag = getAliPropValue(key);
            if (LePayConstant.IS_TEST_PAY.equals(testTag)){
                return true;
            }else if (LePayConstant.IS_REAL_PAY.equals(testTag)){
                return false;
            }else {
                return false;
            }
        }catch (Exception e){
            logger.info("Call isTestPay Error:Error Cause By :" + e);
            return false;
        }
    }

    @Override
    public String updateRemoteOrder(MerchantPayPlatView merchantPayPlatView, String trade_no, String orderMainCode, String gmt_payment, String lenovoId, String payment, String signature, String orderPrimaryId) throws Exception {
        PayOrder payOrder = payOrderApi.getPayOrderByPrimaryId(Long.valueOf(orderPrimaryId));
        if(payOrder==null){
            logger.info("异步回调失败，未找到原支付订单，订单唯一标识：" + orderPrimaryId);
            return "fail";
        }
        RemoteResult<MerchantPayPlatView> merchantPayPlatViewResult = new RemoteResult<MerchantPayPlatView>();
        try{
            merchantPayPlatViewResult = merchantPayPlatManager.getMerchantPayPlatById(payOrder.getMerchant_id());
        }catch(Exception e){
            logger.error("查询商户平台信息异常",e);
            return "fail";
        }
        if(merchantPayPlatViewResult.isSuccess()){
            logger.info("异步回调订单查询商户平台信息成功，订单唯一标识：" + orderPrimaryId);
        }else{
            logger.info("异步回调订单查询商户平台信息失败，订单唯一标识：" + orderPrimaryId);
            return "fail";
        }
        String payCallbackUrl = "trade_no=" + trade_no + "&orderMainCode=" + orderMainCode + "&payDatetime=" + gmt_payment + "&payment=" + payment + "&lenovoId=" + lenovoId + "&signature=" + signature + "&orderPrimaryId="+orderPrimaryId;
        logger.warn("更新订单参数==>" + payCallbackUrl);
        RemoteResult<String> remoteResult = commonCallBackManager.payCallback(merchantPayPlatViewResult.getT(),payOrder.getOs(),signature,payOrder.getOut_trade_no(),trade_no,gmt_payment,payment,lenovoId,payOrder.getId().toString(),payOrder);
        logger.warn("更新订单状态返回结果：" + JSON.toJSONString(remoteResult));
        if(remoteResult.isSuccess()){
            return remoteResult.getT();
        }else{
            return "fail";
        }
    }

    @Override
    public String getSignature(String orderPrimaryId, String payOrderCode, String orderCode, String payDatetime, String payment, String lenovoId) {
        Map paraMap = new HashMap();
        paraMap.put("orderPrimaryId", "");
        paraMap.put("payOrderCode", payOrderCode);
        paraMap.put("orderCode", orderCode);
        paraMap.put("payDatetime", payDatetime);
        paraMap.put("payment", payment);
        paraMap.put("lenovoId", lenovoId);
        Map proMap = PropertiesHelper.loadToMap();
        return Signature.getSign(paraMap, (String) proMap.get("b2cKey"));
    }

    private PayOrderView getPayOrderView(String os, String orderMainCode, String merchantCode, String payType, String lenovoId, MerchantPayPlatView merchantPayPlatView, String _total_fee, String prodName) {
        PayOrderView payOrderView = new PayOrderView();
        payOrderView.setOs(Integer.parseInt(os));
        payOrderView.setOut_trade_no(orderMainCode);
        payOrderView.setU_id(lenovoId);
        payOrderView.setPay_type(Integer.parseInt(payType));

        payOrderView.setMerchant_id(merchantPayPlatView.getId());
        payOrderView.setMerchant_flag(PeakConstant.MFLAG_NOT);
        payOrderView.setTrade_state(0);
        String total_fee = "";
        total_fee = Util.getMoney(_total_fee);//支付金额

        payOrderView.setTotal_fee(Integer.parseInt(total_fee));
        payOrderView.setBody(prodName);
        payOrderView.setTime_start(new Date());
        payOrderView.setVersion(PeakConstant.VERSION_ONE);
        payOrderView.setMerchant_plat(merchantCode);
        return payOrderView;
    }




    public boolean checkStatus(String keyId){
        boolean flag = false;
        com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder payOrder =null;
        if (keyId.trim().length()== 10){
            payOrder =  payOrderApi.getTwoStatus(keyId);
        }else{
            payOrder =payOrderApi.getPayOrderById(keyId);
        }
        if(null!=payOrder.getMerchant_flag()&&null!=payOrder.getTrade_state()&&payOrder.getMerchant_flag()==1 && payOrder.getTrade_state()==1){
           flag=true;
        }

        return flag;
    }

    /******------------------------------ 新增方法 -------------------------------*******/
    @Override
    public PayPortalOrder getPayPortalOrderInfo(String orderId, String lenovoId, String plat, String merchantOrderUrl, String shopId) {
        logger.info("<--getMchOrderInfo-->");
        logger.info("查询订单-->lenovoId=" + lenovoId + "&orderno=" + orderId + "" + "&plat=" + plat);
        PayPortalOrder payPortalOrder = null;
        try {
            Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
            RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(orderId, lenovoId, tenant);
            if(payPortalOrderRemoteResult.isSuccess()){
                payPortalOrder = payPortalOrderRemoteResult.getT();
                if("1".equals(payPortalOrder.getPaymentWay())){
                    commonManager.getLedgerFAID(payPortalOrder);
                }
            }else{
                logger.info("未能获取到渠道订单信息："+JSON.toJSONString(payPortalOrder));
            }
        } catch (Exception e) {
            logger.error("获取渠道订单信息异常",e);
        }
        return payPortalOrder;
    }

    @Override
    public RemoteResult<List<PayOrder>> getOrderListByPayType(String ordercode, Integer payType) {
        return payOrderApi.getOrderListByPayType(ordercode , payType);
    }

    @Override
    public int updatePayBankByID(String keyId, String defaultbank) {
        return payOrderApi.updatePayBankByID(keyId, defaultbank);
    }
}
