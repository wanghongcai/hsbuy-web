package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.framework.manager.impl.GenericManagerImpl;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.JacksonUtil;
import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.ReturnCode;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayConfig;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipaySubmit;
import com.lenovo.m2.buy.promotion.admin.domain.pay.alipay.AliPayCwgModel;
import com.lenovo.m2.buy.promotion.admin.domain.pay.wxpay.PayOrder;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCwgManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.MerchantPayPlatManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.service.pay.soa.MerchantPayPlatService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.*;

/**
 * Created by MengQiang on 2015/5/23.
 */
@Service
public class AliPayCwgManagerImpl extends GenericManagerImpl<PayOrder, Long> implements AliPayCwgManager {
    private final Logger logger = Logger.getLogger(this.getClass());
    @Autowired
    private AliPayCommonManager aliPayCommonManager;
    @Autowired
    private MerchantPayPlatManager merchantPayPlatManager;
    @Autowired
    private MerchantPayPlatService merchantPayPlatService;
    @Autowired
    private PayOrderApi payOrderApi;
    @Autowired
    private CommonCallBackManager commonCallBackManager;
    @Autowired
    private CommonManager commonManager;
    @Autowired
    private PayPortalOrderManager payPortalOrderManager;

    @Override
    public RemoteResult toAliCwgPay(HttpServletRequest request) {
        logger.info("<--支付宝纯网关支付交易-->");
        RemoteResult<String> returnResult = new RemoteResult<String>();
        returnResult.setSuccess(true);
        AliPayCwgModel model = (AliPayCwgModel) BaseModel.getModel(request);
        String orderMainCode = model.getOrderMainCode();
        String merchantCode = model.getMerchantCode();
        String payType = model.getPayType();
        String lenovoId = model.getLenovoId();
        String defaultbank = model.getDefaultbank();
        String plat = model.getPlat();
        String shopId= model.getShopId();
        String terminal = model.getTerminal();
        logger.info("HTTPS AliPay CWG Pay Ready To Go! orderMainCode[" + orderMainCode + "],merchantCode[" + merchantCode + "],payType[" + payType + "],lenovoId[" + lenovoId + "],defaultbank[" + defaultbank + "],plat[" + plat + "],shopId[" + shopId + "],terminal[" + terminal + "]");
        Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(orderMainCode, lenovoId, tenant);
        PayPortalOrder payPortalOrder;
        if(payPortalOrderRemoteResult.isSuccess()){
            payPortalOrder = payPortalOrderRemoteResult.getT();
            if(payPortalOrder == null||payPortalOrder.getOutTradeNo() == null){
                logger.warn("查询支付订单信息异常");
                CommonMethod.getRemoteResult(returnResult, "", false, "400", "未查到订单信息");
                return returnResult;
            }
        } else {
            logger.info("Invoke queryChannelOrderCodeDetail Get PayPortalOrder IS NULL，orderMainCode [" + orderMainCode + "]");
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "未查到订单信息");
            return returnResult;
        }
        if("1".equals(payPortalOrder.getPaymentWay())){
            commonManager.getLedgerFAID(payPortalOrder);
        }
        StringBuffer commonParamBuffer = new StringBuffer();
        commonParamBuffer.append("faid=" + payPortalOrder.getFaId() +  ",");
        commonParamBuffer.append("payType=" + payType + ",");
        commonParamBuffer.append("lenovoId=" + lenovoId);
        String extra_common_param = "";
        try {
            extra_common_param = URLEncoder.encode(commonParamBuffer.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            logger.error("支付宝回传数据Encode异常",e);
            returnResult.setSuccess(false);
            returnResult.setResultCode("30001");
            returnResult.setResultMsg("支付宝回传数据Encode异常");
            return returnResult;
        }
        logger.info("extra_common_param--->" + extra_common_param);
        if(PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(payPortalOrder.getPayStatus()))){
            logger.info("Check PayPortalOrder Already PAY, OrderMainCode [" + orderMainCode + "]");
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "订单已支付，请到订单列表页确认");
            return returnResult;
        }
        if(PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(payPortalOrder.getOrderStatus()))){
            logger.info("Check PayPortalOrder OrderStatus FAIL, OrderMainCode [" + orderMainCode + "]");
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "订单已失效，请到订单列表页确认");
            return returnResult;
        }
        MerchantPayPlatView merchantPayPlatView = null;
        RemoteResult<MerchantPayPlatView> remoteResult = aliPayCommonManager.getMerchantPayPlatView(payPortalOrder.getFaId(), payType);
        if (remoteResult.isSuccess()) {
            merchantPayPlatView = remoteResult.getT();
            logger.info(remoteResult.isSuccess());
            logger.info(merchantPayPlatView.toString());
        } else {
            logger.warn("未查询到平台信息");
            returnResult.setSuccess(false);
            returnResult.setResultCode("30002");
            returnResult.setResultMsg("查询商户平台信息异常");
            return returnResult;
        }
        String totalFee = String.valueOf(payPortalOrder.getTotalFee().getAmount());//支付金额,单位（元）
        String currencyCode = payPortalOrder.getCurrencyCode();
        String prodName = CommonMethod.getProductName(payPortalOrder.getSubject());
        String bodyHtml = null;
        try {
            String orderPrimaryId = null;
            RemoteResult<String> savePayOrderResult = new RemoteResult<String>();
            RemoteResult<List<com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder>> orderListResult = aliPayCommonManager.getOrderListByPayType(orderMainCode, Integer.parseInt(payType));
            if(orderListResult.isSuccess() && orderListResult.getT().size() > 0){
                orderPrimaryId = String.valueOf(orderListResult.getT().get(0).getId());
                logger.info("查询纯网关支付类型交易已存在，ID==>" + orderPrimaryId);
                try{
                    int updateFlag = aliPayCommonManager.updatePayBankByID(orderPrimaryId, defaultbank);
                    logger.info("更新纯网关支付银行返回==>" + updateFlag);
                }catch (Exception ex){
                    logger.info("更新纯网关支付银行异常,订单ID==>" +  orderPrimaryId + " 异常原因==>" + ex);
                }
            }else{
                savePayOrderResult = commonManager.savePayOrder(lenovoId,plat,payType,orderMainCode,totalFee,prodName,"",0,"",merchantCode,defaultbank,shopId,terminal,merchantPayPlatView,currencyCode);
                if(!savePayOrderResult.isSuccess()){
                    logger.warn("保存订单信息失败");
                    returnResult.setSuccess(false);
                    returnResult.setResultCode("30004");
                    returnResult.setResultMsg("保存订单信息失败");
                    return returnResult;
                }
                logger.info("保存订单成功");
                orderPrimaryId = savePayOrderResult.getT();
                logger.info("查询纯网关支付类型交易不存在，新建记录ID==>" + orderPrimaryId);
            }
            bodyHtml = this.getCwgPcHtml(orderPrimaryId, prodName, totalFee, defaultbank, extra_common_param, merchantPayPlatView);
            bodyHtml = "<html>" + "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>支付宝订单请求</title></head>" + "<body>"
                    + bodyHtml + "</body></html>";
        }catch(Exception e){
            logger.error("保存订单或构建HTML表单异常",e);
            returnResult.setSuccess(false);
            returnResult.setResultCode("30004");
            returnResult.setResultMsg("支付平台处理订单信息异常");
            return returnResult;
        }
        logger.info(bodyHtml);
        if (bodyHtml == null || "".equals(bodyHtml)) {
            logger.warn("构建支付HTML失败");
            returnResult.setSuccess(false);
            returnResult.setResultCode("30005");
            returnResult.setResultMsg("构建请求HTML失败");
        }
        returnResult.setT(bodyHtml);
        return returnResult;
    }


    public String getCwgPcHtml(String ordercode, String prodName, String totalFee, String defaultbank, String extra_common_param, MerchantPayPlatView merchantPayPlatView) {
        Map<String, String> sParaTemp = new HashMap<String, String>();
        String payment_type = "1";
        String body = "";
        sParaTemp.put("service", "create_direct_pay_by_user");
        sParaTemp.put("partner", merchantPayPlatView.getMechId());
        sParaTemp.put("_input_charset", AlipayConfig.input_charset);
        sParaTemp.put("payment_type", payment_type);
        String outNotifyUrl = merchantPayPlatView.getOutNotifyUrl();
//        outNotifyUrl = CommonMethod.getHlwzqUrl(outNotifyUrl);
        sParaTemp.put("notify_url", outNotifyUrl);
        sParaTemp.put("return_url", merchantPayPlatView.getOutCallBackUrl());
        sParaTemp.put("seller_email", merchantPayPlatView.getAppId());
        sParaTemp.put("out_trade_no", ordercode);
        sParaTemp.put("subject", prodName);
        sParaTemp.put("total_fee", totalFee);
        sParaTemp.put("body", body);
        sParaTemp.put("paymethod", "bankPay");
        sParaTemp.put("defaultbank", defaultbank);
        sParaTemp.put("extra_common_param", extra_common_param);
        String sHtmlText = AlipaySubmit.buildRequest(sParaTemp, "get", "确认", merchantPayPlatView.getSignKey());
        return sHtmlText;
    }



    @Override
    public RemoteResult<Map<String, Object>> callUpdate(String lenovoId, String orderPrimaryId, String trade_no, String gmt_payment, String faid, String payType, MerchantPayPlatView merchantPayPlatView, String notifyId, String bankSeqNo) {
        RemoteResult<Map<String, Object>> result = new RemoteResult<Map<String, Object>>();
        result.setSuccess(false);
        int tryNumber = 0;
        Map<String, Object> stringtomap = null;
        boolean flag = aliPayCommonManager.checkStatus(orderPrimaryId);
        com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder payOrder =null;
        //TODO 增加修改渠道订单信息
//        ChannelOrder channelOrder = new ChannelOrder();
        if (!flag){
            if (orderPrimaryId.trim().length()== 10){
                payOrder =payOrderApi.getTwoStatus(orderPrimaryId);
            }else{
                payOrder =payOrderApi.getPayOrderById(orderPrimaryId);
                orderPrimaryId=payOrder.getId().toString();
            }
            String orderCode = payOrder.getOut_trade_no();
//            //设置主单号
//            channelOrder.setOrderCode(orderCode);
//            //设置LenovoID
//            channelOrder.setLenovoId(payOrder.getU_id());
//            channelOrder.setPayment(Integer.parseInt(PeakConstant.PAY_TYPE_ALCWG));
//            channelOrder.setTransationId(String.valueOf(payOrder.getId()));
//            channelOrder.setPayStatus(1);
//            channelOrder.setShopId(payOrder.getShop_id());
//            channelOrder.setPayTime(DateUtil.formatDate(new Date(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
            payOrderApi.updateAliPayNotifyState(orderPrimaryId, lenovoId, trade_no, PeakConstant.MFLAG_REPEAT, notifyId, PeakConstant.TRADE_SUCCESS,bankSeqNo, Integer.parseInt(PeakConstant.PAY_TYPE_ALCWG));
            PayPortalOrder updatePayPortalOrder = CommonMethod.buildUpdatePayPortalOrder(String.valueOf(payOrder.getId()), orderCode, payOrder.getU_id(), Integer.parseInt(PeakConstant.PAY_TYPE_ALCWG), PeakConstant.PAY_STATUS_ALREADY_PAID, payOrder.getShop_id() ,new Date());
            try{
                RemoteResult<Integer> updatePayPortalOrderResult = payPortalOrderManager.updatePayPortalOrderPayStatus(updatePayPortalOrder);
                if (updatePayPortalOrderResult.isSuccess()) {
                    logger.info("Update PayPortalOrder SUCCESS，outTradeNo[" + payOrder.getOut_trade_no() + "]");
                } else {
                    logger.info("Update PayPortalOrder FAIL，outTradeNo[" + payOrder.getOut_trade_no() + "]");
                }
            }catch(Exception e){
                logger.info("更新渠道订单失败 ，订单号==>" + orderCode, e);
            }
            try {
                String signature = "signature";
                String updateOrder ="trade_no=" + trade_no + "&orderCode=" + orderCode + "&gmt_payment=" + gmt_payment + "&payment="+ PeakConstant.PAYMENT_ALI + "&lenovoId=" + lenovoId +"&signature=" + signature+"&orderPrimaryId=" + orderPrimaryId;
                logger.info("更新订单：" + updateOrder);
                String firstRemoteStr = aliPayCommonManager.updateRemoteOrder(merchantPayPlatView,trade_no,orderCode,gmt_payment,lenovoId,PeakConstant.PAYMENT_ALI,signature,orderPrimaryId);
                if (!(("").equals(firstRemoteStr))&&"success".equalsIgnoreCase(firstRemoteStr.trim())) {
                    logger.info("更新订单状态返回信息：" + firstRemoteStr.trim());
                    payOrderApi.updateAliPayNotifyState(orderPrimaryId, lenovoId, trade_no, PeakConstant.MFLAG_SUCC, notifyId, PeakConstant.TRADE_SUCCESS, bankSeqNo, Integer.parseInt(PeakConstant.PAY_TYPE_ALCWG));
                    result.setSuccess(true);
                }else {
                    stringtomap = JacksonUtil.toObjectMap(firstRemoteStr);
                    log.warn("回调客户服务器返回的数据-->" + stringtomap);
                    logger.info("***服务器异常***");
                    Iterator iter = stringtomap.entrySet().iterator();
                    while (iter.hasNext()) {
                        Map.Entry entry = (Map.Entry) iter.next();
                        logger.warn("异常码：" + entry.getKey() + "  异常信息：" + entry.getValue());
                        if ("500".equals(entry.getKey())) {
                            Boolean isSuccess = true;
                            while (isSuccess && tryNumber < 3) {
                                String secondRemoteStr = aliPayCommonManager.updateRemoteOrder(merchantPayPlatView, trade_no, orderCode, gmt_payment, lenovoId, PeakConstant.PAYMENT_ALI,signature,orderPrimaryId);
                                if(!(("").equals(secondRemoteStr))){
                                    logger.info("更新订单状态服务器异常后二次更新返回信息：" + secondRemoteStr.trim());
                                }
                                if (!(("").equals(secondRemoteStr)) && "success".equalsIgnoreCase(secondRemoteStr.trim())) {
                                    payOrderApi.updateAliPayNotifyState(orderPrimaryId, lenovoId, trade_no, PeakConstant.MFLAG_SUCC, notifyId, PeakConstant.TRADE_SUCCESS, bankSeqNo, Integer.parseInt(PeakConstant.PAY_TYPE_ALCWG));
                                    result.setSuccess(true);
                                    isSuccess = false;
                                } else {
                                    tryNumber++;
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                result.setSuccess(false);
                result.setResultCode(ReturnCode.InNotifyFail.getCode());
                result.setResultMsg(ReturnCode.InNotifyFail.getMessage());
                logger.error("纯网关支付回调订单状态更新异常--->" + e.getMessage());
                payOrderApi.updateAliPayNotifyState(orderPrimaryId,lenovoId,trade_no,PeakConstant.MFLAG_REPEAT,notifyId,PeakConstant.TRADE_SUCCESS,bankSeqNo, Integer.parseInt(PeakConstant.PAY_TYPE_ALCWG));
            }
        }else{
            result.setSuccess(true);
        }
        return result;
    }
}
