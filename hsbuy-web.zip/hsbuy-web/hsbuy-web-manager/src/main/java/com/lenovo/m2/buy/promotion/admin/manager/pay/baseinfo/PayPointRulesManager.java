package com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayPointRules;

/**
 * Created by jh on 2017/8/10.
 */
public interface PayPointRulesManager {

    RemoteResult<PayPointRules> getPayPointRulesByfaId(String faId);
}
