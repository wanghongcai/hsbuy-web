package com.lenovo.m2.buy.promotion.admin.manager.inventory.impl;

import com.lenovo.common.base.PageMap;
import com.lenovo.fis.model.FaBaseInfoes;
import com.lenovo.m2.buy.promotion.admin.manager.inventory.FaBaseInfoManager;
import com.lenovo.m2.hsbuy.domain.inventory.FaBaseInfo;
import com.lenovo.shop.admin.api.FaBaseInfoesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mayan3 on 2016/3/22.
 */

@Service
@Component("faBaseInfoManager")
public class FaBaseInfoManagerImpl implements FaBaseInfoManager {
    @Autowired
    private FaBaseInfoesService faBaseInfoesService;


    @Override
    public List<FaBaseInfo> getFaBaseInfoList(List<String> listIds) throws Exception {

        List<FaBaseInfoes> faBaseInfoesList=faBaseInfoesService.getByIdList(listIds);
        List<FaBaseInfo> baseInfoList=new ArrayList<FaBaseInfo>();
        for (FaBaseInfoes infoes:faBaseInfoesList){
            FaBaseInfo faBaseInfo=new FaBaseInfo();
            faBaseInfo.setName(infoes.getFaName());
            faBaseInfo.setType(infoes.getFaType());
            faBaseInfo.setId(infoes.getFaid());
            baseInfoList.add(faBaseInfo);
        }
        return baseInfoList;
    }

    @Override
    public FaBaseInfoes getFaBaseInfo(String faid) throws Exception {
        PageMap pageMap = new PageMap();
        List<String> falist = new ArrayList<String>();
        falist.add(faid);
        pageMap.putSelectParams("faIds", falist);
        PageMap resultMap = faBaseInfoesService.PageQuery(pageMap);
        List<FaBaseInfoes> pageList = (List<FaBaseInfoes>) resultMap.getPageList();
        FaBaseInfoes faBaseInfo=null;
        if (pageList!=null&&pageList.size()>0) {
            faBaseInfo = pageList.get(0);
        }
        return faBaseInfo;
    }
}
