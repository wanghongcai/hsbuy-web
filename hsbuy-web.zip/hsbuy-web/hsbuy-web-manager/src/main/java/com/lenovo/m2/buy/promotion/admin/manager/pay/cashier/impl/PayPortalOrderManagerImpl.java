package com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayPortalOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by MengQiang on 2016/9/13.
 */
@Service
public class PayPortalOrderManagerImpl implements PayPortalOrderManager{
    private final Logger LOGGER = Logger.getLogger(this.getClass());

    @Autowired
    private PayPortalOrderApi payPortalOrderApi;

    @Override
    public RemoteResult<Integer> deleteByPrimaryKey(Integer primaryKey) {
        return payPortalOrderApi.deleteByPrimaryKey(primaryKey);
    }

    @Override
    public RemoteResult<Integer> insert(PayPortalOrder payPortalOrder) {
        return payPortalOrderApi.insert(payPortalOrder);
    }

    @Override
    public RemoteResult<Integer> insertSelective(PayPortalOrder payPortalOrder) {
        return payPortalOrderApi.insertSelective(payPortalOrder);
    }

    @Override
    public RemoteResult<PayPortalOrder> selectByPrimaryKey(Integer primaryKey) {
        return payPortalOrderApi.selectByPrimaryKey(primaryKey);
    }

    @Override
    public RemoteResult<Integer> updateByPrimaryKeySelective(PayPortalOrder payPortalOrder) {
        return payPortalOrderApi.updateByPrimaryKeySelective(payPortalOrder);
    }

    @Override
    public RemoteResult<Integer> updateByPrimaryKey(PayPortalOrder payPortalOrder) {
        return payPortalOrderApi.updateByPrimaryKey(payPortalOrder);
    }

    @Override
    public RemoteResult<Long> insertReturnPrimaryId(PayPortalOrder payPortalOrder) {
        return payPortalOrderApi.insertReturnPrimaryId(payPortalOrder);
    }

    @Override
    public RemoteResult<List<PayPortalOrder>> queryPayPortalOrderListByOutTradeNoList(List<String> outTradeNoList, String lenovoId, Tenant tenant) {
        LOGGER.info("Invoke queryPayPortalOrderListByOutTradeNoList, OutTradeNoList[" + outTradeNoList +"],lenovoId[" + lenovoId + "],tenant[" + tenant + "]");
        RemoteResult<List<PayPortalOrder>> payPortalOrderListRemoteResult = new RemoteResult<List<PayPortalOrder>>();
        try {
            payPortalOrderListRemoteResult = payPortalOrderApi.queryPayPortalOrderListByOutTradeNoList(outTradeNoList, lenovoId, tenant);
        } catch (Exception e) {
            payPortalOrderListRemoteResult.setSuccess(false);
            LOGGER.info("Invoke queryChannelOrderMainCodeDetail Exception", e);
        }
        return payPortalOrderListRemoteResult;
    }

    @Override
    public RemoteResult<Boolean> saveOrUpdatePayPortalOrderList(List<PayPortalOrder> savePayPortalOrderList, List<PayPortalOrder> updatePayPortalOrderList) {
        LOGGER.info("Invoke saveOrUpdatePayPortalOrderList, SavePayPortalOrderList[" + savePayPortalOrderList +"],UpdatePayPortalOrderList[" + updatePayPortalOrderList + "]");
        RemoteResult<Boolean> saveOrUpdateRemoteResult = new RemoteResult<Boolean>();
        try{
            saveOrUpdateRemoteResult = payPortalOrderApi.saveOrUpdatePayPortalOrderList(savePayPortalOrderList, updatePayPortalOrderList);
        }catch(Exception e){
            saveOrUpdateRemoteResult.setSuccess(false);
            LOGGER.info("Invoke saveOrUpdatePayPortalOrderList Exception", e);
        }
        return saveOrUpdateRemoteResult;
    }

    @Override
    public RemoteResult<PayPortalOrder> queryPayPortalOrderByOutTradeNo(String outTradeNo, String lenovoId, Tenant tenant) {
        LOGGER.info("Invoke queryPayPortalOrderByOutTradeNo, outTradeNo[" + outTradeNo +"],lenovoId[" + lenovoId + "],tenant[" + tenant + "]");
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = new RemoteResult<PayPortalOrder>();
        try{
            payPortalOrderRemoteResult = payPortalOrderApi.queryPayPortalOrderByOutTradeNo(outTradeNo, lenovoId, tenant) ;
        } catch (Exception e){
            payPortalOrderRemoteResult.setSuccess(false);
            LOGGER.info("Invoke queryPayPortalOrderByOutTradeNo Exception", e);
        }
        return payPortalOrderRemoteResult;
    }

    @Override
    public RemoteResult<Integer> updatePayPortalOrderPayStatus(PayPortalOrder updatePayPortalOrder) {
        LOGGER.info("Invoke updatePayPortalOrderPayStatus, PayPortalOrder[" + updatePayPortalOrder +"]");
        RemoteResult<Integer> updatePayPortalOrderRemoteResult = new RemoteResult<Integer>();
        try{
            updatePayPortalOrderRemoteResult = payPortalOrderApi.updatePayPortalOrderPayStatus(updatePayPortalOrder) ;
        } catch (Exception e){
            updatePayPortalOrderRemoteResult.setSuccess(false);
            LOGGER.info("Invoke updatePayPortalOrderPayStatus Exception", e);
        }
        return updatePayPortalOrderRemoteResult;
    }

    @Override
    public RemoteResult<Integer> updatePayPortalOrderOrderStatus(String outTradeNo, Tenant tenant, String orderStatus) {
        LOGGER.info("Invoke updatePayPortalOrderOrderStatus, outTradeNo[" + outTradeNo +"],tenant[" + tenant + "],orderStatus[" + orderStatus + "]");
        RemoteResult<Integer> updatePayPortalOrderRemoteResult = new RemoteResult<Integer>();
        try{
            updatePayPortalOrderRemoteResult = payPortalOrderApi.updatePayPortalOrderOrderStatus(outTradeNo, tenant, orderStatus) ;
        } catch (Exception e){
            updatePayPortalOrderRemoteResult.setSuccess(false);
            LOGGER.info("Invoke updatePayPortalOrderOrderStatus Exception", e);
        }
        return updatePayPortalOrderRemoteResult;
    }

    @Override
    public RemoteResult<PayPortalOrder> queryPayPortalOrderByShowTradeNo(String showTradeNo, String lenovoId, Tenant tenant) {
        LOGGER.info("Invoke queryPayPortalOrderByShowTradeNo, showTradeNo[" + showTradeNo +"],lenovoId[" + lenovoId + "],tenant[" + tenant + "]");
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = new RemoteResult<PayPortalOrder>();
        try{
            payPortalOrderRemoteResult = payPortalOrderApi.queryPayPortalOrderByShowTradeNo(showTradeNo, lenovoId, tenant) ;
        } catch (Exception e){
            payPortalOrderRemoteResult.setSuccess(false);
            LOGGER.info("Invoke queryPayPortalOrderByShowTradeNo Exception", e);
        }
        return payPortalOrderRemoteResult;
    }

    @Override
    public void testPath(String path) {
        payPortalOrderApi.testPath(path);
    }

}
