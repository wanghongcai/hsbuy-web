package com.lenovo.m2.buy.promotion.admin.manager.couponManager.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.buy.promotion.admin.manager.couponManager.AdminGetCouponService;
import com.lenovo.m2.buy.promotion.admin.remote.coupon.GetCouponsRemote;
import com.lenovo.m2.couponV2.api.model.AvailableSalescouponsApi;
import com.lenovo.m2.couponV2.common.CouponConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by fenglg1 on 2016/12/13.
 */
@Service("adminGetCouponsService")
public class AdminGetCouponServiceImpl implements AdminGetCouponService {

    @Autowired
    private GetCouponsRemote getCouponsRemote;

    @Override
    public RemoteResult saveAvailableSalescoupons(String createBy, String[] salescouponsIds,Integer displayPosition) {
        RemoteResult remoteResult = new RemoteResult();
        if(salescouponsIds == null && salescouponsIds.length == 0){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode(CouponConstant.RESULT_CODE_EMPTY);
            remoteResult.setResultMsg("参数为空");
            return remoteResult;
        }
        List<AvailableSalescouponsApi> couponsList = new ArrayList<AvailableSalescouponsApi>();
        Date createTime = new Date();
        for(String id : salescouponsIds){
            AvailableSalescouponsApi salescouponsApi = new AvailableSalescouponsApi();
            salescouponsApi.setSalesCouponsID(Long.valueOf(id));
            salescouponsApi.setCreateBy(createBy);
            salescouponsApi.setCreateTime(createTime);
            couponsList.add(salescouponsApi);
        }
        return getCouponsRemote.saveSelectedSalescoupons(couponsList,displayPosition);
    }

    @Override
    public RemoteResult deleteAvailableSalescoupons(String operator, String couponId,String displayPosition) {
        RemoteResult remoteResult = new RemoteResult();
        if(StringUtils.isEmpty(couponId)){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode(CouponConstant.RESULT_CODE_EMPTY);
            remoteResult.setResultMsg("参数为空");
            return remoteResult;
        }

        return getCouponsRemote.deleteAvailableSalescoupons(operator, couponId,displayPosition);
    }

    @Override
    public RemoteResult deleteAllAvailableSalescoupons(String operator) {
        return getCouponsRemote.deleteAllAvailableSalescoupons(operator);
    }
}
