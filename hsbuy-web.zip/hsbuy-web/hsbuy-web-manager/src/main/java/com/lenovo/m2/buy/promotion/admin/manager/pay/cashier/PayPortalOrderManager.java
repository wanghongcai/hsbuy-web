package com.lenovo.m2.buy.promotion.admin.manager.pay.cashier;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;

import java.util.List;

/**
 * 支付服务前置订单
 * Created by MengQiang on 2016/9/13.
 */
public interface PayPortalOrderManager {
    /**
     * delete
     */
    public RemoteResult<Integer> deleteByPrimaryKey(Integer primaryKey);

    /**
     * Insert
     */
    public RemoteResult<Integer> insert(PayPortalOrder payPortalOrder);

    /**
     * insert
     */
    public RemoteResult<Integer> insertSelective(PayPortalOrder payPortalOrder);


    /**
     * selectByPrimaryKey
     */
    public RemoteResult<PayPortalOrder> selectByPrimaryKey(Integer primaryKey);

    /**
     * update
     */
    public RemoteResult<Integer> updateByPrimaryKeySelective(PayPortalOrder payPortalOrder);

    /**
     * update
     */
    public RemoteResult<Integer> updateByPrimaryKey(PayPortalOrder payPortalOrder);

    /**
     *
     * @param payPortalOrder
     * @return PrimaryId
     */
    public RemoteResult<Long> insertReturnPrimaryId(PayPortalOrder payPortalOrder);

    /**
     * 基于前置订单号查询已存在PayPortalOrder
     * @param outTradeNoList list
     * @param lenovoId  lenovoid
     * @param tenant    shopid
     * @return
     */
    public RemoteResult<List<PayPortalOrder>> queryPayPortalOrderListByOutTradeNoList(List<String> outTradeNoList, String lenovoId, Tenant tenant);

    public RemoteResult<Boolean> saveOrUpdatePayPortalOrderList(List<PayPortalOrder> savePayPortalOrderList, List<PayPortalOrder> updatePayPortalOrderList);

    public RemoteResult<PayPortalOrder> queryPayPortalOrderByOutTradeNo(String orderMainCode, String lenovoId, Tenant tenant);

    public RemoteResult<Integer> updatePayPortalOrderPayStatus(PayPortalOrder updatePayPortalOrder);

    public RemoteResult<Integer> updatePayPortalOrderOrderStatus(String outTradeNo, Tenant tenant, String orderStatusInvalid);

    public RemoteResult<PayPortalOrder> queryPayPortalOrderByShowTradeNo(String showTradeNo, String lenovoId, Tenant tenant);

    public void testPath(String path);
}
