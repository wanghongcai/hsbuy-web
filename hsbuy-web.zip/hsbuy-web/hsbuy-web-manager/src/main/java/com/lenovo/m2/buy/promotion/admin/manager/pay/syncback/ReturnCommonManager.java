package com.lenovo.m2.buy.promotion.admin.manager.pay.syncback;

import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

/**
 * Created For Return CallBack
 * 同步回调Manager接口
 * Created by MengQiang on 2015/8/28.
 */
public interface ReturnCommonManager {
    /**
     * 通过支付单号获取支付订单信息
     * @param payOrderId
     * @return
     */
    public PayOrder getPayOrderByPrimaryId(long payOrderId);
}
