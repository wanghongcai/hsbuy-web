package com.lenovo.m2.buy.promotion.admin.manager.pay.umpay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

import javax.servlet.http.HttpServletRequest;

/**
 * 联动优势支付接口
 * Created by tianchuyang on 2016/11/9.
 */
public interface UmpayManager {

    /**
     * 联动优势去支付
     *
     * @param request 请求数据
     * @return
     */
    public RemoteResult<String> toUmPay(HttpServletRequest request) throws Exception;
}
