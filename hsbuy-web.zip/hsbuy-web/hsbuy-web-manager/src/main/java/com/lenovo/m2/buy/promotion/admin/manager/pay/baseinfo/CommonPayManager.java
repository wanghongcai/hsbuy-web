package com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.ChannelOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;

/**
 * 支付公共Manager
 * 处理公共去支付逻辑
 * Created by mengqiang1 on 2016/1/4.
 */
public interface CommonPayManager {

    /**
     * 获取支付平台绑定商户支付信息
     * @param faId
     * @param payType
     * @return
     */
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlat(String faId, String payType);

    RemoteResult<MerchantPayPlatView> getMerchantPayPlatByAccountType(String faId, String payType, Integer accountType);

    /**
     * 校验订单支付状态
     * 暂时校验主订单和支付平台库
     * @param channelOrder
     * @return
     */
    public boolean checkPayStatus(ChannelOrder channelOrder);

    /**
     * 校验主订单状态
     * @param channelOrder
     * @return
     */
    public boolean checkOrderStatus(ChannelOrder channelOrder);

    /**
     * 获取当前订单中商品名
     * 采用拼接方式，如有特殊字符改为LenovoProduct
     * @param channelOrder
     * @return
     */
    public String getProductNameFromMongoOrder(ChannelOrder channelOrder);
}
