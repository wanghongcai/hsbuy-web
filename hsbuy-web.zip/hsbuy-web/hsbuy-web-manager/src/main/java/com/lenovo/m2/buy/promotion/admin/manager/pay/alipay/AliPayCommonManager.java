package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

import java.util.List;

/**
 * 支付宝接入公共Manager
 * Created by MengQiang on 2015/5/22.
 */
public interface AliPayCommonManager {

//    /**
//     * 获取订单信息
//     * @param orderId
//     * @param lenovoId
//     * @param plat
//     * @param merchantOrderUrl
//     * @return
//     */
//    public MongoOrder getMchOrderInfo(String orderId, String lenovoId, String plat, String merchantOrderUrl);
    /**
     * 保存支付订单
     * @param os
     * @param ordercode
     * @param merchantCode
     * @param payType
     * @param lenovoId
     * @param merchantPayPlatView
     * @param _total_fee
     * @param prodName
     * @return
     */
    public RemoteResult<String> savePayOrder(String os, String ordercode, String merchantCode, String payType, String lenovoId, MerchantPayPlatView merchantPayPlatView, String _total_fee, String prodName, String currencyCode);
    /**
     * 保存支付订单
     * @param os
     * @param ordercode
     * @param merchantCode
     * @param payType
     * @param lenovoId
     * @param merchantPayPlatView
     * @param _total_fee
     * @param prodName
     * @return
     */
    public RemoteResult<String> savePayOrder(String os, String ordercode, String merchantCode, String payType, String lenovoId, MerchantPayPlatView merchantPayPlatView, String _total_fee, String prodName, String fqRate, int fqNum, String fqCode, String pay_bank, String currencyCode);

    /**
     * 获取商户平台信息
     * @param merchantCode
     * @param payType
     * @return
     */
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatView(String merchantCode, String payType);
    /**
     * 检查订单是否支付
     * @param payStatus
     * @return boolean
     */
    public boolean checkPay(String payStatus);

    /**
     * 校验订单状态
     * @param orderStatus
     * @return
     */
    public boolean checkOrderStatus(String orderStatus);

    /**
     * 获取支付宝配置信息
     * @param key
     * @return
     */
    public String getAliPropValue(String key);

    boolean isTestPay(String key);

    /**
     * 更新订单
     * @param merchantPayPlatView
     * @param trade_no
     * @param orderMainCode
     * @param gmt_payment
     * @param lenovoId
     * @param payment
     * @param signature
     * @return
     * @throws Exception
     */
    public String updateRemoteOrder(MerchantPayPlatView merchantPayPlatView, String trade_no, String orderMainCode, String gmt_payment, String lenovoId, String payment, String signature, String orderPrimaryId) throws Exception;

    /**
     *
     * @param payOrderCode
     * @param orderCode
     * @param payDatetime
     * @param payment
     * @param lenovoId
     * @return
     */
    public String getSignature(String orderPrimaryId, String payOrderCode, String orderCode, String payDatetime, String payment, String lenovoId);

    public boolean checkStatus(String key_id);

    /**
     * 根据支付类型获取订单列表
     * @param ordercode
     * @param payType
     * @return
     */
    public RemoteResult<List<PayOrder>> getOrderListByPayType(String ordercode, Integer payType);

    /**
     * 根据ID更新纯网关支付银行简码
     * @param keyId
     * @param defaultbank
     */
    public int updatePayBankByID(String keyId, String defaultbank);

    /***-------------------------新增方法------------------------------***/
    /**
     * 获取订单信息
     * @param orderId
     * @param lenovoId
     * @param plat
     * @param merchantOrderUrl
     * @return
     */
    public PayPortalOrder getPayPortalOrderInfo(String orderId, String lenovoId, String plat, String merchantOrderUrl, String shopId);
}
