package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.impl;


import com.alibaba.fastjson.JSON;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.framework.manager.impl.GenericManagerImpl;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.*;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.*;
import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;
import com.lenovo.m2.buy.promotion.admin.domain.pay.alipay.AliPaySjModel;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPaySjManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.*;


/**
 * AliPay Wap
 * Created by Mq on 2015/5/23.
 */
@Service
public class AliPaySjManagerImpl extends GenericManagerImpl<PayOrder, Long> implements AliPaySjManager {
    private final Logger logger = Logger.getLogger(this.getClass());
    private static final String success = "success";
    private static final String fail = "fail";
    private String wxhtml="";
    //支付宝网关地址
    public static final String ALIPAY_GATEWAY_NEW = "https://wappaygw.alipay.com/service/rest.htm?";

    private Map<String, String> sParaTempWxAlipay;
    private String keyWxAlipay;


    @Autowired
    private AliPayCommonManager aliPayCommonManager;
    @Autowired
    private PayOrderApi payOrderApi;

    @Autowired
    private CommonCallBackManager commonCallBackManager;

    @Autowired
    private CommonManager commonManager;
    @Autowired
    private PayPortalOrderManager payPortalOrderManager;

    @Override
    public Map<String, Object> getMchOrderInfo(String orderId, String lenovoId, String merchantOrderUrl) {
        return null;
    }


    /**
     * <br>
     * 拼接支付界面html
     *
     * @param partner      合作身份者ID
     * @param seller_email 支付宝账号
     * @param key          md5加密秘钥
     * @param orderNum     订单号
     * @param prodName     订单名
     * @param _total_fee   价格
     * @return
     * @throws Exception
     * @author shenjc
     */
    @Override
    public String getPsnSjHtml(String partner, String seller_email, String key,
                               String orderNum, String prodName, String _total_fee, int plat,
                               long expire, String notify_url, String call_back_url) throws Exception {

        logger.info("seller_email>>>" + seller_email);
        // 获取token
        Map<String, String> map = getToken(partner, seller_email, key, orderNum,
                prodName, _total_fee, plat, expire, notify_url, call_back_url,null);
        logger.info("request_token>>>" + map.get("request_token"));
        // 生成表单提交html代码
        String sHtmlText = getHtmlSubmit(map.get("request_token"), partner, key);
        logger.info("sHtmlText>>" + sHtmlText);
        return sHtmlText;
    }

    public String getPsnSjHtmlwxAlipay(String partner, String seller_email, String key,
                                       String orderNum, String prodName, String _total_fee, int plat,
                                       long expire, String notify_url, String call_back_url, String cachierCode) throws Exception {

        logger.info("seller_email>>>" + seller_email);
        // 获取token
        Map<String, String> map = getToken(partner, seller_email, key, orderNum,
                prodName, _total_fee, plat, expire, notify_url, call_back_url, cachierCode);
        logger.info("request_token>>>" + map.get("request_token"));
        // 生成表单提交html代码
        String sHtmlText = getHtmlSubmitwxAlipay(map.get("request_token"), partner, key);
        logger.info("sHtmlText>>" + sHtmlText);
        return sHtmlText;
    }


    /**
     * @param request_token 请求所需token
     * @param partner       商户签约的支付宝账号对应的支付宝唯一用户号
     * @param partner       md5加密秘钥
     * @return String 生成的表单提交html代码
     * @Description: 生成表单提交html代码
     * @Modified:
     */
    private String getHtmlSubmit(String request_token, String partner,
                                 String key) {
        // 业务详细
        String req_data = "<auth_and_execute_req><request_token>"
                + request_token + "</request_token></auth_and_execute_req>";
        // 把请求参数打包成数组
        Map<String, String> sParaTemp = new HashMap<String, String>();
        sParaTemp.put("service", "alipay.wap.auth.authAndExecute");
        sParaTemp.put("partner", partner);
        sParaTemp.put("_input_charset", AlipayConfig.input_charset);
        sParaTemp.put("sec_id", AlipayConfig.sign_type);
        sParaTemp.put("format", AlipayConfig.format);
        sParaTemp.put("v", AlipayConfig.v);
        sParaTemp.put("req_data", req_data);
        // sParaTemp.put("pay_expire", "1");
        // 建立请求
        String sHtmlText = buildRequest(
                ALIPAY_GATEWAY_NEW, sParaTemp,
                "get", "确认", key);
        wxhtml=sHtmlText;//给微信支付宝的请求html
        return sHtmlText;
    }

    private String getHtmlSubmitwxAlipay(String request_token, String partner,
                                         String key) {
        // 业务详细
        String req_data = "<auth_and_execute_req><request_token>"
                + request_token + "</request_token></auth_and_execute_req>";
        // 把请求参数打包成数组
        Map<String, String> sParaTemp = new HashMap<String, String>();
        sParaTemp.put("service", "alipay.wap.auth.authAndExecute");
        sParaTemp.put("partner", partner);
        sParaTemp.put("_input_charset", AlipayConfig.input_charset);
        sParaTemp.put("sec_id", AlipayConfig.sign_type);
        sParaTemp.put("format", AlipayConfig.format);
        sParaTemp.put("v", AlipayConfig.v);
        sParaTemp.put("req_data", req_data);
        // sParaTemp.put("pay_expire", "1");
        // 建立请求
        String sHtmlText = buildRequestWxAlipay(
                ALIPAY_GATEWAY_NEW, sParaTemp,
                "get", "确认", key);
        wxhtml=sHtmlText;//给微信支付宝的请求html
        return sHtmlText;
    }

    /**
     * @param partner      商户签约的支付宝账号对应的支付宝唯一用户号
     * @param seller_email 支付宝卖家账号
     * @param key          md5加密秘钥
     * @param orderNum     订单号
     * @param prodName     订单名
     * @param _total_fee   价格
     * @return 包含token的xml
     * @throws Exception String
     * @Description:调用支付宝授权接口获取token 订单
     * @Modified:
     */
    private Map<String, String> getToken(String partner, String seller_email, String key,
                                         String orderNum, String prodName, String _total_fee, int plat,
                                         long expire, String notify_url, String call_back_url, String cachierCode) throws Exception {

        // 组装请求支付宝支付token的参数
        Map<String, String> sParaTempToken = generateTokenRequestParam(partner,
                seller_email, orderNum, prodName, _total_fee, plat, expire, notify_url, call_back_url,cachierCode);
        logger.info("sParaTempToken：" + sParaTempToken);
        // 发起请求
        String sHtmlTextToken = buildRequest(ALIPAY_GATEWAY_NEW, sParaTempToken, key);
        // URLDECODE返回的信息
        sHtmlTextToken = URLDecoder.decode(sHtmlTextToken,
                AlipayConfig.input_charset);
        logger.info("decode后返回值：" + sHtmlTextToken);
        // 获取token
        Map<String, String> map = getRequestToken(sHtmlTextToken);
        logger.info("token：" + map.toString());
        return map;
    }

    /**
     * @param partner      合作身份者ID
     * @param seller_email 支付宝账号
     * @param orderNum     商户订单号
     * @param prodName     订单名
     * @param _total_fee   总价
     * @return Map<String, String>
     * @Description: 组装请求支付宝支付token的参数
     * @author shenjc
     */
    private Map<String, String> generateTokenRequestParam(String partner,
                                                          String seller_email, String orderNum, String prodName,
                                                          String _total_fee, int plat, long expire, String notify_url, String call_back_url, String cachierCode) {
        String req_id = orderNum; // 请求号，必填，须保证每次请求都是唯一

        String out_trade_no = orderNum; // 商户订单号
        String subject = prodName; // 订单名称
        String total_fee = _total_fee; // 付款金额
        StringBuilder sb = new StringBuilder();

        sb.append("<direct_trade_create_req><notify_url>").append(notify_url)
                .append("</notify_url><call_back_url>").append(call_back_url)
                .append("</call_back_url><seller_account_name>")
                .append(seller_email)
                .append("</seller_account_name><out_trade_no>")
                .append(out_trade_no).append("</out_trade_no><subject>")
                .append(subject).append("</subject><total_fee>")
                .append(total_fee).append("</total_fee><merchant_url>")
                .append("</merchant_url>").append("<pay_expire>")
                .append("</pay_expire>");

        if(!StringUtils.isBlank(cachierCode)){
            sb.append("<cashier_code>" + cachierCode + "</cashier_code>");
        }

        sb.append("</direct_trade_create_req>");

        // 请求业务参数详细
        String req_dataToken = sb.toString();


        logger.info("请求业务参数详细" + req_dataToken);
        // 把请求参数打包成数组
        Map<String, String> sParaTempToken = new HashMap<String, String>();
        sParaTempToken.put("service", "alipay.wap.trade.create.direct");
        sParaTempToken.put("partner", partner);
        sParaTempToken.put("_input_charset", AlipayConfig.input_charset);
        sParaTempToken.put("sec_id", AlipayConfig.sign_type);
        sParaTempToken.put("format", AlipayConfig.format);
        sParaTempToken.put("v", AlipayConfig.v);
        sParaTempToken.put("req_id", req_id);
        sParaTempToken.put("req_data", req_dataToken);
        return sParaTempToken;
    }

    /**
     * 建立请求，以表单HTML形式构造（默认）
     *
     * @param sParaTemp     请求参数数组
     * @param strMethod     提交方式。两个值可选：post、get
     * @param strButtonName 确认按钮显示文字
     * @return 提交表单HTML文本
     * @paramALIPAY_GATEWAY_NEW 支付宝网关地址
     */
    private String buildRequest(String ALIPAY_GATEWAY_NEW,
                                Map<String, String> sParaTemp, String strMethod,
                                String strButtonName, String key) {
        // 待请求参数数组
        Map<String, String> sPara = buildRequestPara(sParaTemp, key);
        List<String> keys = new ArrayList<String>(sPara.keySet());
        StringBuffer sbHtml = new StringBuffer();
        sbHtml.append("<form id=\"alipaysubmit\" name=\"alipaysubmit\" action=\""
                + ALIPAY_GATEWAY_NEW
                + "_input_charset="
                + AlipayConfig.input_charset
                + "\" method=\""
                + strMethod
                + "\">");

        for (int i = 0; i < keys.size(); i++) {
            String name = (String) keys.get(i);
            String value = (String) sPara.get(name);

            sbHtml.append("<input type=\"hidden\" name=\"" + name
                    + "\" value=\"" + value + "\"/>");
        }

        // submit按钮控件请不要含有name属性
        sbHtml.append("<input type=\"submit\" value=\"" + strButtonName
                + "\" style=\"display:none;\"></form>");
        sbHtml.append("<script>document.forms['alipaysubmit'].submit();</script>");
        logger.info("生成html代码：" + sbHtml.toString());
        return sbHtml.toString();
    }



    private String buildRequestWxAlipay(String ALIPAY_GATEWAY_NEW,
                                        Map<String, String> sParaTemp, String strMethod,
                                        String strButtonName, String key) {
        // 待请求参数数组
        Map<String, String> sPara = buildRequestPara(sParaTemp, key);
        List<String> keys = new ArrayList<String>(sPara.keySet());
        sParaTempWxAlipay=sPara;
        keyWxAlipay=key;
        StringBuffer sbHtml = new StringBuffer();

        sbHtml.append("<form id=\"alipaysubmit\" name=\"alipaysubmit\" action=\""
                + ALIPAY_GATEWAY_NEW
                + "_input_charset="
                + AlipayConfig.input_charset
                + "\" method=\""
                + strMethod
                + "\">");

        for (int i = 0; i < keys.size(); i++) {
            String name = (String) keys.get(i);
            String value = (String) sPara.get(name);

            sbHtml.append("<input type=\"hidden\" name=\"" + name
                    + "\" value=\"" + value + "\"/>");
        }

        // submit按钮控件请不要含有name属性
        sbHtml.append("<input type=\"submit\" value=\"" + strButtonName
                + "\" style=\"display:none;\"></form>");
        logger.info("生成html代码：" + sbHtml.toString());
        return sbHtml.toString();
    }

    /**
     * @param ALIPAY_GATEWAY_NEW 支付宝网关地址
     * @param sParaTemp          请求参数
     * @param key                md5加密秘钥
     * @return String
     * @Description: 向支付宝发起请求，获取支付请求用的token
     * @Modified:
     */
    private String buildRequest(String ALIPAY_GATEWAY_NEW,
                                Map<String, String> sParaTemp, String key) throws Exception {
        // 待请求参数数组
        Map<String, String> sPara = buildRequestPara(sParaTemp, key);
        String prestr = AlipayCore.createLinkString(sPara);
        // 创建请求
        logger.info("请求支付宝授权接口请求值值：" + prestr);
        String result = "";
        String url = ALIPAY_GATEWAY_NEW + "_input_charset="
                + AlipayConfig.input_charset;
        try {
            HttpPost post = new HttpPost(url);
            HttpEntity entity = new StringEntity(prestr,
                    AlipayConfig.input_charset);
            post.setEntity(entity);
            post.setHeader("Content-Type",
                    "application/x-www-form-urlencoded; charset=UTF-8");
            HttpResponse response = HttpUtil.execute/* Proxy */(post);
            result = EntityUtils.toString(response.getEntity());
            logger.info("请求支付宝授权接口返回值：" + result);
        } catch (Exception e) {
            logger.error("请求支付宝授权接口失败" + e.toString(), e);
        }
        return result;
    }

    /**
     * @param sParaTemp 组装的参数map
     * @param key       md5加密秘钥
     * @return Map<String,String> 经过处理并经过签名的参数map
     * @Description: 生成要请求给支付宝的参数map
     * @Modified:
     */
    private Map<String, String> buildRequestPara(Map<String, String> sParaTemp,
                                                 String key) {
        // 除去数组中的空值和签名参数
        Map<String, String> sPara = AlipayCore.paraFilter(sParaTemp);
        // 生成签名结果
        String mysign = buildSign(sPara, key);
        // 签名结果与签名方式加入请求提交参数组中
        sPara.put("sign", mysign);
        if (!sPara.get("service").equals("alipay.wap.trade.create.direct")
                && !sPara.get("service").equals(
                "alipay.wap.auth.authAndExecute")) {
            sPara.put("sign_type", AlipayConfig.sign_type);
        }

        return sPara;
    }

    /**
     * @param sPara 需签名的参数map
     * @param key   md5签名秘钥
     * @return String 生成的签名串
     * @Description: 生成签名结果
     * @Modified:
     */
    private String buildSign(Map<String, String> sPara, String key) {
        String prestr = AlipayCore.createLinkString(sPara); // 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
        String mysign = "";
        if (AlipayConfig.sign_type.equals("MD5")) {
            mysign = MD5.sign(prestr, key, AlipayConfig.input_charset);
        }
        if (AlipayConfig.sign_type.equals("0001")) {
            mysign = RSA.sign(prestr, AlipayConfig.private_key,
                    AlipayConfig.input_charset);
        }
        return mysign;
    }

    /**
     * 解析远程模拟提交后返回的信息，获得token
     *
     * @param text 要解析的字符串
     * @return 解析结果
     * @throws Exception
     */
    private Map<String, String> getRequestToken(String text) throws Exception {
        String request_token = "";
        // 以“&”字符切割字符串
        String[] strSplitText = text.split("&");
        // 把切割后的字符串数组变成变量与数值组合的字典数组
        Map<String, String> map = new HashMap<String, String>();
        Map<String, String> paraText = new HashMap<String, String>();
        for (int i = 0; i < strSplitText.length; i++) {

            // 获得第一个=字符的位置
            int nPos = strSplitText[i].indexOf("=");
            // 获得字符串长度
            int nLen = strSplitText[i].length();
            // 获得变量名
            String strKey = strSplitText[i].substring(0, nPos);
            // 获得数值
            String strValue = strSplitText[i].substring(nPos + 1, nLen);
            // 放入MAP类中
            paraText.put(strKey, strValue);
        }

        if (paraText.get("res_data") != null) {
            String res_data = paraText.get("res_data");
            // 解析加密部分字符串（RSA与MD5区别仅此一句）
            if (AlipayConfig.sign_type.equals("0001")) {
                res_data = RSA.decrypt(res_data, AlipayConfig.private_key,
                        AlipayConfig.input_charset);
            }

            // token从res_data中解析出来（也就是说res_data中已经包含token的内容）
            // Document document = DocumentHelper.parseText(res_data);

            SAXReader saxReader = new SAXReader();
            saxReader.setEncoding("utf-8");
            Document doc;
            Element root = null;
            try {
                doc = saxReader.read(new ByteArrayInputStream(res_data.trim()
                        .getBytes("UTF-8")));
                root = doc.getRootElement();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                logger.warn("读取xml文件错误------》" + e);
            } catch (DocumentException e) {
                // TODO Auto-generated catch block
                logger.warn("读取xml文件错误------》" + e);
            }
            if (root != null) {
                request_token = root.elementText("request_token");

                map.put("request_token", request_token);
                logger.info("token------>" + map.get("request_token"));


            }


        }
        return map;
    }


    /**
     * <br>
     * 支付结果返回
     */

    public String payCallBack(Map<String, String> params, String _key) {
        String out_trade_no = params.get("out_trade_no"); // 商户订单号
        // String trade_no = params.get("trade_no"); //支付宝交易号
        String result = params.get("result"); // 交易状态
        // 查询秘钥
        String key = EncryptionUtil.deEncryption(_key); // 交易安全检验码，由数字和字母组成的32位字符串，如果签名方式设置为“MD5”时，请设置该参数
        // 计算得出通知验证结果
        boolean verify_result = AlipayNotify.verifyReturn(params, key);
        if (verify_result) {// 验证成功
            // 判断结果
            if ("success".equals(result)) {
                logger.info("支付结果通知，支付成功，订单号：" + out_trade_no);
            } else {
                logger.info("支付结果通知，支付失败，订单号：" + out_trade_no);
            }
        } else {
            logger.info("支付结果通知MD5签名验签失败，订单号：" + out_trade_no);
        }
        return out_trade_no;
    }

    /**
     * <br>
     * 支付结果通知
     */

    public String payNotice(Map<String, String> params, String _key,
                            String _partner) throws Exception {
        Document doc_notify_data = DocumentHelper.parseText(params
                .get("notify_data")); // XML解析notify_data数据
        String out_trade_no = doc_notify_data.selectSingleNode(
                "//notify/out_trade_no").getText(); // 商户订单号
        // String trade_no = doc_notify_data.selectSingleNode(
        // "//notify/trade_no" ).getText(); //支付宝交易号
        String trade_status = doc_notify_data.selectSingleNode(
                "//notify/trade_status").getText(); // 交易状态
        // 查询秘钥
        String key = EncryptionUtil.deEncryption(_key); // 交易安全检验码，由数字和字母组成的32位字符串，如果签名方式设置为“MD5”时，请设置该参数
        String partner = _partner;
        if (AlipayNotify.verifyNotify(params, key, partner)) {
            if (trade_status.equals("TRADE_FINISHED")
                    || trade_status.equals("TRADE_SUCCESS")) {
                logger.info("支付结果通知，支付成功，订单号：" + out_trade_no);
            } else {
                logger.info("支付结果通知，支付状态不是finished或success，订单号：" + out_trade_no);
            }
            return success;
        } else {// 验证失败
            logger.info("支付结果通知MD5签名验签失败，订单号：" + out_trade_no);
        }
        return fail;
    }


    @Override
    public RemoteResult<Map<String, Object>> callUpdate(String notifyId, String payTransactionId, String trade_no, String gmt_payment, String merchantCode, String payType, MerchantPayPlatView merchantPayPlatView) {
        RemoteResult<Map<String, Object>> result = new RemoteResult<Map<String, Object>>();
        boolean flag = aliPayCommonManager.checkStatus(payTransactionId);
        com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder payOrder=null;
//        ChannelOrder channelOrder = new ChannelOrder();
        if (!flag){
            if (payTransactionId.trim().length()== 10){
                payOrder = payOrderApi.getPayOrderByPrimaryId(Long.valueOf(payTransactionId));
            }else{
                payOrder =payOrderApi.getPayOrderById(payTransactionId);
                payTransactionId=payOrder.getId().toString();
            }
            String out_trade_no = payOrder.getOut_trade_no();
//            channelOrder.setOrderCode(out_trade_no);
//            设置LenovoID
//            channelOrder.setLenovoId(payOrder.getU_id());
//            channelOrder.setPayment(Integer.parseInt(PeakConstant.PAY_TYPE_ALSJ));
//            channelOrder.setTransationId(String.valueOf(payOrder.getId()));
//            channelOrder.setPayStatus(1);
//            channelOrder.setShopId(payOrder.getShop_id());
//            channelOrder.setPayTime(DateUtil.formatDate(new Date(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
            PayPortalOrder updatePayPortalOrder = CommonMethod.buildUpdatePayPortalOrder(payTransactionId, out_trade_no, payOrder.getU_id(), Integer.parseInt(PeakConstant.PAY_TYPE_ALSJ), PeakConstant.PAY_STATUS_ALREADY_PAID, payOrder.getShop_id() ,new Date());
            payOrderApi.updateAliIphonePayNotifyState(payTransactionId, trade_no, PeakConstant.MFLAG_REPEAT, notifyId, PeakConstant.TRADE_SUCCESS, null, Integer.parseInt(PeakConstant.PAY_TYPE_ALSJ));
            try{
//                RemoteResult<Integer> updateChannelOrderResult = commonManager.updateChannelOrderMainCodeDetail(channelOrder);
                RemoteResult<Integer> updatePayPortalOrderResult = payPortalOrderManager.updatePayPortalOrderPayStatus(updatePayPortalOrder);
                if (updatePayPortalOrderResult.isSuccess()) {
                    logger.info("Update PayPortalOrder SUCCESS，outTradeNo[" + out_trade_no + "]");
                } else {
                    logger.info("Update PayPortalOrder FAIL，outTradeNo[" + out_trade_no + "]");
                }
            }catch(Exception e){
                logger.info("更新渠道订单失败 ，订单号==>" + out_trade_no, e);
            }
            String updateOrder="";
            try {
                String signature = aliPayCommonManager.getSignature(payTransactionId,trade_no, out_trade_no, gmt_payment, PeakConstant.PAYMENT_ALI, payOrder.getU_id());
                updateOrder = merchantPayPlatView.getInNotifyUrl()+"orderCode=" + out_trade_no + "&payOrderCode=" +trade_no  + "&payDatetime=" + gmt_payment +"&payment="+ PeakConstant.PAYMENT_ALI +"&signature=" + signature + "&payTransactionId="+payTransactionId;
                logger.warn("updateOrder====>"+updateOrder);
                RemoteResult<String> remoteResult = commonCallBackManager.payCallback(merchantPayPlatView,payOrder.getOs(),signature,payOrder.getOut_trade_no(),trade_no,gmt_payment,PeakConstant.PAYMENT_ALI,payOrder.getU_id(),payOrder.getId().toString(),payOrder);
                logger.warn("更新订单状态返回结果：" + JSON.toJSONString(remoteResult));
                String str = remoteResult.getT();
                if ("success".equalsIgnoreCase(str.trim())) {
                    payOrderApi.updateAliIphonePayNotifyState(payTransactionId, trade_no, PeakConstant.MFLAG_SUCC, notifyId, PeakConstant.TRADE_SUCCESS, null, Integer.parseInt(PeakConstant.PAY_TYPE_ALSJ));
                    result.setSuccess(true);
                }
            } catch (Exception e) {
                result.setSuccess(false);
                result.setResultCode(ReturnCode.InNotifyFail.getCode());
                result.setResultMsg(ReturnCode.InNotifyFail.getMessage());
                logger.error("手机支付回调订单状态更新异常--->" + e.getMessage(),e);
                payOrderApi.updateAliIphonePayNotifyState(payTransactionId, trade_no, PeakConstant.MFLAG_REPEAT, notifyId, PeakConstant.TRADE_SUCCESS, null, Integer.parseInt(PeakConstant.PAY_TYPE_ALSJ));
            }
        }else {
            result.setSuccess(true);
        }
        return result;
    }




    @Override
    public RemoteResult toAliSjPayWxAlipay(HttpServletRequest request ,Map<String,Object> wxmap) {
        RemoteResult resultHtml = new RemoteResult();
        RemoteResult<String> returnResult = new RemoteResult<String>();
        resultHtml.setSuccess(true);
        AliPaySjModel model = (AliPaySjModel) BaseModel.getModel(request);
        String orderMainCode = model.getOrderMainCode();
        String merchantCode = model.getMerchantCode();
        String payType = model.getPayType();
        String lenovoId = model.getLenovoId();
        String plat = model.getPlat();
        String shopId = model.getShopId();
        String terminal = model.getTerminal();
        Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
        logger.info("订单号：" + orderMainCode + "  商户号:" + merchantCode + "  支付类型:" + payType + "  lenovoId:" + lenovoId);
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(orderMainCode, lenovoId, tenant);
        PayPortalOrder payPortalOrder;
        if(payPortalOrderRemoteResult.isSuccess()){
            payPortalOrder = payPortalOrderRemoteResult.getT();
            if(payPortalOrder == null||payPortalOrder.getOutTradeNo() == null){
                logger.warn("查询支付订单信息异常");
                returnResult.setSuccess(false);
                returnResult.setResultCode("30003");
                returnResult.setResultMsg("查询支付订单信息异常");
                return returnResult;
            }
        }else{
            logger.warn("查询支付订单信息异常");
            returnResult.setSuccess(false);
            returnResult.setResultCode("30003");
            returnResult.setResultMsg("查询支付订单信息异常");
            return returnResult;
        }
        if("1".equals(payPortalOrder.getPaymentWay())){
            commonManager.getLedgerFAID(payPortalOrder);
        }
        StringBuffer sb = new StringBuffer();
        sb.append("faid=" + payPortalOrder.getFaId() + ",");
        sb.append("payType=" + payType + ",");
        sb.append("lenovoId=" + lenovoId);
        String extra_common_param = "";
        try {
            extra_common_param = URLEncoder.encode(sb.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            logger.error("支付宝回传数据Encode异常",e);
            returnResult.setSuccess(false);
            returnResult.setResultCode("30001");
            returnResult.setResultMsg("支付宝回传数据Encode异常");
            return returnResult;
        }
        logger.info("extra_common_param--->" + extra_common_param);
        //PayStatus 1为已支付，0为未支付
        if(PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(payPortalOrder.getPayStatus()))){
            logger.info("PayPortalOrder ALREADY PAID ,outTradeNo[" + orderMainCode + "]");
            returnResult.setSuccess(false);
            returnResult.setResultCode("30008");
            returnResult.setResultMsg("订单已支付");
            return returnResult;
        }
        if(PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(payPortalOrder.getOrderStatus()))){
            logger.info("PayPortalOrder Order Status INVALID, outTradeNo[" + orderMainCode + "]");
            returnResult.setSuccess(false);
            returnResult.setResultCode("30009");
            returnResult.setResultMsg("订单已失效");
            return returnResult;
        }
        MerchantPayPlatView merchantPayPlatView = null;
        RemoteResult<MerchantPayPlatView> MppvRemoteResult = aliPayCommonManager.getMerchantPayPlatView(payPortalOrder.getFaId(), payType);
        if ( MppvRemoteResult.isSuccess()) {
            merchantPayPlatView =  MppvRemoteResult.getT();
            logger.info( MppvRemoteResult.isSuccess());
            logger.info(merchantPayPlatView.toString());
        } else {
            logger.info("未查询到平台信息");
            MppvRemoteResult.setSuccess(false);
            MppvRemoteResult.setResultCode("30002");
            MppvRemoteResult.setResultMsg("查询商户平台信息异常");
            return MppvRemoteResult;
        }
        String totalFee = String.valueOf(payPortalOrder.getTotalFee());//支付金额,单位（元）
        String prodName = CommonMethod.getProductName(payPortalOrder.getSubject());
        String currencyCode = payPortalOrder.getCurrencyCode();
        String bodyHtml = null;
        try {
            String callBackUrl = merchantPayPlatView.getOutCallBackUrl();
            String orderPrimaryId = null;
            RemoteResult<String> savePayOrderResult = new RemoteResult<String>();
            RemoteResult<List<com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder>> orderListResult = aliPayCommonManager.getOrderListByPayType(orderMainCode, Integer.parseInt(payType));
            if(orderListResult.isSuccess() && orderListResult.getT().size() > 0){
                orderPrimaryId = String.valueOf(orderListResult.getT().get(0).getId());
                logger.info("支付宝手机支付类型交易已存在，ID==>" + orderPrimaryId);
            }else{
                savePayOrderResult = commonManager.savePayOrder(lenovoId,plat,payType,orderMainCode,totalFee,prodName,"",0,"",merchantCode,"",shopId,terminal,merchantPayPlatView,currencyCode);
                if(!savePayOrderResult.isSuccess()){
                    logger.warn("保存订单信息失败");
                    returnResult.setSuccess(false);
                    returnResult.setResultCode("400");
                    returnResult.setResultMsg("保存订单信息失败");
                    return returnResult;
                }
                logger.info("保存订单成功");
                orderPrimaryId = savePayOrderResult.getT();
                logger.info("查询支付宝手机支付类型交易不存在，新建记录ID==>" + orderPrimaryId);
            }

            logger.info("保存订单成功");
            logger.info("callBackUrl=======>"+callBackUrl);
            String cashierCode = request.getParameter("cashierCode");
            logger.info("微信商城-cashierCode:"+cashierCode);
            //TODO 适配互联网专区
            String outNotifyUrl = merchantPayPlatView.getOutNotifyUrl();
            outNotifyUrl = CommonMethod.getHlwzqUrl(outNotifyUrl);
            bodyHtml = this.getPsnSjHtmlwxAlipay(merchantPayPlatView.getMechId(), merchantPayPlatView.getAppId(), merchantPayPlatView.getSignKey(), orderPrimaryId, prodName, totalFee, merchantPayPlatView.getPayType(), 1440L, outNotifyUrl, callBackUrl,cashierCode);
            logger.info("微信支付宝走的方法==========》");
            wxmap.put("bodyHtml",bodyHtml);
            logger.info("微信====》支付宝的form表单=====》"+bodyHtml);
            wxmap.put("subject",payPortalOrder.getSubject());
            wxmap.put("total_fee",totalFee);
            logger.info("微信====》支付金额===》"+totalFee);
            wxmap.put("wxhtml",wxmap);
            logger.info("微信====》wxhtml===》"+wxhtml);
            resultHtml.setT(wxmap);
            String wxallipayurl=wxalipayUrl();
            logger.info("微信====》wxallipay===》"+wxallipayurl);
            wxmap.put("wxallipayurl",wxallipayurl);


        } catch (Exception e) {
            resultHtml.setSuccess(false);
            resultHtml.setResultMsg("保存订单或构建支付HTML失败");
            logger.info("构建支付HTML失败", e);
        }

        if (bodyHtml == null || "".equals(bodyHtml)) {
            logger.info("保存订单或构建支付HTML失败");
            resultHtml.setSuccess(false);
            resultHtml.setResultMsg("保存订单或构建支付HTML失败");
        }
        return resultHtml;

    }


    @Override
    public RemoteResult toAliSjPay(HttpServletRequest request ) {
        logger.info("<--支付宝WAP端支付交易-->");
        RemoteResult resultHtml = new RemoteResult();
        RemoteResult<String> returnResult = new RemoteResult<String>();
        resultHtml.setSuccess(true);
        AliPaySjModel model = (AliPaySjModel) BaseModel.getModel(request);
        //String ordercode = model.getOrderId();
        String orderMainCode = model.getOrderMainCode();
        String merchantCode = model.getMerchantCode();
        String shopId = request.getParameter("shopId");
        String terminal = request.getParameter("terminal");
        String plat = model.getPlat();
        if("roaming".equals(merchantCode)){
            orderMainCode = model.getOrderId();
            shopId = CommonMethod.getShopIdFromPlat(plat);
        }
        String payType = model.getPayType();
        String lenovoId = model.getLenovoId();
        if(StringUtils.isEmpty(plat)){
            plat = CommonMethod.getPlatFromShopIdTerminal(shopId, terminal);
        }
        Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
        logger.info("支付宝WAP支付,orderMainCode[" + orderMainCode + "],merchantCode[" + merchantCode + "],shopId[" + shopId + "],terminal[" + terminal + "],plat[" + plat + "],payType[" + payType + "],lenovoId[" + lenovoId + "]");
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(orderMainCode, lenovoId, tenant);
        PayPortalOrder payPortalOrder;
        if(payPortalOrderRemoteResult.isSuccess()){
            payPortalOrder = payPortalOrderRemoteResult.getT();
            if(payPortalOrder == null||payPortalOrder.getOutTradeNo() == null){
                logger.info("查询支付订单信息异常" + orderMainCode);
                returnResult.setSuccess(false);
                returnResult.setResultCode("30003");
                returnResult.setResultMsg("查询支付订单信息异常");
                return returnResult;
            }
        }else{
            logger.info("查询支付订单信息异常" + orderMainCode);
            returnResult.setSuccess(false);
            returnResult.setResultCode("30003");
            returnResult.setResultMsg("查询支付订单信息异常");
            return returnResult;
        }
        //TODO 校验渠道订单是否为MBG
        if("1".equals(payPortalOrder.getPaymentWay())){
            commonManager.getLedgerFAID(payPortalOrder);
        }
        StringBuffer commomParamBuffer = new StringBuffer();
        //TODO 修改为从ChannelOrder中获取FaId 已修改
        commomParamBuffer.append("faid=" + payPortalOrder.getFaId() + ",");
        commomParamBuffer.append("payType=" + payType + ",");
        commomParamBuffer.append("lenovoId=" + lenovoId);
        String extra_common_param;
        try {
            extra_common_param = URLEncoder.encode(commomParamBuffer.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            logger.error("支付宝回传数据Encode异常",e);
            returnResult.setSuccess(false);
            returnResult.setResultCode("30001");
            returnResult.setResultMsg("支付宝回传数据Encode异常");
            return returnResult;
        }
        logger.info("extra_common_param--->" + extra_common_param);
        if(PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(payPortalOrder.getPayStatus()))){
            logger.error("订单已支付，订单号[" + orderMainCode + "]");
            returnResult.setSuccess(false);
            returnResult.setResultCode("30008");
            returnResult.setResultMsg("订单已支付");
            return returnResult;
        }
        if(PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(payPortalOrder.getOrderStatus()))){
            logger.info("主订单已失效，订单号[" + orderMainCode + "]");
            returnResult.setSuccess(false);
            returnResult.setResultCode("30009");
            returnResult.setResultMsg("订单已失效");
            return returnResult;
        }

        MerchantPayPlatView merchantPayPlatView = null;
        RemoteResult<MerchantPayPlatView> MerchantPayPlatViewRemoteResult = aliPayCommonManager.getMerchantPayPlatView(payPortalOrder.getFaId(), payType);
        if ( MerchantPayPlatViewRemoteResult.isSuccess()) {
            merchantPayPlatView =  MerchantPayPlatViewRemoteResult.getT();
            logger.info("支付平台信息==>" + merchantPayPlatView.toString());
        } else {
            logger.info("未查询到平台信息，订单号==>" + orderMainCode);
            returnResult.setSuccess(false);
            returnResult.setResultCode("30002");
            returnResult.setResultMsg("查询商户平台信息异常");
            return returnResult;
        }
        String totalFee = String.valueOf(payPortalOrder.getTotalFee());
        String prodName = CommonMethod.getProductName(payPortalOrder.getSubject());
        String currencyCode = payPortalOrder.getCurrencyCode();
        String bodyHtml = null;
        try {
            String callBackUrl;
            if (PeakConstant.SHOPID_ROAMING.equals(shopId)) {
                callBackUrl = "";
            }else {
                callBackUrl = merchantPayPlatView.getOutCallBackUrl();
            }
            String orderPrimaryId;
            RemoteResult<String> savePayOrderResult = new RemoteResult<String>();
            RemoteResult<List<PayOrder>> orderListResult = aliPayCommonManager.getOrderListByPayType(orderMainCode, Integer.parseInt(payType));
            if(orderListResult.isSuccess() && orderListResult.getT().size() > 0){
                orderPrimaryId = String.valueOf(orderListResult.getT().get(0).getId());
                logger.info("支付宝手机支付类型交易已存在，ID==>" + orderPrimaryId);
            }else{
                savePayOrderResult = commonManager.savePayOrder(lenovoId,plat,payType,orderMainCode,totalFee,prodName,"",0,"","","",shopId,terminal,merchantPayPlatView,currencyCode);
                if(!savePayOrderResult.isSuccess()){
                    logger.warn("保存订单信息失败");
                    returnResult.setSuccess(false);
                    returnResult.setResultCode("400");
                    returnResult.setResultMsg("保存订单信息失败");
                    return returnResult;
                }
                logger.info("保存订单成功");
                orderPrimaryId = savePayOrderResult.getT();
                logger.info("查询支付宝手机支付类型交易不存在，新建记录ID==>" + orderPrimaryId);
            }
            logger.info("保存订单成功orderPrimaryId=========="+orderPrimaryId);
            if(PeakConstant.SHOPID_MOTO.equals(shopId)){
                logger.info("适配摩托罗拉用商城订单号支付");
                orderPrimaryId = orderMainCode;
            }
            if( PeakConstant.SHOPID_LENOVO.equals(shopId)&&PeakConstant.TERMINAL_APP.equals(terminal) && PeakConstant.PAY_TYPE_ALSJ.equals(payType) && AliSimplePaltPayConfig.partner.equals(merchantPayPlatView.getMechId())){
                resultHtml.setT(getSimplePlatData(merchantPayPlatView ,payPortalOrder,prodName,orderPrimaryId));
              return resultHtml;
            }
            String outNotifyUrl = merchantPayPlatView.getOutNotifyUrl();
            outNotifyUrl = CommonMethod.getHlwzqUrl(outNotifyUrl);
            bodyHtml = this.getPsnSjHtml(merchantPayPlatView.getMechId(), merchantPayPlatView.getAppId(), merchantPayPlatView.getSignKey(), orderPrimaryId, prodName, totalFee, merchantPayPlatView.getPayType(), 1440L, outNotifyUrl, callBackUrl);

            bodyHtml = "<html>" + "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>支付宝订单请求</title></head>" + "<body>"
                    + bodyHtml + "</body></html>";
            logger.info("构建支付HTML" + bodyHtml);
            resultHtml.setT(bodyHtml);


        } catch (Exception e) {
            resultHtml.setSuccess(false);
            resultHtml.setResultMsg("保存订单或构建支付HTML失败");
            logger.info("构建支付HTML失败", e);
        }

        if (bodyHtml == null || "".equals(bodyHtml)) {
            logger.info("保存订单或构建支付HTML失败");
            resultHtml.setSuccess(false);
            resultHtml.setResultMsg("保存订单或构建支付HTML失败");
        }
        return resultHtml;

    }

    private String getSimplePlatData(MerchantPayPlatView merchantPayPlatView , PayPortalOrder payPortalOrder, String pName, String key_id){
        String notify_url = merchantPayPlatView.getOutNotifyUrl();
        //TODO 适配互联网专区
        notify_url = CommonMethod.getHlwzqUrl(notify_url);
        notify_url=notify_url.substring(0,notify_url.indexOf(".jhtm"))+"/simplePlatPay.jhtm";
        String return_url=merchantPayPlatView.getOutCallBackUrl().substring(0,merchantPayPlatView.getOutCallBackUrl().indexOf(".jhtm"))+"/js.jhtm";
//        String  notify_url="http://pay.test.lenovo.com/unReturn.jhtm";
//        String  return_url="http://pay.test.lenovo.com/unReturn.jhtm";
           // 合作者身份ID
        String orderInfo = "partner=" + "\"" + AliSimplePaltPayConfig.partner + "\"";

        // 卖家支付宝账号
        orderInfo += "&seller_id=" + "\"" + AliSimplePaltPayConfig.seller + "\"";

        // 商户网站唯一订单号
        orderInfo += "&out_trade_no=" + "\"" +key_id + "\"";

        // 商品名称
        orderInfo += "&subject=" + "\"" + pName + "\"";

        // 商品详情
        orderInfo += "&body=" + "\"" + pName + "\"";

        // 商品金额
        //TODO 修改为从channelOrder中获取订单金额 已修改
        orderInfo += "&total_fee=" + "\"" + payPortalOrder.getTotalFee() + "\"";

        // 服务器异步通知页面路径
        orderInfo += "&notify_url=" + "\""
                + notify_url + "\"";

        // 接口名称， 固定值
        orderInfo += "&service=\"mobile.securitypay.pay\"";

        // 支付类型， 固定值
        orderInfo += "&payment_type=\"1\"";

        // 参数编码， 固定值
        orderInfo += "&_input_charset=\"utf-8\"";

        // 设置未付款交易的超时时间
        // 默认30分钟，一旦超时，该笔交易就会自动被关闭。
        // 取值范围：1m～15d。
        // m-分钟，h-小时，d-天，1c-当天（无论交易何时创建，都在0点关闭）。
        // 该参数数值不接受小数点，如1.5h，可转换为90m。
        orderInfo += "&it_b_pay=\"1d\"";
        // 支付宝处理完请求后，当前页面跳转到商户指定页面的路径，可空
        orderInfo += "&return_url="+ "\""+return_url+"\"";
        logger.info("极简支付：参数"+orderInfo);
        String sign = RSA.sign(orderInfo, AliSimplePaltPayConfig.private_key_pkcs8,AliSimplePaltPayConfig.input_charset);
        // 仅需对sign 做URL编码
        try {
            sign = URLEncoder.encode(sign, AliSimplePaltPayConfig.input_charset);
        } catch (Exception e){
            logger.info("转码失败！");
        }
        String linkString = orderInfo + "&sign=\"" + sign + "\"&sign_type=\""
                + AliSimplePaltPayConfig.sign_type+"\"";
        return linkString;
    }
    private String wxalipayUrl(){
        Map<String, String> sPara = buildRequestPara(sParaTempWxAlipay, keyWxAlipay);
        List<String> keys = new ArrayList<String>(sPara.keySet());
        String url = ALIPAY_GATEWAY_NEW+"_input_charset="+AlipayConfig.input_charset;
        String keyvalue="";
        for (int i = 0; i < keys.size(); i++) {
            String name = (String) keys.get(i);
            String value = (String) sPara.get(name);
            keyvalue+= "&"+name+"="+value;
        }
        return url+keyvalue;
    }
}
