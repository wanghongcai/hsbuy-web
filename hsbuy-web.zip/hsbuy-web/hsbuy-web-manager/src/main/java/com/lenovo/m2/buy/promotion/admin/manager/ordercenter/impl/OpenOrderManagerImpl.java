package com.lenovo.m2.buy.promotion.admin.manager.ordercenter.impl;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.buy.promotion.admin.domain.ordercenter.ItemOfShotInfo;
import com.lenovo.m2.buy.promotion.admin.domain.ordercenter.ThrowWareHouseListParam;
import com.lenovo.m2.buy.promotion.admin.domain.ordercenter.ThrowWareHouseResult;
import com.lenovo.m2.buy.promotion.admin.manager.ordercenter.OpenOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.ordercenter.OpenOrderRemote;
import com.lenovo.m2.hsbuy.domain.inventory.HsStock;
import com.lenovo.m2.hsbuy.domain.order.OrderItem;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.domain.order.mongo.PayRecords;
import com.lenovo.m2.hsbuy.domain.ordercenter.AuditOrderDetailRequest;
import com.lenovo.m2.hsbuy.domain.ordercenter.AuditOrderDetailResult;
import com.lenovo.m2.hsbuy.domain.ordercenter.DownlinePayListParam;
import com.lenovo.m2.hsbuy.domain.ordercenter.ResultCode;
import com.lenovo.m2.hsbuy.domain.throwengine.OrderItemHSVo;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by jh on 2016/9/9.
 */
@Service
@Component
public class OpenOrderManagerImpl implements OpenOrderManager {
    @Autowired
    private OpenOrderRemote openOrderRemote;

    private static final Logger LOGGER = Logger.getLogger(OpenOrderManagerImpl.class);


    /**
     * 获取惠商待审核订单（分页）
     *
     * @param pageQuery
     * @param filterMap
     * @param tenant
     * @return
     */
    @Override
    public RemoteResult<PageModel2<MongoOrderDetail>> getMongoOrderList(PageQuery pageQuery, Map<String, Object> filterMap, Tenant tenant) {
        return openOrderRemote.getMongoOrderList(pageQuery, filterMap, tenant);
    }

    /**
     * 组装惠商审单详情页数据
     *
     * @param map    key：orderId
     * @param tenant
     * @return
     */
    @Override
    public RemoteResult<AuditOrderDetailResult> getMongoOrderDetail(Map<String, Object> map, Tenant tenant) {
        return openOrderRemote.getMongoOrderDetail(map, tenant);
    }

    @Override
    public RemoteResult auditOrderDetail(AuditOrderDetailRequest request, Tenant tenant) {
        return openOrderRemote.auditOrderDetail(request, tenant);
    }

    /**获取惠商抛单列表信息
     * @param param
     * @return
     */
    @Override
    public RemoteResult<ThrowWareHouseResult> getHSThrowList(ThrowWareHouseListParam param) {
        //获取详情
        //获取抛单列表，
        //获取库存地列表
        RemoteResult remoteResult = new RemoteResult(false);
        //根据权限和订单号从MongoDB获取抛单页面的总信息
        RemoteResult<MongoOrderDetail> detailRemoteResult = openOrderRemote.getMongoOrderDetail(param.getTenant(), param.getOrderId());
        if (!detailRemoteResult.isSuccess()) {
            remoteResult.setResultCode(detailRemoteResult.getResultCode());
            remoteResult.setResultMsg(detailRemoteResult.getResultMsg());
            return remoteResult;
        }
        if (detailRemoteResult.getT() == null) {
            remoteResult.setResultCode(ResultCode.TEMP);
            remoteResult.setResultMsg("未获取到订单信息，订单号：" + param.getOrderId());
            return remoteResult;
        }
        //根据订单号获取抛单商品信息
        RemoteResult order = openOrderRemote.getOrderItemsByOrderId(Long.parseLong(param.getOrderId()));
        if (order == null || !order.isSuccess()) return remoteResult;
        if (order.getT() == null||CollectionUtils.isEmpty((List)order.getT())) {
            remoteResult.setResultCode(ResultCode.TEMP);
            remoteResult.setResultMsg("抛单列表还未同步，请稍等再试...");
            return remoteResult;
        }

        List<ItemOfShotInfo> itemOfShotInfos =new ArrayList<ItemOfShotInfo>();
        ItemOfShotInfo itemOfShotInfo = null;
        List<OrderItem> orderItems = (List<OrderItem>) order.getT();
        //循环抛单商品List,新增加库存地址信息
        for(OrderItem orderItem : orderItems) {
            String materialCode = orderItem.getMaterialCode();
            String faId = orderItem.getFAID();
            String deatLike = orderItem.getDeatLike();
            RemoteResult hsStockRemoteResult = openOrderRemote.getHsStocksByPcode(materialCode, faId, deatLike);
            if (!hsStockRemoteResult.isSuccess()) {
                return hsStockRemoteResult;
            }
            if (CollectionUtils.isEmpty((List<HsStock>) hsStockRemoteResult.getT())) {
                remoteResult.setResultCode(ResultCode.TEMP);
                remoteResult.setResultMsg("库存地列表为空");
                LOGGER.info("====OrderOpenService getMongoOrderDetail step 2 getHsStocksByPcode empty meterialCode："+materialCode+"，faId："+ faId);
                return remoteResult;
            }
            itemOfShotInfo = new ItemOfShotInfo();
            org.springframework.beans.BeanUtils.copyProperties(orderItem, itemOfShotInfo);
            itemOfShotInfo.setHsStocks((List<HsStock>) hsStockRemoteResult.getT());
            itemOfShotInfos.add(itemOfShotInfo);
        }
        //封装待抛单订单和包含的商品详情信息
        ThrowWareHouseResult throwWareHouseResult = new ThrowWareHouseResult();
        throwWareHouseResult.setOrder(detailRemoteResult.getT());
        throwWareHouseResult.setItemOfShotInfo(itemOfShotInfos);

        remoteResult.setT(throwWareHouseResult);
        remoteResult.setSuccess(true);
        return remoteResult;
    }



    @Override
    public RemoteResult saveItemsWareHouse(List<OrderItemHSVo> list, int shopId) {
        RemoteResult remoteResult = new RemoteResult();
        List<OrderItemHSVo> listReq = new ArrayList<OrderItemHSVo>();
        if (list!=null && list.size()>0) {
            for (OrderItemHSVo orderItemHSVo : list) {
                remoteResult = this.checkSaveItemsWareParam(orderItemHSVo, remoteResult);
                if (!remoteResult.isSuccess()) {
                    return remoteResult;
                } else {
                    OrderItemHSVo orderItemReq = new OrderItemHSVo();
                    orderItemReq.setOrderId(orderItemHSVo.getOrderId());
                    orderItemReq.setOrderItemId(orderItemHSVo.getOrderItemId());
                    orderItemReq.setWareHouse(orderItemHSVo.getWareHouse());
                    orderItemReq.setStockType(orderItemHSVo.getStockType());
                    orderItemReq.setTmsordno(orderItemHSVo.getTmsordno());
                    orderItemReq.setTmsagentordno(orderItemHSVo.getTmsagentordno());
                    orderItemReq.setChannel(orderItemHSVo.getChannel());
                    orderItemReq.setBiztypecode(orderItemHSVo.getBiztypecode());
                    orderItemReq.setShopId(shopId);
                    orderItemReq.setNum(orderItemHSVo.getNum());
                    listReq.add(orderItemReq);
                }
            }
            remoteResult = openOrderRemote.saveItemsWareHouse(listReq);
        } else {
            remoteResult.setResultCode(ResultCode.PARAMETER_ERROR);
            remoteResult.setResultMsg("传入orderItem参数有误");
            LOGGER.info("==============orderItem list is null==============");
        }
        return remoteResult;
    }

    @Override
    public RemoteResult saveItemsWareHouseAndThrowOrder(OrderItemHSVo orderItemHSVo) {
        RemoteResult remoteResult = new RemoteResult(false);
        remoteResult = this.checkSaveItemsWareParam(orderItemHSVo, remoteResult);
        if (!remoteResult.isSuccess()) {
            return remoteResult;
        }
        return openOrderRemote.saveItemsWareHouseAndThrowOrder(orderItemHSVo);
    }

    /**
     * 保存分配库存地信息非空校验
     * @param orderItemHSVo
     * @param remoteResult
     * @return
     */
    public RemoteResult checkSaveItemsWareParam(OrderItemHSVo orderItemHSVo, RemoteResult remoteResult) {
        if (orderItemHSVo.getOrderId() == 0) {
            remoteResult.setResultMsg("参数错误，订单号为空");
            LOGGER.info("参数错误，订单号为空");
        } else if (orderItemHSVo.getNum() <= 0) {
            remoteResult.setResultMsg("参数错误，商品数量为空");
            LOGGER.info("参数错误，商品数量为空orderId=" + orderItemHSVo.getOrderId());
        } else if (StringUtils.isEmpty(orderItemHSVo.getWareHouse())) {
            remoteResult.setResultMsg("参数错误，wareHouse为空");
            LOGGER.info("参数错误，wareHouse为空orderId=" + orderItemHSVo.getOrderId());
        } else if (orderItemHSVo.getStockType() == 1) {
            if (StringUtils.isEmpty(orderItemHSVo.getChannel())) {
                remoteResult.setResultMsg("参数错误，channel 为空");
                LOGGER.info("参数错误，channel 为空orderId=" + orderItemHSVo.getOrderId());
            } else if (StringUtils.isEmpty(orderItemHSVo.getBiztypecode())) {
                remoteResult.setResultMsg("参数错误，biztypecode 为空");
                LOGGER.info("参数错误，biztypecode 为空 orderId=" + orderItemHSVo.getOrderId());
            }
            remoteResult.setSuccess(true);
        } else {
            remoteResult.setSuccess(true);
        }
        return remoteResult;
    }

    @Override
    public RemoteResult<PageModel2<PayRecords>> queryDownlinePayList(DownlinePayListParam downlinePayParam) {
        return openOrderRemote.queryDownlinePayList(downlinePayParam);
    }

}
