package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

import java.util.Map;

/**
 * 支付宝交易查询Manager
 * Created by MengQiang on 2015/11/18.
 */
public interface AliPayTradeQueryManager{
    /**
     * 支付宝交易查询
     * @param payOrder
     * @return
     */
    public RemoteResult<Map<String, Object>> aliPayTradeQuery(PayOrder payOrder);
}
