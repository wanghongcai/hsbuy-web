package com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.domain.pay.PhoneRechargeForPay;
import com.lenovo.m2.hsbuy.domain.pay.soa.ChannelOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

import java.util.List;
import java.util.Map;

/**
 * 公共业务处理Manager
 * Created by MengQiang on 2016/2/22.
 */
public interface CommonManager {


    RemoteResult<List<ChannelOrder>> queryChannelOrderMainCodeList(List<String> orderMainCodeList, String lenovoId, String shopId);

    RemoteResult<ChannelOrder> queryChannelOrderMainCodeDetail(String orderMainCode, String lenovoId, String shopId);

    RemoteResult<Integer> updateChannelOrderMainCodeDetail(ChannelOrder channelOrder);

    RemoteResult<List<ChannelOrder>> queryChannelOrderCodeList(String orderMainCode, String lenovoId, int mainFlag, String shopId);

    RemoteResult<ChannelOrder> queryChannelOrderCodeDetail(String orderCode, String lenovoId, int mainFlag, String shopId);

    RemoteResult<ChannelOrder> querySmbChannelOrderDetail(String smbOrderCode, int mainFlag, String shopId);

    String getLedgerFAID(ChannelOrder channelOrder);

    String getLedgerFAID(PayPortalOrder payPortalOrder);

    RemoteResult<List<ChannelOrder>> queryOrderCodeList(List<String> orderCodeList, String lenovoId, int mainFlag, String shopId);

    RemoteResult<Integer> updateChannelOrderOrderStatus(int orderStatus, String orderCode, int mainFlag, String shopId);

    RemoteResult<List<PayOrder>> getPayOrderListByPayType(String orderCode, Integer payType);

    RemoteResult<String> savePayOrder(String lenovoId, String plat, String payType, String orderMainCode, String total_fee, String prodName, String fqRate, int fqNum, String fqCode, String merchantCode, String pay_bank, String shopId, String terminal, MerchantPayPlatView merchantPayPlatView, String currencyCode);
}
