package com.lenovo.m2.buy.promotion.admin.manager.commonManager.impl;

import com.lenovo.m2.arch.framework.domain.Tenant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.manager.commonManager.EppPromotionService;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.SalesGoodsPromotionRoles;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.SessionUser;
import com.lenovo.m2.buy.promotion.admin.soa.api.service.PromotionAdminWrite;
import com.lenovo.m2.buy.promotion.admin.soa.utils.BaseInfo;

@Service
public class EppPromotionServiceImpl implements EppPromotionService{  //TODO 弃用

	private static Logger log = LoggerFactory.getLogger(EppPromotionServiceImpl.class);

    @Autowired
    private PromotionAdminWrite promotionAdminWrite;


	@Override
    public BaseInfo update(Tenant tenant, SalesGoodsPromotionRoles role, String details, String groups, String groupName, SessionUser user){

        log.info("修改人itcode={},促销id={}", user.getItcode(), role.getId());
        RemoteResult<BaseInfo> remoteResult = promotionAdminWrite.eppUpdate(tenant, role, details, groups, groupName, user);
        return remoteResult.getT();

    }

}
