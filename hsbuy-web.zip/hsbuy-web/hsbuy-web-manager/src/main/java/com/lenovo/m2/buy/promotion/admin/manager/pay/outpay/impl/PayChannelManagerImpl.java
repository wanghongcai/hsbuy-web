package com.lenovo.m2.buy.promotion.admin.manager.pay.outpay.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.pay.baseinfo.soa.api.UserInfoService;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.LePayConstant;
import com.lenovo.m2.buy.promotion.admin.domain.pay.outpay.DirectBank;
import com.lenovo.m2.buy.promotion.admin.domain.pay.outpay.OutPayType;
import com.lenovo.m2.buy.promotion.admin.domain.pay.outpay.PayChannel;
import com.lenovo.m2.buy.promotion.admin.domain.pay.outpay.Points;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.PayPointRulesManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.CashierManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.outpay.PayChannelManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.BankCardLimitApi;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayPortalOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayPointRules;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.OrderSupportPayType;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.outpay.BankCardLimit;
import com.lenovo.points.client.MemPointsQueryClient;
import com.lenovo.points.vo.MemAccountMessage;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

/**
 * Created by tianchuyang on 2017/1/10.
 */
@Service
public class PayChannelManagerImpl implements PayChannelManager {

    private static final Logger logger = Logger.getLogger(PayChannelManagerImpl.class);

    @Autowired
    private CashierManager cashierManager;

    @Autowired
    private BankCardLimitApi bankCardLimitApi;

    @Autowired
    private PayPortalOrderApi payPortalOrderApi;

    @Autowired
    private PayPointRulesManager payPointRulesManager;

    private UserInfoService userInfoService;

    @Override
    public PayChannel getPayChannel(String faId, String shopId, BigDecimal billAmount, String accountType, String outTradeNo, String lenovoId) throws Exception {

        logger.info("请求参数列表. faId[" + faId + "]," + "billAmount[" + billAmount + "]" + "accountType[" + accountType + "], outTradeNo[" + outTradeNo + "], lenovoId [" + lenovoId + "]");
        PayChannel payChannel = new PayChannel();
        // 商户支持的支付方式
        List<OrderSupportPayType> orderSupportPayTypeList = null;
        // 商户返回的支付渠道
        List<OutPayType> outPayTypes = null;
        // 获取商户支持的支付方式
        RemoteResult<List<OrderSupportPayType>> orderSupportPayTypeResult = cashierManager.getOrderSupportPayTypeList(faId);
        logger.info("根据faid查询结果：orderSupportPayTypeResult=" + orderSupportPayTypeResult);
        // 商户无可支持的支付方式
        if (null == orderSupportPayTypeResult.getT() || orderSupportPayTypeResult.getT().size() == 0) {
            logger.info("商户没有可支持的支付渠道：orderSupportPayTypeResult=" + orderSupportPayTypeResult);
            // 商户无可支持的支付方式
            return this.getPayChannel(payChannel, false, "商户没有可支持的支付渠道!", null, null);
        }
        // shopId筛选
        orderSupportPayTypeList = orderSupportPayTypeResult.getT();
        Iterator<OrderSupportPayType> iterator = orderSupportPayTypeList.iterator();
        while (iterator.hasNext()) {
            OrderSupportPayType orderSupportPayType = iterator.next();
            if (null != orderSupportPayType.getShop_id() && !shopId.equals(orderSupportPayType.getShop_id()) ||
                    (null != orderSupportPayType.getAccountType() && !accountType.equals(orderSupportPayType.getAccountType()))) {
                iterator.remove();
            }
        }
        logger.info("根据shopId和accountType过滤之后：orderSupportPayTypeList=" + orderSupportPayTypeList);
        // 相同支付方式去重
        orderSupportPayTypeList= this.removeDuplicatePayType(orderSupportPayTypeList);
        logger.info("根据payType排重之后：newOrderSupportPayTypeList=" + orderSupportPayTypeList);
        if (null == orderSupportPayTypeList || orderSupportPayTypeList.size() == 0) {
            logger.info("商户没有可支持的支付渠道：newOrderSupportPayTypeList=" + orderSupportPayTypeList);
            return this.getPayChannel(payChannel, false, "商户没有可支持的支付渠道!", null, null);
        }

        outPayTypes = new ArrayList<OutPayType>();
        for (OrderSupportPayType orderSupportPayType : orderSupportPayTypeList) {
            logger.info("Invoke getPayChannel orderSupportPayType=" + orderSupportPayType);
            // 其他支付渠道
            List<DirectBank> directBankList = null;
            if (null == orderSupportPayType.getAccountType() || accountType.equals(String.valueOf(orderSupportPayType.getAccountType()))) {
                BankCardLimit bankCardLimitQo = null;
                RemoteResult<List<BankCardLimit>> bankCardLimits = null;
                if (LePayConstant.ACCOUNT_TYPE_B2B.equals(Integer.parseInt(accountType))){
                    bankCardLimitQo = new BankCardLimit(Integer.parseInt(orderSupportPayType.getPayType()),null,null,null,null,null);
                }else if (LePayConstant.ACCOUNT_TYPE_B2C.equals(Integer.parseInt(accountType))){       // 对私帐号收款  则只允许个人网银支付
                    bankCardLimitQo = new BankCardLimit(Integer.parseInt(orderSupportPayType.getPayType()),null,null,PeakConstant.BANK_TYPE_B2C,null,null);
                }else {
                    logger.info("The accountType is Other!");
                }
                if (null != bankCardLimitQo){
                    bankCardLimits = bankCardLimitApi.queryBankCardLimitByParams(bankCardLimitQo);
                    logger.info("获取网银列表!根据条件：bankCardLimitQo="+bankCardLimitQo+"，查询的数据结果："+bankCardLimits);
                    if (null != bankCardLimits.getT() && bankCardLimits.getT().size()>0){
                        directBankList = new ArrayList<DirectBank>();
                        for (BankCardLimit bankCardLimit : bankCardLimits.getT()) {
                            DirectBank directBank = new DirectBank(bankCardLimit.getBankType(),bankCardLimit.getBankCode(),bankCardLimit.getBankAbbr(),bankCardLimit.getCardType());
                            directBankList.add(directBank);
                        }
                        // 网银排序
                        Collections.sort(directBankList);
                    }
                }
            }
            OutPayType outPayType = new OutPayType(orderSupportPayType.getMerchantId(),orderSupportPayType.getPayType(),orderSupportPayType.getAccountType(),directBankList);
            logger.info("The accountType outPayType="+outPayType);
            outPayTypes.add(outPayType);
        }
        Points points = usePonitsResult(outTradeNo, lenovoId, faId, shopId);
        logger.info("The accountType outPayTypes="+outPayTypes+",points="+points);
        return this.getPayChannel(payChannel, true, "获取支付渠道成功!", outPayTypes, points);
    }

    //积分支付
    public Points usePonitsResult(String outTradeNo, String lenovoId, String faId, String shopId) {
        logger.info("HS  points pay start outTradeNo=[" + outTradeNo + "], lenovoId=[" + lenovoId + "], faId=[" + faId + "],shopId=[" + shopId + "]");
        Points points = new Points();

        RemoteResult<PayPointRules> payPointRulesRemoteResult = payPointRulesManager.getPayPointRulesByfaId(faId);
        PayPointRules payPointRules;
        if (payPointRulesRemoteResult.isSuccess() && PeakConstant.SHOPID_HUISHANG.equals(shopId)) {//可用
            payPointRules = payPointRulesRemoteResult.getT();
            MemPointsQueryClient memPointsQueryClient;
            MemAccountMessage memAccountMessage;
            Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
            RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderApi.queryPayPortalOrderByOutTradeNo(outTradeNo, lenovoId, tenant);
            logger.info("outTradeNo==="+outTradeNo+"lenovoId==="+lenovoId+"tenant==="+tenant);
            if (payPortalOrderRemoteResult.isSuccess()) {
                Integer rewardPoint = payPortalOrderRemoteResult.getT().getPoint();
                logger.info("rewardPoint-----"+rewardPoint);
                points.setUsedPoints(rewardPoint);//已使用积分
            }
            try {
                memPointsQueryClient = MemPointsQueryClient.getInstance();
                memAccountMessage = memPointsQueryClient.getMemAccount(lenovoId);
                Long availablePointsLong = memAccountMessage.getThisQuarterLef();
                logger.info("availablePointsLong=" + availablePointsLong + "],lenovoId=[" + lenovoId + "]");
                points.setAvailablePoints(availablePointsLong.intValue());

            } catch (Exception e) {
                logger.error("调用积分接口错误 经销商编码 =" + lenovoId, e);
                return points;
            }
            points.setPointRate(payPointRules.getPointRate());
            points.setPointStatus(1);
        }
        logger.info("points详细信息 " + points.toString());
        return points;
    }


    private ArrayList<OrderSupportPayType> removeDuplicatePayType(List<OrderSupportPayType> orderSupportPayTypes) {
        Set<OrderSupportPayType> set = new TreeSet<OrderSupportPayType>(new Comparator<OrderSupportPayType>() {
            @Override
            public int compare(OrderSupportPayType o1, OrderSupportPayType o2) {
                //字符串,则按照asicc码升序排列
                return o1.getPayType().compareTo(o2.getPayType());
            }
        });
        set.addAll(orderSupportPayTypes);
        return new ArrayList<OrderSupportPayType>(set);
    }

    public UserInfoService getUserInfoService() {
        return userInfoService;
    }
    public void setUserInfoService(UserInfoService userInfoService) {
        this.userInfoService = userInfoService;
    }
    private PayChannel getPayChannel(PayChannel payChannel, boolean success, String resultMessage, List<OutPayType> outPayTypes, Points points) {
        payChannel.setSuccess(success);
        payChannel.setResultMessage(resultMessage);
        payChannel.setPay_type_list(outPayTypes);
        payChannel.setPoints(points);
        return payChannel;
    }
}
