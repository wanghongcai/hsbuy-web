package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.impl;

import com.alibaba.fastjson.JSON;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.LePayUtil;
import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AliSimplePaltPayConfig;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayConfig;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipaySubmit;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.RSA;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.DateUtil;
import com.lenovo.m2.buy.promotion.admin.domain.pay.alipay.AliPayDirectWapModel;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayDirectWapManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonPayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.CashierManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.net.URLEncoder;
import java.util.*;

/**
 * 支付宝WAP直连
 * Created by MengQiang on 2016/9/1.
 */
@Service
public class AliPayDirectWapManagerImpl implements AliPayDirectWapManager {
    private final Logger LOGGER = Logger.getLogger(this.getClass());

    @Autowired
    private CommonPayManager commonPayManager;
    @Autowired
    private CommonCallBackManager commonCallBackManager;
    @Autowired
    private AliPayCommonManager aliPayCommonManager;
    @Autowired
    private CashierManager cashierManager;
    @Autowired
    private PayOrderApi payOrderApi;
    @Autowired
    private CommonManager commonManager;
    @Autowired
    private PayPortalOrderManager payPortalOrderManager;

    @Override
    public RemoteResult<String> toDirectWapPay(HttpServletRequest request) {
        RemoteResult<String> returnResult = new RemoteResult<String>();
        AliPayDirectWapModel aliPayDirectWapModel = (AliPayDirectWapModel) BaseModel.getModel(request);
        String orderMainCode = aliPayDirectWapModel.getOrderMainCode();
        String payType = aliPayDirectWapModel.getPayType();
        String plat = aliPayDirectWapModel.getPlat();
        String lenovoId = aliPayDirectWapModel.getLenovoId();
        String merchantCode = aliPayDirectWapModel.getMerchantCode();
        String shopId = aliPayDirectWapModel.getShopId();
        String terminal = aliPayDirectWapModel.getTerminal();
        String browser = aliPayDirectWapModel.getBrowser();

        // 外部支付流程
        Map<String, String> tradeMap = null;
        String accountType = null;
        if (PeakConstant.SHOPID_HUISHANG.equals(shopId)){
            String tradeInfo = request.getParameter("trade_info");
            try {
                tradeMap = LePayUtil.parseTradeInfo(tradeInfo);
                // 收款账户类型
                accountType = tradeMap.get("account_type");
            } catch (Exception e) {
                LOGGER.info("Parse TradeInfo error:",e);
                CommonMethod.getRemoteResult(returnResult, "", false, "400", "错误的支付请求参数");
                return returnResult;
            }
        }

        //TODO 待统一多租户
        if ("roaming".equals(merchantCode)) {
            orderMainCode = aliPayDirectWapModel.getOrderId();
            if(StringUtils.isEmpty(shopId)){
                LOGGER.info("Roaming Pay ShopId IS NULL, orderMainCode[" + orderMainCode + "]");
                shopId = CommonMethod.getShopIdFromPlat(plat);
            }else{
                LOGGER.info("Roaming Pay ShopId["+ shopId +"], orderMainCode[" + orderMainCode + "]");
            }
        }
        if (StringUtils.isEmpty(plat)) {
            plat = CommonMethod.getPlatFromShopIdTerminal(shopId, terminal);
        }
        LOGGER.info("HTTPS AliPay Direct Wap Pay Ready To Go! orderMainCode[" + orderMainCode + "],payType[" + payType + "],plat[" + plat + "],lenovoId[" + lenovoId + "],merchantCode[" + merchantCode + "],browser[" + browser + "],shopId[" + shopId + "],terminal[" + terminal + "]");
        Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult;
        if(PeakConstant.SHOPID_ROAMING.equals(shopId)){
            LOGGER.info("Invoke queryPayPortalOrderByShowTradeNo Get Roaming PayPortalOrder");
            payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByShowTradeNo(orderMainCode, lenovoId, tenant);
            orderMainCode = payPortalOrderRemoteResult.getT().getOutTradeNo();
        }else{
            LOGGER.info("Invoke queryPayPortalOrderByOutTradeNo Get PayPortalOrder");
            payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(orderMainCode, lenovoId, tenant);
        }
        PayPortalOrder payPortalOrder;
        if (payPortalOrderRemoteResult.isSuccess()) {
            payPortalOrder = payPortalOrderRemoteResult.getT();
            if (payPortalOrder == null || payPortalOrder.getOutTradeNo() == null) {
                LOGGER.info("Invoke queryChannelOrderCodeDetail Get PayPortalOrder IS NULL，orderMainCode [" + orderMainCode + "]");
                CommonMethod.getRemoteResult(returnResult, "", false, "400", "未查到订单信息");
                return returnResult;
            }
        } else {
            LOGGER.info("Invoke queryChannelOrderCodeDetail Get PayPortalOrder IS NULL，orderMainCode [" + orderMainCode + "]");
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "未查到订单信息");
            return returnResult;
        }
        if ("1".equals(payPortalOrder.getPaymentWay())) {
            commonManager.getLedgerFAID(payPortalOrder);
        }
        RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult;
        MerchantPayPlatView merchantPayPlatView;
        try {
            if (PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(payPortalOrder.getPayStatus()))) {
                LOGGER.info("Check PayPortalOrder Already PAY, OrderMainCode [" + orderMainCode + "]");
                CommonMethod.getRemoteResult(returnResult, "", false, "400", "订单已支付，请到订单列表页确认");
                return returnResult;
            }
            if (PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(payPortalOrder.getOrderStatus()))) {
                LOGGER.info("Check PayPortalOrder OrderStatus FAIL, OrderMainCode [" + orderMainCode + "]");
                CommonMethod.getRemoteResult(returnResult, "", false, "400", "订单已失效，请到订单列表页确认");
                return returnResult;
            }
            if (StringUtils.isEmpty(accountType)){
                 merchantPayPlatViewRemoteResult = commonPayManager.getMerchantPayPlat(payPortalOrder.getFaId(), payType);
            }else {
                merchantPayPlatViewRemoteResult = commonPayManager.getMerchantPayPlatByAccountType(payPortalOrder.getFaId(), payType, Integer.parseInt(accountType));
            }
            if (merchantPayPlatViewRemoteResult != null && merchantPayPlatViewRemoteResult.isSuccess()) {
                merchantPayPlatView = merchantPayPlatViewRemoteResult.getT();
                LOGGER.info("MerchantPayPlat INFO [" + merchantPayPlatView + "]");
            } else {
                LOGGER.info("Get MerchantPayPlat FAIL，OrderMainCode [" + orderMainCode + "]");
                CommonMethod.getRemoteResult(returnResult, "", false, "400", "查询支付平台信息失败");
                return returnResult;
            }
        } catch (Exception e) {
            LOGGER.error("支付宝WAP支付异常" + e);
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "支付异常");
            return returnResult;
        }
        String productName = CommonMethod.getProductName(payPortalOrder.getSubject());
        LOGGER.info("Product Name [" + productName + "]");
        String currencyCode = payPortalOrder.getCurrencyCode();
        String bodyHtml;
        try {
            String orderPrimaryId;
            RemoteResult<String> savePayOrderResult;
            RemoteResult<List<PayOrder>> orderListResult = aliPayCommonManager.getOrderListByPayType(orderMainCode, Integer.parseInt(payType));
            if (orderListResult.isSuccess() && orderListResult.getT().size() > 0) {
                orderPrimaryId = String.valueOf(orderListResult.getT().get(0).getId());
                LOGGER.info("AliPay Direct Wap Pay PayOrder Already EXIST，OrderPrimaryID [" + orderPrimaryId + "]");
            } else {
                savePayOrderResult = commonManager.savePayOrder(lenovoId, plat, payType, orderMainCode, String.valueOf(payPortalOrder.getTotalFee().getAmount()), productName, "", 0, "", merchantCode, "", shopId, terminal, merchantPayPlatView,currencyCode);
                if (!savePayOrderResult.isSuccess()) {
                    LOGGER.warn("Save PayOrder FAIL, OrderMainCode [" + orderMainCode + "]");
                    CommonMethod.getRemoteResult(returnResult, "", false, "400", "保存订单信息失败");
                    return returnResult;
                }
                LOGGER.info("Save PayOrder SUCCESS, OrderMainCode [" + orderMainCode + "]");
                orderPrimaryId = savePayOrderResult.getT();
                LOGGER.info("AliPay Direct Wap Pay PayOrder NOT EXIST, New OrderPrimaryID [" + orderPrimaryId + "]");
            }
            // 扩展参数
            Map<String, Object> paraMap = new HashMap<String, Object>();
            if ("micromessenger".equals(browser)) {
                bodyHtml = this.buildWeChatAliPayHtml(orderPrimaryId, productName, payPortalOrder, merchantPayPlatView, paraMap);
            } else if (PeakConstant.SHOPID_LENOVO.equals(shopId) && PeakConstant.TERMINAL_APP.equals(terminal) && PeakConstant.PAY_TYPE_ALSJ.equals(payType) && AliSimplePaltPayConfig.partner.equals(merchantPayPlatView.getMechId())) {
                bodyHtml = this.buildSimplePlatHtml(orderPrimaryId, productName, payPortalOrder, merchantPayPlatView, paraMap);
            } else {
                bodyHtml = this.buildDirectWapHtml(orderPrimaryId, productName, payPortalOrder, merchantPayPlatView, paraMap);
                bodyHtml = "<html>" + "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>支付宝WAP</title></head>" + "<body>"
                        + bodyHtml + "</body></html>";
            }
        } catch (Exception e) {
            LOGGER.error("保存订单或构建HTML表单异常", e);
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "支付平台处理订单信息异常");
            return returnResult;
        }
        LOGGER.info("AliPay Direct Wap HTML [" + bodyHtml + "]");
        if (StringUtils.isNotEmpty(bodyHtml)) {
            CommonMethod.getRemoteResult(returnResult, bodyHtml, true, "100", "");
            return returnResult;
        } else {
            CommonMethod.getRemoteResult(returnResult, "", false, "400", "构建请求HTML失败");
            return returnResult;
        }
    }

    //TODO Wechat Alipay
    private String buildWeChatAliPayHtml(String orderPrimaryId, String productName, PayPortalOrder payPortalOrder, MerchantPayPlatView merchantPayPlatView, Map<String, Object> paraMap) {
        LOGGER.info("Invoke buildWechatAlipayHtml OrderPrimaryId[" + orderPrimaryId + "],ProductName[" + productName + "],PayPortalOrder[" + payPortalOrder + "],merchantPayPlatView[" + merchantPayPlatView + "],ParaMap[" + paraMap + "]");
        Map<String, String> postMap = new HashMap<String, String>();
        postMap.put("service", "alipay.wap.create.direct.pay.by.user");
        postMap.put("partner", merchantPayPlatView.getMechId());
        postMap.put("_input_charset", AlipayConfig.input_charset);
        postMap.put("notify_url", merchantPayPlatView.getOutNotifyUrl());
        postMap.put("return_url", merchantPayPlatView.getOutCallBackUrl());
        postMap.put("out_trade_no", orderPrimaryId);
        postMap.put("subject", productName);
        postMap.put("total_fee", String.valueOf(payPortalOrder.getTotalFee().getAmount()));
        postMap.put("seller_id", merchantPayPlatView.getMechId());
        postMap.put("seller_email", merchantPayPlatView.getAppId());
        postMap.put("payment_type", "1");

        String bodyHtml = AlipaySubmit.wxHbBuildRequest(postMap, merchantPayPlatView.getSignKey());
        return bodyHtml;
    }

    //TODO Simple Plat
    private String buildSimplePlatHtml(String orderPrimaryId, String productName, PayPortalOrder payPortalOrder, MerchantPayPlatView merchantPayPlatView, Map<String, Object> paraMap) {
        LOGGER.info("Invoke buildSimplePlatHtml OrderPrimaryId[" + orderPrimaryId + "],ProductName[" + productName + "],PayPortalOrder[" + payPortalOrder + "],merchantPayPlatView[" + merchantPayPlatView + "],ParaMap[" + paraMap + "]");
        String notify_url = merchantPayPlatView.getOutNotifyUrl();
        notify_url = notify_url.substring(0, notify_url.indexOf(".jhtm")) + "/simplePlatNotify.jhtm";
        String return_url = merchantPayPlatView.getOutCallBackUrl();
        return_url = return_url.substring(0, return_url.indexOf(".jhtm")) + "/simplePlatReturn.jhtm";
        String orderInfo = "partner=" + "\"" + AliSimplePaltPayConfig.partner + "\"";
        orderInfo += "&seller_id=" + "\"" + AliSimplePaltPayConfig.seller + "\"";
        orderInfo += "&out_trade_no=" + "\"" + orderPrimaryId + "\"";
        orderInfo += "&subject=" + "\"" + productName + "\"";
        orderInfo += "&body=" + "\"" + productName + "\"";
        orderInfo += "&total_fee=" + "\"" + payPortalOrder.getTotalFee().getAmount() + "\"";
        orderInfo += "&notify_url=" + "\"" + notify_url + "\"";
        orderInfo += "&service=\"mobile.securitypay.pay\"";
        orderInfo += "&payment_type=\"1\"";
        orderInfo += "&_input_charset=\"utf-8\"";
//        orderInfo += "&it_b_pay=\"1d\"";
        orderInfo += "&return_url=" + "\"" + return_url + "\"";
        String sign = RSA.sign(orderInfo, AliSimplePaltPayConfig.private_key_pkcs8, AliSimplePaltPayConfig.input_charset);
        try {
            sign = URLEncoder.encode(sign, AliSimplePaltPayConfig.input_charset);
        } catch (Exception e) {
            LOGGER.info("极简收银台转码失败！", e);
            return "";
        }
        String linkString = orderInfo + "&sign=\"" + sign + "\"&sign_type=\"" + AliSimplePaltPayConfig.sign_type + "\"";
        LOGGER.info("SimplePlat Param[" + linkString + "]");
        return linkString;
    }

    //TODO Direct Wap
    private String buildDirectWapHtml(String orderPrimaryId, String productName, PayPortalOrder payPortalOrder, MerchantPayPlatView merchantPayPlatView, Map<String, Object> paraMap) {
        LOGGER.info("Invoke buildDirectWapHtml OrderPrimaryId[" + orderPrimaryId + "],ProductName[" + productName + "],PayPortalOrder[" + payPortalOrder + "],merchantPayPlatView[" + merchantPayPlatView + "],ParaMap[" + paraMap + "]");
        Map<String, String> postMap = new HashMap<String, String>();
        postMap.put("service", "alipay.wap.create.direct.pay.by.user");
        postMap.put("partner", merchantPayPlatView.getMechId());
        postMap.put("_input_charset", AlipayConfig.input_charset);
        postMap.put("notify_url", merchantPayPlatView.getOutNotifyUrl());
        if (PeakConstant.SHOPID_ROAMING.equals(payPortalOrder.getShopId())) {
            LOGGER.info("Roaming Order ReturnURL is NULL");
        } else {
            postMap.put("return_url", merchantPayPlatView.getOutCallBackUrl());
        }
        postMap.put("out_trade_no", orderPrimaryId);
        postMap.put("subject", productName);
        postMap.put("total_fee", String.valueOf(payPortalOrder.getTotalFee().getAmount()));
        postMap.put("seller_id", merchantPayPlatView.getMechId());
        postMap.put("seller_email", merchantPayPlatView.getAppId());
        postMap.put("payment_type", "1");

        String bodyHtml = AlipaySubmit.buildRequest(postMap, "get", "确认", merchantPayPlatView.getSignKey());
        return bodyHtml;
    }

    @Override
    public RemoteResult<String> callUpdate(PayOrder payOrder, MerchantPayPlatView merchantPayPlatView, String gmtPayment, String tradeNo, String notifyId, String outChannelType, String outChannelAmount) {
        RemoteResult<String> returnResult = new RemoteResult<String>();
        if (this.checkStatus(payOrder)) {
            LOGGER.info("订单已支付，流水号==>" + payOrder.getId());
            returnResult.setSuccess(true);
            returnResult.setResultMsg("SUCCESS");
            return returnResult;
        } else {
            try {
                commonCallBackManager.updatePayNotifyState(payOrder.getId(), payOrder.getU_id(), tradeNo, PeakConstant.MFLAG_REPEAT, notifyId, PeakConstant.TRADE_SUCCESS, "", Integer.parseInt(PeakConstant.PAY_TYPE_ALSJ));
                LOGGER.info("Call Update PayOrder, OrderPrimaryId[" + payOrder.getId() + "],TransactionId[" + tradeNo + "]");
            } catch (Exception payOrderException) {
                LOGGER.info("Call Update PayOrder Exception, OrderPrimaryId[" + payOrder.getId() + "]", payOrderException);
            }
            try {
                PayPortalOrder updatePayPortalOrder = CommonMethod.buildUpdatePayPortalOrder(String.valueOf(payOrder.getId()), payOrder.getOut_trade_no(), payOrder.getU_id(), Integer.parseInt(PeakConstant.PAY_TYPE_ALSJ), PeakConstant.PAY_STATUS_ALREADY_PAID, payOrder.getShop_id() ,new Date());
                RemoteResult<Integer> updatePayPortalOrderResult = payPortalOrderManager.updatePayPortalOrderPayStatus(updatePayPortalOrder);
                if (updatePayPortalOrderResult.isSuccess()) {
                    LOGGER.info("Update PayPortalOrder SUCCESS，outTradeNo[" + payOrder.getOut_trade_no() + "]");
                } else {
                    LOGGER.info("Update PayPortalOrder FAIL，outTradeNo[" + payOrder.getOut_trade_no() + "]");
                }
            } catch (Exception channelOrderException) {
                LOGGER.info("Call Update ChannelOrder Exception, OrderPrimaryId[" + payOrder.getId() + "]", channelOrderException);
            }
            try {
                payOrder.setTransation_id(tradeNo);
                String payTime = DateUtil.formatDate(new Date(), PeakConstant.CALL_MIDDLEWARE_PAY_TYPE);
                Map<String, String> paraMap = new HashMap<String, String>();
                if(StringUtils.isNotEmpty(outChannelType) && StringUtils.isNotEmpty(outChannelAmount)){
                    String[] channelTypeArray = outChannelType.split("\\|");
                    String[] channelAmountArray = outChannelAmount.split("\\|");
                    if(channelTypeArray != null && channelTypeArray.length > 0 && channelAmountArray != null && channelAmountArray.length > 0){
                        for(int i = 0 ; i< channelTypeArray.length ; i++){
                            String channelType = channelTypeArray[i];
                            String channelAmount = channelAmountArray[i];
                            LOGGER.info("AliPayDirectWap Pay ChannelType[" + channelType + "],ChannelAmount[" + channelAmount + "]");
                            if("RT_DISCOUNT".equals(channelType)){
                                LOGGER.info("GO RT_DISCOUNT");
                                paraMap.put("RT_DISCOUNT", channelType);
                                paraMap.put("RT_DISCOUNTAMOUNT", channelAmount);
                            }
                        }
                    }
                }
                paraMap.put("payTime", payTime);
                paraMap.put("payment", PeakConstant.PAYMENT_ALI);
                Tenant tenant = CommonMethod.buildTenant(payOrder.getShop_id(), null, null, null, null, null, null);
                RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(payOrder.getOut_trade_no(), payOrder.getU_id(), tenant);
                if (payPortalOrderRemoteResult.isSuccess()) {
                    PayPortalOrder payPortalOrder = payPortalOrderRemoteResult.getT();
                    RemoteResult<String> remoteResult = commonCallBackManager.paidCallback(payPortalOrder, payOrder, merchantPayPlatView, paraMap);
                    if (remoteResult.isSuccess()) {
                        returnResult.setSuccess(true);
                        commonCallBackManager.updatePayNotifyState(payOrder.getId(), payOrder.getU_id(), tradeNo, PeakConstant.MFLAG_SUCC, notifyId, PeakConstant.TRADE_SUCCESS, "", Integer.parseInt(PeakConstant.PAY_TYPE_ALSJ));
                        LOGGER.info("AliPay DirectWAP Call MiddleWare SUCCESS, OrderPrimaryId[" + payOrder.getId() + "]");
                    } else {
                        returnResult.setSuccess(false);
                        LOGGER.info("AliPay DirectWAP Call MiddleWare FAIL, OrderPrimaryId[" + payOrder.getId() + "]");
                    }
                } else {
                    returnResult.setSuccess(false);
                    LOGGER.info("Get ChannelOrder FAIL, OrderPrimaryId[" + payOrder.getId() + "]");
                }
            } catch (Exception middleWareException) {
                returnResult.setSuccess(false);
                LOGGER.info("Call MiddleWare FAIL, OrderPrimaryId[" + payOrder.getId() + "]");
            }
        }
        return returnResult;
    }

    /**
     * 校验订单状态，防止重复通知
     *
     * @param payOrder payOrder
     * @return boolean
     */
    private boolean checkStatus(PayOrder payOrder) {
        boolean flag = false;
        if (null != payOrder.getMerchant_flag() && null != payOrder.getTrade_state() && payOrder.getMerchant_flag() == 1 && payOrder.getTrade_state() == 1) {
            flag = true;
        }
        return flag;
    }
}
