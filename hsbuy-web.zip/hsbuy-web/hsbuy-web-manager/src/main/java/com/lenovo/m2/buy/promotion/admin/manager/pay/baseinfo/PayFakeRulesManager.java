package com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayFakeRules;

import java.util.List;
import java.util.Map;

/**
 * Created by mengqiang1 on 2016/5/6.
 */
public interface PayFakeRulesManager {

    /**
     * 保存假支付规则
     * @param payFake
     * @return
     */
    public RemoteResult<Map<String,Integer>> pushFakePay(PayFakeRules payFake) throws Exception;

    /**
     * 修改假支付规则
     * @param payFake
     * @return
     */
    public RemoteResult<Map<String,Integer>> updateFakePay(PayFakeRules payFake);

    /**
     * 根据lenovoId获取假支付规则（lenovoId为空时查询所有）
     * @param lenovoId
     * @return
     */
    public RemoteResult<List<PayFakeRules>> queryFakePayList(String lenovoId);
}
