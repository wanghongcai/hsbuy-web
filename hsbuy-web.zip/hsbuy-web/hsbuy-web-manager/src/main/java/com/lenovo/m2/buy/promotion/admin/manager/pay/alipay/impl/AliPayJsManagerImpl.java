package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.impl;

import com.alibaba.fastjson.JSON;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.framework.manager.impl.GenericManagerImpl;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.LePayUtil;
import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.ReturnCode;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayConfig;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipaySubmit;
import com.lenovo.m2.buy.promotion.admin.domain.pay.alipay.AliPayJsModel;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayJsManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonPayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import com.lenovo.m2.hsbuy.service.pay.soa.MerchantPayPlatService;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 支付宝即时支付业务处理
 * Modify By MengQiang 2016年2月23日17:55:15
 */
@Service
public class AliPayJsManagerImpl extends GenericManagerImpl<PayOrder, Long> implements AliPayJsManager {

    private final Logger logger = Logger.getLogger(AliPayJsManagerImpl.class);

    @Autowired
    private CommonPayManager commonPayManager;
    @Autowired
    private AliPayCommonManager aliPayCommonManager;
    @Autowired
    private MerchantPayPlatService merchantPayPlatService;
    @Autowired
    private PayOrderApi payOrderApi;
    @Autowired
    private CommonCallBackManager commonCallBackManager;
    @Autowired
    private CommonManager commonManager;
    @Autowired
    private PayPortalOrderManager payPortalOrderManager;

    private String homeUrl;

    public RemoteResult toAliJsPay(HttpServletRequest request) {
        RemoteResult<String> returnResult = new RemoteResult<String>();
        returnResult.setSuccess(true);
        AliPayJsModel model = (AliPayJsModel) BaseModel.getModel(request);
        String orderMainCode = model.getOrderMainCode();
        String merchantCode = model.getMerchantCode();
        String payType = model.getPayType();
        String lenovoId = model.getLenovoId();
        String plat = model.getPlat();
        String shopId = model.getShopId();
        String terminal = model.getTerminal();
        if (StringUtils.isEmpty(plat)) {
            plat = CommonMethod.getPlatFromShopIdTerminal(shopId, terminal);
        }
        String qrPayMode = model.getQrPayMode();
        logger.info("支付宝即时支付!orderMaincode[" + orderMainCode + "],merchantCode[" + merchantCode + "],payType[" + payType + "],lenovoId[" + lenovoId + "],plat[" + plat + "],shopId[" + shopId + "],terminal[" + terminal + "],qrPayMode[" + qrPayMode + "]");
        if (checkQrPayModeValue(qrPayMode)) {
            logger.warn("支付宝支付扫码类型错误");
            returnResult.setSuccess(false);
            returnResult.setResultCode("30008");
            returnResult.setResultMsg("支付宝支付扫码类型错误");
            return returnResult;
        }
        Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(orderMainCode, lenovoId, tenant);
        PayPortalOrder payPortalOrder;
        if (payPortalOrderRemoteResult.isSuccess()) {
            payPortalOrder = payPortalOrderRemoteResult.getT();
            if (payPortalOrder == null || payPortalOrder.getOutTradeNo() == null) {
                logger.error("Alipay Direct Pay Get PayPortalOrder Fail, OrderMainCode[" + orderMainCode + "]");
                returnResult.setSuccess(false);
                returnResult.setResultCode("400");
                returnResult.setResultMsg("未查到订单信息，请重新发起支付");
                return returnResult;
            }
        }else{
            logger.error("Alipay Direct Pay Get ChannelOrder Fail, OrderMainCode[" + orderMainCode + "]");
            returnResult.setSuccess(false);
            returnResult.setResultCode("400");
            returnResult.setResultMsg("未查到订单信息，请重新发起支付");
            return returnResult;
        }
        if ("1".equals(payPortalOrder.getPaymentWay())) {
            commonManager.getLedgerFAID(payPortalOrder);
        }
        RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult;
        MerchantPayPlatView merchantPayPlatView = null;
        try {
            if (PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(payPortalOrder.getPayStatus()))) {
                logger.error("订单已支付，订单号[" + orderMainCode + "]");
                returnResult.setSuccess(false);
                returnResult.setResultCode("400");
                returnResult.setResultMsg("订单已支付，请到订单列表页确认。");
                return returnResult;
            }
            if (PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(payPortalOrder.getOrderStatus()))) {
                logger.error("主订单已失效，订单号[" + orderMainCode + "]");
                returnResult.setSuccess(false);
                returnResult.setResultCode("400");
                returnResult.setResultMsg("订单已失效，请到订单列表页确认");
                return returnResult;
            }
            merchantPayPlatViewRemoteResult = commonPayManager.getMerchantPayPlat(payPortalOrder.getFaId(), payType);
            if (merchantPayPlatViewRemoteResult != null && merchantPayPlatViewRemoteResult.isSuccess()) {
                merchantPayPlatView = merchantPayPlatViewRemoteResult.getT();
                logger.info("MerchantPayPlatView[" + merchantPayPlatView + "],OrderMainCode[" + orderMainCode + "]");
            } else {
                logger.error("查询支付平台信息失败，订单号[" + orderMainCode + "]");
                returnResult.setSuccess(false);
                returnResult.setResultCode("400");
                returnResult.setResultMsg("查询支付平台信息失败");
                return returnResult;
            }
        } catch (Exception e) {
            logger.error("支付宝即时支付异常" + e);
            returnResult.setSuccess(false);
            returnResult.setResultCode("400");
            returnResult.setResultMsg("支付异常");
        }
        StringBuffer commonParamBuffer = new StringBuffer();
        commonParamBuffer.append("faid=" + payPortalOrder.getFaId() + ",");
        commonParamBuffer.append("payType=" + payType + ",");
        commonParamBuffer.append("lenovoId=" + lenovoId);
        String extra_common_param = "";
        try {
            extra_common_param = URLEncoder.encode(commonParamBuffer.toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            logger.info("支付宝回传数据Encode异常");
        }
        logger.info("AliPay Direct Pay Extra_Common_Param[" + extra_common_param + "]");
        //支付金额,单位（元）
        String totalFee = String.valueOf(payPortalOrder.getTotalFee().getAmount());
        String currencyCode = payPortalOrder.getCurrencyCode();
        String prodName = CommonMethod.getProductName(payPortalOrder.getSubject());
        if (PeakConstant.SHOPID_MOTO.equals(shopId) && "LenovoProduct".equals(prodName)) {
            prodName = "MotorolaProduct";
        } else if (PeakConstant.SHOPID_DONGDE.equals(shopId) && "LenovoProduct".equals(prodName)) {
            prodName = "DongDeProduct";
        }
        String body = payPortalOrder.getSubject();
        String orderPrimaryId;
        RemoteResult<List<PayOrder>> orderListResult = new RemoteResult<List<PayOrder>>();
        try {
            orderListResult = aliPayCommonManager.getOrderListByPayType(orderMainCode, Integer.parseInt(payType));
        } catch (Exception e) {
            logger.error("Check AliPay DirectPay PayOrder Exist FAIL，OrderMainCode[" + orderMainCode + "]");
        }
        if (StringUtils.isEmpty(lenovoId)){
            lenovoId = payPortalOrder.getLenovoId();
        }
        if (orderListResult != null && orderListResult.isSuccess() && orderListResult.getT().size() > 0) {
            orderPrimaryId = String.valueOf(orderListResult.getT().get(0).getId());
            logger.info("Check AliPay DirectPay PayOrder ALREADY EXIST ,orderPrimaryId[" + orderPrimaryId + "]");
        } else {
            RemoteResult<String> savePayOrderResult = commonManager.savePayOrder(lenovoId, plat, payType, orderMainCode, totalFee, prodName, "", 0, "", merchantCode, "", shopId, terminal, merchantPayPlatView,currencyCode);
            if (!savePayOrderResult.isSuccess()) {
                logger.warn("Save AliPay PayOrder FAIL");
                returnResult.setSuccess(false);
                returnResult.setResultCode("30004");
                returnResult.setResultMsg("保存订单信息失败");
                return returnResult;
            }
            orderPrimaryId = savePayOrderResult.getT();
            logger.info("Save AliPay DirectPay Pay PayOrder SUCCESS, orderPrimaryId[" + orderPrimaryId + "]");
        }
        if (PeakConstant.SHOPID_MOTO.equals(shopId)) {
            logger.info("适配摩托罗拉用商城订单号支付");
            orderPrimaryId = orderMainCode;
        }
        try {
            String bodyHtml = this.getPsnPcHtmlNew(qrPayMode, plat, orderPrimaryId, prodName, totalFee, extra_common_param, merchantPayPlatView, orderMainCode, lenovoId, body, shopId, terminal);
//            logger.info(bodyHtml);
            bodyHtml = "<html>" + "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>支付宝订单请求</title></head>" + "<body>"
                    + bodyHtml + "</body></html>";
            returnResult.setT(bodyHtml);
            if (StringUtils.isEmpty(bodyHtml)) {
                returnResult.setSuccess(false);
                returnResult.setResultMsg("处理支付宝即时支付失败");
                logger.info("构建支付HTML失败");
            }
        } catch (Exception ex) {
            returnResult.setSuccess(false);
            returnResult.setResultMsg("网络异常，请刷新！！");
            logger.error("保存订单失败或构建HTML失败" + ex);
        }
        return returnResult;
    }


    //add by zhangqy10
    private String getPsnPcHtmlNew(String qrPayMode, String plat, String orderPrimaryId, String prodName, String _total_fee,
                                   String extra_common_param, MerchantPayPlatView merchantPayPlatView,
                                   String orderMaincode, String lenovoId, String body, String shopId, String terminal) {
        Map<String, String> sParaTemp = new HashMap<String, String>();
        String callBackUrl = merchantPayPlatView.getOutCallBackUrl();
        String payment_type = "1";
        sParaTemp.put("service", "create_direct_pay_by_user");
        sParaTemp.put("partner", merchantPayPlatView.getMechId());
        sParaTemp.put("_input_charset", AlipayConfig.input_charset);
        sParaTemp.put("payment_type", payment_type);
        //TODO 增加互联网专区适配
        String notifyUrl = CommonMethod.getHlwzqUrl(merchantPayPlatView.getOutNotifyUrl());
        sParaTemp.put("notify_url", notifyUrl);
        sParaTemp.put("seller_email", merchantPayPlatView.getAppId());
        sParaTemp.put("out_trade_no", orderPrimaryId);
        sParaTemp.put("subject", prodName);
        sParaTemp.put("total_fee", _total_fee);
        String subject = LePayUtil.replaceSpecStr(body);
        if (subject.length() > 60) {
            subject = subject.substring(0,60);
        }
        sParaTemp.put("body", subject);
        sParaTemp.put("extra_common_param", extra_common_param);
        if (StringUtils.isNotEmpty(qrPayMode)) {
            if(PeakConstant.QRPAYMODE_FIVE.equals(qrPayMode)){
                sParaTemp.put("qr_pay_mode", PeakConstant.QRPAYMODE_FOUR);
                sParaTemp.put("qrcode_width", "100");
            }else if(PeakConstant.QRPAYMODE_SIX.equals(qrPayMode)){
                sParaTemp.put("qr_pay_mode", PeakConstant.QRPAYMODE_FOUR);
                sParaTemp.put("qrcode_width", "150");
            }else if(PeakConstant.QRPAYMODE_SEVEN.equals(qrPayMode)){
                sParaTemp.put("qr_pay_mode", PeakConstant.QRPAYMODE_FOUR);
                sParaTemp.put("qrcode_width", "200");
            }else if(PeakConstant.QRPAYMODE_EIGHT.equals(qrPayMode)){
                sParaTemp.put("qr_pay_mode", PeakConstant.QRPAYMODE_FOUR);
                sParaTemp.put("qrcode_width", "300");
            }else{
                sParaTemp.put("qr_pay_mode", qrPayMode);
            }
            if(PeakConstant.SHOPID_LENOVO.equals(shopId) || PeakConstant.SHOPID_EPP.equals(shopId) || PeakConstant.SHOPID_THINK.equals(shopId)
                    || PeakConstant.SHOPID_SMB.equals(shopId)){
                logger.info("Go Inner AliPay QrCode Return [scanCodeCallBack]");
                sParaTemp.put("return_url", homeUrl + "/scanCodeCallBack.html?orderMainCode=" + orderMaincode + "&lenovoId=" + lenovoId + "&plat=" + plat + "&orderPrimaryId=" + orderPrimaryId + "&shopId=" + shopId + "&terminal=" + terminal);
            }else{
                logger.info("Go Outer AliPay QrCode Return [outAliPayQRCodeReturn]");
                sParaTemp.put("return_url", homeUrl + "/outAliPayQRCodeReturn.html");
            }
        } else {
            sParaTemp.put("return_url", callBackUrl);
        }
        String sHtmlText = AlipaySubmit.buildRequest(sParaTemp, "get", "确认", merchantPayPlatView.getSignKey());
        return sHtmlText;
    }

    @Override
    public RemoteResult<String> callUpdate(String lenovoId, String payTransactionId, String trade_no, String gmt_payment, String faid, String payType, MerchantPayPlatView merchantPayPlatView, String notifyId, String buyer_email) {
        RemoteResult<String> result = new RemoteResult<String>();
        boolean flag = aliPayCommonManager.checkStatus(payTransactionId);
        PayOrder payOrder;
        if (!flag) {
            if (payTransactionId.trim().length() == 10) {
                payOrder = payOrderApi.getPayOrderByPrimaryId(Long.valueOf(payTransactionId));
            } else {
                payOrder = payOrderApi.getPayOrderById(payTransactionId);
                payTransactionId = payOrder.getId().toString();
            }
            String outTradeNo = payOrder.getOut_trade_no();
            PayPortalOrder updatePayPortalOrder = CommonMethod.buildUpdatePayPortalOrder(payTransactionId, outTradeNo, lenovoId, Integer.parseInt(payType), PeakConstant.PAY_STATUS_ALREADY_PAID, payOrder.getShop_id() ,new Date());
            payOrderApi.updateAliPayNotifyState(payTransactionId, lenovoId, trade_no, PeakConstant.MFLAG_REPEAT, notifyId, PeakConstant.TRADE_SUCCESS, null, Integer.parseInt(payType));
            try {
                RemoteResult<Integer> updatePayPortalOrderResult = payPortalOrderManager.updatePayPortalOrderPayStatus(updatePayPortalOrder);
                if (updatePayPortalOrderResult.isSuccess()) {
                    logger.info("Update PayPortalOrder SUCCESS，outTradeNo[" + outTradeNo + "]");
                } else {
                    logger.info("Update PayPortalOrder FAIL，outTradeNo[" + outTradeNo + "]");
                }
            } catch (Exception e) {
                logger.info("更新渠道订单失败 ，订单号==>" + outTradeNo, e);
            }
            try {
                String signature = buyer_email;
                String updateOrder = "payTransactionId=" + payTransactionId + "&outTradeNo=" + outTradeNo + "&trade_no=" + trade_no + "&gmt_payment=" + gmt_payment + "&payment=" + payType + "&lenovoId=" + lenovoId + "&signature=" + signature;
                logger.warn("即时支付更新订单请求==>" + updateOrder);
                RemoteResult<String> remoteResult = commonCallBackManager.payCallback(merchantPayPlatView, payOrder.getOs(), signature, payOrder.getOut_trade_no(), trade_no, gmt_payment, payType, lenovoId, payOrder.getId().toString(), payOrder);
                logger.warn("更新订单状态返回结果：" + JSON.toJSONString(remoteResult));
                if (remoteResult.isSuccess()) {
                    payOrderApi.updateAliPayNotifyState(payTransactionId, lenovoId, trade_no, PeakConstant.MFLAG_SUCC, notifyId, PeakConstant.TRADE_SUCCESS, null, Integer.parseInt(payType));
                    result.setSuccess(true);
                } else {
                    logger.info("更新订单异常");
                    int tryNumber = 0;
                    Boolean isSuccess = true;
                    while (isSuccess && tryNumber < 3) {
                        RemoteResult<String> remoteResult2 = commonCallBackManager.payCallback(merchantPayPlatView, payOrder.getOs(), signature, payOrder.getOut_trade_no(), trade_no, gmt_payment, payType, lenovoId, payOrder.getId().toString(), payOrder);
                        logger.warn("更新订单状态返回结果：" + JSON.toJSONString(remoteResult));
                        isSuccess = !remoteResult2.isSuccess();
                        tryNumber++;
                    }
                }
            } catch (Exception e) {
                result.setSuccess(false);
                result.setResultCode(ReturnCode.InNotifyFail.getCode());
                result.setResultMsg(ReturnCode.InNotifyFail.getMessage());
                logger.error("Excep--->" + e.getMessage());
                payOrderApi.updateAliPayNotifyState(payTransactionId, lenovoId, trade_no, PeakConstant.MFLAG_REPEAT, notifyId, PeakConstant.TRADE_SUCCESS, null, Integer.parseInt(payType));
            }
        } else {
            result.setSuccess(true);
        }
        return result;
    }



    /**
     * 校验取值是否异常，异常返true
     * @param qrPayMode QRCode
     * @return boolean
     */
    private boolean checkQrPayModeValue(String qrPayMode) {
        if (StringUtils.isNotEmpty(qrPayMode)) {
            if (PeakConstant.QRPAYMODE_ZERO.equals(qrPayMode)) {
                return false;
            } else if (PeakConstant.QRPAYMODE_ONE.equals(qrPayMode)) {
                return false;
            } else if (PeakConstant.QRPAYMODE_THREE.equals(qrPayMode)) {
                return false;
            } else if (PeakConstant.QRPAYMODE_FIVE.equals(qrPayMode)) {
                return false;
            } else if (PeakConstant.QRPAYMODE_SIX.equals(qrPayMode)) {
                return false;
            }else if (PeakConstant.QRPAYMODE_SEVEN.equals(qrPayMode)) {
                return false;
            }else if (PeakConstant.QRPAYMODE_EIGHT.equals(qrPayMode)) {
                return false;
            }else {
                return true;
            }
        } else {
            return false;
        }
    }
}

