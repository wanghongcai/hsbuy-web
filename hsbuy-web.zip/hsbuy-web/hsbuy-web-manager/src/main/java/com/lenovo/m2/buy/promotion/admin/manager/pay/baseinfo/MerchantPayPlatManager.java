package com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.FakeRule;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.OrderSupportPayType;

import java.util.List;

/**
 * Created by yangjj7 on 2015/5/2.
 */
public interface MerchantPayPlatManager {

    /**
     * 查询商户与三方支付平台
     * @param merchantId
     * @param payType
     * @return
     */
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatByMerchantId(String merchantId, int payType);
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatForWeChat(String merchantId, int payType, String shopId);

    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatById(long merchantId);

    /**
     * 根据FAID获取支持支付类型
     * @param FAID
     * @return
     */

    public RemoteResult<List<OrderSupportPayType>> getOrderSupportPayTypeList(String FAID);

    /**
     * 查询所有FA支持的支付方式
     * @return
     */
    public RemoteResult<List<FakeRule>> getMerchantPayPlatByGroupBy();

    public RemoteResult<List<OrderSupportPayType>> getOrderSupportPayTypeListByFaIDPayment(String faId, List<Integer> payTypeList);
}
