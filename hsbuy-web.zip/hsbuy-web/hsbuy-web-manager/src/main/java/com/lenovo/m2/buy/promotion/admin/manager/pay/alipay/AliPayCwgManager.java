package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.manager.GenericManager;
import com.lenovo.m2.buy.promotion.admin.domain.pay.wxpay.PayOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * 支付宝纯网关业务Manager
 * Created by MengQiang on 2015/5/23.
 */
public interface AliPayCwgManager extends GenericManager<PayOrder, Long> {
    /**
     * 更新支付订单
     * @param lenovoId 用户LenovoID
     * @param orderPrimaryId 支付平台订单唯一标识
     * @param trade_no  第三方交易流水
     * @param gmt_payment   支付时间
     * @param faid FAID
     * @param payType 支付类型
     * @param merchantPayPlatView 支付平台信息
     * @param notifyId  支付校验ID
     * @param bankSeqNo 银行流水
     * @return
     */
    public RemoteResult<Map<String,Object>> callUpdate(String lenovoId, String orderPrimaryId, String trade_no, String gmt_payment, String faid, String payType, MerchantPayPlatView merchantPayPlatView, String notifyId, String bankSeqNo);



    /**
     * 支付宝纯网关支付业务处理
     * @param request
     * @return
     */
    public RemoteResult toAliCwgPay(HttpServletRequest request);
}
