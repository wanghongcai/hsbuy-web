package com.lenovo.m2.buy.promotion.admin.manager.pay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by caoxd2 on 2015/5/24.
 */
public interface PayManager {
    public boolean isParamValid(RemoteResult<String> romoteResult, HttpServletRequest request);

    public RemoteResult<String> prepareForPay(HttpServletRequest request);

    public void payCallback(HttpServletRequest request, HttpServletResponse response);

    public void syncCallback(int plat, HttpServletResponse response);
}
