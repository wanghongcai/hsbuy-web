package com.lenovo.m2.buy.promotion.admin.manager.pay.pingan;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * 平安支付Manager
 * Created by qixin on 2011/11/01.
 */
public interface PingAnPayManager {

    /**
     * 平安银行支付业务处理
     * @param request
     * @return
     */
    public RemoteResult toPay(HttpServletRequest request);

    RemoteResult<String> callUpdate(PayOrder payOrder, MerchantPayPlatView merchantPayPlatView, String tradeNo, Map<String, Object> paraMap);
}
