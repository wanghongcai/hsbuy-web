package com.lenovo.m2.buy.promotion.admin.manager.inventory;

import com.lenovo.fis.model.FaBaseInfoes;
import com.lenovo.m2.hsbuy.domain.inventory.FaBaseInfo;

import java.util.List;

/**
 * Created by mayan3 on 2016/3/22.
 */
public interface FaBaseInfoManager {
    public List<FaBaseInfo> getFaBaseInfoList(List<String> listIds) throws Exception;
    public FaBaseInfoes getFaBaseInfo(String faid) throws Exception;
}
