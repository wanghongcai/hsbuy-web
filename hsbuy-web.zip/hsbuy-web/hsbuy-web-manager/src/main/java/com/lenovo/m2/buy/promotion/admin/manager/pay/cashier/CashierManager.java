package com.lenovo.m2.buy.promotion.admin.manager.pay.cashier;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.OrderSupportPayType;

import java.util.List;
import java.util.Map;

/**
 * Create For Cashier
 * 收银台业务Manager
 * Created by MengQiang on 2015/8/21.
 */
public interface CashierManager {


    RemoteResult<List<OrderSupportPayType>> getOrderSupportPayTypeList(String FAID);

    RemoteResult<List<OrderSupportPayType>> getOrderSupportPayTypeListByFaIDPayment(String faId, int payment);

    int getStatusByOrderCode(String orderCode);
}
