package com.lenovo.m2.buy.promotion.admin.manager.pay.alipay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.manager.GenericManager;
import com.lenovo.m2.buy.promotion.admin.domain.pay.wxpay.PayOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * 支付宝分期业务Manager
 * Created by MengQiang on 2015/5/19.
 */
public interface AliPayFqManager extends GenericManager<PayOrder, Long> {
    /**
     *更新支付订单
     * @param lenovoId
     * @param out_trade_no
     * @param trade_no
     * @param gmt_payment
     * @param merchantCode
     * @param payType
     */
    public RemoteResult<Map<String,Object>> callUpdate(String lenovoId, String out_trade_no, String trade_no, String gmt_payment, String merchantCode, String payType, MerchantPayPlatView merchantPayPlatView, String notifyId);



    /**
     * 支付宝分期支付业务处理
     * @param request
     * @return
     */
    public RemoteResult toAliFqPay(HttpServletRequest request);
}
