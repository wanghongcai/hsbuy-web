package com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.impl;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.StringUtil;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonPayManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.MerchantPayPlatApi;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.ChannelOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.Product;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 支付公共Manager实现
 * 优化支付整体流程，去支付统一用公共方法
 * Created by MengQiang on 2016/1/4.
 */
@Service
public class CommonPayManagerImpl implements CommonPayManager {

    private final Logger logger = Logger.getLogger(this.getClass());
    @Autowired
    private PayOrderApi payOrderApi;
    @Autowired
    private MerchantPayPlatApi merchantPayPlatApi;

    @Override
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlat(String faId, String payType) {
        RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult = new RemoteResult<MerchantPayPlatView>();
        if(StringUtil.isEmpty(faId) || StringUtil.isEmpty(payType)){
            logger.info("获取支付平台信息失败，请求参数为空FAID==>" + faId +" payType==>" + payType);
            merchantPayPlatViewRemoteResult.setSuccess(false);
        }
        try{
            merchantPayPlatViewRemoteResult = merchantPayPlatApi.getMerchantPayPlatByMerchantId(faId, Integer.parseInt(payType));
        }catch(Exception e){
            logger.error("获取支付平台信息异常，FAID==>" + faId + " payType==>" + payType);
            merchantPayPlatViewRemoteResult.setSuccess(false);
        }
        return merchantPayPlatViewRemoteResult;
    }
    @Override
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatByAccountType(String faId, String payType, Integer accountType) {
        RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult = new RemoteResult<MerchantPayPlatView>();
        if(StringUtil.isEmpty(faId) || StringUtil.isEmpty(payType)){
            logger.info("获取支付平台信息失败，请求参数为空FAID==>" + faId +" payType==>" + payType);
            merchantPayPlatViewRemoteResult.setSuccess(false);
        }
        try{
            merchantPayPlatViewRemoteResult = merchantPayPlatApi.getMerchantPayPlatByAccountType(faId, Integer.parseInt(payType),accountType);
        }catch(Exception e){
            logger.error("获取支付平台信息异常，FAID==>" + faId + " payType==>" + payType+" accountType==>" + accountType);
            merchantPayPlatViewRemoteResult.setSuccess(false);
        }
        return merchantPayPlatViewRemoteResult;
    }

    /**
     * 校验支付状态
     * true：支付
     * false：未支付
     * @param channelOrder channelOrder
     * @return boolean
     */
    @Override
    public boolean checkPayStatus(ChannelOrder channelOrder) {
        boolean payStatus =  PeakConstant.TRUE_FLAG_STR.equals(String.valueOf(channelOrder.getPayStatus()));
        if(payStatus){
            logger.info("订单已支付，订单号==>" + channelOrder.getOrderCode());
        }
        return payStatus;
    }

    /**
     * 获取当前订单中商品名
     * 采用拼接方式，如有特殊字符改为LenovoProduct
     * @param channelOrder
     * @return
     */
    @Override
    public String getProductNameFromMongoOrder(ChannelOrder channelOrder) {
        StringBuffer productNameBuffer = new StringBuffer();
        List<Product> list = channelOrder.getProduct();
        if(list.size()>0){
            for (Product product : list){
                productNameBuffer.append(product.getProductName());
            }
        }
        String productName = productNameBuffer.toString();
        Pattern p = Pattern.compile("^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$");
        Matcher m = p.matcher(productName);
        if (!m.matches()||productName.getBytes().length > 120) {
            productName = "LenovoProduct";
        }
        return productName;
    }

    /**
     * 校验主订单状态
     * true：失效
     * false：有效
     * @param channelOrder channelOrder
     * @return boolean
     */
    public boolean checkOrderStatus(ChannelOrder channelOrder){
        return PeakConstant.TRUE_FLAG_STR.equals(String.valueOf(channelOrder.getOrderStatus()));
    }
}
