package com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.impl;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.*;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayConfig;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipaySubmit;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.*;
import com.lenovo.m2.buy.promotion.admin.domain.pay.order.BaseInfo;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonPayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.MerchantPayPlatManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.ChannelOrderApi;
import com.lenovo.m2.buy.promotion.admin.remote.pay.MerchantPayPlatApi;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderSoaChannelPayCenterApi;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.baseInfo.PayAccountVo;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import com.lenovo.m2.arch.tool.util.StringParse;
import com.lenovo.m2.hsbuy.service.pay.soa.PaidCallBackDataService;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.*;

/**
 * Created by yangjj7 on 2015/5/2.
 */
@Service
public class CommonCallBackManagerImpl implements CommonCallBackManager {

    private final Logger logger = Logger.getLogger(this.getClass());

    @Autowired
    private MerchantPayPlatManager merchantPayPlatManager;
    @Autowired
    private PayOrderApi payOrderApi;
    @Autowired
    private MerchantPayPlatApi merchantPayPlatApi;
    @Autowired
    private ChannelOrderApi channelOrderApi;
    @Autowired
    private AliPayCommonManager aliPayCommonManager;
    @Autowired
    private PayPortalOrderManager payPortalOrderManager;
    @Autowired
    private PayOrderSoaChannelPayCenterApi payOrderSoaChannelPayCenterApi;

    @Autowired
    private PaidCallBackDataService paidCallBackDataService;

    @Autowired
    private CommonPayManager commonPayManager;

    /**
     * 根据支付类型和平台判断跳转中间件还是老商城逻辑
     *
     * @param merchantPayPlatView 商户支付数据
     * @param platformCode        支付平台
     * @param signature           签名
     * @param orderCode           商城订单号
     * @param payOrderCode        交易订单号
     * @param payDatetime         支付时间
     * @param payment             支付类型
     * @param lenovoId            id
     * @param payTransactionNo    交易号
     * @return
     */
    @Override
    public RemoteResult<String> payCallback(MerchantPayPlatView merchantPayPlatView, int platformCode, String signature, String orderCode, String payOrderCode, String payDatetime, String payment, String lenovoId, String payTransactionNo, PayOrder payOrder) throws Exception {
        RemoteResult<String> remoteResult = null;
        String shopId = payOrder.getShop_id();
        logger.info("构建异步回调更新订单platformCode[" + platformCode + "],signature[" + signature + "],orderCode[" + orderCode + "],payOrderCode[" + payOrderCode + "],payDatetime[" + payDatetime + "],payment[" + payment + "],lenovoId[" + lenovoId + "],payTransactionNo[" + payTransactionNo + "],shopId[" + shopId + "]");
        Tenant tenant = CommonMethod.buildTenant(shopId, payOrder.getCurrencyCode(), null, null, null, null, null);
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(payOrder.getOut_trade_no(), lenovoId, tenant);
        PayPortalOrder payPortalOrder;
        if (payPortalOrderRemoteResult != null && payPortalOrderRemoteResult.isSuccess()) {
            payPortalOrder = payPortalOrderRemoteResult.getT();
            logger.info("支付回调查询支付渠道订单成功");
        } else {
            logger.info("支付回调查询支付渠道订单失败，订单号：" + payTransactionNo);
            remoteResult.setSuccess(false);
            remoteResult.setT("fail");
            return remoteResult;
        }
        PayAccountVo payAccountVo = this.buildPayAccountVo(merchantPayPlatView);
        payAccountVo.setTotalPay(payPortalOrder.getTotalFee());
        payAccountVo.setPoint(payPortalOrder.getPoint());//惠商积分 //TODO 异步回调 通知 订单积分
        if(PeakConstant.SHOPID_PCSD.equals(shopId) && "16".equals(payAccountVo.getPayment())){
            payAccountVo.setPayment(PeakConstant.PAY_TYPE_WECHAT);
        }
        if (PeakConstant.SHOPID_SMB.equals(shopId)) {
            logger.info("SMB Alipay buyer_email[" + signature + "]");
            payAccountVo.setBuyerAccount(signature);
        }
        if (PeakConstant.SHOPID_MOTO.equals(payOrder.getShop_id())) {
            logger.info("适配摩托罗拉支付回调");
            payAccountVo.setPayVoucherNo(payOrder.getOut_trade_no());
        } else {
            payAccountVo.setPayVoucherNo(payTransactionNo);
        }
        payAccountVo.setPaymentUser(payPortalOrder.getMemberCode());
        payAccountVo.setBankTraceNo(payOrderCode);
        payAccountVo.setPaidTime(payDatetime);
        logger.info("payAccountVo==>" + payAccountVo);
        boolean isOutMerchant = false;
        if (PeakConstant.SHOPID_PCSD.equals(shopId) || PeakConstant.SHOPID_HUISHANG.equals(shopId)
                || PeakConstant.SHOPID_MOTO_INDIA.equals(shopId)){
            isOutMerchant = true;
        }
        if (PeakConstant.SHOPID_LENOVO.equals(shopId)&& PeakConstant.TERMINAL_WECHAT_APPLET.equals(payOrder.getTerminal())){
            lenovoId = LePayConstant.LENOVO_ID_WX_APPLET;
        }
        remoteResult = this.payCallbackForMiddle(tenant ,orderCode, lenovoId, payAccountVo,payPortalOrder.getOrderType(),isOutMerchant);

        if (remoteResult.isSuccess()){
            logger.info("payCallback 支付通知订单成功：orderCode="+orderCode+",remoteResult="+remoteResult);
        }else {
            logger.info("payCallback 支付通知订单失败：orderCode="+orderCode+",remoteResult="+remoteResult);
        }
        //0元支付跳过
        if (!PeakConstant.PAY_TYPE_ZERO.equals(String.valueOf(merchantPayPlatView.getPayType()))) {
            RemoteResult<String> handleResult = paidCallBackDataService.handleCallBackData(remoteResult,shopId,payPortalOrder.getFaId(),payPortalOrder.getOutTradeNo(),payOrder.getId().toString(),payOrder.getTransation_id(),
                    payOrder.getPay_type().toString(),payOrder.getPay_money().getAmount(),payPortalOrder.getOrderStatus(),payOrder.getTrade_state(),null,null,remoteResult.getResultMsg(),payOrder.getCreateTime(),DateUtil.parseDate(payDatetime, "yyyyMMddHHmmss"),new Date(),payPortalOrder.getExtendParam());
            if (handleResult.isSuccess()){
                logger.info("payCallback 调用处理回调数据服务成功！备注："+handleResult.getResultMsg());
            }else {
                logger.info("payCallback 调用处理回调数据服务失败！原因："+handleResult.getResultMsg());
            }

        }

        return remoteResult;
    }
    private RemoteResult<String> payCallbackForMiddle(Tenant tenant, String orderCode, String lenovoId, PayAccountVo payAccountVo, String orderType, boolean isOutMerchant) {
        return payOrderSoaChannelPayCenterApi.updateChannelOrderPayStatus(tenant, orderCode,  lenovoId, payAccountVo,orderType,isOutMerchant);
    }

    /**
     * Call MiddleWare For OrderStatusPayChannelManagerImpl
     *
     * @param payPortalOrder      payPortalOrder
     * @param payOrder            payOrder
     * @param merchantPayPlatView merchantPayPlatView
     * @param paraMap             paraMap
     * @return RemoteResult
     */
    @Override
    public RemoteResult<String> paidCallback(PayPortalOrder payPortalOrder, PayOrder payOrder, MerchantPayPlatView merchantPayPlatView, Map<String, String> paraMap) {
        RemoteResult<String> remoteResult = new RemoteResult<String>();
        try {
            String outTradeNo = payOrder.getOut_trade_no();
            String transactionId = payOrder.getTransation_id();
            String lenovoId = payPortalOrder.getLenovoId();
            String orderPrimaryId = String.valueOf(payOrder.getId());
            String shopId = payPortalOrder.getShopId();
            String payTime = paraMap.get("payTime");
            String payment = paraMap.get("payment");
            String channelType = paraMap.get("RT_DISCOUNT");
            String channelAmount = paraMap.get("RT_DISCOUNTAMOUNT");
            Tenant tenant = CommonMethod.buildTenant(shopId, payPortalOrder.getCurrencyCode(), null, null, null, null, null);
            logger.info("Invoke paidCallBack Call MiddleWare, outTradeNo[" + outTradeNo + "],transactionId[" + transactionId + "],lenovoId[" + lenovoId + "],orderPrimaryId[" + orderPrimaryId + "],shopId[" + shopId + "],payTime[" + payTime + "],payment[" + payment + "]");
            PayAccountVo payAccountVo = this.buildPayAccountVo(merchantPayPlatView);
            payAccountVo.setTotalPay(payPortalOrder.getTotalFee());
            if(PeakConstant.SHOPID_PCSD.equals(shopId) && "16".equals(payAccountVo.getPayment())){
                payAccountVo.setPayment(PeakConstant.PAY_TYPE_WECHAT);
            }
            if (PeakConstant.SHOPID_SMB.equals(shopId)) {
                payAccountVo.setBuyerAccount(paraMap.get("payAcc"));
            }
            if (PeakConstant.SHOPID_MOTO.equals(shopId)) {
                logger.info("适配摩托罗拉支付回调");
                payAccountVo.setPayVoucherNo(payOrder.getOut_trade_no());
            } else {
                payAccountVo.setPayVoucherNo(orderPrimaryId);
            }
            payAccountVo.setPaymentUser(payPortalOrder.getMemberCode());
            payAccountVo.setBankTraceNo(transactionId);
            payAccountVo.setPaidTime(payTime);
            if(StringUtils.isNotEmpty(channelType) && StringUtils.isNotEmpty(channelAmount)){
                payAccountVo.setDiscountType(1);
                payAccountVo.setDiscountAmount(new Money(channelAmount, payPortalOrder.getCurrencyCode()));
            }
            payAccountVo.setPoint(payPortalOrder.getPoint());
            logger.info("payAccountVo==>" + payAccountVo);
            boolean isOutMerchant = false;
            if (PeakConstant.SHOPID_PCSD.equals(shopId) || PeakConstant.SHOPID_HUISHANG.equals(shopId)
                    || PeakConstant.SHOPID_MOTO_INDIA.equals(shopId)){
                isOutMerchant = true;
            }
            remoteResult = payOrderSoaChannelPayCenterApi.updateChannelOrderPayStatus(tenant, outTradeNo, lenovoId, payAccountVo,payPortalOrder.getOrderType(),isOutMerchant);
            if (remoteResult.isSuccess()) {
                logger.info("Call MiddleWare SUCCESS, outTradeNo[" + outTradeNo + "]");
            } else {
                boolean tryFlag = true;
                int tryNum = 1;
                while (tryFlag && tryNum < 4) {
                    remoteResult = payOrderSoaChannelPayCenterApi.updateChannelOrderPayStatus(tenant, outTradeNo, lenovoId, payAccountVo,payPortalOrder.getOrderType(),isOutMerchant);
                    logger.info("Call MiddleWare Fail, ReTry Time[" + tryNum + "],ReTry Result[" + remoteResult + "]");
                    if (remoteResult.isSuccess()) {
                        tryFlag = false;
                        logger.info("Call MiddleWare SUCCESS, outTradeNo[" + outTradeNo + "]");
                    } else {
                        tryNum++;
                    }
                }
            }

            RemoteResult<String> handleResult = paidCallBackDataService.handleCallBackData(remoteResult,shopId,payPortalOrder.getFaId(),payPortalOrder.getOutTradeNo(),payOrder.getId().toString(),payOrder.getTransation_id(),
                    payOrder.getPay_type().toString(),payOrder.getPay_money().getAmount(),payPortalOrder.getOrderStatus(),payOrder.getTrade_state(),null,null,remoteResult.getResultMsg(),payOrder.getCreateTime(),DateUtil.parseDate(payTime, "yyyyMMddHHmmss"),new Date(),payPortalOrder.getExtendParam());
            if (handleResult.isSuccess()){
                logger.info("paidCallback 调用处理回调数据服务成功！备注："+handleResult.getResultMsg());
            }else {
                logger.info("paidCallback 调用处理回调数据服务失败！原因："+handleResult.getResultMsg());
            }
            logger.info("Invoke paidCallBack Call MiddleWare FINISH ,RemoteResult[" + remoteResult + "]");
        } catch (Exception e) {
            logger.error("调用中间件异常", e);
            remoteResult.setSuccess(false);
            remoteResult.setResultMsg("调用中间件异常");
        }
        return remoteResult;
    }



    @Override
    public RemoteResult<String> callOutUpdate(PayOrder payOrder, MerchantPayPlatView merchantPayPlatView, Map<String, String> paraMap, Map<String, Object> commonParam) {
        RemoteResult<String> returnResult = new RemoteResult<String>();
        String tradeStatus = paraMap.get("tradeStatus");
        String tradeNo = paraMap.get("tradeNo");
        String gmtPayment = paraMap.get("gmtPayment");
        String notifyId = paraMap.get("notifyId");
        String payType = paraMap.get("payType");
        String bankSeqNo = paraMap.get("bankSeqNo");
        String shopId = null;
        logger.info("CallOutUpdate, tradeStatus[" + tradeStatus + "],tradeNo[" + tradeNo + "],gmtPayment[" + gmtPayment + "],notifyId[" + notifyId + "],payType[" + payType + "],bankSeqNo[" + bankSeqNo + "]");
        Date payTime;
        try {
            payTime = DateUtil.parseDate(gmtPayment, "yyyyMMddHHmmss");
        } catch (ParseException e) {
            logger.info("处理订单支付时间错误",e);
            payTime = new Date();
        }
        try {
            PayPortalOrder updatePayPortalOrder = CommonMethod.buildUpdatePayPortalOrder(String.valueOf(payOrder.getId()), payOrder.getOut_trade_no(), payOrder.getU_id(), Integer.parseInt(payType), PeakConstant.PAY_STATUS_ALREADY_PAID, payOrder.getShop_id(), payTime);
            payOrderApi.updateAliPayNotifyState(String.valueOf(payOrder.getId()), payOrder.getU_id(), tradeNo, PeakConstant.MFLAG_REPEAT, notifyId, PeakConstant.TRADE_SUCCESS, bankSeqNo, Integer.parseInt(payType));
            RemoteResult<Integer> updatePayPortalOrderResult = payPortalOrderManager.updatePayPortalOrderPayStatus(updatePayPortalOrder);
            if (updatePayPortalOrderResult.isSuccess()) {
                logger.info("Update PayPortalOrder SUCCESS，outTradeNo[" + payOrder.getOut_trade_no() + "]");
            } else {
                logger.info("Update PayPortalOrder FAIL，outTradeNo[" + payOrder.getOut_trade_no() + "]");
            }
        } catch (Exception e) {
            logger.info("更新渠道订单失败 ，订单号==>" + payOrder.getOut_trade_no(), e);
        }
        PayPortalOrder payPortalOrder = null;
        try{
            Tenant tenant = CommonMethod.buildTenant(payOrder.getShop_id(), null, null, null, null, null, null);
            RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(payOrder.getOut_trade_no(), null, tenant);
            logger.info("CallOutUpdate Get PayPortalOrder[" + payPortalOrderRemoteResult + "]");
            if(payPortalOrderRemoteResult.isSuccess()){
                // HTTP异步回调
                payPortalOrder = payPortalOrderRemoteResult.getT();
                String returnStr = invokeOutPayNotify(payOrder, merchantPayPlatView, payPortalOrder, commonParam, tradeStatus, tradeNo, payTime, payType);
                logger.info("invokeOutPayNotify Return STATUS[" + returnStr + "]");
                if("success".equalsIgnoreCase(returnStr)){
                    returnResult.setSuccess(true);
                }else{
                    returnResult.setSuccess(false);
                }
            }else{
                logger.info("CallOutUpdate Get PayPortalOrder Fail");
                returnResult.setSuccess(false);
            }
        }catch(Exception e){
            returnResult.setSuccess(false);
            logger.info("Invoke CallOutUpdate Exception", e);
        }

        RemoteResult<String> handleResult = paidCallBackDataService.handleCallBackData(returnResult,shopId,payPortalOrder.getFaId(),payPortalOrder.getOutTradeNo(),payOrder.getId().toString(),payOrder.getTransation_id(),
                payOrder.getPay_type().toString(),payOrder.getPay_money().getAmount(),payPortalOrder.getOrderStatus(),payOrder.getTrade_state(),null,null,returnResult.getResultMsg(),payOrder.getCreateTime(),payTime,new Date(),payPortalOrder.getExtendParam());
        if (handleResult.isSuccess()){
            logger.info("callOutUpdate调用处理回调数据服务成功！备注："+handleResult.getResultMsg());
        }else {
            logger.info("callOutUpdate调用处理回调数据服务失败！原因："+handleResult.getResultMsg());
        }
        return returnResult;
    }

    private String invokeOutPayNotify(PayOrder payOrder, MerchantPayPlatView merchantPayPlatView, PayPortalOrder payPortalOrder, Map<String, Object> commonParam, String tradeStatus, String tradeNo, Date payTime, String payType) {
        BufferedReader bufferedReader = null;
        InputStreamReader content = null;
        try {
            String notifyURL = payPortalOrder.getNotifyUrl();
            if (StringUtils.isEmpty(notifyURL)) {
                return "fail";
            }
            StringBuffer stringBuffer = new StringBuffer();
            Map<String, String> postMap = new HashMap<String, String>();
            postMap.put("notify_time", DateUtil.formatDate(new Date(), PeakConstant.CALL_MIDDLEWARE_PAY_TYPE));
            postMap.put("notify_type", "trade_status_async");
            postMap.put("out_trade_no", payPortalOrder.getOutTradeNo());
            if (PeakConstant.SHOPID_HUISHANG.equals(payPortalOrder.getShopId())&&StringUtils.isNotEmpty(payPortalOrder.getExtendParam())){
                postMap.put("extend_param", payPortalOrder.getExtendParam());
            }
            postMap.put("shop_id", payPortalOrder.getShopId());
            postMap.put("fa_id", payPortalOrder.getFaId());
            postMap.put("payment", payType);
            postMap.put("total_fee", String.valueOf(payPortalOrder.getTotalFee()));
            postMap.put("trade_no", String.valueOf(payOrder.getId()));
            postMap.put("transaction_no", tradeNo);
            postMap.put("trade_status", tradeStatus);
            postMap.put("gmt_create", DateUtil.formatDate(payOrder.getCreate_time(), PeakConstant.CALL_MIDDLEWARE_PAY_TYPE));
            postMap.put("gmt_payment", DateUtil.formatDate(payTime, PeakConstant.CALL_MIDDLEWARE_PAY_TYPE));
            RemoteResult<MerchantPayPlatView> merchantPayPlatRemoteResult = null;
            String signKey = null;
            if (PeakConstant.SHOPID_LENOVO.equals(payOrder.getShop_id())&& PeakConstant.TERMINAL_WECHAT_APPLET.equals(payOrder.getTerminal())){
                merchantPayPlatRemoteResult = commonPayManager.getMerchantPayPlatByAccountType(payPortalOrder.getFaId(),payType, Integer.parseInt(payOrder.getTerminal()));
                if (merchantPayPlatRemoteResult.isSuccess() && null != merchantPayPlatRemoteResult.getT()){
                    signKey = merchantPayPlatRemoteResult.getT().getPayKey();
                }
            }else {
                signKey = (String) commonParam.get(payPortalOrder.getShopId());
            }
            String sign = PaySignUtils.buildSignKey(postMap, "MD5", signKey);
            postMap.put("sign", sign);
            postMap.put("sign_type", "MD5");
            List<String> keys = new ArrayList<String>(postMap.keySet());
            for (int i = 0; i < keys.size(); i++) {
                String key = keys.get(i);
                String value = postMap.get(key);
                if (i == 0) {
                    stringBuffer.append(key).append("=").append(value);
                } else {
                    stringBuffer.append("&").append(key).append("=").append(value);
                }
            }
            logger.info("Invoke OutPayNotify URL[" + notifyURL + "],Parameter[" + stringBuffer.toString() + "]");

            if (notifyURL.startsWith("https") || notifyURL.startsWith("HTTPS")) {
                return this.postHTTPS(notifyURL, stringBuffer.toString());
            } else{
                HttpGet post = new HttpGet(notifyURL + "?" + stringBuffer.toString());
                HttpResponse httpResponse = HttpUtil.executeProxy(post);
                content = new InputStreamReader(httpResponse.getEntity().getContent());
                logger.info("OutPayNotify Content[" + content + "]");
                bufferedReader = new BufferedReader(content);
                StringBuffer responseBuffer = new StringBuffer();
                String responseStr = "";
                // 获取系统分行标准
    //            String NL = System.getProperty("line.separator");
                while ((responseStr = bufferedReader.readLine()) != null) {
                    responseBuffer.append(responseStr);
                }
    //            String responseStr = responseBuffer.toString();
                logger.info("Invoke OutPayNotify Merchant Return[" + responseBuffer.toString() + "]");
                return responseBuffer.toString();
            }
        }catch(Exception e){
            logger.info("invokeOutPayNotify Exception", e);
            return "fail";
        }finally {
            try {
                if(bufferedReader != null){
                    bufferedReader.close();
                }
                if(content!=null){
                    content.close();
                }

            } catch (IOException e) {
                logger.error("文件流关闭失败");
            } finally {
                bufferedReader = null;
                content = null;
            }
        }
    }

    private String postHTTPS(String notifyURL, String postParameter) {
        logger.info("HTTPS通知外部商户");
        try {
            byte[] resultBytes = HttpsUtil.post(notifyURL, postParameter, "UTF-8");
            String resultStr = new String(resultBytes);
            logger.info("HTTPS通知外部商户返回结果[" + resultStr + "]");
            return resultStr;
        } catch (Exception e) {
            logger.info("HTTPS通知外部商户失败 Exception：",e);
            return "fail";
        }
    }

    private PayAccountVo buildPayAccountVo(MerchantPayPlatView merchantPayPlatView){
        PayAccountVo payAccountVo = new PayAccountVo();
        String payType = String.valueOf(merchantPayPlatView.getPayType());
        if (PeakConstant.PAY_TYPE_CMB.equals(payType)) {
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("0");
            payAccountVo.setGatheringBank("招商银行");
            payAccountVo.setGatheringDesc("支付");
        } else if (PeakConstant.PAY_TYPE_ALJS.equals(payType) || PeakConstant.PAY_TYPE_ALSJ.equals(payType) || PeakConstant.PAY_TYPE_ALCWG.equals(payType) ||
                PeakConstant.PAY_TYPE_ALHB.equals(payType) || PeakConstant.PAY_TYPE_ALFQ.equals(payType) || PeakConstant.PAY_TYPE_YDKJ.equals(payType) ||
                PeakConstant.PAY_TYPE_ALHUABEIFQ.equals(payType)) {
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("1");
            payAccountVo.setGatheringBank("支付宝");
            payAccountVo.setGatheringDesc("支付");
        } else if (PeakConstant.PAY_TYPE_UNION.equals(payType)) {
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("7");
            payAccountVo.setGatheringBank("银联");
            payAccountVo.setGatheringDesc("支付");
        } else if (PeakConstant.PAY_TYPE_WECHAT.equals(payType)||PeakConstant.PAY_TYPE_WECHAT_JSAPI.equals(payType)||PeakConstant.PAY_TYPE_WECHAT_H5.equals(payType)||
                PeakConstant.PAY_TYPE_WECHAT_APP.equals(payType) || PeakConstant.PAY_TYPE_WECHAT_APPLET.equals(payType)) {
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("16");
            payAccountVo.setGatheringBank("微信");
            payAccountVo.setGatheringDesc("支付");
        } else if (PeakConstant.PAY_TYPE_ABCFQ.equals(payType)) {
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("17");
            payAccountVo.setGatheringBank("农业银行");
            payAccountVo.setGatheringDesc("分期");
        } else if (PeakConstant.PAY_TYPE_CMBFQ.equals(payType)) {
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("24");
            payAccountVo.setGatheringBank("招商银行");
            payAccountVo.setGatheringDesc("分期");
        } else if (PeakConstant.PAY_TYPE_SMB_OFFLINE.equals(payType)) {
            payAccountVo.setPaymentType("2");
            payAccountVo.setPayment("20");
            payAccountVo.setGatheringBank(merchantPayPlatView.getAppId());
            payAccountVo.setGatheringDesc("SMB线下支付");
        }else if (PeakConstant.PAY_TYPE_ALLINPAY.equals(payType)) {
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("31");
            payAccountVo.setGatheringBank("通联网关");
            payAccountVo.setGatheringDesc("支付");
        }else if (PeakConstant.PAY_TYPE_PINGAN.equals(payType)) {
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("32");
            payAccountVo.setGatheringBank("平安网关");
            payAccountVo.setGatheringDesc("支付");
        }else if (PeakConstant.PAY_TYPE_UMPAY.equals(payType)) {
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("33");
            payAccountVo.setGatheringBank("联动优势网关");
            payAccountVo.setGatheringDesc("支付");
        }else if (PeakConstant.PAY_TYPE_UMPAY_WAP.equals(payType)) {
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("34");
            payAccountVo.setGatheringBank("联动优势快捷");
            payAccountVo.setGatheringDesc("支付");
        }else if (PeakConstant.PAY_TYPE_ALLINPAY_SHORTCUT.equals(payType)) {
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("35");
            payAccountVo.setGatheringBank("通联手机快捷");
            payAccountVo.setGatheringDesc("支付");
        }else if (PeakConstant.PAY_TYPE_PAYU.equals(payType)) {
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("28");
            payAccountVo.setGatheringBank("PayU");
            payAccountVo.setGatheringDesc("支付");
        }else if (PeakConstant.PAY_TYPE_PAYTM_WEB.equals(payType)) {
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("29");
            payAccountVo.setGatheringBank("PayTM");
            payAccountVo.setGatheringDesc("支付");
        }else if(PeakConstant.PAY_TYPE_ZERO.equals(payType)){
            payAccountVo.setPaymentType("0");
            payAccountVo.setPayment("43");
            payAccountVo.setGatheringBank("0 元支付");
            payAccountVo.setGatheringDesc("0 元支付");

        }
        payAccountVo.setGatheringName(merchantPayPlatView.getAppId());
        payAccountVo.setGatheringCode(merchantPayPlatView.getMechId());
        payAccountVo.setPayStatus("1");
        return payAccountVo;
    }




    /**
     * 老商城逻辑
     *
     * @param merchantPayPlatView
     * @param trade_no
     * @param out_trade_no
     * @param gmt_payment
     * @param lenovoId
     * @param payment
     * @param signature
     * @param key_id
     * @return
     * @throws Exception
     */
    public RemoteResult<String> updateRemoteOrder(MerchantPayPlatView merchantPayPlatView, String trade_no, String out_trade_no, String gmt_payment, String lenovoId, String payment, String signature, String key_id) throws Exception {
        RemoteResult remoteResult = new RemoteResult();
        String sign = this.getSignature("", trade_no, out_trade_no, gmt_payment, payment, lenovoId);
        HttpPost post = new HttpPost(merchantPayPlatView.getInNotifyUrl() + "payOrderCode=" + trade_no + "&orderCode=" + out_trade_no + "&payDatetime=" + gmt_payment + "&payment=" + payment + "&lenovoId=" + lenovoId + "&signature=" + sign);
        StringBuffer sb = null;
        HttpResponse response = HttpUtil.executeProxy(post);
        InputStreamReader content = new InputStreamReader(response.getEntity().getContent());
        logger.info("content--->" + content);
        BufferedReader in = new BufferedReader(content);
        sb = new StringBuffer();
        String line = "";
        // 获取系统分行标准
        String NL = System.getProperty("line.separator");
        while ((line = in.readLine()) != null) {
            sb.append(line + NL);
        }
        in.close();
        content.close();
        remoteResult.setSuccess(true);
        remoteResult.setT(sb.toString());
        return remoteResult;
    }




    public String getSignature(String orderPrimaryId, String payOrderCode, String orderCode, String payDatetime, String payment, String lenovoId) {
        Map paraMap = new HashMap();
        paraMap.put("orderPrimaryId", "");
        paraMap.put("payOrderCode", payOrderCode);
        paraMap.put("orderCode", orderCode);
        paraMap.put("payDatetime", payDatetime);
        paraMap.put("payment", payment);
        paraMap.put("lenovoId", lenovoId);
        Map proMap = PropertiesHelper.loadToMap();
        return Signature.getSign(paraMap, (String) proMap.get("b2cKey"));
    }

    /**
     * 取消支付宝交易逻辑
     *
     * @param orderCode
     * @param faid
     * @param payType
     * @return
     * @throws IOException
     */
    public String cancelPayOrderForAli(String orderCode, String faid, String payType) throws IOException {
        logger.info("取消订单得---〉orderCode=" + orderCode + ",faid=" + faid + ",payType=" + payType);
        if (Util.isNull(orderCode)) {
            logger.info("订单号为空");
            return JacksonUtil.toJson(new BaseInfo(400, "单号不能为空"));
        }
        RemoteResult<List<PayOrder>> result = payOrderApi.getOrderListByOrderCode(orderCode);
        if (!result.isSuccess() || null == result || null == result.getT()) {
            return "";
        }
        List<PayOrder> payOrders = result.getT();
        RemoteResult<MerchantPayPlatView> remoteResult = merchantPayPlatManager.getMerchantPayPlatByMerchantId(faid, StringParse.parseInt(payType));
        logger.info("取消订单得到的商户信息---〉" + remoteResult.getT());
        String cancelUrl = aliPayCommonManager.getAliPropValue("ALIPAY_GATEWAY_NEW");
        String str = "";
        for (PayOrder order : payOrders) {
            if (order.getPay_type() == 2 || order.getPay_type() == 4 || order.getPay_type() == 5 || order.getPay_type() == 6) {
//                if(order.getOs() == 6 || order.getOs() == 7){
//                    str= this.cancelAliRequest(orderCode,remoteResult.getT().getMechId(),remoteResult.getT().getSignKey(),cancelUrl);
//                    break;
//                }else{
                logger.info("切换支付方式取消订单，支付平台流水==>" + order.getId());
                str = this.cancelAliRequest(order.getId().toString(), remoteResult.getT().getMechId(), remoteResult.getT().getSignKey(), cancelUrl);
                logger.info("支付平台流水：" + order.getId() + ",取消订单返回结果：" + str);
//                }
            }
        }

        Map reslut = null;
        try {
            reslut = XMLParser.getMapFromXML(str);
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        }
        return JacksonUtil.toJson(reslut);
    }

    private String cancelAliRequest(String orderCode, String partner, String signKey, String cancelUrl) {
        String str = "";
        StringBuffer sb = new StringBuffer();
        Map<String, String> sParaTemp = new HashMap<String, String>();
        sParaTemp.put("service", "close_trade");
        sParaTemp.put("partner", partner);
        sParaTemp.put("_input_charset", AlipayConfig.input_charset);
        sParaTemp.put("out_order_no", orderCode);
        String sign = AlipaySubmit.buildRequestMysign(sParaTemp, signKey);
        sb.append("?sign=" + sign);
        sb.append("&_input_charset=utf-8");
        sb.append("&sign_type=MD5");
        sb.append("&service=close_trade");
        sb.append("&out_order_no=" + orderCode);
        sb.append("&partner=" + partner);
        logger.info("参数---》" + sb.toString());
        HttpGet post = new HttpGet(cancelUrl + sb.toString());
        HttpResponse response1 = null;
        try {
            response1 = HttpUtil.executeProxy(post);

            InputStreamReader content = new InputStreamReader(
                    response1.getEntity().getContent());
            logger.info("content--->" + content);
            BufferedReader in = new BufferedReader(content);
            StringBuffer sb1 = new StringBuffer();
            String line = "";
            // 获取系统分行标准
            String NL = System.getProperty("line.separator");
            while ((line = in.readLine()) != null) {
                sb1.append(line + NL);
            }
            in.close();
            content.close();
            str = sb1.toString();
            logger.info("stringtomap" + str);
        } catch (Exception e) {

        }
        return str;
    }

    @Override
    public PayOrder getPayOrderById(String id) {
        return payOrderApi.getTwoStatus(id);
    }

    @Override
    public RemoteResult<MerchantPayPlatView> getMerchantPayPlatById(long id) {
        return this.merchantPayPlatApi.getMerchantPayPlatById(id);
    }

    @Override
    public void updatePayNotifyState(Long id, String u_id, String tradeNo, int merchantFlag, String notifyId, int tradeSuccess, String bankSeq, int payType) {
        this.payOrderApi.updateAliPayNotifyState(String.valueOf(id), u_id, tradeNo, merchantFlag, notifyId, tradeSuccess, bankSeq, payType);
    }

    @Override
    public PayOrder getPayOrderByTransationId(String transation_id) {
        return this.payOrderApi.getPayOrderByTransactionId(transation_id);
    }
}
