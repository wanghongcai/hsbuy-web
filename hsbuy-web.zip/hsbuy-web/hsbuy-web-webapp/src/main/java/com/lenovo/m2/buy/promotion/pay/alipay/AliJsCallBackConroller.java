package com.lenovo.m2.buy.promotion.pay.alipay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayNotify;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayUtil;
import com.lenovo.m2.buy.promotion.admin.controller.util.DateUtil;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayJsManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.MerchantPayPlatManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Modify By MengQiang 20160713.
 */
@Controller
@Scope("prototype")
public class AliJsCallBackConroller {
    private final Logger LOGGER = Logger.getLogger(this.getClass());
    @Autowired
    private PayOrderApi payOrderApi;
    @Autowired
    private MerchantPayPlatManager merchantPayPlatManager;
    @Autowired
    private AliPayJsManager aliPayJsManager;
    @Autowired
    private CommonManager commonManager;
    @Autowired
    private CommonCallBackManager commonCallBackManager;
    @Autowired
    private PayPortalOrderManager payPortalOrderManager;

    /**
     * 支付宝即时支付完成之后的服务器异步通知
     */
    @RequestMapping("/aliJsPayNotice")
    public void AliJsPayNotice(HttpServletRequest request, HttpServletResponse response) {
        Map<String, String> params;
        Map<?, ?> requestParams = request.getParameterMap();
        PrintWriter out = null;
        try {
            out = response.getWriter();
        } catch (IOException e) {
            LOGGER.info("GET PRINTWRITER ERROR!");
        }
        params = AlipayUtil.parseRequestParams(requestParams);
        String orderPrimaryId = params.get("out_trade_no");
        String trade_status = params.get("trade_status");
        String gmt_payment = params.get("gmt_payment");
        gmt_payment = gmt_payment.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
//        gmt_payment = DateUtil.formatString(new Date(),"yyyyMMddHHmmss");
        String trade_no = params.get("trade_no");
        String notifyId = params.get("notify_id");
        String extra_common_param = params.get("extra_common_param");
        String outChannelType = params.get("out_channel_type");
        String outChannelAmount = params.get("out_channel_amount");
        String buyer_email = params.get("buyer_email");
        String business_scene = params.get("business_scene");
        LOGGER.info("Https AliJsPayNotice To Go! orderPrimaryId[" + orderPrimaryId + "],trade_status[" + trade_status + "],gmt_payment[" + gmt_payment + "],trade_no[" + trade_no + "],notifyId[" + notifyId + "],extra_common_param[" + extra_common_param + "],outChannelType[" + outChannelType + "],outChannelAmount[" + outChannelAmount + "],buyer_email[" +buyer_email+"],business_scene["+business_scene+"]");
        Map sParaMap = null;
        try {
            sParaMap = AlipayUtil.parseCommonParam(extra_common_param);
        } catch (Exception e) {
            LOGGER.error("解析支付宝反馈数据异常", e);
        }
        LOGGER.info("AliPay JSPay CommonParam [" + sParaMap + "]");
        savePayMethodToCookie(request, response, "", PeakConstant.PAY_TYPE_ALJS);
        PayOrder payOrder;
        RemoteResult<MerchantPayPlatView> merchantPayPlatRemoteResult;
        MerchantPayPlatView merchantPayPlatView;
        try{
            if(StringUtils.isNotEmpty(orderPrimaryId)){
                payOrder = commonCallBackManager.getPayOrderById(orderPrimaryId);
                LOGGER.info("AliPay JSPay Original PayOrder [" + payOrder + "]");
            }else{
                LOGGER.info("支付宝即时支付异步通知订单号为空");
                return;
            }
            if(payOrder != null){
                merchantPayPlatRemoteResult = commonCallBackManager.getMerchantPayPlatById(payOrder.getMerchant_id());
            }else{
                LOGGER.info("未查到原支付订单，订单号==>" + orderPrimaryId);
                return;
            }
            if(merchantPayPlatRemoteResult.isSuccess()){
                merchantPayPlatView = merchantPayPlatRemoteResult.getT();
                LOGGER.info("AliPay JSPay Original MerchantPayPlat [" + merchantPayPlatView + "]");
            }else{
                LOGGER.info("未查到商户平台信息");
                return;
            }
        }catch(Exception e){
            LOGGER.info("异步回调获取订单平台信息异常");
            return;
        }
        String sandbox = PropertiesHelper.loadToMap("pay_switch.properties").get("aliPay_sandbox").toString();
        LOGGER.info("是否沙箱判断：aliPay_sandbox=" + sandbox);
        boolean verify_result = true;
        try {
            if ("2".equals(sandbox)) {
                verify_result = true;
            } else {
                verify_result = AlipayNotify.verifyNotify(params, merchantPayPlatView.getSignKey(), merchantPayPlatView.getMechId());
            }
        } catch (Exception signEx) {
            LOGGER.info("签名验证异常!", signEx);
        }
        if (verify_result) {
            if (trade_status.equals("TRADE_FINISHED")|| trade_status.equals("TRADE_SUCCESS")) {
                LOGGER.info("支付结果通知，支付成功，支付平台唯一标识：" + orderPrimaryId);
                try {
                    RemoteResult<String> result;
                    if(CommonMethod.checkInShopId(payOrder.getShop_id())){
                        LOGGER.info("AliPay DirectPay Go Inner Asynchronous Notify，shopId[" + payOrder.getShop_id() + "]");
                        result = aliPayJsManager.callUpdate(payOrder.getU_id(), orderPrimaryId, trade_no, gmt_payment, merchantPayPlatView.getMerchantId(), String.valueOf(payOrder.getPay_type()), merchantPayPlatView, notifyId, buyer_email);
                    }else{
                        Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
                        Map<String, String> paraMap = new HashMap<String, String>();
                        paraMap.put("tradeStatus", trade_status);
                        paraMap.put("tradeNo", trade_no);
                        paraMap.put("gmtPayment", gmt_payment);
                        paraMap.put("notifyId", notifyId);
                        paraMap.put("payType", PeakConstant.PAY_TYPE_ALJS);
                        result = commonCallBackManager.callOutUpdate(payOrder, merchantPayPlatView, paraMap, commonParam);
                    }
                    if (result.isSuccess()) {
                        out.println("success");
                        out.close();
                    }
                } catch (Exception ex) {
                    LOGGER.info("支付宝反馈成功，更新订单或通知支付结果失败，支付平台唯一标识：" + orderPrimaryId, ex);
                }

            } else {
                LOGGER.info("支付宝通知支付失败，支付平台唯一标识：" + orderPrimaryId);
            }
        } else {
            LOGGER.info("支付结果通知MD5签名验签失败，支付平台唯一标识：" + orderPrimaryId);
        }
    }


    @RequestMapping("/aliDirectPCReturn")
    public String aliDirectPCReturn(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        Map<?, ?> requestParams = request.getParameterMap();
        Map<String, String> aliPayParam = AlipayUtil.parseRequestParams(requestParams);
        String orderPrimaryId = aliPayParam.get("out_trade_no");
        String tradeStatus = aliPayParam.get("trade_status");
//        String gmtPayment = aliPayParam.get("gmt_payment");
//        gmtPayment = gmtPayment.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
        String tradeNo = aliPayParam.get("trade_no");
        String notifyId = aliPayParam.get("notify_id");
        String buyer_email = aliPayParam.get("buyer_email");
        LOGGER.info("Https aliDirectPCReturn To Go! orderPrimaryId[" + orderPrimaryId + "],trade_status[" + tradeStatus + "],trade_no[" + tradeNo + "],notifyId[" + notifyId + "],buyer_email[" +buyer_email+"]");
        PayOrder payOrder;
        RemoteResult<MerchantPayPlatView> merchantPayPlatRemoteResult;
        MerchantPayPlatView merchantPayPlatView;
        try{
            if(StringUtils.isNotEmpty(orderPrimaryId)){
                payOrder = commonCallBackManager.getPayOrderById(orderPrimaryId);
            }else{
                LOGGER.info("HTTPS aliDirectPCReturn orderPrimaryId IS NULL");
                paraMap.put("error_msg", "支付宝同步通知异常，out_trade_no为空");
                return "outpay/outpay_pc_fail";
            }
            if(payOrder != null){
                LOGGER.info("HTTPS aliDirectPCReturn Original PayOrder [" + payOrder + "]");
                merchantPayPlatRemoteResult = commonCallBackManager.getMerchantPayPlatById(payOrder.getMerchant_id());
            }else{
                LOGGER.info("HTTPS aliDirectPCReturn Get Original PayOrder IS NULL");
                paraMap.put("error_msg", "支付平台未查到交易流水");
                return "outpay/outpay_pc_fail";
            }
            if (merchantPayPlatRemoteResult.isSuccess()) {
                merchantPayPlatView = merchantPayPlatRemoteResult.getT();
                LOGGER.info("HTTPS aliDirectPCReturn Original MerchantPayPlat [" + merchantPayPlatView + "]");
            } else {
                LOGGER.info("HTTPS aliDirectPCReturn Original MerchantPayPlat Is Null");
                paraMap.put("error_msg", "支付平台未查商户信息异常");
                return CommonMethod.getPCFailSyncReturnURLByShopId(payOrder.getShop_id());
            }
            boolean verifyFlag;
            try {
                verifyFlag = AlipayNotify.verifyNotify(aliPayParam, merchantPayPlatView.getSignKey(), merchantPayPlatView.getMechId());
            } catch (Exception checkSignException) {
                LOGGER.error("HTTPS aliDirectPCReturn Check Signature EXCEPTION，OrderPrimaryId[" + orderPrimaryId + "],TradeNo[" + tradeNo + "]", checkSignException);
                paraMap.put("error_msg", "验证支付宝签名异常");
                return CommonMethod.getPCFailSyncReturnURLByShopId(payOrder.getShop_id());
            }
            Tenant tenant = CommonMethod.buildTenant(payOrder.getShop_id(), null, null, null, null, null, null);
            RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(payOrder.getOut_trade_no(), null, tenant);
            PayPortalOrder payPortalOrder;
            if(payPortalOrderRemoteResult.isSuccess()){
                payPortalOrder = payPortalOrderRemoteResult.getT();
                LOGGER.info("HTTPS aliDirectPCReturn Original payPortalOrderRemoteResult [" + payPortalOrderRemoteResult + "]");
            }else{
                LOGGER.info("HTTPS aliDirectPCReturn Original PayPortalOrder Is Null");
                paraMap.put("error_msg", "支付平台未查到订单信息");
                return CommonMethod.getPCFailSyncReturnURLByShopId(payOrder.getShop_id());
            }
            CommonMethod.buildReturnParaMap(paraMap, payOrder, merchantPayPlatView, payPortalOrder);
            String returnUrl = payPortalOrder.getReturnUrl();
            Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
            if (verifyFlag && (("TRADE_SUCCESS".equals(tradeStatus) || "TRADE_FINISHED".equals(tradeStatus) || "success".equals(tradeStatus)))) {
                if(PeakConstant.SHOPID_LENOVO.equals(payPortalOrder.getShopId()) || PeakConstant.SHOPID_EPP.equals(payPortalOrder.getShopId()) || PeakConstant.SHOPID_THINK.equals(payPortalOrder.getShopId()) || PeakConstant.SHOPID_SMB.equals(payPortalOrder.getShopId())){
                    return CommonMethod.getPCSuccSyncReturnURLByShopId(payOrder.getShop_id());
                }else if(StringUtils.isNotEmpty(returnUrl)){
                    return CommonMethod.getOutSyncReturnForm(payOrder ,merchantPayPlatView, payPortalOrder, paraMap, commonParam, "TRADE_SUCCESS", tradeNo);
                }else{
                    return CommonMethod.getPCSuccSyncReturnURLByShopId(payOrder.getShop_id());
                }
            }else{
                if(PeakConstant.SHOPID_LENOVO.equals(payPortalOrder.getShopId()) || PeakConstant.SHOPID_EPP.equals(payPortalOrder.getShopId()) || PeakConstant.SHOPID_THINK.equals(payPortalOrder.getShopId()) || PeakConstant.SHOPID_SMB.equals(payPortalOrder.getShopId())){
                    if(PeakConstant.ORDER_TYPE_DONGDE_CZ.equals(payPortalOrder.getOrderType())){
                        if(PeakConstant.SHOPID_LENOVO.equals(payPortalOrder.getShopId())){
                            return "syncback/dongde_pc_fail";
                        }else {
                            return "charge/epp_pc_charge_fail";
                        }
                    }else{
                        return CommonMethod.getPCFailSyncReturnURLByShopId(payOrder.getShop_id());
                    }
                }else if(StringUtils.isNotEmpty(returnUrl)){
                    return CommonMethod.getOutSyncReturnForm(payOrder ,merchantPayPlatView, payPortalOrder, paraMap, commonParam, "TRADE_FAIL", tradeNo);
                }else{
                    return CommonMethod.getPCFailSyncReturnURLByShopId(payOrder.getShop_id());
                }
            }
        }catch(Exception e){
            LOGGER.info("HTTPS aliDirectPCReturn Exception", e);
            paraMap.put("error_msg", "服务器异常，请到支付后台查询交易状态！");
            return "outpay/outpay_pc_fail";
        }
    }
    /**
     * 回调完把这个用户本次的用的支付方式存到cookie中
     */
    public void savePayMethodToCookie(HttpServletRequest request, HttpServletResponse response, String directbank, String payType) {
        String lenovoId = request.getParameter("lenovoId");
        Cookie cookie = new Cookie("userPayMethod", lenovoId + "," + directbank + "," + payType);
        cookie.setMaxAge(24 * 60 * 60 * 183);
        cookie.setSecure(true);
        response.addCookie(cookie);
    }

    public PayOrderApi getPayOrderApi() {
        return payOrderApi;
    }

    public void setPayOrderApi(PayOrderApi payOrderApi) {
        this.payOrderApi = payOrderApi;
    }

    public MerchantPayPlatManager getMerchantPayPlatManager() {
        return merchantPayPlatManager;
    }

    public void setMerchantPayPlatManager(MerchantPayPlatManager merchantPayPlatManager) {
        this.merchantPayPlatManager = merchantPayPlatManager;
    }

    public AliPayJsManager getAliPayJsManager() {
        return aliPayJsManager;
    }

    public void setAliPayJsManager(AliPayJsManager aliPayJsManager) {
        this.aliPayJsManager = aliPayJsManager;
    }

    public CommonManager getCommonManager() {
        return commonManager;
    }

    public void setCommonManager(CommonManager commonManager) {
        this.commonManager = commonManager;
    }

    public CommonCallBackManager getCommonCallBackManager() {
        return commonCallBackManager;
    }

    public void setCommonCallBackManager(CommonCallBackManager commonCallBackManager) {
        this.commonCallBackManager = commonCallBackManager;
    }

    public PayPortalOrderManager getPayPortalOrderManager() {
        return payPortalOrderManager;
    }

    public void setPayPortalOrderManager(PayPortalOrderManager payPortalOrderManager) {
        this.payPortalOrderManager = payPortalOrderManager;
    }
}
