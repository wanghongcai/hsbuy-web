package com.lenovo.m2.buy.promotion.admin.controller.api.seckillActivity;


import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.controller.util.ThreadLocalObjs;
import com.lenovo.m2.buy.promotion.admin.domain.AuthData;
import com.lenovo.m2.buy.promotion.admin.domain.promotion.SeckillActivityListQry;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.SeckillActivity;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.SessionUser;
import com.lenovo.m2.buy.promotion.admin.soa.api.service.PromotionAdminRead;
import com.lenovo.m2.buy.promotion.admin.soa.api.service.PromotionAdminWrite;
import com.lenovo.m2.buy.promotion.admin.soa.api.service.SeckillActivityService;
import com.lenovo.m2.buy.promotion.admin.soa.enums.GloablErrorMessageEnum;
import com.lenovo.m2.buy.promotion.admin.soa.utils.StringUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.Map;


@Controller
@RequestMapping("/api/seckillActivity")
public class SeckillActivityCheckApi {

	@Autowired
	private PromotionAdminRead promotionAdminRead;
	@Autowired
	private PromotionAdminWrite promotionAdminWrite;
	@Autowired
	private SeckillActivityService seckillActivityService;

	private static Logger log = LoggerFactory.getLogger(SeckillActivityCheckApi.class);


	/**
	 * @desc 限时折扣-提交审核
	 * @param ids
	 * @return
	 */
	@RequestMapping("/submitAudit")
	@ResponseBody
	public RemoteResult submitCheck(String ids){
		RemoteResult remoteResult = new RemoteResult(false);

		AuthData authData = ThreadLocalObjs.getAuthData();
		String userId = authData.getUserid();

		if(StringUtils.isEmpty(ids) || StringUtils.isEmpty(userId)){
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
			remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
			return remoteResult;
		}

		String[] idarr = ids.split(",");
		if(idarr.length <= 0){
			log.error("idarr={}",idarr);
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
			remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
			return remoteResult;
		}

		Integer[] activityIds = new Integer[idarr.length];
		for(int i=0; i < idarr.length; i++){
			activityIds[i] = Integer.parseInt(idarr[i]);
		}
		try {
			remoteResult =  seckillActivityService.submitToAudit(activityIds, userId);
		} catch (Exception e) {
			log.error("seckillActivity submitCheck Error-->", e);
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
			remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
			remoteResult.setSuccess(false);
		}
		return remoteResult;
	}


	/**
	 * @desc 限时折扣审核   0 驳回  1 通过
	 * @param status
	 * @param ids
	 * @return
	 */
	@RequestMapping("/audit")
	@ResponseBody
	public RemoteResult checkPassOrNot(String ids, int status, String rejectReason){

		Tenant tenant = ThreadLocalObjs.getTenant();
		AuthData authData = ThreadLocalObjs.getAuthData();
		String userId = authData.getUserid();

		SessionUser user = ThreadLocalObjs.getUser();

		RemoteResult remoteResult = new RemoteResult(false);
		if(StringUtils.isEmpty(ids) || StringUtils.isEmpty(userId) ){
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
			remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
			return remoteResult;
		}
		try {
			if(status == 0){
				if(StringUtil.isEmpty(rejectReason)){
					remoteResult.setSuccess(false);
					remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
					remoteResult.setResultMsg("拒绝原因不能为空");
				} else {
								//审核 为通过
					remoteResult = promotionAdminWrite.updateSeckillActivityCheckReject(tenant, user, ids, rejectReason); //驳回
				}
			} else {
						//审核 通过
				remoteResult = promotionAdminWrite.updateSeckillActivityCheckPass(tenant, user, ids.split(","));  //通过
			}
		} catch (Exception e) {
			log.error("submitAudit audit error", e);
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
			remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
			remoteResult.setSuccess(false);
		}
		return remoteResult;
	}



    /**
	 * 根据限时折扣审核表id 获取对应的限时折扣审核信息
	 * @param auditId
     * @return
     */
    @RequestMapping("/getAudit")
    @ResponseBody
    public RemoteResult<SeckillActivity> getSeckillActivityCheck(String auditId){
		Tenant tenant = ThreadLocalObjs.getTenant();
        RemoteResult<SeckillActivity> result = new RemoteResult<SeckillActivity>(false);

        if(StringUtils.isEmpty(auditId)|| tenant == null){
			result.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
			result.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
			return result;
		}

		result =  promotionAdminRead.getSeckillactivityCheckById(tenant, auditId);
        log.info("getSeckillActivityCheck 返回结果={}",result);
        return result;
        
    }

    /**
     * 获取审核列表
	 * @param request
	 * @return
	 */
    @RequestMapping("/auditList")
    @ResponseBody
    public RemoteResult seckillActivityAuditList(SeckillActivityListQry request){
		AuthData authData = ThreadLocalObjs.getAuthData();
		Tenant tenant = ThreadLocalObjs.getTenant();

		List<String> shopIds = authData.getShopIds();
		List<String> faIds = authData.getFaIds();

		PageQuery pageQuery = new PageQuery();
        pageQuery.setPageNum(request.getPageNum());
        pageQuery.setPageSize(request.getPageSize());

        Map map = request.toMap();
        map.put("shopId", tenant.getShopId());
		map.put("shopIds",shopIds);
		map.put("faIds",faIds);
        RemoteResult<PageModel2<SeckillActivity>> getCheckList = new RemoteResult<>();
        getCheckList = promotionAdminRead.getSeckillActivityCheckList(tenant, pageQuery, map);
        return getCheckList;
    }

}
