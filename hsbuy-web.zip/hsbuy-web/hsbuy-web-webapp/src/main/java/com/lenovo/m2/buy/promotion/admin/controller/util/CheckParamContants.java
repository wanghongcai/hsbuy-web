package com.lenovo.m2.buy.promotion.admin.controller.util;

/**
 * Created by pengyy on 2018/03/05.
 */
public class CheckParamContants {

    //------17及17积分订单导出查询校验错误编号--------//
    public static final String RIGHT_PARAM = "100"; //参数正常
    public static final String NULL_PARAM = "101";  //条件为null
    public static final String ERROR_TIME = "102";  //起始时间大于结束时间
    public static final String NULL_TIME = "103";   //起始，结束时间为空
    public static final String EROOR_SYSTEM = "104";   //系统错误

}

