package com.lenovo.m2.buy.promotion.pay.syncback;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayUtil;
import com.lenovo.m2.buy.promotion.admin.domain.pay.PhoneRechargeForPay;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.CashierManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.syncback.ReturnCommonManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import com.lenovo.ucenter.sso.client.util.SSOUserInfoUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * Created For Alipay Return
 * 支付宝同步回调Controller
 * Created by mengqiang1 on 2015/8/27.
 */
@Controller
public class AliReturnController {
    private final Logger logger = Logger.getLogger(AliReturnController.class);
    @Autowired
    private ReturnCommonManager returnCommonManager;
    @Autowired
    private CashierManager cashierManager;
    @Autowired
    private CommonManager commonManager;
    @Autowired
    private PayPortalOrderManager payPortalOrderManager;
    @Autowired
    private PayOrderApi payOrderApi;

    @RequestMapping("/aliReturn")
    public String aliReturn(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        Map<?, ?> requestParams = request.getParameterMap();
        Map<String, String> params = AlipayUtil.parseRequestParams(requestParams);
        String orderPrimaryId = params.get("out_trade_no");
        String tradeStatus = params.get("trade_status");
        String mergeTradeResult = request.getParameter("merge_trade_result");
        String result = request.getParameter("result");
        String SSOLenovoID = SSOUserInfoUtil.getLenovoId(request);
        logger.info("Https aliReturn Ready To Go! orderPrimaryId[" + orderPrimaryId + "],mergeTradeResult[" + mergeTradeResult + "],tradeStatus[" + tradeStatus + "],result[" + result + "],SSOLenovoID[" + SSOLenovoID + "]");
        logger.info("支付同步回调请求数据" + params);
        String returnUtl = "";
        Map<String, Object> urlMap = PropertiesHelper.loadToMap("ali_pay.properties");
        try {
            if (mergeTradeResult == null && orderPrimaryId != null) {
                logger.info("Invoke AliPay Direct Pay SyncBack");
                PayOrder payOrder;
                if (orderPrimaryId.trim().length() == 10) {
                    payOrder = payOrderApi.getTwoStatus(orderPrimaryId);
                } else {
                    payOrder = payOrderApi.getPayOrderById(orderPrimaryId);
                    orderPrimaryId = payOrder.getId().toString();
                }
                logger.info("AliPay Original PayOrder [" + payOrder + "]");
                String outTradeNo = payOrder.getOut_trade_no();
                int plat = payOrder.getOs();
                String lenovoId = payOrder.getU_id();
                int payType = payOrder.getPay_type();
                String shopId = payOrder.getShop_id();
                String terminal = payOrder.getTerminal();
                String totalFee = params.get("total_fee");
                paraMap.put("pay_type", payType);
                paraMap.put("lenovoId", lenovoId);
                paraMap.put("shopId", shopId);
                paraMap.put("terminal", terminal);
                paraMap.put("outTradeNo", outTradeNo);
                paraMap.put("totalFee", totalFee);
                paraMap.put("plat", plat);
                Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
                if (!PeakConstant.SHOPID_HUISHANG.equals(shopId) || !PeakConstant.SHOPID_SQGC.equals(shopId)) {
                    if (!lenovoId.equals(SSOLenovoID)) {
                        logger.info("获取LenovoID与单点获取LenovoID不匹配");
                        paraMap.put("resultReason", "非法请求");
                        tradeStatus = "FALSE";
                    }
                }
                RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(outTradeNo, lenovoId, tenant);
                String order_type = "";
                if (payPortalOrderRemoteResult.isSuccess()) {
                    logger.info("Get PayPortalOrder SUCCESS, PayPortalOrder Result[" + payPortalOrderRemoteResult + "]");
                    paraMap.put("payPortalOrder", payPortalOrderRemoteResult.getT());
                    order_type = payPortalOrderRemoteResult.getT().getOrderType();
                } else {
                    logger.info("Get PayPortalOrder FAIL, OrderMainCode[" + outTradeNo + "]");
                    paraMap.put("resultReason", "订单处理异常，请到订单详情查询状态");
                    paraMap.put("error_msg", "订单处理异常，请到订单详情查询状态");
                }
                // 为何不对数据进行验签？
                if ("TRADE_SUCCESS".equals(tradeStatus) || "TRADE_FINISHED".equals(tradeStatus) || "success".equals(result)) {
                    logger.info("支付宝同步回调，支付成功，OrderMainCode[" + outTradeNo + "],OrderPrimaryId[" + orderPrimaryId + "]");
                    // 惠商支付宝
                    if (PeakConstant.SHOPID_HUISHANG.equals(shopId)) {
                        try {
                            if (payPortalOrderRemoteResult.isSuccess()) {
                                Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
                                paraMap.put("error_msg", "订单支付，支付金额为+" + payOrder.getPay_money().getAmount().toString() + "元");
                                return CommonMethod.getOutSyncReturnForm(payOrder, null, payPortalOrderRemoteResult.getT(), paraMap, commonParam, "TRADE_SUCCESS", String.valueOf(payOrder.getId()));
                            } else {
                                logger.info("支付宝同步回调外部URL失败!未查询到原始订单！ out_trade_no=" + payOrder.getOut_trade_no());
                                paraMap.put("error_msg", "支付异常,未查询到有效订单");
                                return CommonMethod.getOutPayFailPage(terminal);
                            }
                        } catch (Exception e) {
                            logger.error("支付宝同步回调外部系统异常 OrderPrimaryId[" + payOrder.getId() + "] Error Cause By :", e);
                            paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
                            return CommonMethod.getOutPayFailPage(terminal);
                        }
                    }
                    int leBean = 0;
                    try {
                        leBean = Integer.parseInt(payPortalOrderRemoteResult.getT().getRewardLedou());
                    } catch (Exception ex) {
                        logger.info("订单乐豆转换异常");
                    }
                    if (leBean != 0) {
                        paraMap.put("leBean", "恭喜您获得了" + String.valueOf(leBean) + "个乐豆，");
                    } else {
                        paraMap.put("leBean", " ");
                    }
                    String delivery = payPortalOrderRemoteResult.getT().getDeliveryInfo();
                    if (StringUtils.isNotEmpty(delivery)) {
                        paraMap.put("delivery", delivery);
                    } else {
                        paraMap.put("delivery", " ");
                    }
                    Integer peakTotalFee = payOrder.getTotal_fee();
                    BigDecimal decimal = new BigDecimal(peakTotalFee);
                    decimal = decimal.movePointLeft(2);
                    logger.info("Order Amount[" + decimal + "]");
                    paraMap.put("totalFee", decimal);
                    if (PeakConstant.SHOPID_LENOVO.equals(shopId)) {
                        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                            returnUtl = "syncback/b2c_pc_succ";
                        } else {
                            returnUtl = "syncback/b2c_wap_success";
                        }
                    } else if (PeakConstant.SHOPID_THINK.equals(shopId)) {
                        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                            response.sendRedirect((String) urlMap.get("THINK_PC_SUCC"));
                        } else {
                            response.sendRedirect((String) urlMap.get("THINK_WAP_SUCC"));
                        }
                    } else if (PeakConstant.SHOPID_EPP.equals(shopId)) {
                        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                            returnUtl = "syncback/epp_pc_succ";
                        } else {
                            returnUtl = "syncback/epp_wap_success";
                        }
                    } else if (PeakConstant.SHOPID_SMB.equals(shopId)) {
                        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                            returnUtl = "syncback/smb_pc_succ";
                        } else {
                            returnUtl = "syncback/b2c_wap_success";
                        }
                    }
                } else {
                    logger.warn("支付宝同步回调，支付失败，OrderPrimaryId[" + orderPrimaryId + "]");
                    paraMap.put("resultReason", "支付失败");
                    if (!PeakConstant.SHOPID_HUISHANG.equals(shopId) || !PeakConstant.SHOPID_SQGC.equals(shopId)) {
                        if (!lenovoId.equals(SSOLenovoID)) {
                            paraMap.put("resultReason", "非法请求");
                        }
                    }
                    if (PeakConstant.ORDER_TYPE_DONGDE_CZ.equals(order_type)) {
                        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                            if (PeakConstant.SHOPID_LENOVO.equals(shopId)) {
                                returnUtl = "syncback/dongde_pc_fail";
                            } else {
                                returnUtl = "charge/epp_pc_charge_fail";
                            }
                        } else {
                            if (PeakConstant.SHOPID_LENOVO.equals(shopId)) {
                                returnUtl = "syncback/dongde_wap_error";
                            } else {
                                returnUtl = "charge/epp_wap_charge_fail";
                            }
                        }
                        return returnUtl;
                    }
                    if (PeakConstant.SHOPID_LENOVO.equals(shopId)) {
                        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                            returnUtl = "syncback/b2c_pc_fail";
                        } else {
                            returnUtl = "syncback/b2c_wap_error";
                        }
                    } else if (PeakConstant.SHOPID_THINK.equals(shopId)) {
                        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                            response.sendRedirect((String) urlMap.get("THINK_PC_ERROR"));
                        } else {
                            response.sendRedirect((String) urlMap.get("THINK_WAP_ERROR"));
                        }
                    } else if (PeakConstant.SHOPID_EPP.equals(shopId)) {
                        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                            returnUtl = "syncback/epp_pc_fail";
                        } else {
                            returnUtl = "syncback/epp_wap_error";
                        }
                    } else if (PeakConstant.SHOPID_SMB.equals(shopId)) {
                        if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                            returnUtl = "syncback/smb_pc_fail";
                        } else {
                            returnUtl = "syncback/b2c_wap_error";
                        }
                    }
                }
            } else {
                logger.info("Invoke AliPay Merge Pay SyncBack");
                Map<String, Object> propMap = PropertiesHelper.loadToMap("ali_hb.properties");
                try {
                    String[] childResults = mergeTradeResult.split("&\\-&");
                    String[] resultItems = childResults[0].split("&\\+&");
                    Map<String, String> itemsMap = new HashMap<String, String>();
                    for (int j = 0; j < resultItems.length; j++) {
                        if (StringUtils.isEmpty(resultItems[j])) {
                            continue;
                        }
                        String[] kvs = resultItems[j].split("=");

                        if (kvs != null && kvs.length == 2) {
                            itemsMap.put(kvs[0], kvs[1]);
                        }
                    }
                    logger.info("AliPay Merge Pay Param [" + itemsMap + "]");
                    String hbOrderPrimaryId = itemsMap.get("out_trade_no");
                    PayOrder payOrder;
                    String shopId = PeakConstant.SHOPID_LENOVO;
                    try {
                        if (hbOrderPrimaryId.trim().length() == 10) {
                            payOrder = payOrderApi.getTwoStatus(hbOrderPrimaryId);
                        } else {
                            payOrder = payOrderApi.getPayOrderById(hbOrderPrimaryId);
                            hbOrderPrimaryId = payOrder.getId().toString();
                        }
                        shopId = payOrder.getShop_id();
                    } catch (Exception ex) {
                        logger.error("合并支付同步回调查询订单失败，订单号：" + hbOrderPrimaryId);
                    }
                    String redirectUrl = (String) propMap.get("b2cPcSyncCallbackUrl");
                    if (PeakConstant.SHOPID_LENOVO.equals(shopId)) {
                        logger.info("同步回调成功，跳转至B2C商城成功页，其一订单号：" + hbOrderPrimaryId);
                        redirectUrl = (String) propMap.get("b2cPcSyncCallbackUrl");
                    } else if (PeakConstant.SHOPID_THINK.equals(shopId)) {
                        logger.info("同步回调成功，跳转至Think商城成功页，其一订单号：" + hbOrderPrimaryId);
                        redirectUrl = (String) propMap.get("tkPcSyncCallbackUrl");
                    } else if (PeakConstant.SHOPID_EPP.equals(shopId)) {
                        logger.info("同步回调成功，跳转至EPP商城成功页，其一订单号：" + hbOrderPrimaryId);
                        redirectUrl = (String) propMap.get("eppPcSyncCallbackUrl");
                    } else if (PeakConstant.SHOPID_SMB.equals(shopId)) {
                        logger.info("同步回调成功，跳转至SMB商城成功页，其一订单号：" + hbOrderPrimaryId);
                        redirectUrl = (String) propMap.get("smbPcSyncCallbackUrl");
                    }
                    logger.info("支付宝合并支付同步回调地址：" + redirectUrl);
                    paraMap.put("hbRedirect", redirectUrl);
                    return "syncback/innerpay_sync";
                } catch (Exception e) {
                    logger.error("合并支付跳转订单列表页面失败");
                    paraMap.put("resultReason", "请到订单列表查看订单状态");
                    returnUtl = "syncback/b2c_pc_fail";
                }
            }
        } catch (Exception e) {
            logger.error("同步回调异常,支付平台ID：" + orderPrimaryId, e);
        }
        logger.info("Return URL[" + returnUtl + "]");
        return returnUtl;
    }

    public ReturnCommonManager getReturnCommonManager() {
        return returnCommonManager;
    }

    public void setReturnCommonManager(ReturnCommonManager returnCommonManager) {
        this.returnCommonManager = returnCommonManager;
    }

    public CashierManager getCashierManager() {
        return cashierManager;
    }

    public void setCashierManager(CashierManager cashierManager) {
        this.cashierManager = cashierManager;
    }

    public CommonManager getCommonManager() {
        return commonManager;
    }

    public void setCommonManager(CommonManager commonManager) {
        this.commonManager = commonManager;
    }

    public PayPortalOrderManager getPayPortalOrderManager() {
        return payPortalOrderManager;
    }

    public void setPayPortalOrderManager(PayPortalOrderManager payPortalOrderManager) {
        this.payPortalOrderManager = payPortalOrderManager;
    }

    public PayOrderApi getPayOrderApi() {
        return payOrderApi;
    }

    public void setPayOrderApi(PayOrderApi payOrderApi) {
        this.payOrderApi = payOrderApi;
    }
}
