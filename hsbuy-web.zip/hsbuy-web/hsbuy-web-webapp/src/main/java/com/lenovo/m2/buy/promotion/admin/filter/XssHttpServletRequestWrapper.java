package com.lenovo.m2.buy.promotion.admin.filter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class XssHttpServletRequestWrapper extends HttpServletRequestWrapper {
	private static String[] filterChar = { "'", "\"", "\\\\", "#", "%3E", "%3e", ">", "u003e" };
	private static String[] replaceChar = { "‘", "“", "＼", "＃", "＞", "＞", "＞", "＞" };
	
	private static String[] filterChar3 = { "'", "#", "%3E", "%3e", ">", "u003e" };
	private static String[] replaceChar3 = { "‘", "＃", "＞", "＞", "＞", "＞" };
	
	
	private static String[] removeFliterChar = { "onchange", "onclick", "ondblclick", "onerror", "onfocus", "onkeydown", "onkeypress", "onkeyup", "onblur", "onabort", "onload", "onmousedown",
			"onmousemove", "onmouseout", "onmouseover", "onmouseup", "onreset", "onresize", "onselect", "onsubmit", "onunload", "alert(" };

	HttpServletRequest orgRequest = null;
	private static Logger logger = LogManager.getLogger(XssHttpServletRequestWrapper.class.getName());

	public XssHttpServletRequestWrapper(HttpServletRequest request) {
		super(request);
		orgRequest = request;
	}

	/**
	 * 覆盖getParameter方法，将参数名和参数值都做xss过滤。<br/>
	 * 如果需要获得原始的值，则通过super.getParameterValues(name)来获取<br/>
	 * getParameterNames,getParameterValues和getParameterMap也可能需要覆盖
	 */
	@Override
	public String getParameter(String name) {
		String value = super.getParameter(xssEncode(name));
		if (value != null) {
			value = xssEncode(value);
		}
		return value;
	}

	/**
	 * 
	 * 重写getParameterMap 完成过滤
	 * @see javax.servlet.ServletRequestWrapper#getParameterMap()
	 */
	@Override
	public Map getParameterMap() {
		Map paramMap = super.getParameterMap();
		if(paramMap != null){
			Set keySet = paramMap.keySet();
			try {
				for (Iterator iterator = keySet.iterator(); iterator.hasNext();) {
					String key = (String) iterator.next();
					Object o = paramMap.get(key);
					if(o  instanceof String[]) {
						String[] str = (String[]) o;
						for (int i = 0; i < str.length; i++) {
							String t = str[i];
							//不能使用xssEncode ,会把" 替换掉 参数是json 的时候带着"
							str[i] = xssEncode3(t);
						}
						paramMap.put(key, str);
					}
					
				}
			} catch (Exception e) {
				logger.error("过滤字符串错误：",e.getMessage());
				
			}
		}
		//logger.info("getParameterMap过滤后:"+JsonUtil.toJson(paramMap));
		return paramMap;
	}

	@Override
	public Enumeration getParameterNames() {

		// TODO Auto-generated method stub
		return super.getParameterNames();
	}

	/**
	 * 
	 * 重写get values 方法，完成xss 方法过滤
	 * 
	 * @see javax.servlet.ServletRequestWrapper#getParameterValues(String)
	 */
	@Override
	public String[] getParameterValues(String name) {

		String[] temp = super.getParameterValues(name);
		if (null != temp && temp.length > 0) {
			for (int i = 0; i < temp.length; i++) {
				String t = temp[i];
				t = xssEncode3(t);
				temp[i] = t;
			}
			//logger.info("getParameterValues过滤后:"+JsonUtil.toJson(temp));
		}
		
		return temp;
	}

	/**
	 * 覆盖getHeader方法，将参数名和参数值都做xss过滤。<br/>
	 * 如果需要获得原始的值，则通过super.getHeaders(name)来获取<br/>
	 * getHeaderNames 也可能需要覆盖
	 */
	@Override
	public String getHeader(String name) {

		String value = super.getHeader(xssEncode(name));
		if (value != null) {
			value = xssEncode(value);
		}
		return value;
	}

	public static void main(String[] args) {
		String res = "<iframe src=javascript:prompt(1)//"; 
		res = xssEncode(res);
		System.out.println(res);
	}

	/**
	 * 将容易引起xss漏洞的半角字符直接替换成全角字符
	 * 
	 * @param s
	 * @return
	 */
	public static String xssEncode(String s) {
		if (s == null || s.isEmpty()) {
			return "";
		}
		for (int i = 0; i < filterChar.length; i++) {
			String fil = filterChar[i];
			s = s.replaceAll(fil, replaceChar[i]);
		}
		for (String rc : removeFliterChar) {
			if (s.toLowerCase().indexOf(rc) != -1) {
				return "";
			}
		}
		return s;
	}
	public static String xssEncode3(String s) {
		if (s == null || s.isEmpty()) {
			return "";
		}
		for (int i = 0; i < filterChar3.length; i++) {
			String fil = filterChar3[i];
			s = s.replaceAll(fil, replaceChar3[i]);
		}
		for (String rc : removeFliterChar) {
			if (s.toLowerCase().indexOf(rc) != -1) {
				return "";
			}
		}
		return s;
	}

	

	/**
	 * 获取最原始的request
	 * 
	 * @return
	 */
	public HttpServletRequest getOrgRequest() {
		return orgRequest;
	}

	/**
	 * 获取最原始的request的静态方法
	 * 
	 * @return
	 */
	public static HttpServletRequest getOrgRequest(HttpServletRequest req) {
		if (req instanceof XssHttpServletRequestWrapper) {
			return ((XssHttpServletRequestWrapper) req).getOrgRequest();
		}

		return req;
	}
	
	
}
