package com.lenovo.m2.buy.promotion.pay.route;

import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

/**
 * 内部跳转
 * Created by MengQiang on 2016/12/9.
 */
@Controller
@Scope("prototype")
public class InnerRedirectController {
    private final Logger LOGGER = Logger.getLogger(InnerRedirectController.class);

    @RequestMapping("/payLimit")
    public String payLimit(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        String shopId = request.getParameter("shopId");
        LOGGER.info("HTTP Invoke InnerRedirectController payLimit, shopId[" + shopId + "]");
        String payLimitURL = null;
        if(PeakConstant.SHOPID_LENOVO.equals(shopId)){
            payLimitURL = "innerpay/b2c_pay_limit";
        } else if (PeakConstant.SHOPID_THINK.equals(shopId)){
            payLimitURL = "innerpay/tk_pay_limit";
        } else if (PeakConstant.SHOPID_EPP.equals(shopId)){
            payLimitURL = "innerpay/epp_pay_limit";
        } else if (PeakConstant.SHOPID_SMB.equals(shopId)){
            payLimitURL = "innerpay/smb_pay_limit";
        } else {
            payLimitURL = "innerpay/b2c_pay_limit";
        }
        LOGGER.info("HTTP Invoke InnerRedirectController payLimit Finish, payLimitURL[" + payLimitURL + "]");
        return payLimitURL;
    }
    @RequestMapping("/payError")
    public String payError(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        String shopId = request.getParameter("shopId");
        LOGGER.info("HTTP Invoke InnerRedirectController payError, shopId[" + shopId + "]");
        String payErrorURL = null;
        if(PeakConstant.SHOPID_LENOVO.equals(shopId)){
            payErrorURL = "innerpay/b2c_pay_error";
        } else if (PeakConstant.SHOPID_THINK.equals(shopId)){
            payErrorURL = "innerpay/tk_pay_error";
        } else if (PeakConstant.SHOPID_EPP.equals(shopId)){
            payErrorURL = "innerpay/epp_pay_error";
        } else if (PeakConstant.SHOPID_SMB.equals(shopId)){
            payErrorURL = "innerpay/smb_pay_error";
        } else {
            payErrorURL = "innerpay/b2c_pay_error";
        }
        LOGGER.info("HTTP Invoke InnerRedirectController payError Finish, payErrorURL[" + payErrorURL + "]");
        return payErrorURL;
    }
    @RequestMapping("/payQuestion")
    public String payQuestion(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        String shopId = request.getParameter("shopId");
        LOGGER.info("HTTP Invoke InnerRedirectController payQuestion, shopId[" + shopId + "]");
        String payQuestionURL = null;
        if(PeakConstant.SHOPID_LENOVO.equals(shopId)){
            payQuestionURL = "innerpay/b2c_pay_question";
        } else if (PeakConstant.SHOPID_THINK.equals(shopId)){
            payQuestionURL = "innerpay/tk_pay_question";
        } else if (PeakConstant.SHOPID_EPP.equals(shopId)){
            payQuestionURL = "innerpay/epp_pay_question";
        } else if (PeakConstant.SHOPID_SMB.equals(shopId)){
            payQuestionURL = "innerpay/smb_pay_question";
        } else {
            payQuestionURL = "innerpay/b2c_pay_question";
        }
        LOGGER.info("HTTP Invoke InnerRedirectController payQuestion Finish, payQuestionURL[" + payQuestionURL + "]");
        return payQuestionURL;
    }
}
