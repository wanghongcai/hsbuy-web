package com.lenovo.m2.buy.promotion.admin.controller.api.ordererp;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.controller.api.inventory.BaseController;
import com.lenovo.m2.buy.promotion.admin.domain.ordercenter.ArapMultiSettleDetail;
import com.lenovo.m2.buy.promotion.admin.domain.ordercenter.ERPResult;
import com.lenovo.m2.buy.promotion.admin.domain.ordercenter.SaleOrderDetail;
import com.lenovo.m2.buy.promotion.admin.remote.ordererp.ERPOrderRemoteService;
import com.lenovo.m2.hsbuy.common.order.JsonUtil;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.domain.order.mongo.PayCount;
import com.lenovo.m2.hsbuy.domain.order.mongo.Product;
import com.lenovo.m2.hsbuy.inventory.constants.StockResultCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * 惠商ERP对接-致益联
 */
@RestController
@Scope("prototype")
@RequestMapping("/api/hs")
public class HsOrderERPController extends BaseController {
    private static final Logger LOGGER = LoggerFactory.getLogger(HsOrderERPController.class);
    @Autowired
    private ERPOrderRemoteService erpOrderRemoteService;

    // ***************************************惠商ERP对接-致益联*******************************************
    /**
     * 查询惠商订单信息
     *
     * @return 惠商订单信息
     */
    @RequestMapping(value = "/getMongoOrderList4ERP", produces = "text/json;charset=UTF-8")
    public String getMongoOrderList4ERP(HttpServletRequest request, HttpServletResponse response) {
        RemoteResult<List<MongoOrderDetail>> re = new RemoteResult<>(false);
        ArrayList<ERPResult> erpResults = new ArrayList<>();
        try {
            String paidTimeStart = request.getParameter("startTime");
            String paidTimeEnd = request.getParameter("endTime");
            String faCode = request.getParameter("faCode");

            if (StringUtils.isEmpty(faCode)) {
                re.setResultMsg("请输入分销商编码");
                re.setResultCode("2001");
                return JsonUtil.toJson(re);
            }

            if (!isValidDate(paidTimeStart)||!isValidDate(paidTimeEnd)){
                re.setResultMsg("日期参数错误，请检查是否为 yyyy-MM-dd HH:mm:ss 格式！");
                re.setResultCode("2001");
                return JsonUtil.toJson(re);
            }
            re = erpOrderRemoteService.getMongoOrderList4ERP(faCode, paidTimeStart, paidTimeEnd);
            List<MongoOrderDetail> t = re.getT();
            for (MongoOrderDetail mongoOrderDetail : t) {

                List<PayCount> pays = mongoOrderDetail.getPay();
                for (PayCount pay : pays) {
                    ERPResult erpResult = new ERPResult();

                    // 订单信息
                    erpResult.setVoucherDate(mongoOrderDetail.getCreateTime());// 下单时间
                    erpResult.setExternalCode(mongoOrderDetail.getOrderCode());// 订单号
                    erpResult.setCode(mongoOrderDetail.getOrderCode());// 订单号
                    erpResult.setCustomerCode(mongoOrderDetail.getLenovoId()); // 经销商编码
                    erpResult.setCustomerName(mongoOrderDetail.getBuyerCode()); // 经销商名称
                    erpResult.setAddress(mongoOrderDetail.getDeliveries().get(0).getFullAddress());// 送货地址
                    erpResult.setLinkMan(mongoOrderDetail.getDeliveries().get(0).getShipName());// 收货人姓名
                    erpResult.setContactPhone(mongoOrderDetail.getDeliveries().get(0).getShipMobile());// 收货人电话
                    erpResult.setMemo(mongoOrderDetail.getMarkText());// 订单备注
                    erpResult.setPaidTime(pay.getPaidTime());// 支付时间

                    // 支付信息
                    ArrayList<ArapMultiSettleDetail> arapMultiSettleDetails = new ArrayList<>();
                    ArapMultiSettleDetail arapMultiSettleDetail = new ArapMultiSettleDetail();
                    arapMultiSettleDetail.setVoucherCode(mongoOrderDetail.getOrderCode());// 订单号
                    arapMultiSettleDetail.setSettleStyle(pay.getPayment());// 支付方式  0 招商银行, 1支付宝, 4支付宝直连支付,2银联支付
                    arapMultiSettleDetail.setBankAccount(pay.getGatheringCode());// 收款账号
                    arapMultiSettleDetail.setOrigAmount(pay.getGatheringNum().getAmount());// 收款金额
                    arapMultiSettleDetails.add(arapMultiSettleDetail);
                    erpResult.setArapMultiSettleDetails(arapMultiSettleDetails);

                    // 商品信息
                    ArrayList<SaleOrderDetail> saleOrderDetails = new ArrayList<>();
                    List<Product> products = mongoOrderDetail.getProducts();
                    for (Product product : products) {
                        SaleOrderDetail saleOrderDetail = new SaleOrderDetail();
                        saleOrderDetail.setQuantity(new BigDecimal(product.getProductNumber()));// 商品数量
                        saleOrderDetail.setOrigDiscountPrice(product.getProductPay().getAmount());// 商品单价
                        saleOrderDetail.setInventoryCode(product.getLenovoProductCode());// 联想物料编码
                        saleOrderDetail.setProductName(product.getProductName());// 商品名称
                        saleOrderDetails.add(saleOrderDetail);
                    }
                    erpResult.setSaleOrderDetails(saleOrderDetails);
                    erpResults.add(erpResult);
                }
            }
        } catch (Exception e) {
            re.setResultMsg("系统异常！");
            re.setResultCode(StockResultCode.STOCK_ERROR);
            LOGGER.error(e.getMessage(), e);
        }
        //将数据格式以json返回
        return JsonUtil.toJson(erpResults);
    }

    private boolean isValidDate(String str) {
        boolean convertSuccess=true;
        // 指定日期格式
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            // 设置lenient为false. 否则SimpleDateFormat会比较宽松地验证日期，比如2007/02/29会被接受，并转换成2007/03/01
            format.setLenient(false);
            format.parse(str);
        } catch (ParseException e) {
            // 如果throw java.text.ParseException或者NullPointerException，就说明格式不对
            convertSuccess=false;
        }
        return convertSuccess;
    }
}
