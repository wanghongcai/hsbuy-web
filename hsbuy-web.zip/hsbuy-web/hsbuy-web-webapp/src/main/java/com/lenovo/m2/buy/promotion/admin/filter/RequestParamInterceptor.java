package com.lenovo.m2.buy.promotion.admin.filter;

import com.lenovo.m2.buy.promotion.admin.soa.utils.JsonUtil;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by dulijie on 2016/12/7.
 * 入参打印
 */
public class RequestParamInterceptor implements MethodInterceptor {
    private static Logger log = LoggerFactory.getLogger(RequestParamInterceptor.class);

    @Override
    public Object invoke(MethodInvocation invocation) throws Throwable {
        String methodName = invocation.getMethod().getName();
        String className = invocation.getMethod().getDeclaringClass().getName();

//        String paramStr = "";
//
//        try{
//            Object arguments = invocation.getArguments();
//            if(null != arguments){
//                paramStr = JsonUtil.toJson(invocation.getArguments());
//            }
//        }catch (Exception e){
//            log.info("arguments={}", invocation.getArguments());
//            log.error("parse arguments error", e);
//        }

        log.info("className={}, methodName={}", new Object[]{className, methodName});

        Object ret = invocation.proceed();
        return ret;
    }
}

