package com.lenovo.m2.buy.promotion.admin.controller.api.ordercenter;

import com.lenovo.m2.arch.framework.domain.*;
import com.lenovo.m2.arch.tool.util.DateFormatUtils;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.StringUtil;
import com.lenovo.m2.buy.promotion.admin.controller.util.CheckParamContants;
import com.lenovo.m2.buy.promotion.admin.controller.util.DateUtil;
import com.lenovo.m2.buy.promotion.admin.controller.util.ExcelSAXHandler;
import com.lenovo.m2.buy.promotion.admin.domain.utils.JqGrid;
import com.lenovo.m2.buy.promotion.admin.remote.ordercenter.OpenOrderRemote;
import com.lenovo.m2.hsbuy.common.middleware.RemoteResultFactory;
import com.lenovo.m2.hsbuy.common.middleware.ResultMessageEnum;
import com.lenovo.m2.hsbuy.common.order.OrderConstance;
import com.lenovo.m2.hsbuy.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.domain.order.Deliveries;
import com.lenovo.m2.hsbuy.domain.order.logistics.LogisticTypeEnum;
import com.lenovo.m2.hsbuy.domain.order.logistics.RemoteLogistic;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.domain.order.mongo.Product;
import com.lenovo.m2.hsbuy.domain.order.mongo.Receiver;
import com.lenovo.m2.hsbuy.domain.ordercenter.HSReportVo;
import com.lenovo.m2.hsbuy.domain.ordercenter.OpenHSOrderReconciliationInfo;
import com.lenovo.m2.hsbuy.domain.ordercenter.OrderLogistics;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by yyduff on 2015/10/31.
 */
@RequestMapping("mdb")
@Controller
public class MDBControllor {
    private static final Logger LOGGER = Logger.getLogger(MDBControllor.class);

    @Autowired
    private OpenOrderRemote openOrderRemote;

    @ResponseBody
    @RequestMapping(value = "/mdborder/list", method = {RequestMethod.GET})
    public JqGrid<MongoOrderDetail> getOrderList(HttpServletRequest request, HttpServletResponse response, JqGrid<MongoOrderDetail> jqGrid) {
        try {
            LOGGER.info("----------request parameter:" + jqGrid.getFilter() + "---" + JsonUtil.toJson(jqGrid.genPageQuery()));


            List<String> shopIds = new ArrayList<>();
            shopIds.add("8");
            shopIds.add("9");
            jqGrid.setFilter("shopIds", shopIds);

            String shopId = (String) jqGrid.getFilter().get("shopId");
            if (StringUtils.isEmpty(shopId)) {
                jqGrid.setFilter("shopId", 0);
            } else {
                jqGrid.setFilter("shopId", Integer.parseInt(shopId));
            }

            RemoteResult<PageModel2<MongoOrderDetail>> pageModel = openOrderRemote.getAllMongoOrderList(8, jqGrid.getFilter(), jqGrid.genPageQuery());

            if (pageModel.isSuccess() && pageModel.getT() != null) {
                PageModel2<MongoOrderDetail> model2 = pageModel.getT();

                LOGGER.info("<====PageNum:"+model2.getPageNum()+"====PageSize:"+model2.getPageSize()+"====TotalCount:"+model2.getTotalCount()+"====TotalPageNum:"+model2.getTotalPageNum()+"==>");
                jqGrid.setPageModel2(model2);
                jqGrid.setTotal(Integer.parseInt(model2.getTotalPageNum() + ""));
            }
        } catch(Exception e) {
            LOGGER.error("system erro", e);
        }
        return jqGrid;

    }


    /**
     * 跳转mdb订单查询页面
     */
    @RequestMapping(value = "/mdbOrderManagement", method = RequestMethod.GET)
    public String tomdbOrderManagement() {
        return "/ocn/mdbOrderManagement";
    }


    /**
     * 查看详情
     */
    @RequestMapping(value = "/getOrderInfo")
    @ResponseBody
    public void getOrderInfo(String orderCode, int plat, HttpServletResponse response) {
        LOGGER.info("getOrderInfo orderCode= " + orderCode);
        RemoteResult<MongoOrderDetail> mongoOrder = openOrderRemote.getMongoOrderDetail(Tenant.getTenant(plat), orderCode);
        response.setContentType("text/html;charset=utf-8");
        try {
            response.getWriter().print(JsonUtil.toJson(mongoOrder));
        } catch(IOException e) {
            LOGGER.error(e);
        }
        //return jqGrid;
    }

    /**
     * 查询商品列表
     */
    @RequestMapping(value = "/getProductsByOrderCode", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public JqGrid<Product> getProducts(String orderCode, int plat, HttpServletResponse response, JqGrid<Product> jqGrid) {
        RemoteResult<MongoOrderDetail> mongoOrder = openOrderRemote.getMongoOrderDetail(Tenant.getTenant(plat), orderCode);
        jqGrid.setDateList(mongoOrder.getT().getProducts());
        return jqGrid;
    }

    /**
     * 查询商品列表
     */
    @RequestMapping(value = "/cancel", method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public RemoteResult cancelOrder(String orderCode, int shopId) {
        LOGGER.info("cancelOrder orderCode=" + orderCode + "shopId=" + shopId);
        RemoteResult remoteResult = new RemoteResult(false);
        if (StringUtil.isEmpty(orderCode)) {
            return RemoteResultFactory.getSuccessResult(ResultMessageEnum.PARAM_EMPTY);
        }
        try {
            RemoteResult<MongoOrderDetail> mongoOrder = openOrderRemote.getMongoOrderDetail(Tenant.getTenant(1), orderCode);
            if (!mongoOrder.isSuccess() || mongoOrder.getT() == null) {
                return RemoteResultFactory.getSuccessResult(ResultMessageEnum.PARAM_EMPTY);
            }
            remoteResult = openOrderRemote.cancelOrder(Long.parseLong(orderCode), 3, Tenant.getTenant(Integer.valueOf(mongoOrder.getT().getShopId())));
        } catch(Exception e) {
            LOGGER.error("OpenOrderRemote cancelOrder error:", e);
            remoteResult.setResultCode("999");
            remoteResult.setResultMsg("调用中间件服务异常");
        }
        return remoteResult;
    }


    public static String toUtf8String(String s) {
        StringBuffer sb = new StringBuffer();
        for(int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 0 && c <= 255) {
                sb.append(c);
            } else {
                byte[] b;
                try {
                    b = Character.toString(c).getBytes("utf-8");
                } catch(Exception ex) {
                    LOGGER.error(ex);
                    b = new byte[0];
                }
                for(int j = 0; j < b.length; j++) {
                    int k = b[j];
                    if (k < 0) k += 256;
                    sb.append("%" + Integer.toHexString(k).toUpperCase());
                }
            }
        }
        return sb.toString();
    }


    public static String getDate(Date aDate) {
        SimpleDateFormat df;
        String returnValue = "";
        if (aDate != null) {
            df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            returnValue = df.format(aDate);
        }
        return (returnValue);
    }

    /**
     * 发货
     *
     * @param orderLogistics
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/sendGoods", method = {RequestMethod.POST, RequestMethod.GET})
    public void sendGoods(OrderLogistics orderLogistics, HttpServletRequest request, HttpServletResponse response) {
        LOGGER.info("===into  sendGoods ready go!！orderLogistics=[" + orderLogistics.toString() + "]");
        RemoteResult remoteResult = new RemoteResult(false);
        if (orderLogistics.getOrderId() == 0) {
            remoteResult.setResultCode("1001");
            remoteResult.setResultMsg("前台传入OrderCode为空");
            LOGGER.info("前台传入OrderCode为空");
        } else if (StringUtils.isEmpty(orderLogistics.getLogisticsNo())) {
            remoteResult.setResultCode("1001");
            remoteResult.setResultMsg("物流单号不能为空！");
            LOGGER.info("物流单号不能为空！orderCode=[" + orderLogistics.getOrderId() + "]");
        } else if (StringUtils.isEmpty(orderLogistics.getLogisticsCompanyName())) {
            remoteResult.setResultCode("1001");
            remoteResult.setResultMsg("物流公司不能为空！");
            LOGGER.info("物流公司不能为空！orderCode=[" + orderLogistics.getOrderId() + "]");
        } else {

            RemoteLogistic remoteLogistic = new RemoteLogistic();
            remoteLogistic.setOrderCode(orderLogistics.getOrderId() + "");
            remoteLogistic.setLogiNo(orderLogistics.getLogisticsNo());
            remoteLogistic.setLogiCode(orderLogistics.getLogisticsCompanyCode());
            remoteLogistic.setLogiName(orderLogistics.getLogisticsCompanyName());
            remoteLogistic.setShipDate(DateFormatUtils.format(new Date()));
            //修改人:pengyy4 ,修改原因：未初始化物流类型，无法更改订单状态。
            remoteLogistic.setLogiType(LogisticTypeEnum.GOOD_LOGI.getCode());
            //remoteLogistic.setShipStatus("0");
            remoteLogistic.setShipStatus("1");
            remoteResult = openOrderRemote.logisticsDelivery(remoteLogistic, "indirect");
        }
        response.setContentType("text/html;charset=utf-8");
        try {
            response.getWriter().print(JsonUtil.toJson(remoteResult));
        } catch(IOException e) {
            LOGGER.error(e);
        }

    }

    /**
     * 导出报表查询条件校验
     * @param jqGrid
     */
    @ResponseBody
    @RequestMapping(value = "report/checkParam", method = RequestMethod.POST )
    public String checkParam(JqGrid<MongoOrderDetail> jqGrid) {

        String code;

        try{

            LOGGER.info("----------request parameter checkParam:" + jqGrid.getFilter());
            Map<String,Object> map = jqGrid.getFilter();

            //校验参数是否为null
            if(map != null){
                //校验时间参数是否为null
                if(map.get("createTimeStart") != null && map.get("createTimeEnd") != null){

                    String format = "yyyy-MM-dd";
                    String createTimeStart = ((String[])map.get("createTimeStart"))[0];
                    String createTimeEnd = ((String[])map.get("createTimeEnd"))[0];

                    if(StringUtil.isNotEmpty(createTimeStart) && StringUtil.isNotEmpty(createTimeEnd)){

                        LOGGER.info("-----createTimeStart:" + createTimeStart + "----createTimeEnd:" + createTimeEnd + "--------");
                        //校验起始时间和结束时间的大小
                        if(DateUtil.parseDate4format(createTimeStart,format).before(DateUtil.parseDate4format(createTimeEnd,format))){
                            code = CheckParamContants.RIGHT_PARAM;
                        }else{
                            code = CheckParamContants.ERROR_TIME;
                        }
                    }else {
                        code = CheckParamContants.NULL_TIME;
                    }

                }else{
                    code = CheckParamContants.NULL_TIME;
                }

            }else{
                code = CheckParamContants.NULL_PARAM;
            }

        }catch (Exception e){
            code = CheckParamContants.EROOR_SYSTEM;
            LOGGER.error("checkParam error", e);
        }

        return code;
    }

    private static final int WORKSIZE = 1000;//超过1000条数据使用缓存
    private static final int PAGESIZE = 1000;//pageSize 分页条数
    private static String[] orderExcelHeader = {"订单号", "订单状态", "FA名称", "订单总价", "会员编码", "优惠金额总计", "订单备注",
            "用户支付方式", "支付状态", "支付时间", "收货人邮编", "收货人手机", "收货人姓名", "省份", "城市", "区县", "收货人地址",
            "下单日期", "商户名称","产品组","LenovoId","联想物料编码","商品名称","商品数量","商品单价","折扣总金额","主订单号"};


    /**
     * 导出报表（17及17积分）
     * @param response
     * @param jqGrid
     */
    @ResponseBody
    @RequestMapping(value = "report/exportMdb", method = RequestMethod.GET )
    public void exportMdb(HttpServletResponse response, JqGrid<MongoOrderDetail> jqGrid) {

        LOGGER.info("----------request parameter exportMdb:" + jqGrid.getFilter() + "---" + JsonUtil.toJson(jqGrid.genPageQuery()));

        SXSSFWorkbook workbook = new SXSSFWorkbook(WORKSIZE);
        workbook.setCompressTempFiles(true);
        RemoteResult rs = new RemoteResult(false);

        //设定shopId
        List<String> shopIds = new ArrayList<>();
        shopIds.add("8");
        shopIds.add("9");
        jqGrid.setFilter("shopIds", shopIds);

        String shopId = (String) jqGrid.getFilter().get("shopId");
        if (StringUtils.isEmpty(shopId)) {
            jqGrid.setFilter("shopId", 0);
        } else {
            jqGrid.setFilter("shopId", Integer.parseInt(shopId));
        }

        try {
            //产生工作表对象
            Sheet sheet;
            if(true){
                sheet = ExcelSAXHandler.createSheet(workbook, "17订单列表", orderExcelHeader);
            }else{
                sheet = ExcelSAXHandler.createSheet(workbook, "17积分订单列表", orderExcelHeader);
            }

            boolean hasDates = true;
            int pageNum = 1;
            int rowNum = 1;
            PageQuery pageQuery = new PageQuery(pageNum, PAGESIZE);

            while (hasDates) {
                pageQuery.setPageNum(pageNum);
                RemoteResult<PageModel2<MongoOrderDetail>> pageModel = openOrderRemote.getAllMongoOrderList(8, jqGrid.getFilter(), pageQuery);

                if (com.alibaba.dubbo.common.utils.CollectionUtils.isNotEmpty(pageModel.getT().getDatas()) && pageModel.getT().getDatas().size() < PAGESIZE) {
                    rowNum = buildDataFor17OrderList(sheet, pageModel.getT().getDatas(), rowNum);
                    hasDates = false;
                } else if (pageModel != null && com.alibaba.dubbo.common.utils.CollectionUtils.isEmpty(pageModel.getT().getDatas())) {
                    hasDates = false;
                } else {
                    rowNum = buildDataFor17OrderList(sheet, pageModel.getT().getDatas(), rowNum);
                    pageNum++;
                }
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            workbook.write(baos);
            byte[] content = baos.toByteArray();
            response.reset();
            response.setContentType("content-disposition");
            response.addHeader("Content-Disposition", "attachment; filename=\""+ UUID.randomUUID().toString().replaceAll("-","")+".xlsx\"");
            ServletOutputStream outputStream = response.getOutputStream();
            outputStream.write(content, 0, content.length);
            outputStream.flush();

        } catch (Exception e) {
            LOGGER.error("17订单报表导出异常", e);
            try {
                if (workbook != null) {
                    workbook.dispose();
                    workbook.close();

                }
            } catch (IOException e1) {
                LOGGER.error("17订单报表关闭workbook异常", e1);
            }
        }

    }


    /**
     * 封装17及17积分订单列表excel数据
     *
     * @param sheet
     */
    private int buildDataFor17OrderList(Sheet sheet, List<MongoOrderDetail> list, int rows) {

        LOGGER.info("<===============封装订单excel数据 start=========>");

        for (int i = 0; i < list.size(); i++) {
            int firstCell = 0;
            MongoOrderDetail mongoOrderDetail = list.get(i);
            Row row = sheet.createRow(rows);//创建一行
            rows++;
            if (mongoOrderDetail == null) {
                continue;
            }

            ExcelSAXHandler.setCellValue(firstCell++, row, mongoOrderDetail.getOrderCode()); //订单编号
            String orderStatus = null;
            switch (Integer.parseInt(mongoOrderDetail.getOrderStatus())){
                case 0:
                    orderStatus = "正常订单";
                    break;
                case 1:
                    orderStatus = "取消订单";
                    break;
                case 2:
                    orderStatus = "已支付";
                    break;
                case 3:
                    orderStatus = "已发货";
                    break;
                case 4:
                    orderStatus = "已签收";
                    break;
                default:
                    orderStatus = "";
                    break;
            }
            ExcelSAXHandler.setCellValue(firstCell++, row, orderStatus); //订单状态
            ExcelSAXHandler.setCellValue(firstCell++, row, mongoOrderDetail.getFaname()); //FA名称
            ExcelSAXHandler.setCellValue(firstCell++, row, mongoOrderDetail.getCostItem()); //订单总价
            ExcelSAXHandler.setCellValue(firstCell++, row, mongoOrderDetail.getMemberCode()); //会员编码
            ExcelSAXHandler.setCellValue(firstCell++, row, mongoOrderDetail.getGiveawayTotal()); //优惠金额总计
            ExcelSAXHandler.setCellValue(firstCell++, row, mongoOrderDetail.getMarkText()); //订单备注
            ExcelSAXHandler.setCellValue(firstCell++, row, mongoOrderDetail.getPaymentType()); //用户支付方式

            String payStatus = null;
            switch (Integer.parseInt(mongoOrderDetail.getPayStatus())){
                case 0:
                    payStatus = "未支付";
                    break;
                case 1:
                    payStatus = "已支付";
                    break;
                default:
                    payStatus = "";
                    break;
            }
            ExcelSAXHandler.setCellValue(firstCell++, row, payStatus); //支付状态
            ExcelSAXHandler.setCellValue(firstCell++, row, mongoOrderDetail.getPayDatetime()); //支付时间

            String shipName = null,shipAddr = null,shipZip = null,shipCity = null,deliverCounty = null,deliverAreaName = null,shipMobile = null;
            if(mongoOrderDetail.getDeliveries() != null && mongoOrderDetail.getDeliveries().size() > 0){
                Receiver receiver = mongoOrderDetail.getDeliveries().get(0);
                shipName = receiver.getShipName();
                shipAddr = receiver.getShipAddr();
                shipZip = receiver.getShipZip();
                shipCity = receiver.getShipCity();
                deliverCounty = receiver.getDeliverCounty();
                deliverAreaName = receiver.getDeliverAreaName();
                shipMobile = receiver.getShipMobile();
            }
            ExcelSAXHandler.setCellValue(firstCell++, row, shipZip); //收货人邮编
            ExcelSAXHandler.setCellValue(firstCell++, row, shipMobile); //收货人手机
            ExcelSAXHandler.setCellValue(firstCell++, row, shipName); //收货人姓名
            ExcelSAXHandler.setCellValue(firstCell++, row, deliverAreaName); //省份
            ExcelSAXHandler.setCellValue(firstCell++, row, shipCity); //城市
            ExcelSAXHandler.setCellValue(firstCell++, row, deliverCounty); //区县
            ExcelSAXHandler.setCellValue(firstCell++, row, shipAddr); //收货人地址
            ExcelSAXHandler.setCellValue(firstCell++, row, mongoOrderDetail.getCreateTime()); //下单日期

            String shopName = null;
            switch (Integer.parseInt(mongoOrderDetail.getShopId())){
                case 8:
                    shopName = "17商城";
                    break;
                case 9:
                    shopName = "17积分商城";
                    break;
                default:
                    shopName = "";
                    break;
            }
            ExcelSAXHandler.setCellValue(firstCell++, row, shopName); //商户名称

            String productName = null,productNumber = null,lenovoProductCode = null,deatLike = null;
            Money productPay = null,favourablePay = null;
            if(mongoOrderDetail.getProducts() != null && mongoOrderDetail.getProducts().size() > 0 ){
                Product product = mongoOrderDetail.getProducts().get(0);
                productName = product.getProductName();
                productNumber = product.getProductNumber();
                productPay = product.getProductPay();
                favourablePay = product.getFavourablePay();
                lenovoProductCode = product.getLenovoProductCode();
                deatLike = product.getDeatLike();
            }

            ExcelSAXHandler.setCellValue(firstCell++, row, deatLike); //产品组
            ExcelSAXHandler.setCellValue(firstCell++, row, mongoOrderDetail.getLenovoId()); //LenovoId
            ExcelSAXHandler.setCellValue(firstCell++, row, lenovoProductCode); //联想物料编码
            ExcelSAXHandler.setCellValue(firstCell++, row, productName); //商品名称
            ExcelSAXHandler.setCellValue(firstCell++, row, productNumber); //商品数量
            ExcelSAXHandler.setCellValue(firstCell++, row, productPay); //商品单价
            ExcelSAXHandler.setCellValue(firstCell++, row, favourablePay); //折扣总金额
            ExcelSAXHandler.setCellValue(firstCell++, row, mongoOrderDetail.getOrderMainCode()); //主订单号

        }

        LOGGER.info("<===============封装订单excel数据 end=========>");

        return rows;
    }
}
