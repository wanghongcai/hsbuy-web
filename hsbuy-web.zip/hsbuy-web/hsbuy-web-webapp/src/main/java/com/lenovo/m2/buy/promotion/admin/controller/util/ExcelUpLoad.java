package com.lenovo.m2.buy.promotion.admin.controller.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lenovo.fileclient.PrivateSpcaceManager;
import com.lenovo.fileclient.UploadImageClient;
import com.lenovo.fileclient.common.UploadResponse;
import com.lenovo.m2.buy.promotion.admin.soa.utils.JsonUtil;


/**
 * excel 文件上传
 * Created by wangyu46 on 2017/6/9.
 */
public class ExcelUpLoad  {
    
	private static Logger log = LoggerFactory.getLogger(ExcelUpLoad.class);

//	//标题
//    private String title;
//    //列名
//    private String[] rowName ;
    
//    /**
//     * 数据 (每一行对象   Object[]每一个单元格对象)
//     */
//    private List<List<Object>>  dataList = new ArrayList<List<Object>>();
    
   //--------- url服务数据
    
    private String fileName;  						//文件名
    private String appid;
    private String appkey;
    private String targetReconciliationFilePath;	 //目标路径
    private String str = "1";    
    private String imageserverurl; 					 //文件服务url
    private String domain; 							 //生成地址
    
 
    
    /**
     * excel 文件上传  返回 excelUrl
     * @return
     * @throws Exception 
     */
	public String getExcelUrl(Workbook workbook) {
		
		String readURL = "";
		try {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			workbook.write(byteArrayOutputStream);
	        long timeStamp = new Date().getTime();
	        String token = UploadImageClient.getToken(appid, appkey, timeStamp, targetReconciliationFilePath + fileName, str);
			
	        UploadResponse uploadResponse = UploadImageClient.upload(appid, token, timeStamp, imageserverurl + targetReconciliationFilePath + fileName, byteArrayOutputStream.toByteArray(), fileName, str);
	        log.info("uploadResponse = {}", JsonUtil.toJson(uploadResponse));
	        readURL = PrivateSpcaceManager.getReadURL(appid, appkey, domain, targetReconciliationFilePath + fileName);
	        log.info("readURL={}", readURL);
		} catch (Exception e) {
			log.error("文件上传异常", e);
		}
		return readURL;
	}
   
	
	  //url服务数据设置
    public ExcelUpLoad(String fileName,String appid,String appkey,String targetReconciliationFilePath
    		,String imageserverurl,String domain){
    	this.fileName = fileName;
    	this.appid = appid;
    	this.appkey = appkey;
    	this.targetReconciliationFilePath = targetReconciliationFilePath;
    	this.imageserverurl = imageserverurl;
    	this.domain = domain;
    }
      
    
}