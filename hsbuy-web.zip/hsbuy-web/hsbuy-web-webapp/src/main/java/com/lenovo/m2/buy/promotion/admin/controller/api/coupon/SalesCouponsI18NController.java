
package com.lenovo.m2.buy.promotion.admin.controller.api.coupon;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.google.gson.Gson;
import com.lenovo.fileclient.PrivateSpcaceManager;
import com.lenovo.fileclient.UploadImageClient;
import com.lenovo.fileclient.common.UploadResponse;
import com.lenovo.m2.arch.framework.domain.*;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.buy.promotion.admin.controller.util.DateUtil;
import com.lenovo.m2.buy.promotion.admin.controller.util.ExcelUtils;
import com.lenovo.m2.buy.promotion.admin.controller.util.JsonUtil;
import com.lenovo.m2.buy.promotion.admin.controller.util.ZipUtils;
import com.lenovo.m2.buy.promotion.admin.domain.coupon.ExtErrorVo;
import com.lenovo.m2.buy.promotion.admin.domain.coupon.JacksonUtil;
import com.lenovo.m2.buy.promotion.admin.manager.couponManager.AdminGetCouponService;
import com.lenovo.m2.buy.promotion.admin.remote.coupon.*;
import com.lenovo.m2.couponV2.api.dubboModel.MemberExcelTempApi;
import com.lenovo.m2.couponV2.api.model.*;
import com.lenovo.m2.couponV2.common.*;
import com.lenovo.m2.couponV2.common.enums.ErrorMessageEnum;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import com.lenovo.m2.hsbuy.common.pruchase.util.StringUtil;
import com.lenovo.m2.ordercenter.soa.api.vat.VatApiOrderCenter;
import com.lenovo.m2.ordercenter.soa.domain.forward.OrdersReportVo;
import net.sf.json.JSONObject;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.beetl.core.Configuration;
import org.beetl.core.GroupTemplate;
import org.beetl.core.Template;
import org.beetl.core.resource.ClasspathResourceLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * Created by fenglg1 on 2017/2/17.
 */
@Controller
@Scope("prototype")
@RequestMapping("/api/coupon")
public class SalesCouponsI18NController extends BaseController{

    protected static Logger logger = LoggerFactory.getLogger(SalesCouponsI18NController.class);

    public static final int PAGE_SIZE = 10;
    public static final int PAGE_MAXSIZE = 100;
    private static final int EXPORT_MAX_PAGE_SIZE = 100000;
    private static final int ROW_LINE = 1000;
    private static final String CONTENT_TYPE = "text/plain; charset=utf-8";
    String[] salescouponsHeader = {"id", "优惠券类型", "商城", "平台", "使用条件", "券名称", "券编码", "券类型", "金额","币种","规则描述", "赠送条件", "是否可领取", "领取开始时间", "领取结束时间", "有效期开始时间", "有效期结束时间", "后台发放", "资格券",  "券分类", "状态", "创建时间", "更新时间", "操作人"};
    String[] couponsHeader={"优惠券ID", "优惠券名称", "LenovoID", "会员帐号", "优惠券金额", "状态", "使用时间"};
    String[] couponsCodeHeader={"批次号","码名称","码","商城","平台","开始时间","结束时间","金额","币种","总可用次数","已经使用次数","绑定规则","创建人","创建时间"};

    String[] couponsOrderHeader={"优惠券ID", "优惠券名称", "LenovoID", "会员帐号", "优惠券金额", "状态", "使用时间", "主订单号", "子订单号", "订单金额", "支付金额", "商品名称", "购买数量", "商品编号", "产品组", "物料编号", "收件人", "收件人手机号", "省", "市", "区/县", "详细地址", "下单时间", "支付时间"};
    private String appId = "coupon";
    private String appKey = "YjXHGtnoBOMMsE2n";
    private String domain = "coupon.app.lefile.cn";
    private static String targetCouponFilePath = "/coupon/";
    private static String targetCouponCodeFilePath = "/couponCode/";
    private String imageServerURL = "http://internal-up.lefile.cn/image/upload";
    private int fetchNumber = 10;

    @Autowired
    private SalescouponsRemote salescouponsRemote;
    @Autowired
    MemberCouponServiceRemote adminMemberCouponService;
    @Autowired
    private CouponsCategoryRemote adminCouponsCategoryService;
    @Autowired
    CouponchecksServiceRemote adminCouponCheckService;
    @Autowired
    private UsergroupcouponrelRemote adminUsergroupcouponrelService;
    @Autowired
    private CouponsRemote adminCouponsService;
    @Autowired
    private AdminGetCouponService adminGetCouponsService;
    @Autowired
    private VatApiOrderCenter vatApiOrderCenter;

    /**
     * 分页查询优惠券或优惠码，用style字段区分查询优惠券（style=1）还是优惠码（style=2）
     * @param request
     * @param response
     * @param map
     */
    @RequestMapping(value = "/queryInfoByPage")
    @ResponseBody
    public void querySalescouponsInfoPage(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        String invokeMethod = "api/coupon/queryInfoByPage";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        try {
            Map<String, Object> conditionMap = new HashMap<String, Object>();
            List<String> shopIdList = AuthData.getShopIds(request);
            String style = request.getParameter("style");
            String name = request.getParameter("name");
            String couponcode = request.getParameter("couponcode");
            String amount = request.getParameter("amount");
            String usescope = request.getParameter("usescope");
            String status = request.getParameter("status");
            String iscanget = request.getParameter("iscanget");
            String getstarttime = request.getParameter("getstarttime");
            String getendtime = request.getParameter("getendtime");
            String fromtime = request.getParameter("fromtime");
            String totime = request.getParameter("totime");
            String createtime_start = request.getParameter("createtime_start");
            String createtime_end = request.getParameter("createtime_end");
            String shopid = request.getParameter("shopid");
            String terminal = request.getParameter("terminal");
            String classification = request.getParameter("classification");
            String classificationName = request.getParameter("classificationName");
            String pageSize = request.getParameter("rows");
            String maxNumber = request.getParameter("maxnumber");
            String type = request.getParameter("type");
            String materialcodes = request.getParameter("materialcodes");

            conditionMap.put("style", Integer.parseInt(style));//查询优惠券
            conditionMap.put("name", name);
            conditionMap.put("couponcode", couponcode);
            conditionMap.put("amount", amount);

            PageQuery pageQuery=null;
            if(StringUtils.isNotEmpty(pageSize)){
                pageQuery = new PageQuery(getPage(request),Integer.parseInt(pageSize));
            }else{
                pageQuery = new PageQuery(getPage(request),PAGE_SIZE);
            }

            if (CollectionUtils.isNotEmpty(shopIdList)){
                conditionMap.put("shopids",shopIdList);
            }else {
                remoteResult.setResultCode("02");
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("没有权限查询数据！");
                remoteResult.setT(new PageModel2<CouponsCategoryApi>(pageQuery, new ArrayList()));
            }
            if (StringUtils.isNotEmpty(usescope) && !"99".equals(usescope)) {
                conditionMap.put("usescope", usescope);
            }
            if (StringUtils.isNotEmpty(status) && !"99".equals(status)) {
                conditionMap.put("status", status);
            }
            if (StringUtils.isNotEmpty(iscanget) && !"99".equals(iscanget)) {
                conditionMap.put("iscanget", iscanget);
            }
            if (StringUtils.isNotEmpty(getstarttime)) {
                conditionMap.put("getstarttime", DateUtil.format4easyui(getstarttime));
            }
            if (StringUtils.isNotEmpty(getendtime)) {
                conditionMap.put("getendtime", DateUtil.format4easyui(getendtime));
            }
            if (StringUtils.isNotEmpty(fromtime)) {
                conditionMap.put("fromtime", DateUtil.format4easyui(fromtime));
            }
            if (StringUtils.isNotEmpty(totime)) {
                conditionMap.put("totime", DateUtil.format4easyui(totime));
            }
            if (StringUtils.isNotEmpty(createtime_start)) {
                conditionMap.put("createtime_start", DateUtil.format4easyui(createtime_start));
            }
            if (StringUtils.isNotEmpty(createtime_end)) {
                conditionMap.put("createtime_end", DateUtil.format4easyui(createtime_end));
            }
            if (StringUtils.isNotEmpty(shopid) && !"99".equals(shopid)) {
                conditionMap.put("shopid", shopid);
            }
            if (StringUtils.isNotEmpty(terminal) && !"99".equals(terminal)) {
                conditionMap.put("terminal", terminal);
            }
            if (StringUtils.isNotEmpty(maxNumber)){
                conditionMap.put("totalNumber", maxNumber);
            }
            if (StringUtils.isNotEmpty(type) && !"99".equals(type)) {
                conditionMap.put("type", type);
            }
            if (StringUtils.isNotEmpty(materialcodes)) {
                conditionMap.put("materialcodes", materialcodes);
            }
            conditionMap.put("classification", classification);
            conditionMap.put("classificationName", classificationName);
            Gson g = new Gson();
            RemoteResult<PageModel2<SalescouponsApi>> result = salescouponsRemote.getSalescouponsInfoPage(pageQuery, conditionMap);
            printResult(invokeMethod, result);
            if (result != null && result.getT() != null && result.isSuccess()) {
                PageModel2<SalescouponsApi> pageModel2 = result.getT();
                remoteResult.setResultCode("00");
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("查询成功");
                remoteResult.setT(pageModel2);
            }else {
                remoteResult.setResultCode("01");
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("没有查询到数据");
                remoteResult.setT(new PageModel2<CouponsCategoryApi>(pageQuery, new ArrayList()));
            }

            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 分页查询用户优惠券列表
     * @param request
     * @param response
     * @param map
     */
    @RequestMapping(value = "/member/queryCouponInfoByPage", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void queryMemberCouponInfoPage(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        String invokeMethod = "api/coupon/member/queryCouponInfoByPage";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        try {
            Map<String,Object> conditionMap = new HashMap<String, Object>();
            List<String> shopIdList = AuthData.getShopIds(request);
            String name = request.getParameter("name");//券名称
            String couponcode = request.getParameter("couponcode");//券编码
            String lenovoid = request.getParameter("lenovoid");//LenovoId
            String usescope = request.getParameter("usescope");//折扣券满减券等
            String membercode = request.getParameter("membercode");//用户登录名
            String disabled = request.getParameter("disabled");//是否禁用0未禁用、1禁用
            String classificationname = request.getParameter("classificationname");//分类名称
            String fromtime = request.getParameter("fromtime");//有效开始时间
            String totime = request.getParameter("totime");//有效结束时间
            String createtime_start = request.getParameter("createtime_start");//创建开始时间
            String createtime_end = request.getParameter("createtime_end");//创建结束时间
            String shopid = request.getParameter("shopId");//商户：Lenovo think epp moto等
            String terminal = request.getParameter("terminal");//终端：0pc 1wap 2android 3ios 99不区分终端
            String classification = request.getParameter("classification");//券分类编码
            String pageSize = request.getParameter("rows");//页容量

            PageQuery pageQuery=null;
            if(StringUtils.isNotEmpty(pageSize)){
                pageQuery = new PageQuery(getPage(request),Integer.parseInt(pageSize));
            }else{
                pageQuery = new PageQuery(getPage(request),PAGE_SIZE);
            }

            if (CollectionUtils.isNotEmpty(shopIdList)){
                conditionMap.put("shopids",shopIdList);
            }else {
                remoteResult.setResultCode("02");
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("没有权限查询数据！");
                remoteResult.setT(new PageModel2<MembercouponrelsApi>(pageQuery, new ArrayList()));
            }
            if (StringUtils.isNotEmpty(name)){
                conditionMap.put("name",name);
            }
            if (StringUtils.isNotEmpty(couponcode)){
                conditionMap.put("couponcode",couponcode);
            }
            if (StringUtils.isNotEmpty(lenovoid)){
                conditionMap.put("lenovoid",lenovoid);
            }
            if (StringUtils.isNotEmpty(membercode)){
                conditionMap.put("membercode",membercode);
            }
            if (StringUtils.isNotEmpty(classificationname)){
                conditionMap.put("classificationname",classificationname);
            }
            if (StringUtils.isNotEmpty(classification)){
                conditionMap.put("classification",classification);
            }
            if(StringUtils.isNotEmpty(usescope) && !"99".equals(usescope)){
                conditionMap.put("usescope",usescope);
            }
            if(StringUtils.isNotEmpty(disabled) && !"99".equals(disabled)){
                conditionMap.put("disabled",disabled);
            }
            if(StringUtils.isNotEmpty(fromtime)){
                conditionMap.put("fromtime",fromtime);
            }
            if(StringUtils.isNotEmpty(totime)){
                conditionMap.put("totime",totime);
            }
            if(StringUtils.isNotEmpty(createtime_start)){
                conditionMap.put("createtime_start",createtime_start);
            }
            if(StringUtils.isNotEmpty(createtime_end)){
                conditionMap.put("createtime_end",createtime_end);
            }
            if(StringUtils.isNotEmpty(shopid)){
                conditionMap.put("shopid", shopid);
            }
            if(StringUtils.isNotEmpty(terminal) && !"99".equals(terminal)){
                conditionMap.put("terminal",terminal);
            }
            logger.info("getMemberCouponsInfoPage param={}"+JsonUtil.toJson(conditionMap)+"pageQuery={}"+pageQuery);
            RemoteResult<PageModel2<MembercouponrelsApi>> result = adminMemberCouponService.getMemberCouponsInfoPage(pageQuery, conditionMap);
            logger.info("getMemberCouponsInfoPage result={}"+JsonUtil.toJson(result));
            printResult(invokeMethod, result);
            if( result != null && result.getT()!=null && result.isSuccess()){
                PageModel2<MembercouponrelsApi> pageModel2 = result.getT();
                remoteResult.setResultCode("00");
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("操作成功");
                remoteResult.setT(pageModel2);
            }else {
                remoteResult.setResultCode("01");
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("没有查询到数据");
                remoteResult.setT(new PageModel2<MembercouponrelsApi>(pageQuery, new ArrayList()));
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 分页查询优惠券类别
     * @param request
     * @param response
     * @param map
     */
    @RequestMapping(value = "/category/queryInfoByPage", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void queryCouponCategoryInfoPage(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        String invokeMethod = "api/coupon/category/queryInfoByPage";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        try {
            Map<String,Object> conditionMap = new HashMap<String, Object>();
            List<String> shopIdList = AuthData.getShopIds(request);
            String superposition = request.getParameter("superposition");//是否叠加 1是　０否
            String usescope = request.getParameter("usescope");//折扣券满减券等
            String classificationname = request.getParameter("classificationname");//分类名称
            String createtime_start = request.getParameter("createtime_start");//创建开始时间
            String createtime_end = request.getParameter("createtime_end");//创建结束时间
            String shopid = request.getParameter("shopId");//商户：Lenovo think epp moto等
            String terminal = request.getParameter("terminal");//终端：0pc 1wap 2android 3ios 99不区分终端
            String disable = request.getParameter("disable");//终端：0pc 1wap 2android 3ios 99不区分终端
            String pageSize = request.getParameter("rows");//页容量

            PageQuery pageQuery=null;
            if(StringUtils.isNotEmpty(pageSize)){
                pageQuery = new PageQuery(getPage(request),Integer.parseInt(pageSize));
            }else{
                pageQuery = new PageQuery(getPage(request),PAGE_SIZE);
            }

            if (CollectionUtils.isNotEmpty(shopIdList)){
                conditionMap.put("shopids",shopIdList);
            }else {
                remoteResult.setResultCode("02");
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("没有权限查询数据！");
                remoteResult.setT(new PageModel2<CouponsCategoryApi>(pageQuery, new ArrayList()));
            }
            if(StringUtils.isNotEmpty(shopid)){
                conditionMap.put("shopid", shopid);
            }
            if (StringUtils.isNotEmpty(classificationname)){
                conditionMap.put("classificationname",classificationname);
            }
            if(StringUtils.isNotEmpty(usescope) && !"99".equals(usescope)){
                conditionMap.put("usescope",usescope);
            }
            if(StringUtils.isNotEmpty(createtime_start)){
                conditionMap.put("createtime_start",createtime_start);
            }
            if(StringUtils.isNotEmpty(createtime_end)){
                conditionMap.put("createtime_end",createtime_end);
            }
            if(StringUtils.isNotEmpty(terminal) && !"99".equals(terminal)){
                conditionMap.put("terminal",terminal);
            }
            if (StringUtils.isNotEmpty(superposition) && !"99".equals(superposition)){
                conditionMap.put("superposition",superposition);
            }
            if (StringUtils.isNotEmpty(disable) && !"99".equals(disable)){
                conditionMap.put("disable",disable);
            }

            RemoteResult<PageModel2<CouponsCategoryApi>> result = adminCouponsCategoryService.getCouponsCategoryInfoPage(pageQuery, conditionMap);
            printResult(invokeMethod, result);
            if( result!=null && result.isSuccess() && result.getT() != null && CollectionUtils.isNotEmpty(result.getT().getDatas())){
                PageModel2<CouponsCategoryApi> pageModel2 = result.getT();
                remoteResult.setResultCode("00");
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("操作成功");
                remoteResult.setT(pageModel2);
            }else {
                remoteResult.setResultCode("01");
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("结果为空");
                remoteResult.setT(new PageModel2<CouponsCategoryApi>(pageQuery, new ArrayList()));
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 分页查询待审核优惠券或优惠码，Style=1为优惠券，Style=2为优惠码
     * @param request
     * @param response
     * @param map
     */
    @RequestMapping(value = "/check/queryInfoByPage" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void queryCouponChecksInfoPage(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        String invokeMethod = "api/coupon/check/queryInfoByPage";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
            return;
        }
        try {
            Map<String,Object> conditionMap = new HashMap<String, Object>();
            List<String> shopIdList = AuthData.getShopIds(request);
            String style = request.getParameter("style");//类型 1 优惠券 2优惠码
            String name = request.getParameter("name");//名称
            String checkstatus = request.getParameter("checkstatus");//审核状态
            String createtime_start = request.getParameter("createtime_start");//创建开始时间
            String createtime_end = request.getParameter("createtime_end");//创建结束时间
            String pageSize = request.getParameter("rows");//页容量

            PageQuery pageQuery=null;
            if(StringUtils.isNotEmpty(pageSize)){
                pageQuery = new PageQuery(getPage(request),Integer.parseInt(pageSize));
            }else{
                pageQuery = new PageQuery(getPage(request),PAGE_SIZE);
            }

            if(CollectionUtils.isNotEmpty(shopIdList)){
                conditionMap.put("shopids",shopIdList);
            }else {
                remoteResult.setResultCode("02");
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("没有权限查询数据！");
                remoteResult.setT(new PageModel2<CouponsCategoryApi>(pageQuery, new ArrayList()));
            }
            if (StringUtils.isNotEmpty(name)){
                conditionMap.put("name",name);
            }
            if(StringUtils.isNotEmpty(style) && !"99".equals(style)){
                conditionMap.put("style",style);
            }
            if(StringUtils.isNotEmpty(createtime_start)){
                conditionMap.put("createtime_start",createtime_start);
            }
            if(StringUtils.isNotEmpty(createtime_end)){
                conditionMap.put("createtime_end",createtime_end);
            }
            if(StringUtils.isNotEmpty(checkstatus) && !"99".equals(checkstatus)){
                conditionMap.put("checkstatus",checkstatus);
            }

            RemoteResult<PageModel2<CouponchecksApi>> result = adminCouponCheckService.getCouponsCheckInfoPage(pageQuery, conditionMap);
            printResult(invokeMethod, result);
            if( result!=null && result.getT()!=null && result.isSuccess()){
                PageModel2<CouponchecksApi> pageModel2 = result.getT();
                remoteResult.setResultCode("00");
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("操作成功");
                remoteResult.setT(pageModel2);
            }else {
                remoteResult.setResultCode("01");
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("结果为空");
                remoteResult.setT(new PageModel2<CouponsCategoryApi>(pageQuery, new ArrayList()));
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
        } catch (NumberFormatException e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 根据UseScope获取所有有效的优惠券，积分商品绑定优惠券使用
     * @param request
     * @param response
     * @param map
     */
    @RequestMapping(value = "/queryCouponByUseScope" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void querySalescouponsByUserScope(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map){
        String invokeMethod = "api/coupon/queryCouponByUseScope";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        try {
            String shopId = request.getParameter("shopId");
            String useScope = request.getParameter("useScope");
            String couponId = request.getParameter("couponId");
            String couponName = request.getParameter("couponName");
            logger.info(String.format("queryCouponByUseScope 参数：shopId=%s, useScope=%s, couponId=%s, couponName=%s", shopId, useScope, couponId, couponName));
            if(StringUtils.isEmpty(shopId) || StringUtils.isEmpty(useScope)){
                remoteResult.setResultCode("01");
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("参数错误");
                printWriter.write(JsonUtil.toJson(remoteResult));
                printWriter.close();
                return;
            }
            Tenant tenant = new Tenant();
            tenant.setShopId(Integer.valueOf(shopId));
            RemoteResult<List<SalescouponsApi>> result = salescouponsRemote.getSalescouponsByUseScope(tenant, Integer.parseInt(useScope), couponId, couponName);
            printResult(invokeMethod, result);
            if(result != null && result.isSuccess()){
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("00");
                remoteResult.setResultMsg("操作成功");
                remoteResult.setT(result.getT());
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("02");
                remoteResult.setResultMsg("结果为空");
                remoteResult.setT(null);
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    @RequestMapping(value = "/toCheckCoupon",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String editCouponsCategory(HttpServletRequest request,HttpServletResponse response,CouponchecksApi couponchecksApi){
        RemoteResult<Boolean> remoteResult = new RemoteResult<Boolean>(false);
        if(couponchecksApi != null ){
            try {
                String itCode = getItCode();
                if (StringUtils.isEmpty(itCode)){
                    logger.info("未获取到用户itcode");
                    return "error";
                }
                couponchecksApi.setUpdateby(itCode);
                couponchecksApi.setCheckpersonid(itCode);
                if (couponchecksApi.getShopid().equals("8") && couponchecksApi.getCheckstatus()==2){
                    couponchecksApi.setSecondsCheckPersonID(itCode);
                    couponchecksApi.setSecondsCheckPostTime(new Date());
                }
                couponchecksApi.setUpdatetime(new Date());
                couponchecksApi.setCheckposttime(new Date());
                remoteResult= adminCouponCheckService.checkCouponByCondition(couponchecksApi);
                return JsonUtil.toJson(remoteResult);
            } catch (Exception e) {
                logger.error(ExceptionUtil.getStackTrace(e));
            }

        }
        return JsonUtil.toJson(remoteResult);
    }

    /**
     * 新建优惠券
     * @param request
     * @param response
     * @param salescouponsApi
     * @param map
     */
    @RequestMapping(value = "/addSalescoupon" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void addSalescoupon(HttpServletRequest request, HttpServletResponse response, SalescouponsApi salescouponsApi, Map<String, Object> map){
        String groups2facodes = request.getParameter("groups2facodes");
        logger.info("addSalescoupon param  groups2facodes:{}",groups2facodes);
        String invokeMethod = "api/coupon/addSalescoupon";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        Date currentTime = new Date();
        try {
            String itCode = AuthData.getUserId(request);
            salescouponsApi.setCouponcode("1111");//优惠券code生成规则  -todo
            salescouponsApi.setStatus(CouponConstant.COUPON_STATUS_NEW_0);
            salescouponsApi.setWholenumber(0);//发全员券次数
            salescouponsApi.setCreateby(itCode);
            salescouponsApi.setCreatetime(currentTime);
            salescouponsApi.setUpdatetime(currentTime);
            salescouponsApi.setHaspassed(0);//有没有审核通过过，1有过
            salescouponsApi.setBacksend(0);//有没有发过券，前后台发券都算
            salescouponsApi.setNoticeValidCount(0);//通知商品和查询有效的次数，
            salescouponsApi.setNoticeInvalidCount(0);//通知商品和查询无效的次数，

            String maxNumLimit = request.getParameter("limitMaxnumber");
            int limitSymbol = salescouponsApi.getLimitSymbol();
            // maxNumLimit  0:
            if(limitSymbol == 0){
                salescouponsApi.setMaxnumber(Integer.MAX_VALUE);
            }else if(limitSymbol == 1){
                Integer maxNumber = salescouponsApi.getMaxnumber();
                maxNumber = maxNumber == null ? new Integer(0) : maxNumber;
                salescouponsApi.setMaxnumber(maxNumber);
            }

            if(salescouponsApi.getUsescope() == CouponConstant.COUPON_USESCOPE_YIJIUHUANXIN){
                salescouponsApi.setType(0);//依旧换新设置为0 代表什么都不绑定
                salescouponsApi.setCouponway(null); //couponway字段只有epp再用，其他情况为null
            }

            //分类
            List<DetailsruleApi> detailsruleApiList = null;
            if (CouponConstant.COUPON_TYPE_DETAIL_1 == salescouponsApi.getType() ) {
                if(StringUtils.isNotEmpty(salescouponsApi.getGoodscategoryids())){
                    String nojoincodes = salescouponsApi.getGoodcodes();
                    detailsruleApiList = new ArrayList<DetailsruleApi>();
                    DetailsruleApi dapi = null;
                    String[] cate = salescouponsApi.getGoodscategoryids().split(",");
                    for (String s : cate) {
                        dapi = new DetailsruleApi();
                        dapi.setGoodscategoryid(s);
                        dapi.setCreateby(itCode);
                        dapi.setCreatetime(currentTime);
                        dapi.setStyle(CouponConstant.COUPON_style_coupon_1);
                        dapi.setUpdatetime(currentTime);
                        dapi.setNojoincodes(salescouponsApi.getGoodcodes());
                        detailsruleApiList.add(dapi);
                    }
                    salescouponsApi.setDetailsruleApiList(detailsruleApiList);
                }else {
                    remoteResult.setResultCode("02");
                    remoteResult.setSuccess(false);
                    remoteResult.setResultMsg("绑定分类必须有商品分类数据！");
                    printWriter.write(JsonUtil.toJson(remoteResult));
                    printWriter.close();
                    return;
                }
            }

            //商品
            if (CouponConstant.COUPON_TYPE_PRODUCT_2 == salescouponsApi.getType()) {
                if (StringUtils.isNotEmpty(salescouponsApi.getGoodcodes())) {
                    ProductruleApi productruleApi = new ProductruleApi();
                    productruleApi.setStyle(CouponConstant.COUPON_style_coupon_1);
                    productruleApi.setGoodscodes(salescouponsApi.getGoodcodes());
                    productruleApi.setCreateby(itCode);
                    productruleApi.setCreatetime(currentTime);
                    productruleApi.setUpdatetime(currentTime);
                    productruleApi.setMaterialcodes(request.getParameter("materialcodes"));
                    salescouponsApi.setProductruleApi(productruleApi);
                } else {
                    remoteResult.setResultCode("03");
                    remoteResult.setSuccess(false);
                    remoteResult.setResultMsg("绑定商品必须有商品数据！");
                    printWriter.write(JsonUtil.toJson(remoteResult));
                    printWriter.close();
                    return;
                }
            }

            //产品组
            List<DistributorruleApi> distributorApiList = null;
            if (CouponConstant.COUPON_TYPE_PRODUCTGROUP_3 == salescouponsApi.getType() ) {
                if(StringUtil.isEmpty(groups2facodes)){
                    remoteResult.setResultCode("02");
                    remoteResult.setSuccess(false);
                    remoteResult.setResultMsg("参数，产品组和分销商信息有误!");
                    printWriter.write(JsonUtil.toJson(remoteResult));
                    printWriter.close();
                    return;
                }
                List<Product2FaRelationsApi> tempList = JsonUtil.readValuesAsArrayList(groups2facodes, Product2FaRelationsApi.class);
                salescouponsApi.setGroup2facodes(tempList);
                //yuzj7 2017年6月5日19:38:29 edit
                boolean flag = validateFaGroup(salescouponsApi.getGroup2facodes());
                if(!flag){
                    remoteResult.setResultCode("02");
                    remoteResult.setSuccess(false);
                    remoteResult.setResultMsg("参数，产品组和分销商信息有误!");
                    printWriter.write(JsonUtil.toJson(remoteResult));
                    printWriter.close();
                    return;
                }
                distributorApiList = new ArrayList<DistributorruleApi>();
                List<Product2FaRelationsApi> listp2fs =  salescouponsApi.getGroup2facodes();
                for(Product2FaRelationsApi api : listp2fs){
                    DistributorruleApi dapi = null;
                    List<String> cate = api.getFacodes();
                    for (String s : cate) {
                        dapi = new DistributorruleApi();
                        dapi.setProductgroupid(api.getProductgroupid());
                        dapi.setFacode(s);
                        dapi.setCreateby(itCode);
                        dapi.setCreatetime(currentTime);
                        dapi.setStyle(CouponConstant.COUPON_style_coupon_1);
                        dapi.setUpdatetime(currentTime);
                        dapi.setNojoincodes(salescouponsApi.getGoodcodes());
                        dapi.setProductgroupno(api.getProductgroupno());
                        distributorApiList.add(dapi);
                    }
                }
                salescouponsApi.setDistributorruleApiList(distributorApiList);
            }

            Tenant tenant = getTenant(request);
            String currencyAmount = request.getParameter("currencyAmount");
            Money money = new Money(currencyAmount, tenant.getCurrencyCode());
            salescouponsApi.setAmount(money);
            salescouponsApi.setCurrencyCode(tenant.getCurrencyCode());
            logger.info("insertSalescoupons param："+JsonUtil.toJson(salescouponsApi));
            RemoteResult result = salescouponsRemote.insertSalescoupons(salescouponsApi);
            logger.info("insertSalescoupons return："+JsonUtil.toJson(result));
            printResult(invokeMethod, result);
            if (result.isSuccess()) {
                remoteResult.setResultCode("00");
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("保存优惠券成功！");
            } else {
                remoteResult.setResultCode("01");
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg(result.getResultMsg());
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
        } catch (Exception e) {
            logger.error("insertSalescoupons error"+e);
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    //校验参数关系是否正确
    private boolean validateFaGroup(List<Product2FaRelationsApi> list){
        if(null == list || list.size() == 0){
            return false;
        }
        for(Product2FaRelationsApi api : list){
            String  temp1 = api.getProductgroupid();
            String temp2 = api.getProductgroupno();
            List<String> facodes = api.getFacodes();
            if(StringUtil.isEmpty(temp1) || StringUtil.isEmpty(temp2) || null == facodes  || facodes.size() ==0){
                return false;
            }
        }
        return true;
    }

    /**
     * 根据主键ID查询优惠券/优惠码
     * @param request
     * @param response
     */
    @RequestMapping(value = "/querySalescouponsById" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void querySalescouponsById(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/querySalescouponsById";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        String id = request.getParameter("id");
        if(StringUtils.isNotEmpty(id)) {
            SalescouponsApi salescouponsApi = new SalescouponsApi();
            salescouponsApi.setId(Long.valueOf(id));
            RemoteResult<SalescouponsApi> result = salescouponsRemote.getSalescoupons(salescouponsApi);
            if(result != null && result.isSuccess()){
                salescouponsApi = result.getT();
                if(CouponConstant.COUPON_TYPE_DETAIL_1 == salescouponsApi.getType()) {
                    List<DetailsruleApi> detailsruleApiList = salescouponsApi.getDetailsruleApiList();
                    StringBuffer catagoryIds = new StringBuffer();
                    int size = detailsruleApiList.size();
                    String noJoinCodes = null;
                    for (int i = 0; i < size; i++) {
                        if (i < size - 1) {
                            catagoryIds.append(detailsruleApiList.get(i).getGoodscategoryid()).append(",");
                        } else {
                            catagoryIds.append(detailsruleApiList.get(i).getGoodscategoryid());
                            noJoinCodes = detailsruleApiList.get(i).getNojoincodes();
                        }
                    }
                    salescouponsApi.setGoodscategoryids(catagoryIds.toString());
                    salescouponsApi.setNojoingoodcodes(noJoinCodes);
                    salescouponsApi.setDetailsruleApiList(null);
                }
                if(CouponConstant.COUPON_TYPE_PRODUCT_2 == salescouponsApi.getType()){
                    ProductruleApi productruleApi = salescouponsApi.getProductruleApi();
                    salescouponsApi.setGoodcodes(productruleApi.getGoodscodes());
                    salescouponsApi.setProductruleApi(null);
                }

                if(CouponConstant.COUPON_TYPE_PRODUCTGROUP_3 == salescouponsApi.getType()) {
                    List<DistributorruleApi> distributorruleApiList = salescouponsApi.getDistributorruleApiList();
                    StringBuffer facodes = new StringBuffer();
                    if(null != distributorruleApiList){
                        int size = distributorruleApiList.size();
                        String noJoinCodes = null;
                        for (int i = 0; i < size; i++) {
                            if (i < size - 1) {
                                facodes.append(distributorruleApiList.get(i).getFacode()).append(",");
                            } else {
                                facodes.append(distributorruleApiList.get(i).getFacode());
                                noJoinCodes = distributorruleApiList.get(i).getNojoincodes();
                            }
                        }
                        salescouponsApi.setFacodes(facodes.toString());
                        salescouponsApi.setProductgroupid(distributorruleApiList.get(0).getProductgroupid());
                        salescouponsApi.setProductgroupno(distributorruleApiList.get(0).getProductgroupno());
                        salescouponsApi.setNojoingoodcodes(noJoinCodes);
                        salescouponsApi.setDetailsruleApiList(null);
                    }
                }
                remoteResult.setResultCode("00");
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("查询成功");
                remoteResult.setT(salescouponsApi);
            }else {
                remoteResult.setResultCode("02");
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("结果为空");
            }
            printResult(invokeMethod, result);
        }else {
            remoteResult.setResultCode("01");
            remoteResult.setResultMsg("参数为空");
            remoteResult.setSuccess(false);
        }
        printWriter.write(JsonUtil.toJson(remoteResult));
        printWriter.close();
    }

    /**
     * 保存编辑后的优惠券
     * @param request
     * @param response
     * @param salescouponsApi
     * @param map
     */
    @RequestMapping(value = "/editSalescoupon" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String editSalescoupons(HttpServletRequest request, HttpServletResponse response, SalescouponsApi salescouponsApi, Map<String, Object> map){
        String groups2facodes = request.getParameter("groups2facodes");
        logger.info("addSalescoupon param  groups2facodes:{}",groups2facodes);
        String invokeMethod = "api/coupon/editSalescoupon";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);

        try {
            Date currentTime = new Date();
            String itCode = AuthData.getUserId(request);
            String currencyCode = getTenant(request).getCurrencyCode();
            String currencyAmount = request.getParameter("currencyAmount");
            salescouponsApi.setUpdateby(itCode);
            salescouponsApi.setUpdatetime(currentTime);
            int limitSymbol = salescouponsApi.getLimitSymbol();
            if(limitSymbol == 0){
                salescouponsApi.setMaxnumber(Integer.MAX_VALUE);
            }else if(limitSymbol == 1){
                Integer maxNumber = salescouponsApi.getMaxnumber();
                maxNumber = maxNumber == null ? new Integer(0) : maxNumber;
                salescouponsApi.setMaxnumber(maxNumber);
            }
            if(salescouponsApi.getUsescope() == CouponConstant.COUPON_USESCOPE_YIJIUHUANXIN){
                salescouponsApi.setType(0);//依旧换新设置为0 代表什么都不绑定
                salescouponsApi.setCouponway(null); //couponway字段只有epp再用，其他情况为null
            }
            Money amount = new Money(currencyAmount, currencyCode);
            salescouponsApi.setAmount(amount);

            //绑定分类
            List<DetailsruleApi> detailsRuleApiList = null;
            if (CouponConstant.COUPON_TYPE_DETAIL_1 == salescouponsApi.getType()) {
                if(StringUtils.isNotEmpty(salescouponsApi.getGoodscategoryids())){
                    detailsRuleApiList = new ArrayList<DetailsruleApi>();
                    DetailsruleApi dapi = null;
                    String[] cate = salescouponsApi.getGoodscategoryids().split(",");
                    for (String s : cate) {
                        dapi = new DetailsruleApi();
                        dapi.setGoodscategoryid(s);
                        dapi.setSalescouponid(salescouponsApi.getId());
                        dapi.setCreateby(itCode);
                        dapi.setCreatetime(new Date());
                        dapi.setStyle(CouponConstant.COUPON_style_coupon_1);
                        dapi.setUpdatetime(new Date());
                        dapi.setNojoincodes(salescouponsApi.getGoodcodes());
                        detailsRuleApiList.add(dapi);
                    }
                    salescouponsApi.setDetailsruleApiList(detailsRuleApiList);
                }else {
                    logger.info("修改优惠券时，绑定分类但是没有分类！");
                    remoteResult.setResultCode("05");
                    remoteResult.setSuccess(false);
                    remoteResult.setResultMsg("修改优惠券时，绑定分类但是没有分类！");
                    return JsonUtil.toJson(remoteResult);
                }
            }

            //绑定商品
            if (CouponConstant.COUPON_TYPE_PRODUCT_2 == salescouponsApi.getType()) {
                if (StringUtils.isNotEmpty(salescouponsApi.getGoodcodes())) {
                    ProductruleApi productruleApi = new ProductruleApi();
                    productruleApi.setStyle(CouponConstant.COUPON_style_coupon_1);
                    productruleApi.setGoodscodes(salescouponsApi.getGoodcodes());
                    productruleApi.setSalescouponid(salescouponsApi.getId());
                    productruleApi.setCreateby(itCode);
                    productruleApi.setCreatetime(new Date());
                    productruleApi.setUpdatetime(new Date());
                    productruleApi.setMaterialcodes(request.getParameter("materialcodes"));
                    salescouponsApi.setProductruleApi(productruleApi);
                } else {
                    logger.info("修改优惠券时，绑定商品但是没有商品！");
                    remoteResult.setResultCode("04");
                    remoteResult.setSuccess(false);
                    remoteResult.setResultMsg("修改优惠券时，绑定商品但是没有商品！");
                    return JsonUtil.toJson(remoteResult);
                }
            }

            //产品组
            List<DistributorruleApi> distributorApiList = null;
            if (CouponConstant.COUPON_TYPE_PRODUCTGROUP_3 == salescouponsApi.getType() ) {
                if(StringUtil.isEmpty(groups2facodes)){
                    remoteResult.setResultCode("02");
                    remoteResult.setSuccess(false);
                    remoteResult.setResultMsg("参数，产品组和分销商信息有误!");
                    return JsonUtil.toJson(remoteResult);
                }
                List<Product2FaRelationsApi> tempList = JsonUtil.readValuesAsArrayList(groups2facodes, Product2FaRelationsApi.class);
                salescouponsApi.setGroup2facodes(tempList);
                boolean flag = validateFaGroup(salescouponsApi.getGroup2facodes());
                if(!flag){
                    remoteResult.setResultCode("02");
                    remoteResult.setSuccess(false);
                    remoteResult.setResultMsg("参数，产品组和分销商信息有误!");
                    return JsonUtil.toJson(remoteResult);
                }
                distributorApiList = new ArrayList<DistributorruleApi>();
                List<Product2FaRelationsApi> listp2fs =  salescouponsApi.getGroup2facodes();
                for(Product2FaRelationsApi api : listp2fs){
                    DistributorruleApi dapi = null;
                    List<String> cate = api.getFacodes();
                    for (String s : cate) {
                        dapi = new DistributorruleApi();
                        dapi.setProductgroupid(api.getProductgroupid());
                        dapi.setFacode(s);
                        dapi.setSalescouponid(salescouponsApi.getId());
                        dapi.setCreateby(itCode);
                        dapi.setCreatetime(currentTime);
                        dapi.setStyle(CouponConstant.COUPON_style_coupon_1);
                        dapi.setUpdatetime(currentTime);
                        dapi.setNojoincodes(salescouponsApi.getGoodcodes());
                        dapi.setProductgroupno(api.getProductgroupno());
                        distributorApiList.add(dapi);
                    }
                }
                salescouponsApi.setDistributorruleApiList(distributorApiList);
            }
            if (salescouponsApi != null && salescouponsApi.getId() > 0) {
                if (String.valueOf(ShopIdEnum.EPP.getType()).equals(salescouponsApi.getShopid())) {
                    salescouponsApi.setCouponway(null);
                }
                RemoteResult result = salescouponsRemote.editSalescoupons(salescouponsApi);
                logger.info("editSalescoupons return:"+salescouponsApi);
                printResult(invokeMethod, result);
                if (result.isSuccess()) {
                    remoteResult.setResultCode("00");
                    remoteResult.setSuccess(true);
                    remoteResult.setResultMsg("保存优惠券成功！");
                } else {
                    remoteResult.setResultCode("01");
                    remoteResult.setSuccess(false);
                    remoteResult.setResultMsg(result.getResultMsg());
                }
                return JsonUtil.toJson(remoteResult);
            } else {
                remoteResult.setResultCode("02");
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("参数错误！");
            }
            return JsonUtil.toJson(remoteResult);
        } catch (Exception e) {
            logger.info("e",e);
        }
        return JsonUtil.toJson(remoteResult);
    }

    /**
     * 发全员券
     * @param request
     * @param response
     */
    @RequestMapping(value = "/sendToAll" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void sendCouponToAll(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/sendToAll";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        try {
            String itCode = AuthData.getUserId(request);
            String salesCouponIds = request.getParameter("ids");
            if(StringUtils.isEmpty(salesCouponIds) || StringUtils.isEmpty(itCode)){
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("02");
                remoteResult.setResultMsg(CouponConstant.RESULT_MSG_ERROR_PARAM);
                printWriter.write(JsonUtil.toJson(remoteResult));
                printWriter.close();
                return;
            }
            String[] ids_array = salesCouponIds.split(",");
            Map paramMap = new HashMap();
            paramMap.put("ids", ids_array);
            RemoteResult<List<SalescouponsApi>> re = salescouponsRemote.getSalescouponsList(paramMap);
            if (re.isSuccess() && re.getT() != null && re.getT().size() > 0) {
                Date currentTime = new Date();
                boolean flag = false;
                List<SalescouponsApi> apiList = re.getT();
                List<UsergroupcouponrelApi> uapiList = new ArrayList<UsergroupcouponrelApi>();
                UsergroupcouponrelApi uapi = null;

                //检查券的有效性
                for (SalescouponsApi api : apiList) {
                    if (CouponConstant.COUPON_STATUS_PASTAUDIT_2 != api.getStatus()) {  //是否审核通过
                        remoteResult.setResultCode("03");
                        remoteResult.setSuccess(false);
                        remoteResult.setResultMsg("优惠券<" + api.getName() + ">未审核，请先审核！");
                        flag = true;
                        break;
                    }
                    if (api.getMaxnumber() != null && api.getMaxnumber() < Integer.MAX_VALUE) {
                        remoteResult.setResultCode("04");
                        remoteResult.setSuccess(false);
                        remoteResult.setResultMsg("优惠券<" + api.getName() + ">限制发放数量，不能发送全员券！");
                        flag = true;
                        break;
                    }
                    if (String.valueOf(ShopIdEnum.EPP.getType()).equals(api.getShopid())) { //epp
                        if (StringUtils.isEmpty(api.getEppgroup())) {
                            remoteResult.setResultCode("05");
                            remoteResult.setSuccess(false);
                            remoteResult.setResultMsg("epp优惠券" + api.getName() + "的组为空，请检查！");
                            flag = true;
                            break;
                        }
                        String[] groups = api.getEppgroup().split(",");
                        for (String group : groups) {
                            uapi = new UsergroupcouponrelApi();
                            uapi.setSalescouponid(api.getId() + "");
                            uapi.setShopid(api.getShopid());
                            uapi.setTerminal(api.getTerminal());
                            uapi.setUsergroup(group);
                            uapi.setSendtime(currentTime);
                            uapi.setRegisterfromtime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("1753-01-01 00:00:00"));
                            uapi.setRegistertotime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("9999-12-31 23:59:59"));
                            uapi.setCreateby(itCode);
                            uapi.setCreatetime(currentTime);
                            uapiList.add(uapi);
                        }
                    } else {
                        uapi = new UsergroupcouponrelApi();
                        uapi.setSalescouponid(api.getId() + "");
                        uapi.setShopid(api.getShopid());
                        uapi.setTerminal(api.getTerminal());
                        uapi.setUsergroup(CouponConstant.COUPON_Lenovo_Think_GROUPCODE);
                        uapi.setSendtime(currentTime);
                        uapi.setRegisterfromtime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("1753-01-01 00:00:00"));
                        uapi.setRegistertotime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("9999-12-31 23:59:59"));
                        uapi.setCreateby(itCode);
                        uapi.setCreatetime(currentTime);
                        uapiList.add(uapi);
                    }
                }
                if (!flag) {
                    RemoteResult result = adminUsergroupcouponrelService.insertBatch(uapiList);
                    if (result.isSuccess()) {
                        remoteResult.setResultCode("00");
                        remoteResult.setSuccess(true);
                        remoteResult.setResultMsg("发全员券成功！");

                        for (SalescouponsApi api : apiList) {
                            SalescouponsApi sapi = new SalescouponsApi();
                            sapi.setId(api.getId());
                            sapi.setWholenumber(api.getWholenumber() + 1);
                            sapi.setBacksend(CouponConstant.COUPON_Backsend_1);// 1 已经发过券，0 未发过券
                            sapi.setUpdatetime(currentTime);
                            sapi.setUpdateby(itCode);
                            salescouponsRemote.editSalescouponsOnly(sapi);
                        }
                    } else {
                        remoteResult.setResultCode("01");
                        remoteResult.setSuccess(false);
                        remoteResult.setResultMsg("发全员券失败，请联系管理员！");
                    }
                    printWriter.write(JsonUtil.toJson(remoteResult));
                    printWriter.close();
                    return;
                }
                printWriter.write(JsonUtil.toJson(remoteResult));
                printWriter.close();
                return;
            } else {
                remoteResult.setResultCode("06");
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("未找到优惠券！");
                printWriter.write(JsonUtil.toJson(remoteResult));
                printWriter.close();
            }
        } catch (ParseException e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 提交审核 优惠券/码通用（style字段区分 1：优惠券 2：优惠码）
     * @param request
     * @param response
     * @param map
     */
    @RequestMapping(value = "/submitToCheck" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void submitToCheck(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map){
        String invokeMethod = "api/coupon/submitToCheck";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        String itCode = AuthData.getUserId(request);
        String style = request.getParameter("style");
        String couponIds = request.getParameter("ids");
        if(StringUtils.isEmpty(couponIds) || StringUtils.isEmpty(style) || StringUtils.isEmpty(itCode)){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("02");
            remoteResult.setResultMsg("请求参数错误");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }

        try {
            String[] strs =  couponIds.split(",");
            if (strs.length <= 0) {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("02");
                remoteResult.setResultMsg("请求参数错误,需要审核的优惠券ID为空");
                printWriter.write(JsonUtil.toJson(remoteResult));
                printWriter.close();
                return;
            }
            List<SalescouponsApi> list = new ArrayList<SalescouponsApi>();
            for (int i = 0; i < strs.length; i++) {
                SalescouponsApi salescouponsApi = new SalescouponsApi();
                String[] idAndName = strs[i].split("\\^");
                salescouponsApi.setId(Long.parseLong(idAndName[0]));
                salescouponsApi.setName(idAndName[1]);
                salescouponsApi.setStatus(3);//审核状态：0新建 1审核未通过2 审核通过3待审核
                salescouponsApi.setStyle(Integer.parseInt(style));
                salescouponsApi.setShopid(idAndName[2]);
                salescouponsApi.setUpdateby(itCode);
                list.add(salescouponsApi);
            }
            RemoteResult<Boolean> result = salescouponsRemote.submitToCheckBatch(list);
            printResult(invokeMethod, result);
            if (result != null && result.isSuccess()) {
                remoteResult.setResultCode("00");
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("操作成功");
            } else {
                remoteResult.setResultCode("01");
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("操作失败");
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 查看用户优惠券详情
     * @param request
     * @param response
     */
    @RequestMapping(value = "/viewMemberCoupon" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void viewUserCoupon(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/viewMemberCoupon";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }

        String id = request.getParameter("id");
        if(StringUtils.isEmpty(id)){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("02");
            remoteResult.setResultMsg("请求参数错误");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }

        try {
            RemoteResult<MembercouponrelsApi> result = adminMemberCouponService.queryMemberCouponById(Long.parseLong(id));
            printResult(invokeMethod, result);
            if(result != null && result.isSuccess()){
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("00");
                remoteResult.setResultMsg("操作成功");
                remoteResult.setT(result.getT());
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("01");
                remoteResult.setResultMsg("结果为空");
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 禁用用户名下的优惠券
     * @param request
     * @param response
     */
    @RequestMapping(value = "/disableMemberCoupon" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void disableUserCoupon(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/disableMemberCoupon";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }

        String id = request.getParameter("id");
        String lenovoid = request.getParameter("lenovoid");
        String itCode = AuthData.getUserId(request);
        if(StringUtils.isEmpty(id) ||StringUtils.isEmpty(lenovoid) ){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("02");
            remoteResult.setResultMsg("参数错误");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }
        try {
            RemoteResult<Boolean> result = adminMemberCouponService.disableMemberCouponByIdandLenovoId(Long.parseLong(id),lenovoid);
            printResult(invokeMethod, result);
            if(result != null && result.isSuccess()){
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("00");
                remoteResult.setResultMsg("操作成功");
                logger.info(String.format("优惠券[%s]被禁用，操作人：%s", id, itCode));
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("01");
                remoteResult.setResultMsg("操作失败");
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 根据主键id查询优惠券分类
     * @param request
     * @param response
     */
    @RequestMapping(value = "/queryCouponCategoryById" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void queryCouponCategoryById(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/queryCouponCategoryById";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        String id = request.getParameter("id");
        if(StringUtil.isEmpty(id)){
            remoteResult.setResultCode("02");
            remoteResult.setSuccess(false);
            remoteResult.setResultMsg("参数错误");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }

        try {
            RemoteResult result = adminCouponsCategoryService.getCouponsCategory(id);
            printResult(invokeMethod, result);
            if(result != null && result.isSuccess()){
                remoteResult.setResultCode("00");
                remoteResult.setSuccess(true);
                remoteResult.setResultMsg("操作成功");
                remoteResult.setT(result.getT());
            }else {
                remoteResult.setResultCode("01");
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("结果为空");
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 新建优惠券类别
     * @param request
     * @param response
     * @param couponsCategoryVo
     */
    @RequestMapping(value = "/addCouponCategory" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void addCouponCategory(HttpServletRequest request, HttpServletResponse response, CouponsCategoryApi couponsCategoryVo){
        String invokeMethod = "api/coupon/addCouponCategory";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        try {
            String itCode = AuthData.getUserId(request);
            Date currentTime = new Date();
            if(couponsCategoryVo != null && !StringUtil.isEmpty(itCode)){
                couponsCategoryVo.setCreateby(itCode);
                couponsCategoryVo.setCreatetime(currentTime);
                couponsCategoryVo.setUpdatetime(currentTime);
                RemoteResult<Integer> result = adminCouponsCategoryService.insertCouponsCategory(couponsCategoryVo);
                if(result != null && result.isSuccess()){
                    remoteResult.setSuccess(true);
                    remoteResult.setResultCode("00");
                    remoteResult.setResultMsg("操作成功");
                    remoteResult.setT(couponsCategoryVo);
                    printResult(invokeMethod, remoteResult);
                }else {
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode("01");
                    remoteResult.setResultMsg("操作失败");
                }
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("02");
                remoteResult.setResultMsg("参数错误");
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 编辑优惠券分类
     * @param request
     * @param response
     * @param couponsCategoryVo
     */
    @RequestMapping(value = "/editCouponCategory" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void editCouponCategory(HttpServletRequest request, HttpServletResponse response, CouponsCategoryApi couponsCategoryVo){
        String invokeMethod = "api/coupon/editCouponCategory";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        try {
            String itCode = AuthData.getUserId(request);
            Date currentTime = new Date();
            if(couponsCategoryVo != null && !StringUtil.isEmpty(itCode)){
                couponsCategoryVo.setUpdateby(itCode);
                couponsCategoryVo.setUpdatetime(currentTime);
                RemoteResult<Boolean> result= adminCouponsCategoryService.editCouponsCategory(couponsCategoryVo);
                if(result != null && result.isSuccess()){
                    remoteResult.setSuccess(true);
                    remoteResult.setResultCode("00");
                    remoteResult.setResultMsg("操作成功");
                    remoteResult.setT(couponsCategoryVo);
                    printResult(invokeMethod, remoteResult);
                }else {
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode("01");
                    remoteResult.setResultMsg("操作失败");
                }
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("02");
                remoteResult.setResultMsg("参数错误");
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 禁用优惠券分类
     * @param request
     * @param response
     */
    @RequestMapping(value = "/disableCouponCategory" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void disableCouponCategoryById(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/disableCouponCategory";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        String id = request.getParameter("id");//主键id
        String itCode = AuthData.getUserId(request);
        if(StringUtil.isEmpty(id) || StringUtil.isEmpty(itCode)){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("02");
            remoteResult.setResultMsg("参数错误");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }

        try {
            RemoteResult<Boolean> result = adminCouponsCategoryService.disableCouponCategoryById(Integer.parseInt(id));
            printResult(invokeMethod, result);
            if(result != null && result.isSuccess()){
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("00");
                remoteResult.setResultMsg("操作成功");
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("01");
                remoteResult.setResultMsg("操作失败");
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 审核优惠券/码，用style区分审核的是优惠券还是优惠码  1：优惠券  2：优惠码。
     * 此审核包括 17商城的二级审核
     * @param request
     * @param response
     * @param couponchecksApi
     */
    @RequestMapping(value = "/checkSingleCoupon", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void checkSingleCoupon(HttpServletRequest request, HttpServletResponse response, CouponchecksApi couponchecksApi){
        String invokeMethod = "api/coupon/checkSingleCoupon";
        String grade = request.getParameter("grade");  // 1: 一级审核  2：二级审核
        RemoteResult remoteResult = new RemoteResult();
        remoteResult.setSuccess(false);
        remoteResult.setResultCode("01");
        remoteResult.setResultMsg("审核失败");
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        String itCode = AuthData.getUserId(request);
        if(couponchecksApi != null ){
            try {
                if(StringUtils.isEmpty(itCode) || StringUtils.isEmpty(grade)){
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode("02");
                    remoteResult.setResultMsg("参数错误");
                    printWriter.write(JsonUtil.toJson(remoteResult));
                    printWriter.close();
                    return;
                }
                couponchecksApi.setUpdateby(itCode);
                couponchecksApi.setCheckpersonid(itCode);
                if (couponchecksApi.getShopid().equals("8") && "2".equals(grade)){
                    couponchecksApi.setSecondsCheckPersonID(itCode);
                    couponchecksApi.setSecondsCheckPostTime(new Date());
                }
                if(couponchecksApi.getShopid().equals("8") && "1".equals(grade) && couponchecksApi.getCheckstatus() == 2){
                    couponchecksApi.setCheckstatus(4);
                }
                couponchecksApi.setUpdatetime(new Date());
                couponchecksApi.setCheckposttime(new Date());
                remoteResult = adminCouponCheckService.checkCouponByCondition(couponchecksApi);
                if(remoteResult.isSuccess()){
                    remoteResult.setSuccess(true);
                    remoteResult.setResultCode("00");
                    remoteResult.setResultMsg("审核成功");
                }else {
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode("01");
                    remoteResult.setResultMsg("审核失败");
                }
            } catch (Exception e) {
                returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
            }
        }
        printWriter.write(JsonUtil.toJson(remoteResult));
        printWriter.close();
    }

    /**
     * 批量审核优惠券/码，一、二级审核共用
     * @param request
     * @param response
     */
    @RequestMapping(value = "/checkBatchCoupon" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String checkBatchCoupon(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/checkBatchCoupon";
        String grade = request.getParameter("grade");  // 1: 一级审核  2：二级审核
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        try {
            Date currentTime = new Date();
            String ids = request.getParameter("ids");
            String checkStatus = request.getParameter("checkstatus");
            String rejectReason = request.getParameter("rejectReason");
            String style = request.getParameter("style");
            String itCode = AuthData.getUserId(request);
            if(StringUtils.isEmpty(itCode) || StringUtils.isEmpty(ids) || StringUtils.isEmpty(checkStatus) || StringUtils.isEmpty(style) || StringUtils.isEmpty(grade)){
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("02");
                remoteResult.setResultMsg("参数错误");
                return JsonUtil.toJson(remoteResult);
            }
            String[] strs = ids.split(",");
            if(strs.length <= 0){
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("02");
                remoteResult.setResultMsg("参数错误");
                return JsonUtil.toJson(remoteResult);
            }
            List<CouponchecksApi> list = new ArrayList<CouponchecksApi>();
            for (int i=0;i<strs.length;i++){
                String[] strings = strs[i].split("-");
                CouponchecksApi couponchecksApi = new CouponchecksApi();
                couponchecksApi.setId(Long.parseLong(strings[0]));
                couponchecksApi.setSalescouponid(Long.parseLong(strings[1]));
                couponchecksApi.setCheckstatus(Integer.parseInt(checkStatus));
                if (strings[2].equals("8") && "1".equals(grade) && "2".equals(checkStatus)){
                    couponchecksApi.setCheckstatus(4);
                }
                if(strings[2].equals("8") && "2".equals(grade)){
                    couponchecksApi.setSecondsCheckPersonID(itCode);
                    couponchecksApi.setSecondsCheckPostTime(currentTime);
                }
                if("1".equals(grade)){
                    couponchecksApi.setCheckpersonid(itCode);
                }
                couponchecksApi.setStyle(Integer.parseInt(style));
                couponchecksApi.setUpdatetime(currentTime);
                couponchecksApi.setCheckposttime(currentTime);
                couponchecksApi.setRejectreason(rejectReason);
                couponchecksApi.setUpdateby(itCode);
                couponchecksApi.setShopid(strings[2]);
                list.add(couponchecksApi);
            }
            RemoteResult<Boolean> result= adminCouponCheckService.updateCouponchecksBatch(list);
            printResult(invokeMethod, result);
            if(result != null && result.isSuccess()){
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("00");
                remoteResult.setResultMsg("审核成功");
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("01");
                remoteResult.setResultMsg("审核失败");
            }
            return JsonUtil.toJson(remoteResult);
        } catch (Exception e) {
            logger.error(ExceptionUtil.getStackTrace(e));
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("9999");
            remoteResult.setResultMsg("系统异常");
        }
        return JsonUtil.toJson(remoteResult);
    }

    /**
     * 新建优惠码
     * @param request
     * @param response
     * @param salescouponsApi
     * @param map
     */
    @RequestMapping(value = "/addCouponCode" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String addCouponCode(HttpServletRequest request, HttpServletResponse response, SalescouponsApi salescouponsApi, Map<String, Object> map){
        String invokeMethod = "api/coupon/addCouponCode";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        try {
            Date currentTime = new Date();
            String itCode = AuthData.getUserId(request);
            String batchNo = String.valueOf(currentTime.getTime());
            String currencyAmount = request.getParameter("currencyAmount");
            String currencyCode = getTenant(request).getCurrencyCode();

            salescouponsApi.setStatus(CouponConstant.COUPON_STATUS_NEW_0);
            salescouponsApi.setBatchno(batchNo);
            salescouponsApi.setCreateby(itCode);
            salescouponsApi.setCreatetime(currentTime);
            salescouponsApi.setUpdatetime(currentTime);
            salescouponsApi.setHaspassed(0);//有没有审核通过过，1有过
            salescouponsApi.setBacksend(0);//有没有发过券，前后台发券都算  优惠码暂时不用这个值，设置默认值0
            salescouponsApi.setNoticeValidCount(0);//通知商品和查询有效的次数，  优惠码暂时不用这个值，设置默认值0
            salescouponsApi.setNoticeInvalidCount(0);//通知商品和查询无效的次数，优惠码暂时不用这个值，设置默认值0
            Money money = new Money(currencyAmount, currencyCode);
            salescouponsApi.setAmount(money);
            salescouponsApi.setCurrencyCode(currencyCode);

            //分类
            List<DetailsruleApi> detailsruleApiList = null;
            if (CouponConstant.COUPON_TYPE_DETAIL_1 == salescouponsApi.getType()) {
                if(StringUtils.isNotEmpty(salescouponsApi.getGoodscategoryids())){
                    String nojoincodes = salescouponsApi.getGoodcodes();
                    detailsruleApiList = new ArrayList<DetailsruleApi>();
                    DetailsruleApi dapi = null;
                    String[] cate = salescouponsApi.getGoodscategoryids().split(",");
                    for (String s : cate) {
                        dapi = new DetailsruleApi();
                        dapi.setGoodscategoryid(s);
                        dapi.setCreateby(itCode);
                        dapi.setCreatetime(currentTime);
                        dapi.setStyle(CouponConstant.COUPON_style_code_2);
                        dapi.setUpdatetime(currentTime);
                        dapi.setNojoincodes(nojoincodes);
                        detailsruleApiList.add(dapi);
                    }
                    salescouponsApi.setDetailsruleApiList(detailsruleApiList);
                }else {
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode("02");
                    remoteResult.setResultMsg("绑定分类必须有商品分类数据！");
                    return JsonUtil.toJson(remoteResult);
                }
            }

            //商品
            if (CouponConstant.COUPON_TYPE_PRODUCT_2 == salescouponsApi.getType()) {
                if (StringUtils.isNotEmpty(salescouponsApi.getGoodcodes())) {
                    ProductruleApi productruleApi = new ProductruleApi();
                    productruleApi.setStyle(CouponConstant.COUPON_style_code_2);
                    productruleApi.setGoodscodes(salescouponsApi.getGoodcodes());
                    productruleApi.setCreateby(itCode);
                    productruleApi.setCreatetime(currentTime);
                    productruleApi.setUpdatetime(currentTime);

                    salescouponsApi.setProductruleApi(productruleApi);
                } else {
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode("03");
                    remoteResult.setResultMsg("绑定商品必须有商品数据！");
                    return JsonUtil.toJson(remoteResult);
                }
            }

            RemoteResult result = salescouponsRemote.insertSalescoupons(salescouponsApi);
            printResult(invokeMethod, result);
            if (result != null && result.isSuccess()) {
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("00");
                remoteResult.setResultMsg("操作成功");
            } else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("01");
                remoteResult.setResultMsg("操作失败");
            }
            return JsonUtil.toJson(remoteResult);
        } catch (Exception e) {
            logger.info("e", e);
        }
        return JsonUtil.toJson(remoteResult);
    }

    /**
     * 编辑优惠码
     * @param request
     * @param response
     * @param salescouponsApi
     * @param map
     */
    @RequestMapping(value = "/editCouponCode" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String editCouponCode(HttpServletRequest request, HttpServletResponse response, SalescouponsApi salescouponsApi, Map<String, Object> map){
        String invokeMethod = "api/coupon/editCouponCode";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);

        if(salescouponsApi == null || salescouponsApi.getId() <= 0){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("02");
            remoteResult.setResultMsg("参数错误");
            return JsonUtil.toJson(remoteResult);
        }

        try {
            String itCode = AuthData.getUserId(request);
            String currencyAmount = request.getParameter("currencyAmount");
            String currencyCode = getTenant(request).getCurrencyCode();
            Money money = new Money(currencyAmount, currencyCode);
            salescouponsApi.setAmount(money);

            //分类
            List<DetailsruleApi> detailsruleApiList = null;
            if (CouponConstant.COUPON_TYPE_DETAIL_1 == salescouponsApi.getType() ) {
                if(StringUtils.isNotEmpty(salescouponsApi.getGoodscategoryids())){
                    detailsruleApiList = new ArrayList<DetailsruleApi>();
                    DetailsruleApi dapi = null;
                    String[] cate = salescouponsApi.getGoodscategoryids().split(",");
                    for (String s : cate) {
                        dapi = new DetailsruleApi();
                        dapi.setGoodscategoryid(s);
                        dapi.setSalescouponid(salescouponsApi.getId());
                        dapi.setCreateby(itCode);
                        dapi.setCreatetime(new Date());
                        dapi.setStyle(CouponConstant.COUPON_style_coupon_1);
                        dapi.setUpdatetime(new Date());
                        dapi.setNojoincodes(salescouponsApi.getGoodcodes());
                        detailsruleApiList.add(dapi);
                    }
                    salescouponsApi.setDetailsruleApiList(detailsruleApiList);
                }else {
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode("05");
                    remoteResult.setResultMsg("修改优惠券时，绑定分类但是没有分类！");
                    return JsonUtil.toJson(remoteResult);
                }
            }

            //商品
            if (CouponConstant.COUPON_TYPE_PRODUCT_2 == salescouponsApi.getType()) {
                if (StringUtils.isNotEmpty(salescouponsApi.getGoodcodes())) {
                    ProductruleApi productruleApi = new ProductruleApi();
                    productruleApi.setStyle(CouponConstant.COUPON_style_coupon_1);
                    productruleApi.setGoodscodes(salescouponsApi.getGoodcodes());
                    productruleApi.setSalescouponid(salescouponsApi.getId());
                    productruleApi.setCreateby(itCode);
                    productruleApi.setCreatetime(new Date());
                    productruleApi.setUpdatetime(new Date());
                    salescouponsApi.setProductruleApi(productruleApi);
                } else {
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode("04");
                    remoteResult.setResultMsg("修改优惠券时，绑定商品但是没有商品！");
                    return JsonUtil.toJson(remoteResult);
                }
            }
            if (String.valueOf(ShopIdEnum.EPP.getType()).equals(salescouponsApi.getShopid())) {
                salescouponsApi.setCouponway(null);
            }
            RemoteResult result = salescouponsRemote.editSalescoupons(salescouponsApi);
            printResult(invokeMethod, result);
            if(result != null && result.isSuccess()){
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("00");
                remoteResult.setResultMsg("保存成功");
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("01");
                remoteResult.setResultMsg("保存失败");
            }
            return JsonUtil.toJson(remoteResult);
        } catch (Exception e) {
            logger.info("e", e);
        }
        return JsonUtil.toJson(remoteResult);
    }

    /**
     * 追加优惠码
     * @param request
     * @param response
     */
    @RequestMapping(value = "/extraAddCouponCode" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String extraAddCouponCode(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/extraAddCouponCode";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);

        try {
            String id = request.getParameter("id");//优惠码主键id
            String num = request.getParameter("num");//追加数量
            String itCode = AuthData.getUserId(request);
            if(StringUtils.isEmpty(id) || StringUtils.isEmpty(num) || StringUtils.isEmpty(itCode)){
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("02");
                remoteResult.setResultMsg("参数错误");
                return JsonUtil.toJson(remoteResult);
            }

            long couponid = Long.parseLong(id);
            int count = Integer.parseInt(num);
            RemoteResult<Boolean> result= adminCouponsService.toIncreaseCodes(couponid, count, itCode);
            printResult(invokeMethod, result);
            if(result != null && result.isSuccess()){
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("00");
                remoteResult.setResultMsg("追加成功");
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("01");
                remoteResult.setResultMsg("追加失败");
            }
            return JsonUtil.toJson(remoteResult);
        } catch (Exception e) {
            logger.info("e",e);
        }
        return JsonUtil.toJson(remoteResult);
    }

    /**
     * 查询登录人创建的优惠码
     * @param request
     * @param response
     * @param map
     */
    @RequestMapping(value = "/queryCouponCodeInfoByPage" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void queryCouponCodeInfoPage(HttpServletRequest request,HttpServletResponse response,Map<String,Object> map){
        String invokeMethod = "api/coupon/queryCouponCodeInfoByPage";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }

        try {
            Map<String, Object> conditionMap = new HashMap<String, Object>();

            String itCode = AuthData.getUserId(request);
            String name = request.getParameter("name");
            String macode = request.getParameter("macode");
            String amount = request.getParameter("amount");
            String fromtime = request.getParameter("fromtime");
            String totime = request.getParameter("totime");
            String shopid = request.getParameter("shopId");
            String terminal = request.getParameter("terminal");
            String type = request.getParameter("type");
            String page = request.getParameter("page");
            String pageSize = request.getParameter("rows");

            if (StringUtils.isNotEmpty(itCode)){
                conditionMap.put("createby", itCode);
            }
            if(StringUtils.isNotEmpty(name)){
                conditionMap.put("name", name);
            }
            if(StringUtils.isNotEmpty(macode)){
                conditionMap.put("macode", macode);
            }
            if(StringUtils.isNotEmpty(amount)){
                conditionMap.put("amount", amount);
            }
            if (StringUtils.isNotEmpty(fromtime)) {
                conditionMap.put("fromtime", DateUtil.format4easyui(fromtime));
            }
            if (StringUtils.isNotEmpty(totime)) {
                conditionMap.put("totime", DateUtil.format4easyui(totime));
            }
            if (StringUtils.isNotEmpty(shopid) && !"99".equals(shopid)) {
                conditionMap.put("shopid", shopid);
            }
            if (StringUtils.isNotEmpty(terminal) && !"99".equals(terminal)) {
                conditionMap.put("terminal", terminal);
            }
            if (StringUtils.isNotEmpty(type) && !"99".equals(type)) {
                conditionMap.put("type", type);
            }

            PageQuery pageQuery=null;
            if(StringUtils.isNotEmpty(pageSize)){
                pageQuery = new PageQuery(getPage(request), Integer.parseInt(pageSize));
            }else{
                pageQuery = new PageQuery(getPage(request), PAGE_SIZE);
            }
            RemoteResult<PageModel2<CouponsApi>> result = adminCouponsService.getCouponsInfoPage(pageQuery, conditionMap);
            printResult(invokeMethod, result);
            if(result != null && result.isSuccess()){
                PageModel2<CouponsApi> pageModel2 = result.getT();
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("00");
                remoteResult.setResultMsg("操作成功");
                remoteResult.setT(pageModel2);
            }else {
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("01");
                remoteResult.setResultMsg("没有查询到数据");
                remoteResult.setT(null);
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 查看优惠码明文
     * @param request
     * @param response
     */
    @RequestMapping(value = "/showTrueMacode" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String showTrueMacode(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/showTrueMacode";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        String id = request.getParameter("id"); // 优惠码的主键ID
        String itCode = AuthData.getUserId(request);

        if(StringUtils.isEmpty(id) || StringUtils.isEmpty(itCode)){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("02");
            remoteResult.setResultMsg("参数错误");
            return JsonUtil.toJson(remoteResult);
        }

        try {
            RemoteResult<CouponsApi> result = adminCouponsService.getTrueMacode(Long.valueOf(id), itCode);
            printResult(invokeMethod, result);
            if(result != null && result.isSuccess()){
                List<CouponsApi> clist = (List<CouponsApi>)result.getT();
                String trueMacode = null;
                for (int i = 0; i <clist.size() ; i++) {
                    trueMacode = clist.get(i).getMacode();
                    if (trueMacode.length()>10){
                        trueMacode = TripleDESUtil.decryptMode(trueMacode);
                    }else {
                        trueMacode = clist.get(i).getMacode();
                    }
                }
                remoteResult.setSuccess(true);
                remoteResult.setResultCode("00");
                remoteResult.setResultMsg("解密成功");
                remoteResult.setT(trueMacode);
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("01");
                remoteResult.setResultMsg("解密失败");
                remoteResult.setT("");
            }
            return JsonUtil.toJson(remoteResult);
        } catch (NumberFormatException e) {
            logger.info("e",e);
        }
        return JsonUtil.toJson(remoteResult);
    }

    /**
     * 导出优惠券
     * @param request
     * @param response
     * @param map
     */
    @RequestMapping("/exportCouponsToExcel")
    public void exportCouponsToExcel(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map){
        String invokeMethod = "api/coupon/exportCouponsToExcel";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        try {
            Map<String, Object> conditionMap = new HashMap<String, Object>();
            List<String> shopIdList = AuthData.getShopIds(request);
            String style = request.getParameter("style");
            String name = request.getParameter("name");
            String amount = request.getParameter("amount");
            String usescope = request.getParameter("usescope");
            String status = request.getParameter("status");
            String iscanget = request.getParameter("iscanget");
            String getstarttime = request.getParameter("getstarttime");
            String getendtime = request.getParameter("getendtime");
            String fromtime = request.getParameter("fromtime");
            String totime = request.getParameter("totime");
            String createtime_start = request.getParameter("createtime_start");
            String createtime_end = request.getParameter("createtime_end");
            String shopid = request.getParameter("shopid");
            String terminal = request.getParameter("terminal");
            String classification = request.getParameter("classification");
            String classificationName = request.getParameter("classificationName");
            String pageSize = request.getParameter("rows");
            String maxNumber = request.getParameter("maxnumber");
            String type = request.getParameter("type");

            conditionMap.put("name", name);
            conditionMap.put("amount", amount);
            conditionMap.put("style", CouponConstant.COUPON_style_coupon_1); //导出优惠券
            if (CollectionUtils.isNotEmpty(shopIdList)){
                conditionMap.put("shopids", shopIdList);
            }
            if (StringUtils.isNotEmpty(usescope) && !"99".equals(usescope)) {
                conditionMap.put("usescope", usescope);
            }
            if (StringUtils.isNotEmpty(status) && !"99".equals(status)) {
                conditionMap.put("status", status);
            }
            if (StringUtils.isNotEmpty(iscanget) && !"99".equals(iscanget)) {
                conditionMap.put("iscanget", iscanget);
            }
            if (StringUtils.isNotEmpty(getstarttime)) {
                conditionMap.put("getstarttime", DateUtil.format4easyui(getstarttime));
            }
            if (StringUtils.isNotEmpty(getendtime)) {
                conditionMap.put("getendtime", DateUtil.format4easyui(getendtime));
            }
            if (StringUtils.isNotEmpty(fromtime)) {
                conditionMap.put("fromtime", DateUtil.format4easyui(fromtime));
            }
            if (StringUtils.isNotEmpty(totime)) {
                conditionMap.put("totime", DateUtil.format4easyui(totime));
            }
            if (StringUtils.isNotEmpty(createtime_start)) {
                conditionMap.put("createtime_start", DateUtil.format4easyui(createtime_start));
            }
            if (StringUtils.isNotEmpty(createtime_end)) {
                conditionMap.put("createtime_end", DateUtil.format4easyui(createtime_end));
            }
            if (StringUtils.isNotEmpty(shopid) && !"99".equals(shopid)) {
                conditionMap.put("shopid", shopid);
            }
            if (StringUtils.isNotEmpty(terminal) && !"99".equals(terminal)) {
                conditionMap.put("terminal", terminal);
            }
            if (StringUtils.isNotEmpty(maxNumber)){
                conditionMap.put("maxnumber", maxNumber);
            }
            if (StringUtils.isNotEmpty(type) && !"99".equals(type)) {
                conditionMap.put("type", type);
            }
            conditionMap.put("classification", classification);
            conditionMap.put("classificationName", classificationName);

            PageQuery pageQuery = new PageQuery(getPage(request), 100000);
            RemoteResult<PageModel2<SalescouponsApi>> result = salescouponsRemote.getSalescouponsInfoPage(pageQuery, conditionMap);
            SXSSFWorkbook wb = new SXSSFWorkbook(1000);
            if (result != null && result.isSuccess() && result.getT() != null) {
                List<SalescouponsApi> couponReportApiList = result.getT().getDatas();
                ExcelUtils.writeXSLXExcel(wb, salescouponsHeader, createSalescouponsData(couponReportApiList));
            }else{
                ExcelUtils.writeXSLXExcel(wb, salescouponsHeader, null);
            }

            String fileName = "SalesCoupon.xlsx";
            long timeStamp = new Date().getTime();
            String token = UploadImageClient.getToken(appId, appKey, timeStamp, targetCouponFilePath+fileName, "1");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            wb.write(bos);
            UploadResponse uploadResponse = UploadImageClient.upload(appId, token, timeStamp, imageServerURL+targetCouponFilePath+fileName, bos.toByteArray(), fileName, "1");
            printResult(invokeMethod, uploadResponse);
            String readURL = PrivateSpcaceManager.getReadURL(appId, appKey, domain, targetCouponFilePath+fileName);
            remoteResult.setSuccess(true);
            remoteResult.setResultCode("00");
            remoteResult.setResultMsg("操作成功");
            remoteResult.setT(readURL);
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }catch (Exception e){
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 导出优惠码的基本信息，并导出生成的优惠码
     * @param request
     * @param response
     * @param map
     */
    @RequestMapping("/exportCouponCode")
    public void exportCouponCodeToExcel(HttpServletRequest request, HttpServletResponse response, Map<String,Object> map){
        String invokeMethod = "api/coupon/exportCouponCode";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        try {
            String salescouponid = request.getParameter("salescouponid");
            String itCode = AuthData.getUserId(request);
            if(StringUtils.isEmpty(salescouponid) || StringUtils.isEmpty(itCode)){
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("02");
                remoteResult.setResultMsg("参数错误");
                printWriter.write(JsonUtil.toJson(remoteResult));
                printWriter.close();
                return;
            }

            if(salescouponid.split(",").length>1){
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("02");
                remoteResult.setResultMsg("参数错误,请选择一条数据导出");
                printWriter.write(JsonUtil.toJson(remoteResult));
                printWriter.close();
                return;
            }
            long t1 = System.currentTimeMillis();
            RemoteResult result = adminCouponsService.getCouponsBySalescouponsId(Integer.parseInt(salescouponid));
            long t2 = System.currentTimeMillis();
            logger.info("导出优惠券，获取数据耗时:{}",(t2-t1));
            SXSSFWorkbook wb = new SXSSFWorkbook(ROW_LINE);
//            List<Object[]> alllist = null;
            if(result != null && result.isSuccess()){
                List<CouponsApi> list = (List<CouponsApi>) result.getT();
                List<CouponsApi> newlist = new ArrayList<CouponsApi>(list.size());
                CouponsApi api = null;
                for(int i = 0; i < list.size(); i++){
                    CouponsApi couponsApi = list.get(i);
                    api = new CouponsApi();
                    String trueMacode = "";
                    trueMacode = list.get(i).getMacode();
                    if (itCode.equals(list.get(i).getCreateby())){
                        if (trueMacode.length()>10){
                            trueMacode = TripleDESUtil.decryptMode(trueMacode);
                        }else {
                            trueMacode = list.get(i).getMacode();
                        }
                    }else {
                        if (trueMacode.length()>10){
                            trueMacode = TripleDESUtil.hiddenCharacter(TripleDESUtil.decryptMode(trueMacode),4,"*");
                        }else {
                            trueMacode = TripleDESUtil.hiddenCharacter(trueMacode, 4, "*");
                        }
                    }
                    api.setBatchno(couponsApi.getBatchno());
                    api.setName(couponsApi.getName());
                    api.setMacode(trueMacode);
                    api.setShopid(couponsApi.getShopid());
                    api.setTerminal(couponsApi.getTerminal());
                    api.setStarttime(couponsApi.getStarttime());
                    api.setEndtime(couponsApi.getEndtime());
                    api.setAmount(couponsApi.getAmount());
                    api.setCurrencyCode(couponsApi.getCurrencyCode());
                    api.setTotalnumber(couponsApi.getTotalnumber());
                    api.setOccupynumber(couponsApi.getOccupynumber());
                    api.setType(couponsApi.getType());
                    api.setCreateby(couponsApi.getCreateby());
                    api.setCreatetime(couponsApi.getCreatetime());
                    newlist.add(api);
                }
                ExcelUtils.writeXSLXExcel(wb, couponsCodeHeader, createCouponsData(newlist));
//                alllist =  createCouponsData(newlist);
            }

            long t3 = System.currentTimeMillis();
//            String fileName = "CouponCode_"+salescouponid+".xlsx";
            String realFileName = "CouponCode_"+salescouponid+".xlsx";
//            byte[] bos = getByte(alllist,fileName);
            long timeStamp = new Date().getTime();
            logger.info("appId:{}，appKey：{},domain:{}",new Object[]{appId, appKey,domain});
            String token = UploadImageClient.getToken(appId, appKey, timeStamp, targetCouponCodeFilePath+realFileName, "1");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            wb.write(bos);
            UploadResponse uploadResponse = UploadImageClient.upload(appId, token, timeStamp, imageServerURL+targetCouponCodeFilePath+realFileName, bos.toByteArray(), realFileName, "1");
            printResult(invokeMethod, uploadResponse);
            String readURL = PrivateSpcaceManager.getReadURL(appId, appKey, domain, targetCouponCodeFilePath+realFileName);
            long t4 = System.currentTimeMillis();
            logger.info("上传文件耗时：{},readUrl:{}",(t4-t3),readURL);
            remoteResult.setSuccess(true);
            remoteResult.setResultCode("00");
            remoteResult.setResultMsg("操作成功");
            remoteResult.setT(readURL);
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            // wb.dispose();
            //bos.close();
            return;
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }



    /**
     * 导出追加优惠码的基本信息，并导出生成的优惠码
     * @param request
     * @param response
     * @param map
     */
    @RequestMapping("/exportCouponCodeIsAppend")
    public void exportCouponCodeToExcelIsAppend(HttpServletRequest request, HttpServletResponse response, Map<String,Object> map){
        String invokeMethod = "api/coupon/exportCouponCode";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        try {
            String salescouponid = request.getParameter("salescouponid");
            String itCode = AuthData.getUserId(request);
            if(StringUtils.isEmpty(salescouponid) || StringUtils.isEmpty(itCode)){
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("02");
                remoteResult.setResultMsg("参数错误");
                printWriter.write(JsonUtil.toJson(remoteResult));
                printWriter.close();
                return;
            }
            long t1 = System.currentTimeMillis();
            RemoteResult result = adminCouponsService.getCouponsBySalescouponsIdIsAppend(Integer.parseInt(salescouponid));
            long t2 = System.currentTimeMillis();
            logger.info("导出优惠券，获取数据耗时:{}",(t2-t1));
            SXSSFWorkbook wb = new SXSSFWorkbook(ROW_LINE);
//            List<Object[]> alllist = null;
            if(result != null && result.isSuccess()){
                List<CouponsApi> list = (List<CouponsApi>) result.getT();
                List<CouponsApi> newlist = new ArrayList<CouponsApi>(list.size());
                CouponsApi api = null;
                for(int i = 0; i < list.size(); i++){
                    CouponsApi couponsApi = list.get(i);
                    api = new CouponsApi();
                    String trueMacode = "";
                    trueMacode = list.get(i).getMacode();
                    if (itCode.equals(list.get(i).getCreateby())){
                        if (trueMacode.length()>10){
                            trueMacode = TripleDESUtil.decryptMode(trueMacode);
                        }else {
                            trueMacode = list.get(i).getMacode();
                        }
                    }else {
                        if (trueMacode.length()>10){
                            trueMacode = TripleDESUtil.hiddenCharacter(TripleDESUtil.decryptMode(trueMacode),4,"*");
                        }else {
                            trueMacode = TripleDESUtil.hiddenCharacter(trueMacode, 4, "*");
                        }
                    }
                    api.setBatchno(couponsApi.getBatchno());
                    api.setName(couponsApi.getName());
                    api.setMacode(trueMacode);
                    api.setShopid(couponsApi.getShopid());
                    api.setTerminal(couponsApi.getTerminal());
                    api.setStarttime(couponsApi.getStarttime());
                    api.setEndtime(couponsApi.getEndtime());
                    api.setAmount(couponsApi.getAmount());
                    api.setCurrencyCode(couponsApi.getCurrencyCode());
                    api.setTotalnumber(couponsApi.getTotalnumber());
                    api.setOccupynumber(couponsApi.getOccupynumber());
                    api.setType(couponsApi.getType());
                    api.setCreateby(couponsApi.getCreateby());
                    api.setCreatetime(couponsApi.getCreatetime());
                    newlist.add(api);
                }
                ExcelUtils.writeXSLXExcel(wb, couponsCodeHeader, createCouponsData(newlist));
//                alllist =  createCouponsData(newlist);
            }

            long t3 = System.currentTimeMillis();
            String realFileName = "CouponCode_Append_"+salescouponid+".xlsx";
//            String realFileName = "CouponCode_Append_"+salescouponid+".zip";
//            byte[] bos = getByte(alllist,fileName);
            long timeStamp = new Date().getTime();
            logger.info("appId:{}，appKey：{},domain:{}",new Object[]{appId, appKey,domain});
            String token = UploadImageClient.getToken(appId, appKey, timeStamp, targetCouponCodeFilePath+realFileName, "1");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            wb.write(bos);
            UploadResponse uploadResponse = UploadImageClient.upload(appId, token, timeStamp, imageServerURL+targetCouponCodeFilePath+realFileName, bos.toByteArray(), realFileName, "1");
            printResult(invokeMethod, uploadResponse);
            String readURL = PrivateSpcaceManager.getReadURL(appId, appKey, domain, targetCouponCodeFilePath+realFileName);
            long t4 = System.currentTimeMillis();
            logger.info("上传文件耗时：{},readUrl:{}",(t4-t3),readURL);
            remoteResult.setSuccess(true);
            remoteResult.setResultCode("00");
            remoteResult.setResultMsg("操作成功");
            remoteResult.setT(readURL);
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            // wb.dispose();
            //bos.close();
            return;
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    private byte[] getByte(List<Object[]> alllist,String name) throws IOException{
        if(null == alllist || alllist.size() <=0){
            return null;
        }
        ClasspathResourceLoader resourceLoader = new ClasspathResourceLoader();
        Configuration cfg = Configuration.defaultConfiguration();
        GroupTemplate gt = new GroupTemplate(resourceLoader, cfg);
        Template t = gt.getTemplate("/reportTemplate/export-couponcode-template.xml");
        List<Object[]> list1 = getList(alllist, 1);

        List<Object[]> list2 = getList(alllist, 2);
        List<Object[]> list3 = getList(alllist, 3);
        List<Object[]> list4 = getList(alllist, 4);
        List<Object[]> list5 = getList(alllist, 5);
        List<Object[]> list6 = getList(alllist, 6);
        List<Object[]> list7 = getList(alllist, 7);
        List<Object[]> list8 = getList(alllist, 8);
        List<Object[]> list9 = getList(alllist, 9);
        List<Object[]> list10 = getList(alllist, 10);

        t.binding("countsheet1", list1.size()+1);
        t.binding("sheet1List", list1);
        t.binding("sheet2List", list2);
        t.binding("sheet3List", list3);
        t.binding("sheet4List", list4);
        t.binding("sheet5List", list5);
        t.binding("sheet6List", list6);
        t.binding("sheet7List", list7);
        t.binding("sheet8List", list8);
        t.binding("sheet9List", list9);
        t.binding("sheet10List", list10);

        t.binding("countsheet2", list2.size()+1);
        t.binding("countsheet3", list3.size()+1);
        t.binding("countsheet4", list4.size()+1);
        t.binding("countsheet5", list5.size()+1);
        t.binding("countsheet6", list6.size()+1);
        t.binding("countsheet7", list7.size()+1);
        t.binding("countsheet8", list8.size()+1);
        t.binding("countsheet9", list9.size()+1);
        t.binding("countsheet10", list10.size()+1);
        String temp = t.render();
        return  ZipUtils.zip(temp, name);
    }

    private List<Object[]> getList(List<Object[]> alllist,int sheet){
        int size = alllist.size();
        int sheetcount = alllist.size() % 50000 ==0 ?alllist.size() / 50000 :alllist.size() / 50000+1 ;
        if(sheet<sheetcount){
            return alllist.subList((sheet-1)*50000, 50000*sheet);
        }
        if(sheet == sheetcount){
            return alllist.subList((sheet-1)*50000, size);
        }
        return new ArrayList<>(1);
    }

    /**
     * 将登录人所创建的优惠码导出到Excel中，并显示明文
     * @param request
     * @param response
     * @param map
     */
    @RequestMapping(value = "/exportMacodeToExcel" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void exportMaCodeToExcel(HttpServletRequest request, HttpServletResponse response, Map<String,Object> map){
        String invokeMethod = "api/coupon/exportMacodeToExcel";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        try {
            Map<String, Object> conditionMap = new HashMap<String, Object>();

            String itCode = AuthData.getUserId(request);
            String name = request.getParameter("name");
            String macode = request.getParameter("macode");
            String amount = request.getParameter("amount");
            String fromtime = request.getParameter("fromtime");
            String totime = request.getParameter("totime");
            String shopid = request.getParameter("shopId");
            String terminal = request.getParameter("terminal");
            String type = request.getParameter("type");

            if (StringUtils.isNotEmpty(itCode)){
                conditionMap.put("createby", itCode);
            }
            if(StringUtils.isNotEmpty(name)){
                conditionMap.put("name", name);
            }
            if(StringUtils.isNotEmpty(macode)){
                conditionMap.put("macode", macode);
            }
            if(StringUtils.isNotEmpty(amount)){
                conditionMap.put("amount", amount);
            }
            if (StringUtils.isNotEmpty(fromtime)) {
                conditionMap.put("fromtime", DateUtil.format4easyui(fromtime));
            }
            if (StringUtils.isNotEmpty(totime)) {
                conditionMap.put("totime", DateUtil.format4easyui(totime));
            }
            if (StringUtils.isNotEmpty(shopid) && !"99".equals(shopid)) {
                conditionMap.put("shopid", shopid);
            }
            if (StringUtils.isNotEmpty(terminal) && !"99".equals(terminal)) {
                conditionMap.put("terminal", terminal);
            }
            if (StringUtils.isNotEmpty(type) && !"99".equals(type)) {
                conditionMap.put("type", type);
            }

            PageQuery pageQuery = new PageQuery(getPage(request), EXPORT_MAX_PAGE_SIZE);;
            RemoteResult<PageModel2<CouponsApi>> result = adminCouponsService.getExportCouponsInfoPage(pageQuery, conditionMap);
            int  allRow =0;
            SXSSFWorkbook wb = new SXSSFWorkbook(ROW_LINE);
            if(result != null && result.isSuccess()){
                List<CouponsApi> hiddenlist = result.getT().getDatas();
                List<CouponsApi> list = new ArrayList<CouponsApi>();
                CouponsApi api = null;
                for (int i=0;i<hiddenlist.size();i++){
                    CouponsApi couponsApi = hiddenlist.get(i);
                    api = new CouponsApi();
                    String trueMacode = "";
                    trueMacode = TripleDESUtil.hiddenCharacter(couponsApi.getMacode(),0,"*");
                    api.setBatchno(couponsApi.getBatchno());
                    api.setName(couponsApi.getName());
                    api.setMacode(trueMacode);
                    api.setShopid(couponsApi.getShopid());
                    api.setTerminal(couponsApi.getTerminal());
                    api.setStarttime(couponsApi.getStarttime());
                    api.setEndtime(couponsApi.getEndtime());
                    api.setAmount(couponsApi.getAmount());
                    api.setCurrencyCode(couponsApi.getCurrencyCode());
                    api.setTotalnumber(couponsApi.getTotalnumber());
                    api.setOccupynumber(couponsApi.getOccupynumber());
                    api.setType(couponsApi.getType());
                    api.setCreateby(couponsApi.getCreateby());
                    api.setCreatetime(couponsApi.getCreatetime());
                    list.add(api);
                }
                allRow = ExcelUtils.writeXSLXExcel(wb, couponsCodeHeader, createCouponsData(list));
            }

            String fileName = "优惠码信息.xlsx";
            long timeStamp = new Date().getTime();
            String token = UploadImageClient.getToken(appId, appKey, timeStamp, targetCouponCodeFilePath+fileName, "1");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            wb.write(bos);
            UploadResponse uploadResponse = UploadImageClient.upload(appId, token, timeStamp, imageServerURL+targetCouponCodeFilePath+fileName, bos.toByteArray(), fileName, "1");
            printResult(invokeMethod, uploadResponse);
            String readURL = PrivateSpcaceManager.getReadURL(appId, appKey, domain, targetCouponCodeFilePath+fileName);
            remoteResult.setSuccess(true);
            remoteResult.setResultCode("00");
            remoteResult.setResultMsg("操作成功");
            remoteResult.setT(readURL);
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 发送优惠券给选中的会员
     * @param request
     * @param response
     */
    @RequestMapping(value = "/sendToSelectedMember" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void sendCouponToSelectedMember(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/sendToSelectedMember";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        String members = request.getParameter("members");
        String couponid = request.getParameter("couponid");
        String shopid = request.getParameter("shopid");
        if(StringUtils.isEmpty(members) || StringUtils.isEmpty(couponid) || StringUtils.isEmpty(shopid)){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("02");
            remoteResult.setResultMsg("参数错误");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }
        String[] member_s = members.split(",");
        if(member_s.length <= 0){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("02");
            remoteResult.setResultMsg("参数错误");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }
        try {
            String itCode = AuthData.getUserId(request);
            RemoteResult<SalescouponsApi> result = salescouponsRemote.getSalescouponsById(Long.valueOf(couponid));
            if(result != null && result.isSuccess()){
                SalescouponsApi salescouponsApi = result.getT();
                int maxNum = salescouponsApi.getMaxnumber() == null ? 0 : salescouponsApi.getMaxnumber();
                int sendNum = salescouponsApi.getSendnumber() == null ? 0 : salescouponsApi.getSendnumber();
                int remainNum = maxNum - sendNum;
                if(remainNum >= member_s.length){
                    List<MemberVo> list = new ArrayList<MemberVo>();
                    for (int i=0; i<member_s.length; i++){
                        String[] strings = member_s[i].split(";");
                        MemberVo memberVo = new MemberVo();
                        memberVo.setLenovoId(strings[0]);
                        memberVo.setLoginname(strings[1]);
                        list.add(memberVo);
                    }
                    RemoteResult<Boolean> sendResult = salescouponsRemote.sendCouponsToMember(salescouponsApi.getId(), list, itCode);
                    if(sendResult != null && sendResult.isSuccess()){
                        remoteResult.setSuccess(true);
                        remoteResult.setResultCode("00");
                        remoteResult.setResultMsg("操作成功");
                        SalescouponsApi coupon = new SalescouponsApi();
                        coupon.setId(salescouponsApi.getId());
                        coupon.setBacksend(CouponConstant.COUPON_Backsend_1);
                        coupon.setSendnumber((salescouponsApi.getSendnumber() == null ? 0 : salescouponsApi.getSendnumber()) + member_s.length);
                        salescouponsRemote.editSalescouponsOnly(coupon);
                    }else {
                        remoteResult.setSuccess(false);
                        remoteResult.setResultCode("01");
                        remoteResult.setResultMsg("操作失败");
                    }
                }else {
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode("03");
                    remoteResult.setResultMsg("优惠券数量不足");
                }
                printWriter.write(JsonUtil.toJson(remoteResult));
                printWriter.close();
                return;
            }
        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 优惠码信息列表查询
     *
     * @param request
     * @param response
     * @param map
     * @return
     */
    @RequestMapping(value = "/queryCouponsCodeInfoPage",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void queryCouponsCodeInfoPage(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        Map<String, Object> conditionMap = new HashMap<String, Object>();
        String itCode = AuthData.getUserId(request);

        List<String> shopids = AuthData.getShopIds(request);

        String name = request.getParameter("name");
        String salescouponid = request.getParameter("salescouponid");
        String macode = request.getParameter("macode");
        String type = request.getParameter("type");
        String amount = request.getParameter("amount");
        String fromtime = request.getParameter("fromtime");
        String totime = request.getParameter("totime");
        String createtime_start = request.getParameter("createtime_start");
        String createtime_end = request.getParameter("createtime_end");
        String shopid = request.getParameter("shopid");
        String terminal = request.getParameter("terminal");
        String pageSize = request.getParameter("rows");

        conditionMap.put("name", name);
        conditionMap.put("macode", macode);
        conditionMap.put("amount", amount);
        conditionMap.put("shopids",shopids);
        if (StringUtils.isNotEmpty(itCode)){
            conditionMap.put("createby", itCode);
        }
        if (StringUtils.isNotEmpty(salescouponid)) {
            conditionMap.put("salescouponid", salescouponid);
        }
        if (StringUtils.isNotEmpty(fromtime)) {
            conditionMap.put("fromtime", DateUtil.format4easyui(fromtime));
        }
        if (StringUtils.isNotEmpty(totime)) {
            conditionMap.put("totime", DateUtil.format4easyui(totime));
        }
        if (StringUtils.isNotEmpty(createtime_start)) {
            conditionMap.put("createtime_start", DateUtil.format4easyui(createtime_start));
        }
        if (StringUtils.isNotEmpty(createtime_end)) {
            conditionMap.put("createtime_end", DateUtil.format4easyui(createtime_end));
        }
        if (StringUtils.isNotEmpty(shopid) && !"99".equals(shopid)) {
            conditionMap.put("shopid", shopid);
        }
        if (StringUtils.isNotEmpty(terminal) && !"99".equals(terminal)) {
            conditionMap.put("terminal", terminal);
        }
        if (StringUtils.isNotEmpty(type) && !"99".equals(type)) {
            conditionMap.put("type", type);
        }

        PageQuery pageQuery=null;
        if(StringUtils.isNotEmpty(pageSize)){
            pageQuery = new PageQuery(getPage(request),Integer.parseInt(pageSize));
        }else{
            pageQuery = new PageQuery(getPage(request),PAGE_SIZE);
        }

        String json = null;
        RemoteResult<PageModel2<CouponsApi>> result = adminCouponsService.getCouponsInfoPage(pageQuery, conditionMap);
        if (result != null && result.getT() != null && result.isSuccess()) {

            PageModel2<CouponsApi> pageModel2 = result.getT();

            json = JsonUtil.toJson(result);
            try {
                response.getWriter().println(json);
            } catch (IOException e) {
                logger.error(ExceptionUtil.getStackTrace(e));
            }
        }
    }

    /**
     * 发送优惠券给查询出来的所有满足条件的用户
     * @param request
     * @param response
     */
    @RequestMapping(value = "/sendToMember" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void sendCouponToMember(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/sendToMember";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        try {
            String itCode = AuthData.getUserId(request);
            String couponId = request.getParameter("couponid");
            String memberCode = request.getParameter("membercode");
            String registerTime_Start = request.getParameter("reg_starttime");
            String registerTime_end = request.getParameter("reg_endtime");
            String eppgroupcode = request.getParameter("eppgroupcode");
            if (StringUtils.isEmpty(couponId)){
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("02");
                remoteResult.setResultMsg("参数错误");
                printWriter.write(JsonUtil.toJson(remoteResult));
                printWriter.close();
                return;
            }
            Date currentTime = new Date();
            SalescouponsApi salescouponsApi = new SalescouponsApi();
            salescouponsApi.setId(Long.valueOf(couponId));
            RemoteResult<SalescouponsApi> result = salescouponsRemote.getSalescoupons(salescouponsApi);
            if(null != result && result.isSuccess() && result.getT() != null){
                List<UsergroupcouponrelApi> ugcList = new ArrayList<UsergroupcouponrelApi>();
                SalescouponsApi coupon = result.getT();
                int flag = 0;
                if(coupon.getStatus() != CouponConstant.COUPON_STATUS_PASTAUDIT_2){
                    logger.info("调用 ["+invokeMethod+"], 优惠券没有通过审核，CouponId: "+couponId);
                    flag++;
                }
                if(currentTime.after(coupon.getTotime())){
                    logger.info("调用 [" + invokeMethod + "], 优惠券已过期，CouponId: " + couponId);
                    flag++;
                }
                if (String.valueOf(ShopIdEnum.EPP.getType()).equals(coupon.getShopid())) {
                    if (StringUtils.isEmpty(coupon.getEppgroup())) {
                        logger.info("调用 ["+invokeMethod+"], EPP组为空，CouponId: "+couponId);
                        flag++;
                    }
                    if(StringUtils.isEmpty(eppgroupcode)){
                        String[] groups = coupon.getEppgroup().split(",");
                        for (String group : groups) {
                            UsergroupcouponrelApi uapi = new UsergroupcouponrelApi();
                            uapi.setSalescouponid(String.valueOf(coupon.getId()));
                            uapi.setShopid(coupon.getShopid());
                            uapi.setTerminal(coupon.getTerminal());
                            uapi.setUsergroup(group);
                            uapi.setSendtime(currentTime);
                            uapi.setCreateby(itCode);
                            uapi.setCreatetime(currentTime);
                            ugcList.add(uapi);
                        }
                    }else {
                        UsergroupcouponrelApi uapi = new UsergroupcouponrelApi();
                        uapi.setSalescouponid(String.valueOf(coupon.getId()));
                        uapi.setShopid(coupon.getShopid());
                        uapi.setTerminal(coupon.getTerminal());
                        uapi.setUsergroup(eppgroupcode);
                        uapi.setSendtime(new Date());
                        uapi.setCreateby(itCode);
                        uapi.setCreatetime(new Date());
                        ugcList.add(uapi);
                    }
                }else{
                    UsergroupcouponrelApi uapi = new UsergroupcouponrelApi();
                    uapi.setSalescouponid(String.valueOf(coupon.getId()));
                    uapi.setShopid(coupon.getShopid());
                    uapi.setTerminal(coupon.getTerminal());
                    uapi.setUsergroup(CouponConstant.COUPON_Lenovo_Think_GROUPCODE);
                    uapi.setSendtime(new Date());
                    uapi.setCreateby(itCode);
                    uapi.setCreatetime(new Date());
                    ugcList.add(uapi);
                }
                if(flag > 0){
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode("03");
                    remoteResult.setResultMsg("优惠券不符合发放条件");
                    printWriter.write(JsonUtil.toJson(remoteResult));
                    printWriter.close();
                    return;
                }
                if(StringUtils.isNotEmpty(registerTime_Start)){
                    for (UsergroupcouponrelApi usergroupcouponrelApi : ugcList){
                        usergroupcouponrelApi.setRegisterfromtime(new SimpleDateFormat("yyyy-MM-dd").parse(registerTime_Start));
                    }
                }else {
                    for (UsergroupcouponrelApi usergroupcouponrelApi : ugcList){
                        usergroupcouponrelApi.setRegisterfromtime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("1970-01-01 00:00:00"));
                    }
                }
                if(StringUtils.isNotEmpty(registerTime_end)){
                    for (UsergroupcouponrelApi usergroupcouponrelApi : ugcList){
                        usergroupcouponrelApi.setRegistertotime(new SimpleDateFormat("yyyy-MM-dd").parse(registerTime_end));
                    }
                }else {
                    for (UsergroupcouponrelApi usergroupcouponrelApi : ugcList){
                        usergroupcouponrelApi.setRegistertotime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("9999-12-31 23:59:59"));
                    }
                }
                RemoteResult saveResult = adminUsergroupcouponrelService.insertBatch(ugcList);
                if(saveResult != null && saveResult.isSuccess()){
                    SalescouponsApi sapi = new SalescouponsApi();
                    sapi.setId(coupon.getId());
                    sapi.setWholenumber(coupon.getWholenumber() + 1);
                    sapi.setBacksend(CouponConstant.COUPON_Backsend_1);// 1 已经发过券，0 未发过券
                    sapi.setUpdatetime(currentTime);
                    sapi.setUpdateby(itCode);
                    RemoteResult rr = salescouponsRemote.editSalescouponsOnly(sapi);
                    if(rr != null && rr.isSuccess()){
                        remoteResult.setSuccess(true);
                        remoteResult.setResultCode("00");
                        remoteResult.setResultMsg("操作成功");
                    }
                }else {
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode("01");
                    remoteResult.setResultMsg("操作失败");
                }
            }else {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("04");
                remoteResult.setResultMsg("优惠券不存在");
            }
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;

        } catch (Exception e) {
            returnExceptionResult(e, remoteResult, printWriter, invokeMethod);
        }
    }

    /**
     * 通过Excel导入，给指定用户发送指定的优惠券
     * @param request
     * @param response
     */
    @RequestMapping(value = "/importMembersToSendCoupon" , produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void importMembersToSendCoupon(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/importMembersToSendCoupon";
        logger.info(invokeMethod + "上传文件");
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        String couponId = request.getParameter("couponId");
        String itCode = request.getParameter("userId");

        if(StringUtils.isEmpty(couponId)){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("02");
            remoteResult.setResultMsg("优惠券为空，请选择要发送的优惠券");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }
        RemoteResult<SalescouponsApi> result = salescouponsRemote.getSalescouponsById(Long.valueOf(couponId));
        if(result == null || !result.isSuccess()){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("02");
            remoteResult.setResultMsg("优惠券不存在");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }
        SalescouponsApi salescouponsApi = result.getT();
        logger.info(request.getParameter("fileData"));
        net.sf.json.JSONArray fileData = request.getParameter("fileData")!=null ? net.sf.json.JSONArray.fromObject(request.getParameter("fileData")):null;
        if(fileData == null || fileData.size() == 0){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("03");
            remoteResult.setResultMsg("上传的文件为空");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }
        /*String fileName = file.getOriginalFilename();
        logger.info(invokeMethod + "上传文件为："+fileName);
        fileName = fileName.toLowerCase();
        logger.info(fileName);
        if(!fileName.endsWith(".xls") && !fileName.endsWith(".xlsx")){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("04");
            remoteResult.setResultMsg("文件格式不正确");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }*/
        Map<String,List> mapExcel = this.uploadJsonMember(fileData);
        List<ExtErrorVo> errorList = mapExcel.get("errorList");
        List<MemberExcelTempApi> memApiList = mapExcel.get("memlist");
        logger.info("导入的用户列表："+JsonUtil.toJson(memApiList));
        if(memApiList == null || memApiList.size() == 0){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("05");
            remoteResult.setResultMsg("上传的Excel内容错误");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }
        int totalCouponNum = salescouponsApi.getMaxnumber()==null?0:salescouponsApi.getMaxnumber();
        int alreadySendNum = salescouponsApi.getSendnumber()==null?0:salescouponsApi.getSendnumber();
        if(memApiList.size() > (totalCouponNum-alreadySendNum)){
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("06");
            remoteResult.setResultMsg("要发送的用户数大于优惠券可发送数");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }
        Map<String, MemberExcelTempApi> memMap = new HashMap<String, MemberExcelTempApi>(memApiList.size());
        for(MemberExcelTempApi memberExcelTempApi :memApiList){
            memMap.put(memberExcelTempApi.getLenovoid(), memberExcelTempApi);
        }
        RemoteResult<List<MembercouponrelsApi>> rr = adminMemberCouponService.getMemberCouponsBySalesCouponId(Long.valueOf(couponId));
        if(rr != null && rr.isSuccess()){
            List<MembercouponrelsApi> membercouponrelsApiList = rr.getT();
            if(CollectionUtils.isNotEmpty(membercouponrelsApiList)) {
                eliminateMember(memMap, membercouponrelsApiList);
            }
        }

        List<MembercouponrelsApi> list = assembleMemberCouponRels(memMap, salescouponsApi, itCode);
        RemoteResult remoteResultInsert = adminMemberCouponService.insertBatchMembercouponrels(list);
        if(remoteResultInsert != null && remoteResultInsert.isSuccess()){
            remoteResult.setSuccess(true);
            remoteResult.setResultCode("00");
            remoteResult.setResultMsg("发券成功");
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
            return;
        }
        remoteResult.setSuccess(false);
        remoteResult.setResultCode("07");
        remoteResult.setResultMsg("发券失败");
        printWriter.write(JsonUtil.toJson(remoteResult));
        printWriter.close();
        return;
    }

    /**
     * 接收JsonArray，读取数据并封装
     * @param fileData
     * @return
     */
    public static Map<String,List> uploadJsonMember(net.sf.json.JSONArray fileData){
        Map<String,List> resultMap = new HashMap<String, List>();
        List<ExtErrorVo> errorVoList = new ArrayList<ExtErrorVo>();
        List<MemberExcelTempApi> memApiList = new ArrayList<MemberExcelTempApi>();
        List<MemberExcelTempApi> memlist = new ArrayList<MemberExcelTempApi>();
        try {
            for (int i = 0; i < fileData.size(); i++) {
                JSONObject jsonData = fileData.get(i) != null ? (JSONObject) fileData.get(i):null;
                if(null==jsonData){
                    continue;
                }
                int rowNumber =i+1;
                insertRow(errorVoList,memlist,rowNumber,jsonData);
            }
            if (!memlist.isEmpty()){
                for (MemberExcelTempApi memApi : memlist){
                    memApiList.add(memApi);
                }
            }
        } catch (Exception e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        resultMap.put("errorList", errorVoList);
        resultMap.put("memlist", memlist);
        return  resultMap;
    }

    /**
     * 插入数据到List
     * @param errorlist
     * @param memlist
     * @param rowNumber
     * @param jsonData
     */
    public static void insertRow(List<ExtErrorVo> errorlist,List<MemberExcelTempApi> memlist,int rowNumber,JSONObject jsonData){
        MemberExcelTempApi member = new MemberExcelTempApi();
        String lenovoId = jsonData.get("LenovoId")!=null?(String)jsonData.get("LenovoId"):null;
        String memberCode = jsonData.get("MemberCode")!=null?(String)jsonData.get("MemberCode"):null;
        if(null!=lenovoId){
            if (StringUtils.isEmpty(lenovoId)){
                logError(errorlist,rowNumber,1,"第"+rowNumber+"行，第"+1+"LenovoId数据错误");
            }else {
                member.setLenovoid(lenovoId);
            }
        }else{
            logError(errorlist,rowNumber,1,"第"+rowNumber+"行，第"+1+"LenovoId数据错误");
        }
        if(null!=memberCode){
            if (StringUtils.isEmpty(memberCode)){
                logError(errorlist,rowNumber,2,"第"+rowNumber+"行，第"+2+"列MemberCode数据错误");
            }else {
                member.setMembercode(memberCode);
            }
        }else{
            logError(errorlist,rowNumber,2,"第"+rowNumber+"行，第"+2+"列MemberCode数据错误");
        }
        if(!memlist.contains(member)) {
            memlist.add(member);
        }
    }

    /**
     * 封装错误信息
     * @param errorList
     * @param rowNumber
     * @param colNumber
     * @param errorMessage
     */
    public static void logError(List<ExtErrorVo> errorList, int rowNumber, int colNumber, String errorMessage){
        ExtErrorVo erVo = new ExtErrorVo();
        erVo.setRowNumber(rowNumber);
        erVo.setColnNumber(colNumber);
        erVo.setErrorMsg(errorMessage);
        errorList.add(erVo);
    }

    /*
     * 领券管理中心--查询
     *分页查询用户可以获得的优惠券列表
     * */
    @RequestMapping(value="/queryAvailableCouponsInfoPage",produces = "text/html;charset=UTF-8")
    public void queryAvailableCouponsInfoPage(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map){

        String invokeMethod = "api/coupon/queryAvailableCouponsInfoPage";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }

        List<String> shopids = AuthData.getShopIds(request);
        Map<String, Object> conditionMap = new HashMap<String, Object>();

        String name = request.getParameter("name");
        String usescope = request.getParameter("usescope");
        String shopid = request.getParameter("shopId");
        String terminal = request.getParameter("terminal");
        String getstarttime = request.getParameter("getstarttime");
        String getendtime = request.getParameter("getendtime");
        String fromtime = request.getParameter("fromtime");
        String totime = request.getParameter("totime");
        String pageSize = request.getParameter("rows");
        String position = request.getParameter("displayPosition");//0，在个人中心显示，1在小新显示


        conditionMap.put("style", CouponConstant.COUPON_style_coupon_1);//查询优惠券
        conditionMap.put("name", name);
        conditionMap.put("shopids",shopids);
        if (StringUtils.isNotEmpty(usescope) && !"99".equals(usescope)) {
            conditionMap.put("usescope", usescope);
        }
        if (StringUtils.isNotEmpty(getstarttime)) {
            conditionMap.put("getstarttime", DateUtil.format4easyui(getstarttime));
        }
        if (StringUtils.isNotEmpty(getendtime)) {
            conditionMap.put("getendtime", DateUtil.format4easyui(getendtime));
        }
        if (StringUtils.isNotEmpty(fromtime)) {
            conditionMap.put("fromtime", DateUtil.format4easyui(fromtime));
        }
        if (StringUtils.isNotEmpty(totime)) {
            conditionMap.put("totime", DateUtil.format4easyui(totime));
        }
        if (StringUtils.isNotEmpty(shopid) && !"99".equals(shopid)) {
            conditionMap.put("shopid", shopid);
        }
        if (StringUtils.isNotEmpty(terminal) && !"99".equals(terminal)) {
            conditionMap.put("terminal", terminal);
        }
        if(StringUtils.isNotEmpty(position)){
            conditionMap.put("displayPosition", position);
        }
        PageQuery pageQuery=null;
        if(StringUtils.isNotEmpty(pageSize)){
            pageQuery = new PageQuery(getPage(request),Integer.parseInt(pageSize));
        }else{
            pageQuery = new PageQuery(getPage(request),PAGE_SIZE);
        }
        String json = null;
        RemoteResult<PageModel2<SalescouponsApi>> result = salescouponsRemote.getAvailableSalescouponsInfoPage(pageQuery, conditionMap);
        if (result != null && result.getT() != null && result.isSuccess()) {

            PageModel2<SalescouponsApi> pageModel2 = result.getT();
            json = JsonUtil.list2json((int) pageModel2.getTotalCount(), pageModel2.getDatas());
            try {
                response.getWriter().println(json);
            } catch (IOException e) {
                logger.error(ExceptionUtil.getStackTrace(e));
            }
        }
    }

    /*
     *领券中心管理--将制定优惠券从列表中删除
     * */

    @RequestMapping(value="/deleteAvailableCoupon",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String deleteAvailableCoupon(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/deleteAvailableCoupon";
        String itCode = AuthData.getUserId(request);
        String couponId = request.getParameter("couponId");
        String displayPosition = request.getParameter("displayPosition");
        RemoteResult remoteResult = adminGetCouponsService.deleteAvailableSalescoupons(itCode, couponId,displayPosition);
        logger.info("deleteAvailableCoupon return="+JsonUtil.toJson(remoteResult));
        return JsonUtil.toJson(remoteResult);
    }
    /*
     *领券中心管理--清空优惠券列表
     *
     * */
    @RequestMapping(value="/deleteAllAvailableCoupons",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String deleteAllAvailableCoupons(HttpServletRequest request, HttpServletResponse response){
        String invokeMethod = "api/coupon/deleteAllAvailableCoupons";
        String itCode = AuthData.getUserId(request);
        RemoteResult remoteResult = adminGetCouponsService.deleteAllAvailableSalescoupons(itCode);
        logger.info("deleteAllAvailableCoupons return="+JsonUtil.toJson(remoteResult));
        return JsonUtil.toJson(remoteResult);
    }
    /*
     *领券中心管理--添加时调用 查询优惠券列表
     *
     * */
    @RequestMapping(value="/queryCouponsInfoPage",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public void queryCouponsInfoPage(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map,Integer displayPosition){
        String invokeMethod = "api/coupon/queryCouponsInfoPage";
        List<String> shopids = AuthData.getShopIds(request);;
        Map<String, Object> conditionMap = new HashMap<String, Object>();

        String name = request.getParameter("name");
        String pageSize = request.getParameter("rows");
        String shopId = request.getParameter("shopId");

        if (StringUtils.isNotEmpty(name)) {
            conditionMap.put("name", name);
        }

        conditionMap.put("style", CouponConstant.COUPON_style_coupon_1);//查询优惠券
        conditionMap.put("iscanget", CouponConstant.COUPON_ISCANGET_CAN);
        conditionMap.put("Status", CouponConstant.COUPON_STATUS_PASTAUDIT_2);
        conditionMap.put("displayPosition",displayPosition);
        conditionMap.put("shopId",shopId);
        PageQuery pageQuery=null;
        if(StringUtils.isNotEmpty(pageSize)){
            pageQuery = new PageQuery(getPage(request),Integer.parseInt(pageSize));
        }else{
            pageQuery = new PageQuery(getPage(request),PAGE_SIZE);
        }
        String json = null;
        RemoteResult<PageModel2<SalescouponsApi>> result = salescouponsRemote.getAllAvailableSalescouponsInfoPage(pageQuery, conditionMap);
        if (result != null && result.getT() != null && result.isSuccess()) {

            PageModel2<SalescouponsApi> pageModel2 = result.getT();
            json = JsonUtil.list2json((int) pageModel2.getTotalCount(), pageModel2.getDatas());
            try {
                logger.info("queryCouponsInfoPage response="+JsonUtil.toJson(json));
                response.getWriter().println(json);
            } catch (IOException e) {
                logger.error(ExceptionUtil.getStackTrace(e));
            }
        }
    }
    /*
     *领券中心管理--保存选中优惠券
     *
     * */
    @RequestMapping(value="/saveSelectedCoupons",produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String saveSelectedCoupons(HttpServletRequest request, HttpServletResponse response,Integer displayPosition){
        String invokeMethod = "api/coupon/saveSelectedCoupons";

        RemoteResult<String> result = new RemoteResult<String>(false);
        String itCode = AuthData.getUserId(request);
        String couponIds = request.getParameter("couponIds");
        try {
            result = adminGetCouponsService.saveAvailableSalescoupons(itCode, couponIds.split(","),displayPosition);
            logger.info("saveSelectedCoupons response="+JsonUtil.toJson(result));

        } catch (Exception e) {
            result.setResultCode("9999");
            result.setResultMsg("网络错误");
        }
        return JsonUtil.toJson(result);
    }
    /*
     *优惠券管理——报表-查询
     */
    @RequestMapping("/query")
    public void queryCouponInfoPage(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map){
        Map<String, Object> conditionMap = new HashMap<String, Object>();
        String salesCouponId = request.getParameter("salesCouponId");
        String status = request.getParameter("status");
        String useFromTime = request.getParameter("useFromTime");
        String useEndTime = request.getParameter("useEndTime");
        String pageSize = request.getParameter("rows");
        if (StringUtils.isNotEmpty(salesCouponId)) {
            conditionMap.put("salesCouponId", salesCouponId);
        }
        if (StringUtils.isNotEmpty(status) && !status.equals("99")){
            conditionMap.put("status", status);
        }else{
            conditionMap.put("status", null);
        }
        if(StringUtils.isNotEmpty(useFromTime)){
            conditionMap.put("useFromTime", useFromTime);
        }
        if(StringUtils.isNotEmpty(useEndTime)){
            conditionMap.put("useEndTime", useEndTime);
        }
        conditionMap.put("style", CouponConstant.COUPON_style_coupon_1);//查询优惠券
        PageQuery pageQuery = null;
        if(StringUtils.isNotEmpty(pageSize)){
            pageQuery = new PageQuery(getPage(request), Integer.parseInt(pageSize));
        }else{
            pageQuery = new PageQuery(getPage(request), PAGE_SIZE);
        }
        RemoteResult<PageModel2<CouponReportApi>> memberCoupons = adminMemberCouponService.getMemberCouponsReportInfoPage(pageQuery, conditionMap);
        try {
            String json = null;
            if(memberCoupons != null && memberCoupons.isSuccess() && memberCoupons.getT() != null){
                PageModel2<CouponReportApi> pageModel2 = memberCoupons.getT();
                json = JsonUtil.list2json((int) pageModel2.getTotalCount(), pageModel2.getDatas());
                response.getWriter().println(json);
            }else{
                json = JsonUtil.list2json(0, new ArrayList());
                response.getWriter().println(json);
            }
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
    }

    /*报表--优惠券导出
     * */
    @RequestMapping("/downloadCoupons")
    public void downloadCoupons(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map){
        String invokeMethod = "api/coupon/downloadCoupons";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        try {
            Map<String, Object> conditionMap = new HashMap<String, Object>();
            String salesCouponId = request.getParameter("salesCouponId");
            String status = request.getParameter("status");
            String useFromTime = request.getParameter("useFromTime");
            String useEndTime = request.getParameter("useEndTime");
            if (StringUtils.isNotEmpty(salesCouponId)) {
                conditionMap.put("salesCouponId", salesCouponId);
            }
            if (StringUtils.isNotEmpty(status) && !status.equals("99")) {
                conditionMap.put("status", status);
            } else {
                conditionMap.put("status", null);
            }
            if(StringUtils.isNotEmpty(useFromTime)){
                conditionMap.put("useFromTime", useFromTime);
            }
            if(StringUtils.isNotEmpty(useEndTime)){
                conditionMap.put("useEndTime", useEndTime);
            }
            conditionMap.put("style", CouponConstant.COUPON_style_coupon_1); //导出优惠券
            PageQuery pageQuery = new PageQuery(getPage(request), EXPORT_MAX_PAGE_SIZE);
            RemoteResult<PageModel2<CouponReportApi>> memberCoupons = adminMemberCouponService.getMemberCouponsReportInfoPage(pageQuery, conditionMap);
            SXSSFWorkbook wb = new SXSSFWorkbook(ROW_LINE);
            if (memberCoupons != null && memberCoupons.isSuccess() && memberCoupons.getT() != null) {
                List<CouponReportApi> couponReportApiList = memberCoupons.getT().getDatas();
                ExcelUtils.writeXSLXExcel(wb, couponsHeader, assembleCouponsData(couponReportApiList));
            }else{
                ExcelUtils.writeXSLXExcel(wb, couponsHeader, null);
            }

            String fileName = "优惠券信息.xlsx";
            long timeStamp = new Date().getTime();
            String token = UploadImageClient.getToken(appId, appKey, timeStamp, targetCouponCodeFilePath+fileName, "1");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            wb.write(bos);
            UploadResponse uploadResponse = UploadImageClient.upload(appId, token, timeStamp, imageServerURL+targetCouponCodeFilePath+fileName, bos.toByteArray(), fileName, "1");
            printResult(invokeMethod, uploadResponse);
            String readURL = PrivateSpcaceManager.getReadURL(appId, appKey, domain, targetCouponCodeFilePath+fileName);
            remoteResult.setSuccess(true);
            remoteResult.setResultCode("00");
            remoteResult.setResultMsg("操作成功");
            remoteResult.setT(readURL);
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();

        }catch (Exception e){
            logger.error(ExceptionUtil.getStackTrace(e));
        }
    }

    /*
     * 导出优惠券及订单
     * **/
    @RequestMapping("/downloadCouponsAndOrders")
    public void downloadCouponsAndOrders(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map){
        String invokeMethod = "api/coupon/downloadCouponsAndOrders";
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType(CONTENT_TYPE);
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
        } catch (IOException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }

        try {
            Map<String, Object> conditionMap = new HashMap<String, Object>();
            String salesCouponId = request.getParameter("salesCouponId");
            String useFromTime = request.getParameter("useFromTime");
            String useEndTime = request.getParameter("useEndTime");
            String status = request.getParameter("status");
            if (StringUtils.isNotEmpty(status) && "99".equals(status)) {
                status = "1";
            }
            logger.info("导出优惠券和订单 status"+status);
            conditionMap.put("status", status);
            if (StringUtils.isNotEmpty(salesCouponId)) {
                conditionMap.put("salesCouponId", salesCouponId);
            }
            if(StringUtils.isNotEmpty(useFromTime)){
                conditionMap.put("useFromTime", useFromTime);
            }
            if(StringUtils.isNotEmpty(useEndTime)){
                conditionMap.put("useEndTime", useEndTime);
            }
            conditionMap.put("style", CouponConstant.COUPON_style_coupon_1); //导出优惠券
            PageQuery pageQuery = new PageQuery(getPage(request), EXPORT_MAX_PAGE_SIZE);
            RemoteResult<PageModel2<CouponReportApi>> memberCoupons = adminMemberCouponService.getCouponsAndOrderIdInfoPage(pageQuery, conditionMap);
            SXSSFWorkbook wb = new SXSSFWorkbook(ROW_LINE);
            if (memberCoupons != null && memberCoupons.isSuccess() && memberCoupons.getT() != null) {
                List<CouponReportApi> couponReportApiList = memberCoupons.getT().getDatas();
                List<CouponOrderReportApi> totalList = new ArrayList<CouponOrderReportApi>();
                int totalNum = couponReportApiList.size();
                for(int i = 0; i < totalNum; ) {
                    int endNumber = i+fetchNumber > totalNum ? totalNum : i+fetchNumber;
                    logger.info(String.format("====== invoke vatApiOrderCenter to fetch Order info from %d to %d", i, endNumber));
                    List<CouponOrderReportApi> subList = fetchOrderInfo(couponReportApiList.subList(i, endNumber));
                    i = i + fetchNumber;
                    totalList.addAll(subList);
                }
                ExcelUtils.writeXSLXExcel(wb, couponsOrderHeader, assembleCouponsOrdersData(totalList));
            } else {
                ExcelUtils.writeXSLXExcel(wb, couponsOrderHeader, null);
            }

            String fileName = "优惠券和订单.xlsx";
            long timeStamp = new Date().getTime();
            String token = UploadImageClient.getToken(appId, appKey, timeStamp, targetCouponCodeFilePath+fileName, "1");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            wb.write(bos);
            UploadResponse uploadResponse = UploadImageClient.upload(appId, token, timeStamp, imageServerURL+targetCouponCodeFilePath+fileName, bos.toByteArray(), fileName, "1");
            printResult(invokeMethod, uploadResponse);
            String readURL = PrivateSpcaceManager.getReadURL(appId, appKey, domain, targetCouponCodeFilePath+fileName);
            remoteResult.setSuccess(true);
            remoteResult.setResultCode("00");
            remoteResult.setResultMsg("操作成功");
            remoteResult.setT(readURL);
            printWriter.write(JsonUtil.toJson(remoteResult));
            printWriter.close();
        } catch (Exception e) {
            logger.error("Download Coupon Report error." + ExceptionUtil.getStackTrace(e));
        }
    }




    private List<Object[]> assembleCouponsOrdersData(List<CouponOrderReportApi> couponOrderReportApiList){
        if(couponOrderReportApiList == null || couponOrderReportApiList.size() <= 0){
            return null;
        }
        Collections.sort(couponOrderReportApiList, new Comparator<CouponOrderReportApi>() {
            @Override
            public int compare(CouponOrderReportApi o1, CouponOrderReportApi o2) {
                return o1.getMainOrderCode().compareTo(o2.getMainOrderCode());
            }
        });
        List<Object[]> result = new LinkedList<Object[]>();
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        for(CouponOrderReportApi couponOrder : couponOrderReportApiList){
            List<Object> row = new LinkedList<Object>();
            row.add(couponOrder.getSalescouponid());
            row.add(couponOrder.getName());
            row.add(couponOrder.getLenovoid());
            row.add(couponOrder.getMembercode());
            row.add(couponOrder.getAmount());
            if(couponOrder.getStatus() == 0) {
                row.add("未使用");
            }else if(couponOrder.getStatus() == 1){
                row.add("已使用");
            }else {
                row.add("禁用");
            }
            if(couponOrder.getUsetime() != null) {
                row.add(sf.format(couponOrder.getUsetime()));
            }else {
                row.add("");
            }
            row.add(couponOrder.getMainOrderCode());
            row.add(couponOrder.getSubOrderCode());
            row.add(couponOrder.getTotalCost());
            row.add(couponOrder.getTotalPay());
            row.add(couponOrder.getGoodsName());
            row.add(couponOrder.getNumStr());
            row.add(couponOrder.getGoodsCode());
            row.add(couponOrder.getDeatLike());
            row.add(couponOrder.getMaterialCode());
            row.add(couponOrder.getReceiver());
            row.add(couponOrder.getMobile());
            row.add(couponOrder.getProvince());
            row.add(couponOrder.getCity());
            row.add(couponOrder.getCounty());
            row.add(couponOrder.getAddress());
            if(couponOrder.getCreateTime() != null) {
                row.add(sf.format(couponOrder.getCreateTime()));
            }else {
                row.add("");
            }
            if(couponOrder.getPaidTime() != null) {
                row.add(sf.format(couponOrder.getPaidTime()));
            }else {
                row.add("");
            }
            result.add(row.toArray());
        }
        return result;
    }

    private List<CouponOrderReportApi> fetchOrderInfo(List<CouponReportApi> couponReportApiList) {
        if(couponReportApiList == null || couponReportApiList.size() <= 0){
            return null;
        }
        DomainUtil domainUtil = new DomainUtil();
        List<String> orderIdList = new ArrayList<String>();
        Map<String, CouponOrderReportApi> resultMap = new HashMap<String, CouponOrderReportApi>(couponReportApiList.size());
        Map<String, CouponOrderReportApi> exportResultMap = new HashMap<String, CouponOrderReportApi>();
        RemoteResult<List<OrdersReportVo>> orderResult = null;
        try {
            for(CouponReportApi couponReportApi : couponReportApiList){
                orderIdList.add(couponReportApi.getOrderId());
                CouponOrderReportApi couponOrderReportApi = new CouponOrderReportApi();
                List<String> escapeFileds = new ArrayList<String>();
                escapeFileds.add("orderId");
                domainUtil.copy2(couponReportApi, couponOrderReportApi, escapeFileds);
                resultMap.put(couponReportApi.getOrderId(), couponOrderReportApi);
            }
            logger.info("vatApiOrderCenter.getOrderReportLists param :"+(JacksonMapper.obj2json(orderIdList)));
            orderResult = vatApiOrderCenter.getOrderReportLists(orderIdList, 1);
            logger.info("vatApiOrderCenter.getOrderReportLists return :"+((null == orderResult && null !=orderResult.getT()) ? 0 :orderResult.getT().size()));
            if(orderResult != null && orderResult.isSuccess() && orderResult.getT() != null) {
                List<OrdersReportVo> ordersReportVoList = orderResult.getT();
                for (OrdersReportVo ordersReportVo : ordersReportVoList){
                    String mainOrderCode = ordersReportVo.getParentId();
                    String subOrderCode = ordersReportVo.getId();
                    String key = mainOrderCode + "-" + subOrderCode;
                    CouponOrderReportApi couponOrderReportApi = exportResultMap.get(key);
                    if(couponOrderReportApi == null) {
                        couponOrderReportApi = new CouponOrderReportApi();
                        domainUtil.copy(resultMap.get(mainOrderCode), couponOrderReportApi);
                        couponOrderReportApi.setMainOrderCode(mainOrderCode);
                        couponOrderReportApi.setSubOrderCode(subOrderCode);
                        couponOrderReportApi.setTotalCost(ordersReportVo.getTotalCost());
                        couponOrderReportApi.setTotalPay(ordersReportVo.getTotalPay());
                        couponOrderReportApi.setDeatLike(ordersReportVo.getDeatLike());
                        couponOrderReportApi.setMaterialCode(ordersReportVo.getMaterialCode());
                        couponOrderReportApi.setGoodsName(ordersReportVo.getGoodsName());
                        couponOrderReportApi.setGoodsCode(ordersReportVo.getGoodsCode());
                        couponOrderReportApi.setNum(ordersReportVo.getNum());
                        couponOrderReportApi.setNumStr(String.valueOf(ordersReportVo.getNum()));
                        couponOrderReportApi.setCreateTime(ordersReportVo.getCreateTime());
                        couponOrderReportApi.setPaidTime(ordersReportVo.getPaidTime());
                        couponOrderReportApi.setReceiver(ordersReportVo.getName());
                        couponOrderReportApi.setMobile(ordersReportVo.getMobile());
                        couponOrderReportApi.setProvince(ordersReportVo.getProvince());
                        couponOrderReportApi.setCity(ordersReportVo.getCity());
                        couponOrderReportApi.setCounty(ordersReportVo.getCounty());
                        couponOrderReportApi.setAddress(ordersReportVo.getAddress());
                        exportResultMap.put(key, couponOrderReportApi);
                    }else {
                        String materialCode = couponOrderReportApi.getMaterialCode() + ";" + ordersReportVo.getMaterialCode();
                        String goodsName = couponOrderReportApi.getGoodsName() + ";" + ordersReportVo.getGoodsName();
                        String goodsCode = couponOrderReportApi.getGoodsCode() + ";" + ordersReportVo.getGoodsCode();
                        String deatLike = couponOrderReportApi.getDeatLike() + ";" + ordersReportVo.getDeatLike();
                        String numStr = couponOrderReportApi.getNumStr() + ";" + ordersReportVo.getNum();
                        couponOrderReportApi.setMaterialCode(materialCode);
                        couponOrderReportApi.setGoodsName(goodsName);
                        couponOrderReportApi.setGoodsCode(goodsCode);
                        couponOrderReportApi.setDeatLike(deatLike);
                        couponOrderReportApi.setNumStr(numStr);
                    }
                }
            }
        } catch (Exception e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        List<CouponOrderReportApi> resultList = new ArrayList<CouponOrderReportApi>();
        if(resultMap != null && resultMap.size() > 0){
            Iterator<CouponOrderReportApi> couponOrder = exportResultMap.values().iterator();
            while(couponOrder.hasNext()) {
                resultList.add(couponOrder.next());
            }
        }
        return resultList;
    }


    private List<Object[]> assembleCouponsData(List<CouponReportApi> couponReportApiList) {
        if(couponReportApiList == null || couponReportApiList.size() <= 0){
            return null;
        }
        List<Object[]> result = new LinkedList<Object[]>();
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        for(CouponReportApi coupon : couponReportApiList){
            List<Object> row = new LinkedList<Object>();
            row.add(coupon.getSalescouponid());
            row.add(coupon.getName());
            row.add(coupon.getLenovoid());
            row.add(coupon.getMembercode());
            row.add(coupon.getAmount());
            if(coupon.getStatus() == 0) {
                row.add("未使用");
            }else if(coupon.getStatus() == 1){
                row.add("已使用");
            }else {
                row.add("禁用");
            }
            if(coupon.getUsetime() != null) {
                row.add(sf.format(coupon.getUsetime()));
            }else {
                row.add("");
            }
            result.add(row.toArray());
        }

        return result;
    }

    /**
     * 打印执行结果
     * @param methodName
     * @param result
     */
    private void printResult(String methodName, Object result){
        logger.info("调用 [" + methodName + "] 查询结果：" + JsonUtil.toJson(result));
    }

    /**
     * 调用发生异常时，记录异常日志，并返回异常结果
     * @param e
     * @param remoteResult
     * @param printWriter
     * @param methodName
     */
    private void returnExceptionResult(Exception e, RemoteResult remoteResult, PrintWriter printWriter, String methodName){
        remoteResult = new RemoteResult<>();
        logger.error("调用 [" + methodName + "] 异常：" + ExceptionUtil.getStackTrace(e));
        remoteResult.setResultCode("9999");
        remoteResult.setSuccess(false);
        remoteResult.setResultMsg("系统异常");
        printWriter.write(JsonUtil.toJson(remoteResult));
        printWriter.close();
    }


    private List<Object[]> createSalescouponsData(List<SalescouponsApi> list) {
        if (list == null || list.size() <= 0) {
            return null;
        }
        List<Object[]> result = new LinkedList<Object[]>();
        String dateFormat = "yyyy-MM-dd HH:mm:ss";
        for (int i = 0; i < list.size(); i++) {
            //查询商品
            SalescouponsApi salescouponsApi = list.get(i);
            List<Object> row = new LinkedList<Object>();
            row.add(salescouponsApi.getId());
            row.add(formatUseScope(salescouponsApi.getUsescope()==null?0:salescouponsApi.getUsescope()));
            row.add(formatShopid(salescouponsApi.getShopid()));
            row.add(formatTerminal(salescouponsApi.getTerminal()));
            row.add(salescouponsApi.getConditions());
            row.add(salescouponsApi.getName());
            row.add(salescouponsApi.getCouponcode());
            row.add(formatType(String.valueOf(salescouponsApi.getType())));
            row.add(salescouponsApi.getAmount());
            row.add(salescouponsApi.getCurrencyCode());
            row.add(salescouponsApi.getDescription());
            row.add(salescouponsApi.getCouponway());
            row.add(formatIsCanGet(salescouponsApi.getIscanget()==null?0:salescouponsApi.getIscanget()));
            row.add(DateUtil.formatString(salescouponsApi.getGetstarttime(), dateFormat));
            row.add(DateUtil.formatString(salescouponsApi.getGetendtime(), dateFormat));
            row.add(DateUtil.formatString(salescouponsApi.getFromtime(), dateFormat));
            row.add(DateUtil.formatString(salescouponsApi.getTotime(), dateFormat));
            row.add(salescouponsApi.getBacksend());
            row.add(salescouponsApi.getQualifications());
            row.add(salescouponsApi.getClassification());
            row.add(formatStatus(salescouponsApi.getStatus()==null?0:salescouponsApi.getStatus()));
            row.add(DateUtil.formatString(salescouponsApi.getCreatetime(), dateFormat));
            row.add(DateUtil.formatString(salescouponsApi.getUpdatetime(), dateFormat));
            row.add(salescouponsApi.getCreateby());

            result.add(row.toArray());
        }
        return result;
    }

    private List<Object[]> createCouponsData(List<CouponsApi> list) {
        if (list == null || list.size() <= 0) {
            return null;
        }
        List<Object[]> result = new LinkedList<Object[]>();
        String dateFormat = "yyyy-MM-dd HH:mm:ss";
        for (int i = 0; i < list.size(); i++) {
            //查询商品
            CouponsApi couponsApi = list.get(i);
            List<Object> row = new LinkedList<Object>();
            row.add(couponsApi.getBatchno());
            row.add(couponsApi.getName());
            row.add(couponsApi.getMacode());
            row.add(formatShopid(couponsApi.getShopid()));
            row.add(formatTerminal(couponsApi.getTerminal()));
            row.add(DateUtil.formatString(couponsApi.getStarttime(), dateFormat));
            row.add(DateUtil.formatString(couponsApi.getEndtime(), dateFormat));
            row.add(couponsApi.getAmount());
            row.add(couponsApi.getCurrencyCode());
            row.add(couponsApi.getTotalnumber());
            row.add(couponsApi.getOccupynumber());
            row.add(formatType(String.valueOf(couponsApi.getType())));
            row.add(couponsApi.getCreateby());
            row.add(DateUtil.formatString(couponsApi.getCreatetime(), dateFormat));
            result.add(row.toArray());
        }
        return result;
    }

    private String formatUseScope(int useScope){
        String useScope_str = "";
        if(useScope == 1)
            useScope_str = "普通券";
        if(useScope == 4)
            useScope_str = "专属券-C2C";
        if(useScope == 6)
            useScope_str = "专属券-以旧换新";
        if(useScope == 7)
            useScope_str = "以旧换新代金券";
        if(useScope == 10)
            useScope_str = "惠商券";
        if(useScope_str.equals(""))
            useScope_str = String.valueOf(useScope);
        return useScope_str;
    }

    private String formatShopid(String shopid){
        String shopid_str= "";
        if("1".equals(shopid))
            shopid_str = "lenovo";
        if("2".equals(shopid))
            shopid_str = "think";
        if("3".equals(shopid))
            shopid_str = "epp";
        if("4".equals(shopid))
            shopid_str = "roming";
        if("5".equals(shopid))
            shopid_str = "moto";
        if("8".equals(shopid))
            shopid_str = "smb";
        if("14".equals(shopid))
            shopid_str= "惠商";
        if(shopid_str.equals(""))
            shopid_str = shopid;

        return  shopid_str;
    }

    private String formatTerminal(String terminal){
        String[] terminal_arr = terminal.split(",");
        String[] terminal_name = new String[terminal_arr.length];
        for(int s=0; s< terminal_arr.length ; s++){
            if("1".equals(terminal_arr[s]))
                terminal_name[s]= "pc";
            if("2".equals(terminal_arr[s]))
                terminal_name[s]=  "wap";
            if("3".equals(terminal_arr[s]))
                terminal_name[s]=  "app";
            if("4".equals(terminal_arr[s]))
                terminal_name[s]=  "微信";
        }
        return  Arrays.toString(terminal_name);
    }

    private String formatType(String type){
        if("1".equals(type))
            return  "分类";
        if("2".equals(type))
            return  "商品";
        else
            return   "";
    }

    private String formatIsCanGet(int isCanGet){
        if (isCanGet == 0)
            return "否";
        if (isCanGet == 1)
            return "是";
        else
            return String.valueOf(isCanGet);
    }

    private String formatStatus(int status){
        if(status == 0)
            return "新建";
        if(status == 1)
            return "审核未通过";
        if(status == 2)
            return "审核通过";
        if(status == 3)
            return "未审核";
        if(status == 4)
            return "一级审核通过";
        else
            return String.valueOf(status);
    }



    private void eliminateMember(Map<String, MemberExcelTempApi> map, List<MembercouponrelsApi> membercouponrelsApiList){
        for(MembercouponrelsApi membercouponrelsApi : membercouponrelsApiList){
            String lenovoId = membercouponrelsApi.getLenovoid();
            MemberExcelTempApi member = map.get(lenovoId);
            if(member != null){
                map.remove(member);
            }
        }
    }

    private List<MembercouponrelsApi> assembleMemberCouponRels(Map<String, MemberExcelTempApi> map, SalescouponsApi api, String userId){
        List<MembercouponrelsApi> mcList = new ArrayList<MembercouponrelsApi>(map.size());
        Set keySet = map.keySet();
        Iterator iterator = keySet.iterator();
        long batchNo = System.currentTimeMillis();
        Date sendTime = new Date();
        while (iterator.hasNext()){
            String lenovoId = (String)iterator.next();
            MemberExcelTempApi mapi = map.get(lenovoId);
            MembercouponrelsApi mcApi = new MembercouponrelsApi();
            mcApi.setLenovoid(mapi.getLenovoid());
            mcApi.setMemberid(mapi.getMemberid());
            mcApi.setMembercode(mapi.getMembercode());
            mcApi.setSalescouponid(api.getId());
            mcApi.setCouponcode(api.getCouponcode());
            mcApi.setUsescope(api.getUsescope());
            mcApi.setShopid(api.getShopid());
            mcApi.setName(api.getName());
            mcApi.setAmount(api.getAmount());
            mcApi.setCurrencyCode(api.getCurrencyCode());
            mcApi.setTerminal(api.getTerminal());
            mcApi.setConditions(api.getConditions());
            mcApi.setType(api.getType());
            mcApi.setFromtime(api.getFromtime());
            mcApi.setTotime(api.getTotime());
            mcApi.setEppgroup(api.getEppgroup());
            mcApi.setTotalnumber(api.getTotalnumber());
            mcApi.setSurplusnumber(api.getSendnumber());
            mcApi.setCouponsource(CouponConstant.COUPON_SOURCE_EXCEL);
            mcApi.setClassification(api.getClassification());
            mcApi.setClassificationname("");
            mcApi.setSuperposition(api.getSuperposition());
            mcApi.setBatchno(String.valueOf(batchNo));
            mcApi.setCreatetime(sendTime);
            mcApi.setUpdatetime(sendTime);
            mcApi.setCreateby(userId);
            mcApi.setDescription(api.getDescription());
            mcApi.setDisabled(0);
            mcApi.setStatus(0);
            mcList.add(mcApi);
        }
        return mcList;
    }

    public static class AuthData{
        static String getUserId(HttpServletRequest request){
            Map<String, Object> paramMap = getParameterMap(request);
            String userId = null;
            if(null != paramMap){
                userId = (String)(paramMap.get("userid") == null ? paramMap.get("userId"):paramMap.get("userid"));
            }
            return userId;
        }
        static List<String> getShopIds(HttpServletRequest request){
            Map<String, Object> paramMap = getParameterMap(request);
            if (null != paramMap){
                return (List<String>)paramMap.get("shopIds");
            }
            return null;
        }
        private static Map<String, Object> getParameterMap(HttpServletRequest request){
            String authData = request.getParameter("authdata");
            if(StringUtils.isEmpty(authData) || "[]".equals(authData)){
                return null;
            }
            Map<String, Object> map = null;
            try {
                map = JacksonUtil.toObjectMap(authData);
            } catch (IOException e) {
                logger.error("解析AuthData异常：" + ExceptionUtil.getStackTrace(e));
            }
            return map;
        }
    }

    /*
     *领券中心管理根据商城查询显示位置
     *
     */
    @RequestMapping(value="/getShowInfo",produces = "text/html;charset=UTF8")
    @ResponseBody
    public String getShowInfoByShopId(HttpServletRequest request, HttpServletResponse response,Integer shopId){

        try {
            RemoteResult<List<ShowInfo>> showPositionInfo = salescouponsRemote.getShowPositionInfo(shopId);
            return JsonUtil.toJson(showPositionInfo);
        } catch (Exception e) {
            logger.error("error info",e);
            return JsonUtil.toJson(RemoteResultUtil.convert(ErrorMessageEnum.ERROR_SERVICE));
        }
    }
}