package com.lenovo.m2.buy.promotion.admin.converter;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.lenovo.m2.arch.framework.domain.Money;

import java.io.IOException;

/**
 * Created by wangrq1 on 2017/1/17.
 */
public class MoneySerializer extends JsonSerializer<Money> {

    @Override
    public void serialize(Money o, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException, JsonProcessingException {
        jsonGenerator.writeString(String.valueOf(o.getAmount()));
    }

}
