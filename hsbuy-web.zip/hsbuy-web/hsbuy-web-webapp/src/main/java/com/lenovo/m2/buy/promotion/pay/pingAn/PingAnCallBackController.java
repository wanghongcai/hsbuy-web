package com.lenovo.m2.buy.promotion.pay.pingAn;

import com.ecc.emp.data.KeyedCollection;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.LePayConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayJsManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.MerchantPayPlatManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.pingan.PingAnPayManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import com.sdb.payclient.core.PayclientInterfaceUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

/**
 * 平安网关支付回调
 * Created by qixin on 2016/11/2.
 */
@Controller
@Scope("prototype")
public class PingAnCallBackController {
    Logger logger = Logger.getLogger(this.getClass());
    @Autowired
    private PayOrderApi payOrderApi;

    @Autowired
    private MerchantPayPlatManager merchantPayPlatManager;

    @Autowired
    private PingAnPayManager pingAnPayManager;

    @Autowired
    private CommonCallBackManager commonCallBackManager;

    @Autowired
    private PayPortalOrderManager payPortalOrderManager;
    @Autowired
    private CommonManager commonManager;
    @Autowired
    private AliPayCommonManager aliPayCommonManager;

    @Autowired
    private AliPayJsManager aliPayJsManager;
    /**
     * <br>
     * 平安银行网关支付完成后的服务器异步通知
     *
     * @param request
     * @param response
     * @return </br>
     */
    @RequestMapping("/pcPingAnPayNotice")
    public void pingAnPayNotice(HttpServletRequest request, HttpServletResponse response) {
        Map<String, String> resultMap = getSignerData(request, "平安银行支付异步回调", false);
        logger.info("平安支付异步回调解码数据：orig=" + resultMap.get("orig"));
        //平安银行返回后台通知原始数据
        String orig = resultMap.get("orig");
        //平安银行返回后台通知签名数据
        String sign = resultMap.get("sign");
        logger.info("平安支付异步回调签名：sign=" + resultMap.get("sign"));
        String tradeStatus = null;
        String orderId = null;
        String remark = null;
        String orderPrimaryId = "";
        PayclientInterfaceUtil util = null;
        String terminal = "4";
        KeyedCollection output = new KeyedCollection("output");
        try {
            util = new PayclientInterfaceUtil();
            output = util.parseOrigData(orig);
            tradeStatus = (String) output.getDataValue("status");//订单状态，只返回„01‟，表示成功
            orderId = (String) output.getDataValue("orderId");//订单号
            remark = (String) output.getDataValue("remark");//用户拓展字段
            if (StringUtils.isNotEmpty(remark)) {
                Map<String, String> paraMap = parseRemark(remark);
                orderPrimaryId = paraMap.get("orderPrimaryId");
                terminal = paraMap.get("terminal");
            }
            logger.info("tradeStatus==" + tradeStatus + "  orderId=" + orderId);
            if (StringUtils.isEmpty(orderId) && StringUtils.isEmpty(remark)) {
                logger.info("获取平安银行反馈订单号为空!");
                return;
            }
            logger.info("平安支付同步回调=========================>商户订单号：" + orderId + " remark：" + remark+ " terminal="+terminal);
        } catch (Exception e) {
            logger.error("解析平安银行反馈数据异常! Error Cause By :" + e);
        }

        PayOrder payOrder = null;
        RemoteResult<MerchantPayPlatView> merchantPayPlatRemoteResult = null;
        MerchantPayPlatView merchantPayPlatView = null;
        try {
            Map<String, String> paraMap = parseRemark(remark);
            if (!paraMap.isEmpty()) {
                payOrder = commonCallBackManager.getPayOrderById(orderPrimaryId);
            }
            if (null != payOrder) {
                merchantPayPlatRemoteResult = commonCallBackManager.getMerchantPayPlatById(payOrder.getMerchant_id());
            } else {
                logger.info("未查到原支付订单，订单号==>" + paraMap.get("orderPrimaryId"));
                return;
            }
            if (merchantPayPlatRemoteResult.isSuccess()) {
                merchantPayPlatView = merchantPayPlatRemoteResult.getT();
                logger.info("平安支付MerchantPayPlat [" + merchantPayPlatView + "]");
            } else {
                logger.info("平安支付未查询到MerchantPayPlat [" + payOrder.getMerchant_id() + "]");
                return;
            }
        } catch (Exception e) {
            logger.info("平安支付异步回调获取订单平台信息异常! Error Cause By :" + e);
            return;
        }
        boolean verify = false;
        try {
            verify = util.verifyData(sign, orig);
        } catch (Exception e) {
            logger.info("签名验证异常! Error Cause By :" + e);
        }
        if (verify && LePayConstant.TRADE_SUCC_PINGAN.equals(tradeStatus)) {// 验证成功
            // 判断结果
            logger.info("数据验签正确，支付成功，orderPrimaryId=" + orderPrimaryId);
            try {
                RemoteResult<String> result = null;
                String gmt_payment = (String) output.getDataValue("date");
                Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
                Map<String, String> paraMap = new HashMap<String, String>();
                paraMap.put("tradeStatus", "TRADE_SUCCESS");
                paraMap.put("tradeNo", orderId);     // 支付流水,即平安订单号
                paraMap.put("gmtPayment", gmt_payment);
                paraMap.put("notifyId", (String) output.getDataValue("paydate")); // 下单时间
                paraMap.put("payType", String.valueOf(payOrder.getPay_type()));
                paraMap.put("bankSeqNo", orderPrimaryId);
                if (PeakConstant.TRADE_SUCCESS == payOrder.getTrade_state() && PeakConstant.MFLAG_SUCC == payOrder.getMerchant_flag()) {
                    logger.info("平安支付异步已回调====>订单,orderPrimaryId[" + orderPrimaryId + "]，" + "订单交易状态："+payOrder.getTrade_state());
                } else {
                    if(CommonMethod.checkInShopId(payOrder.getShop_id())){
                        logger.info("平安支付异步回调，支付系统通过dubbo通知商户系统，shopId[" + payOrder.getShop_id() + "],orderPrimaryId[" + orderPrimaryId + "]");
                        result = aliPayJsManager.callUpdate(payOrder.getU_id(), orderPrimaryId, orderId, paraMap.get("gmtPayment"), merchantPayPlatView.getMerchantId(), String.valueOf(payOrder.getPay_type()), merchantPayPlatView, paraMap.get("notifyId"), null);
                    }else{
                        logger.info("平安支付异步回调，支付系统通过HTTP通知商户系统，shopId[" + payOrder.getShop_id() + "],orderPrimaryId[" + orderPrimaryId + "]");
                        result = commonCallBackManager.callOutUpdate(payOrder, merchantPayPlatView, paraMap, commonParam);
                    }
                    if (result.isSuccess()) {
                        logger.info("平安支付异步回调通知外部系统成功！orderPrimaryId[" + orderPrimaryId + "]");
                        payOrderApi.updateAliPayNotifyState(String.valueOf(payOrder.getId()), payOrder.getU_id(), paraMap.get("tradeNo"), PeakConstant.MFLAG_SUCC, paraMap.get("notifyId"), PeakConstant.TRADE_SUCCESS, paraMap.get("bankSeqNo"), Integer.parseInt(paraMap.get("payType")));
                    } else {
                        logger.info("平安支付异步回调通知外部系统失败！orderPrimaryId[" + orderPrimaryId + "]");
                        payOrderApi.updateAliPayNotifyState(String.valueOf(payOrder.getId()), payOrder.getU_id(), paraMap.get("tradeNo"), PeakConstant.MFLAG_REPEAT, paraMap.get("notifyId"), PeakConstant.TRADE_SUCCESS, paraMap.get("bankSeqNo"), Integer.parseInt(paraMap.get("payType")));
                    }
                }
            } catch (Exception e) {
                logger.info("平安支付异步回调数据处理异常! Error Cause By :" + e);
                return;
            }
        } else {
            logger.info("平安支付异步回调验签或订单支付失败！商户订单号：" + orderId);
            return;
        }
    }


    //获取平安银行下送数据
    private Map<String, String> getSignerData(HttpServletRequest request, String msg, boolean isSync) {
        Map<String, String> resultMap = new HashMap<String, String>();
        try {
            //银行返回后台通知原始数据
            String orig = request.getParameter("orig");
            logger.info(msg + "---银行返回后台通知原始数据---" + orig);
            //银行返回后台通知签名数据
            String sign = request.getParameter("sign");
            logger.info(msg + "---银行返回后台通知签名数据---" + sign);
            String encoding = "GBK";
            //只有同步进行 decode
            if (isSync) {
                orig = URLDecoder.decode(orig, encoding);
                logger.info(msg + "---URLDecoder decode 解码原始数据---" + orig);
            }
            orig = PayclientInterfaceUtil.Base64Decode(orig, encoding);
            logger.info(msg + "---Base64Decode 解析原始数据---" + orig);

            //只有同步进行 decode
            if (isSync) {
                sign = URLDecoder.decode(sign, encoding);
                logger.info(msg + "---URLDecoder decode 解码签名数据---" + sign);
            }
            sign = PayclientInterfaceUtil.Base64Decode(sign, encoding);
            logger.info(msg + "---Base64Decode 解析签名数据---" + sign);
            resultMap.put("orig", orig);
            resultMap.put("sign", sign);
        } catch (Exception e) {
            logger.error("解包平安银行返回后台通知数据异常! Error Cause By :", e);
        }
        return resultMap;
    }

    /**
     * 同步回调
     *
     * @param request
     * @param response
     * @param paraMap
     * @return
     */
    @RequestMapping("/pcPingAnSynPayNotice")
    public String pingAnSynPCReturn(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        logger.info("平安支付同步回调=========================");
        Map<String, String> resultMap = getSignerData(request, "平安银行支付同步回调", true);
        String orig = resultMap.get("orig");
        logger.info("---平安银行返回后台通知原始数据---" + orig);
        //平安银行返回后台通知签名数据
        String sign = resultMap.get("sign");
        logger.info("---平安银行返回后台通知签名数据---" + sign);
        String orderId = "";
        String orderPrimaryId = "";
        String tradeStatus = "";
        String remark = null;
        String terminal = null;
        PayclientInterfaceUtil util = null;
        Map<String, String> remarkMap = null;
        try {
            util = new PayclientInterfaceUtil();
            KeyedCollection output = new KeyedCollection("output");
            output = util.parseOrigData(orig);
            tradeStatus = (String) output.getDataValue("status");
            orderId = (String) output.getDataValue("orderId");//订单号
            remark = (String) output.getDataValue("remark");
            if (StringUtils.isNotEmpty(remark)) {
                remarkMap = parseRemark(remark);
                orderPrimaryId = remarkMap.get("orderPrimaryId");
                terminal = remarkMap.get("terminal");
            }
            logger.info("平安支付同步回调=========================>商户订单号：" + orderId + ", orderPrimaryId=" + orderPrimaryId);
        } catch (Exception e) {
            logger.info("平安银行返回后台通知数据解析异常! Error Cause By :" + e);
            paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
            return CommonMethod.getOutPayFailPage(terminal);
        }
        PayOrder payOrder = null;
        RemoteResult<MerchantPayPlatView> merchantPayPlatRemoteResult;
        MerchantPayPlatView merchantPayPlatView;
        try {
            if (StringUtils.isNotEmpty(orderPrimaryId)) {
                payOrder = commonCallBackManager.getPayOrderById(orderPrimaryId);
            }else {
                logger.info("平安支付未上送原支付订单orderPrimaryId [" + orderPrimaryId + "]");
            }
            if (payOrder != null) {
                logger.info("HTTPS pcPingAnSynPayNotice Original PayOrder [" + payOrder + "]");
                merchantPayPlatRemoteResult = commonCallBackManager.getMerchantPayPlatById(payOrder.getMerchant_id());
            } else {
                logger.info("HTTPS pcPingAnSynPayNotice Get Original PayOrder IS NULL");
                paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
                return CommonMethod.getOutPayFailPage(terminal);
            }
            if (merchantPayPlatRemoteResult.isSuccess()) {
                merchantPayPlatView = merchantPayPlatRemoteResult.getT();
                logger.info("HTTPS pcPingAnSynPayNotice Original MerchantPayPlat [" + merchantPayPlatView + "]");
            } else {
                logger.info("HTTPS pcPingAnSynPayNotice Original MerchantPayPlat Is Null");
                paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
                return CommonMethod.getOutPayFailPage(terminal);
            }
            boolean verifyFlag;
            try {
                //验证平安银行签名
                verifyFlag = util.verifyData(sign, orig);
            } catch (Exception e) {
                logger.error("HTTPS pcPingAnSynPayNotice Check Signature EXCEPTION，OrderPrimaryId[" + orderPrimaryId + "],TradeNo[" + orderPrimaryId + "]! Error Cause By :",e);
                paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
                return CommonMethod.getOutPayFailPage(terminal);
            }
            if (verifyFlag && LePayConstant.TRADE_SUCC_PINGAN.equals(tradeStatus)) {
                Tenant tenant = CommonMethod.buildTenant(payOrder.getShop_id(), null, null, null, null, null, null);
                RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByShowTradeNo(String.valueOf(payOrder.getOut_trade_no()), null, tenant);
                if (payPortalOrderRemoteResult.isSuccess()) {
                    Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
                    return CommonMethod.getOutSyncReturnForm(payOrder, merchantPayPlatView, payPortalOrderRemoteResult.getT(), paraMap, commonParam, "TRADE_SUCCESS", String.valueOf(payOrder.getId()));
                } else {
                    logger.info("Pingan Pay Sync CallBack Invoke queryPayPortalOrderByShowTradeNo Fail! out_trade_no=" + payOrder.getOut_trade_no());
                    paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
                    return CommonMethod.getOutPayFailPage(terminal);
                }
            } else {
                paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
                return CommonMethod.getOutPayFailPage(terminal);
            }
        } catch (Exception e) {
            logger.info("HTTPS pcPingAnSynPayNotice Exception! Error Cause By :" + e);
            paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
            return CommonMethod.getOutPayFailPage(terminal);
        }
    }

    private Map<String,String> parseRemark(String remark) throws Exception {
        remark = URLDecoder.decode(remark,"UTF-8");
        Map<String,String> tradeMap = new HashMap<String, String>();
        String[] paramPairs = remark.split("PARTITION");
        tradeMap.put("orderPrimaryId",paramPairs[0]);
        tradeMap.put("terminal",paramPairs[1]);
        return tradeMap;
    }

    public PayOrderApi getPayOrderApi() {
        return payOrderApi;
    }

    public void setPayOrderApi(PayOrderApi payOrderApi) {
        this.payOrderApi = payOrderApi;
    }

    public MerchantPayPlatManager getMerchantPayPlatManager() {
        return merchantPayPlatManager;
    }

    public void setMerchantPayPlatManager(MerchantPayPlatManager merchantPayPlatManager) {
        this.merchantPayPlatManager = merchantPayPlatManager;
    }

    public PingAnPayManager getPingAnPayManager() {
        return pingAnPayManager;
    }

    public void setPingAnPayManager(PingAnPayManager pingAnPayManager) {
        this.pingAnPayManager = pingAnPayManager;
    }

    public CommonCallBackManager getCommonCallBackManager() {
        return commonCallBackManager;
    }

    public void setCommonCallBackManager(CommonCallBackManager commonCallBackManager) {
        this.commonCallBackManager = commonCallBackManager;
    }

    public PayPortalOrderManager getPayPortalOrderManager() {
        return payPortalOrderManager;
    }

    public void setPayPortalOrderManager(PayPortalOrderManager payPortalOrderManager) {
        this.payPortalOrderManager = payPortalOrderManager;
    }

    public CommonManager getCommonManager() {
        return commonManager;
    }

    public void setCommonManager(CommonManager commonManager) {
        this.commonManager = commonManager;
    }

    public AliPayCommonManager getAliPayCommonManager() {
        return aliPayCommonManager;
    }

    public void setAliPayCommonManager(AliPayCommonManager aliPayCommonManager) {
        this.aliPayCommonManager = aliPayCommonManager;
    }
}
