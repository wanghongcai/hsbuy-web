package com.lenovo.m2.buy.promotion.admin.controller.util;

import com.lenovo.m2.arch.framework.domain.Money;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;

import java.io.IOException;

/**
 * Created by fenglg1 on 2017/2/13.
 */
public class MoneySerializer extends JsonSerializer<Money> {

    private final String separator = "||";

    @Override
    public void serialize(Money money, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException, JsonProcessingException {
        if(money == null){
            jsonGenerator.writeString("");
        }
        jsonGenerator.writeString(money.getAmount().toString());
    }
}
