package com.lenovo.m2.buy.promotion.admin.controller.api;

/**
 * Created by wangrq1 on 2017/1/23.
 */
public class BaseApiController {



}
