package com.lenovo.m2.buy.promotion.admin.controller.util;

/**
 * Created by lihc5 on 2015/11/20.
 */
public class WebContants {
    // 平台商品促销规则审核
    public static final String PROMOTIONCHECK_EDIT="/promotion/promotionCheckEdit";

    // 平台商品促销规则审核
    public static final String EPP_PROMOTIONCHECK_EDIT="/epp/promotionCheckEdit";  

    // 平台商品限时折扣审核
    public static final String SECKILLACTIVITYCHECK_EDIT="/seckillactivity/seckillactivityCheckEdit";

    // 平台商品首单立减审核
    public static final String FIRSTREDUCECHECK_LIST="/firstReduction/firstReduceCheckList";

    //首单立减查询列表
    public static final String FIRSTREDUCE_LIST="/firstReduction/firstReductionList";

    // 首单立减审核列表
    public static final String FIRSTREDUCECHECK_EDIT="/firstReduction/firstReduceCheckEdit";

    //平台促销规则列表
    public static final  String PROMOTION_LIST="/promotion/promotionList";

    //平台促销规则新增
    public static final  String PROMOTION_CREATE="/promotion/addpromotion";

    //平台促销规则修改
    public static final  String PROMOTION_EDIT="promotion/edit";

    //平台促销审核列表
    public static final  String PROMOTION_CHECKLIST="/promotion/promotionCheckList";


    //首单立减新增
    public static final String FIRSTREDUCE_ADD="/firstReduction/addfirstReduce";

    //限时折扣列表
    public static final String ACTIVITY_LIST="/seckillactivity/activityList";

    //限时审核列表
    public static final String ACTIVITYCHECK_LIST="/seckillactivity/seckillactivityCheckList";

    //预约信息列表
    public static final String RESERVATION_INFO="/promotion/reservationInfoList";

    //折扣专区列表
    public static final String DISCOUNTZONE_INFO="/discountZone/discountZoneList";

    //折扣专区审核列表
    public static final String DISCOUNTCHECKZONE_INFO="/discountZone/discountZoneCheckList";

    //折扣专区新增
    public static final  String DISCOUNTZONE_CREATE="/discountZone/addDiscountZone";

    //下单立减列表
    public static final String SALEREDUCTION_INFO="/discountZone/saleReductionList";

    //下单立减专区审核列表
    public static final String SALEREDUCTIONCHECKZONE_INFO="/discountZone/SaleReductionCheckList";

    //预售商品列表
    public static final  String PRESELL_LIST="/presell/presellList";


    //预售商品审核列表 //预售商品编辑列表
    public static final  String PRESELL_EDIT="/presell/presellEditList";

    public static final  String PRESELL_CHECK="/presell/presellCheckList";

    //预售商品新增
    public static final  String PRESELL_CREATE="/presell/addEditPresell";

    // 预售商品审核拒绝原因
    public static final String PRESELL_RESON="/presell/presellRefuseReson";

    //下单立减新增
    public static final  String SALEREDUCTION_CREATE="/discountZone/addSaleReduction";

    //促销规则导出列表
    public static final  String PROMOTION_EXPORT="/promotion/promotionExport";

}

