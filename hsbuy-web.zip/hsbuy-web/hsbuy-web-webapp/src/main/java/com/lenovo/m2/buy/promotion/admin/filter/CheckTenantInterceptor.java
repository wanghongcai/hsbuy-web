package com.lenovo.m2.buy.promotion.admin.filter;

import com.lenovo.m2.buy.promotion.admin.common.utils.CheckTenant;
import com.lenovo.m2.buy.promotion.admin.common.utils.Token;
import com.lenovo.m2.buy.promotion.admin.controller.util.ThreadLocalObjs;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.UUID;


/**
 *校验租户信息拦截器
 *没有注解时直接放行， 有注解时校验租户信息
 *
 */
public class CheckTenantInterceptor extends HandlerInterceptorAdapter {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (handler instanceof HandlerMethod) {
            HandlerMethod handlerMethod = (HandlerMethod) handler;
            Method method = handlerMethod.getMethod();
            CheckTenant annotation = method.getAnnotation(CheckTenant.class);
            if(annotation == null){
                return true;
            }else{
                if (ThreadLocalObjs.getTenant() != null) {
                    return true;
                }else{
                    return false;
                }
            }
        } else {
            return true;
        }
    }
}
