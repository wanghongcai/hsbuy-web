package com.lenovo.m2.buy.promotion.admin.controller.api.address;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.hsbuy.address.AddressService;
import com.lenovo.m2.hsbuy.common.address.enums.ErrorMessageEnum;
import com.lenovo.m2.hsbuy.common.address.utils.JsonUtil;
import com.lenovo.m2.hsbuy.common.address.utils.StringUtil;
import com.lenovo.m2.hsbuy.domain.address.Memberaddrs;
import com.lenovo.m2.hsbuy.domain.address.param.ConsigneeParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * Created by admin on 2017/7/25.
 */
@Controller
@RequestMapping("/api/address")
public class AddressController {
    private static final Logger LOGGER = LoggerFactory.getLogger(AddressController.class);

    @Autowired
    private AddressService addressService;

    /**
     * 惠商审单获取用户地址
     * @param tenant
     * @param consigneeParam
     * @return
     */
    @RequestMapping(value = "/getHsAddressList",produces = "application/json; charset=utf-8")
    @ResponseBody
    public RemoteResult<List<Memberaddrs>> getHsAddressList(Tenant tenant,ConsigneeParam consigneeParam) {
        LOGGER.info("getHsAddressList==参数=="+ JsonUtil.toJson(tenant)+"=="+JsonUtil.toJson(consigneeParam));
        RemoteResult<List<Memberaddrs>> remoteResult = new RemoteResult<List<Memberaddrs>>();
        try {
            if (tenant == null || tenant.getShopId()==null || consigneeParam==null || StringUtil.isEmpty(consigneeParam.getLenovoId(), consigneeParam.getType())) {
                remoteResult.setResultCode(ErrorMessageEnum.ERROR_PARAM.getCode());
                remoteResult.setResultMsg(ErrorMessageEnum.ERROR_PARAM.getCommon());
                LOGGER.info("getHsAddressList==返回值=="+JsonUtil.toJson(remoteResult));
                return remoteResult;
            }
            remoteResult = addressService.getAddressListByUser(tenant, consigneeParam);
        }catch (Exception e){
            LOGGER.info("getHsAddressList==出现异常==" + e.getMessage(), e);
            remoteResult.setResultCode(ErrorMessageEnum.ERROR_SYSTEM_BUSY.getCode());
            remoteResult.setResultMsg(ErrorMessageEnum.ERROR_SYSTEM_BUSY.getCommon());
        }
        LOGGER.info("getHsAddressList==返回值==" + JsonUtil.toJson(remoteResult));
        return remoteResult;
    }

}
