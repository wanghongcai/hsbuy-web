package com.lenovo.m2.buy.promotion.pay.alipay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AliSimplePaltPayConfig;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayNotify;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayUtil;
import com.lenovo.m2.buy.promotion.admin.domain.pay.alipay.AliPayDirectWapModel;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayDirectWapManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * 支付宝WAP直连
 * Created by MengQiang on 2016/9/13.
 */
@Controller
@Scope("prototype")
public class AliPayDirectWapController {
    private final Logger LOGGER = Logger.getLogger(this.getClass());

    @Autowired
    private CommonCallBackManager commonCallBackManager;

    @Autowired
    private AliPayDirectWapManager aliPayDirectWapManager;

    @Autowired
    private PayPortalOrderManager payPortalOrderManager;

    @Autowired
    private CommonManager commonManager;

    @RequestMapping("/aliDirectWapNotify")
    public void aliDirectWapNotify(HttpServletRequest request, HttpServletResponse response) {
        Map<String, String> params;
        Map<?, ?> requestParams = request.getParameterMap();
        params = AlipayUtil.parseRequestParams(requestParams);
        String orderPrimaryId = params.get("out_trade_no");
        String tradeStatus = params.get("trade_status");
        String gmtPayment = params.get("gmt_payment");
        gmtPayment = gmtPayment.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
        String tradeNo = params.get("trade_no");
        String notifyId = params.get("notify_id");
        String outChannelType = params.get("out_channel_type");
        String outChannelAmount = params.get("out_channel_amount");
        LOGGER.info("Https aliDirectWapNotify Ready To Go! orderPrimaryID[" + orderPrimaryId + "],tradeStatus[" + tradeStatus + "],gmtPayment[" + gmtPayment + "],notifyId[" + notifyId + "],tradeNo[" + tradeNo + "],outChannelType[" + outChannelType + "],outChannelAmount[" + outChannelAmount + "]");
        PayOrder payOrder;
        RemoteResult<MerchantPayPlatView> merchantPayPlatRemoteResult;
        MerchantPayPlatView merchantPayPlatView;
        try {
            if (StringUtils.isNotEmpty(orderPrimaryId)) {
                payOrder = commonCallBackManager.getPayOrderById(orderPrimaryId);
                LOGGER.info("AliPay DirectWap Original PayOrder [" + payOrder + "]");
            } else {
                LOGGER.info("AliPay DirectWap Original PayOrder Is Null");
                return;
            }
            if (payOrder != null) {
                merchantPayPlatRemoteResult = commonCallBackManager.getMerchantPayPlatById(payOrder.getMerchant_id());
            } else {
                LOGGER.info("AliPay DirectWap Original PayOrder Is Null, OrderPrimaryId[" + orderPrimaryId + "]");
                return;
            }
            if (merchantPayPlatRemoteResult.isSuccess()) {
                merchantPayPlatView = merchantPayPlatRemoteResult.getT();
                LOGGER.info("AliPay DirectWap Original MerchantPayPlat [" + merchantPayPlatView + "]");
            } else {
                LOGGER.info("AliPay DirectWap Original MerchantPayPlat Is Null");
                return;
            }
        } catch (Exception e) {
            LOGGER.info("支付宝WAP直连异步回调获取订单平台信息异常", e);
            return;
        }
        boolean verifyFlag;
        try {
            verifyFlag = AlipayNotify.verifyNotify(params, merchantPayPlatView.getSignKey(), merchantPayPlatView.getMechId());
        } catch (Exception e) {
            LOGGER.error("AliPay DirectWap Notify Check Signature EXCEPTION，OrderPrimaryId[" + orderPrimaryId + "],TradeNo[" + tradeNo + "]", e);
            return;
        }
        if (verifyFlag) {
            if ("TRADE_FINISHED".equals(tradeStatus) || "TRADE_SUCCESS".equals(tradeStatus)) {
                LOGGER.info("AliPay DirectWap TRADE_SUCCESS ,OrderPrimaryId[" + orderPrimaryId + "]");
                try {
                    RemoteResult<String> updateResult;
                    if(CommonMethod.checkInShopId(payOrder.getShop_id())){
                        updateResult = aliPayDirectWapManager.callUpdate(payOrder, merchantPayPlatView, gmtPayment, tradeNo, notifyId, outChannelType, outChannelAmount);
                    }else{
                        Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
                        Map<String, String> paraMap = new HashMap<String, String>();
                        paraMap.put("tradeStatus", tradeStatus);
                        paraMap.put("tradeNo", tradeNo);
                        paraMap.put("gmtPayment", gmtPayment);
                        paraMap.put("notifyId", notifyId);
                        paraMap.put("payType", PeakConstant.PAY_TYPE_ALSJ);
                        updateResult = commonCallBackManager.callOutUpdate(payOrder, merchantPayPlatView, paraMap, commonParam);
                    }
                    PrintWriter out = null;
                    try {
                        out = response.getWriter();
                        if (updateResult.isSuccess()) {
                            LOGGER.info("Send SUCCESS TO AliPay");
                            out.println("success");
                        } else {
                            LOGGER.info("Send FAIL TO AliPay");
                            out.println("fail");
                        }
                    } catch (IOException e) {
                        LOGGER.error("GET PRINTWRITER ERROR!");
                    } finally {
                        if (out != null) {
                            out.close();
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("AliPay DirectWap Call MiddleWare FAIL, OrderPrimaryId[" + orderPrimaryId + "]", ex);
                }
            } else {
                LOGGER.info("AliPay DirectWap ALI Return FAIL, OrderPrimaryId" + orderPrimaryId + "],tradeStatus[" + tradeStatus + ']');
            }
        } else {
            LOGGER.info("AliPay DirectWap Check Signature FAIL，OrderPrimaryId[" + orderPrimaryId + "]");
        }
    }

    @RequestMapping("/aliDirectWapNotify/simplePlatNotify")
    public void aliDirectWapSimplePlatNotify(HttpServletRequest request, HttpServletResponse response) {
        Map<String, String> params;
        Map<?, ?> requestParams = request.getParameterMap();
        params = AlipayUtil.parseRequestParams(requestParams);
        String orderPrimaryId = params.get("out_trade_no");
        String tradeStatus = params.get("trade_status");
        String gmtPayment = params.get("gmt_payment");
        gmtPayment = gmtPayment.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
        String tradeNo = params.get("trade_no");
        String notifyId = params.get("notify_id");
        String outChannelType = params.get("out_channel_type");
        String outChannelAmount = params.get("out_channel_amount");
        LOGGER.info("Https AliDirectWap SimplePlatNotify Ready To Go! orderPrimaryID[" + orderPrimaryId + "],tradeStatus[" + tradeStatus + "],gmtPayment[" + gmtPayment + "],notifyId[" + notifyId + "],tradeNo[" + tradeNo + "],outChannelType[" + outChannelType + "],outChannelAmount[" + outChannelAmount + "]");
        PayOrder payOrder;
        RemoteResult<MerchantPayPlatView> merchantPayPlatRemoteResult;
        MerchantPayPlatView merchantPayPlatView;
        try {
            if (StringUtils.isNotEmpty(orderPrimaryId)) {
                payOrder = commonCallBackManager.getPayOrderById(orderPrimaryId);
                LOGGER.info("AliPay DirectWap SimplePlatNotify Original PayOrder [" + payOrder + "]");
            } else {
                LOGGER.info("AliPay DirectWap SimplePlatNotify Original PayOrder Is Null");
                return;
            }
            if (payOrder != null) {
                merchantPayPlatRemoteResult = commonCallBackManager.getMerchantPayPlatById(payOrder.getMerchant_id());
            } else {
                LOGGER.info("AliPay DirectWap SimplePlatNotify Original PayOrder Is Null, OrderPrimaryId[" + orderPrimaryId + "]");
                return;
            }
            if (merchantPayPlatRemoteResult.isSuccess()) {
                merchantPayPlatView = merchantPayPlatRemoteResult.getT();
                LOGGER.info("AliPay DirectWap SimplePlatNotify Original MerchantPayPlat [" + merchantPayPlatView + "]");
            } else {
                LOGGER.info("AliPay DirectWap SimplePlatNotify Original MerchantPayPlat Is Null");
                return;
            }
        } catch (Exception e) {
            LOGGER.info("支付宝WAP直连异步回调获取订单平台信息异常", e);
            return;
        }
        boolean verifyFlag;
        try {
            verifyFlag = AlipayNotify.verifyNotifyJS(params, AliSimplePaltPayConfig.ali_public_key, merchantPayPlatView.getMechId());
        } catch (Exception e) {
            LOGGER.error("AliPay DirectWap SimplePlatNotify Check Signature EXCEPTION，OrderPrimaryId[" + orderPrimaryId + "],TradeNo[" + tradeNo + "]", e);
            return;
        }
        if (verifyFlag) {
            if ("TRADE_FINISHED".equals(tradeStatus) || "TRADE_SUCCESS".equals(tradeStatus)) {
                LOGGER.info("AliPay DirectWap SimplePlatNotify TRADE_SUCCESS ,OrderPrimaryId[" + orderPrimaryId + "]");
                try {
                    RemoteResult<String> updateResult = aliPayDirectWapManager.callUpdate(payOrder, merchantPayPlatView, gmtPayment, tradeNo, notifyId, null, null);
                    PrintWriter out = null;
                    try {
                        out = response.getWriter();
                        if (updateResult.isSuccess()) {
                            LOGGER.info("Send SUCCESS TO AliPay");
                            out.println("success");
                        } else {
                            LOGGER.info("Send FAIL TO AliPay");
                            out.println("fail");
                        }
                    } catch (IOException e) {
                        LOGGER.error("GET PRINTWRITER ERROR!");
                    } finally {
                        if (out != null) {
                            out.close();
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("AliPay DirectWap SimplePlatNotify Call MiddleWare FAIL, OrderPrimaryId[" + orderPrimaryId + "]", ex);
                }
            } else {
                LOGGER.info("AliPay DirectWap SimplePlatNotify ALI Return FAIL, OrderPrimaryId" + orderPrimaryId + "],tradeStatus[" + tradeStatus + ']');
            }
        } else {
            LOGGER.info("AliPay DirectWap SimplePlatNotify Check Signature FAIL，OrderPrimaryId[" + orderPrimaryId + "]");
        }
    }

    @RequestMapping("/aliDirectWapReturn")
    public String aliDirectWapReturn(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        Map<String, String> params;
        Map<?, ?> requestParams = request.getParameterMap();
        params = AlipayUtil.parseRequestParams(requestParams);
        String orderPrimaryId = params.get("out_trade_no");
        String tradeStatus = params.get("trade_status");
        String tradeNo = params.get("trade_no");
        String notifyId = params.get("notify_id");
        String outChannelType = params.get("out_channel_type");
        String outChannelAmount = params.get("out_channel_amount");
        LOGGER.info("Https aliDirectWapRetrun Ready To Go! orderPrimaryID[" + orderPrimaryId + "],tradeStatus[" + tradeStatus + "],notifyId[" + notifyId + "],tradeNo[" + tradeNo + "],outChannelType[" + outChannelType + "],outChannelAmount[" + outChannelAmount + "]");
        PayOrder payOrder;
        RemoteResult<MerchantPayPlatView> merchantPayPlatRemoteResult;
        MerchantPayPlatView merchantPayPlatView;
        try {
            if (StringUtils.isNotEmpty(orderPrimaryId)) {
                payOrder = commonCallBackManager.getPayOrderById(orderPrimaryId);
                LOGGER.info("AliPay DirectWap Original PayOrder [" + payOrder + "]");
            } else {
                LOGGER.info("AliPay DirectWap Original PayOrder Is Null");
                return "syncback/b2c_wap_error";
            }
            if (payOrder != null) {
                merchantPayPlatRemoteResult = commonCallBackManager.getMerchantPayPlatById(payOrder.getMerchant_id());
            } else {
                LOGGER.info("AliPay DirectWap Original PayOrder Is Null, OrderPrimaryId[" + orderPrimaryId + "]");
                return "syncback/b2c_wap_error";
            }
            if (merchantPayPlatRemoteResult.isSuccess()) {
                merchantPayPlatView = merchantPayPlatRemoteResult.getT();
                LOGGER.info("AliPay DirectWap Original MerchantPayPlat [" + merchantPayPlatView + "]");
            } else {
                LOGGER.info("AliPay DirectWap Original MerchantPayPlat Is Null");
                return CommonMethod.getFailSyncReturnURLByShopIdTerminal(payOrder.getShop_id(), payOrder.getTerminal());
            }
        } catch (Exception e) {
            LOGGER.info("支付宝WAP直连异步回调获取订单平台信息异常", e);
            return "syncback/b2c_wap_error";
        }
        boolean verifyFlag;
        try {
            verifyFlag = AlipayNotify.verifyNotify(params, merchantPayPlatView.getSignKey(), merchantPayPlatView.getMechId());
        } catch (Exception e) {
            LOGGER.error("AliPay DirectWap Notify Check Signature EXCEPTION，OrderPrimaryId[" + orderPrimaryId + "],TradeNo[" + tradeNo + "]", e);
            return CommonMethod.getFailSyncReturnURLByShopIdTerminal(payOrder.getShop_id(), payOrder.getTerminal());
        }
        Tenant tenant = CommonMethod.buildTenant(payOrder.getShop_id(), null, null, null, null, null, null);
//        RemoteResult<ChannelOrder> channelOrderResult = commonManager.queryChannelOrderCodeDetail(payOrder.getOut_trade_no(), payOrder.getU_id(), PeakConstant.MAIN_ORDER_FLAG, payOrder.getShop_id());
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(payOrder.getOut_trade_no(), payOrder.getU_id(), tenant);
        String order_type = "";
        if (payPortalOrderRemoteResult.isSuccess()) {
            LOGGER.info("Get PayPortalOrder SUCCESS, PayPortalOrderRemoteResult[" + payPortalOrderRemoteResult + "]");
            paraMap.put("payPortalOrder", payPortalOrderRemoteResult.getT());
            order_type = payPortalOrderRemoteResult.getT().getOrderType();
        } else {
            LOGGER.info("Get PayPortalOrder FAIL, OrderMainCode[" + payOrder.getOut_trade_no() + "]");
            paraMap.put("resultReason", "订单处理异常，请到订单详情查询状态");
            return CommonMethod.getFailSyncReturnURLByShopIdTerminal(payOrder.getShop_id(), payOrder.getTerminal());
        }
        this.buildReturnParaMap(paraMap, payOrder, merchantPayPlatView, payPortalOrderRemoteResult.getT());
        String returnURL;
        if (verifyFlag && (("TRADE_SUCCESS".equals(tradeStatus) || "TRADE_FINISHED".equals(tradeStatus) || "success".equals(tradeStatus)))) {
            returnURL = CommonMethod.getSuccessSyncReturnURLByShopIdTerminal(payOrder.getShop_id(), payOrder.getTerminal());
            LOGGER.info("TRADE_SUCCESS verifyFlag[" + verifyFlag + "],tradeStatus[" + tradeStatus + "],returnURL[" + returnURL + "]");
        } else {
            paraMap.put("resultReason", "支付失败");
            if (PeakConstant.ORDER_TYPE_DONGDE_CZ.equals(order_type)) {
                if (PeakConstant.TERMINAL_PC.equals(payOrder.getTerminal())) {
                    if(PeakConstant.SHOPID_LENOVO.equals(payOrder.getShop_id())){
                        returnURL = "syncback/dongde_pc_fail";
                    }else{
                        returnURL = "charge/epp_pc_charge_fail";
                    }
                } else {
                    if(PeakConstant.SHOPID_LENOVO.equals(payOrder.getShop_id())){
                        returnURL = "syncback/dongde_wap_error";
                    }else{
                        returnURL = "charge/epp_wap_charge_fail";
                    }
                }
            } else {
                returnURL = CommonMethod.getFailSyncReturnURLByShopIdTerminal(payOrder.getShop_id(), payOrder.getTerminal());
            }
            LOGGER.info("TRADE_FAIL verifyFlag[" + verifyFlag + "],tradeStatus[" + tradeStatus + "],returnURL[" + returnURL + "]");
        }
        if (PeakConstant.SHOPID_THINK.equals(payOrder.getShop_id())) {
            try {
                response.sendRedirect(returnURL);
            } catch (Exception e) {
                LOGGER.error("Response SendRedirect THINK EXCEPTION", e);
            }
            return null;
        } else {
            return returnURL;
        }
    }

    @RequestMapping("/aliDirectWapReturn/simplePlatReturn")
    public String aliDirectWapSimplePlatReturn(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        Map<String, String> params;
        Map<?, ?> requestParams = request.getParameterMap();
        params = AlipayUtil.parseRequestParams(requestParams);
        String orderPrimaryId = params.get("out_trade_no");
        String tradeStatus = params.get("trade_status");
        String tradeNo = params.get("trade_no");
        String notifyId = params.get("notify_id");
        String outChannelType = params.get("out_channel_type");
        String outChannelAmount = params.get("out_channel_amount");
        LOGGER.info("Https AliDirectWap SimplePlatReturn Ready To Go! orderPrimaryID[" + orderPrimaryId + "],tradeStatus[" + tradeStatus + "],notifyId[" + notifyId + "],tradeNo[" + tradeNo + "],outChannelType[" + outChannelType + "],outChannelAmount[" + outChannelAmount + "]");
        PayOrder payOrder;
        RemoteResult<MerchantPayPlatView> merchantPayPlatRemoteResult;
        MerchantPayPlatView merchantPayPlatView;
        try {
            if (StringUtils.isNotEmpty(orderPrimaryId)) {
                payOrder = commonCallBackManager.getPayOrderById(orderPrimaryId);
                LOGGER.info("AliPay DirectWap SimplePlatReturn Original PayOrder [" + payOrder + "]");
            } else {
                LOGGER.info("AliPay DirectWap SimplePlatReturn Original PayOrder Is Null");
                return "syncback/b2c_wap_error";
            }
            if (payOrder != null) {
                merchantPayPlatRemoteResult = commonCallBackManager.getMerchantPayPlatById(payOrder.getMerchant_id());
            } else {
                LOGGER.info("AliPay DirectWap SimplePlatReturn Original PayOrder Is Null, OrderPrimaryId[" + orderPrimaryId + "]");
                return "syncback/b2c_wap_error";
            }
            if (merchantPayPlatRemoteResult.isSuccess()) {
                merchantPayPlatView = merchantPayPlatRemoteResult.getT();
                LOGGER.info("AliPay DirectWap SimplePlatReturn Original MerchantPayPlat [" + merchantPayPlatView + "]");
            } else {
                LOGGER.info("AliPay DirectWap SimplePlatReturn Original MerchantPayPlat Is Null");
                return "syncback/b2c_wap_error";
            }
        } catch (Exception e) {
            LOGGER.info("支付宝WAP极简收银台同步回调获取订单平台信息异常", e);
            return "syncback/b2c_wap_error";
        }
        boolean verifyFlag;
        try {
            verifyFlag = AlipayNotify.verifyNotifyJS(params, AliSimplePaltPayConfig.ali_public_key, merchantPayPlatView.getMechId());
        } catch (Exception e) {
            LOGGER.error("AliPay DirectWap SimplePlatReturn Check Signature EXCEPTION，OrderPrimaryId[" + orderPrimaryId + "],TradeNo[" + tradeNo + "]", e);
            return "syncback/b2c_wap_error";
        }
        Tenant tenant = CommonMethod.buildTenant(payOrder.getShop_id(), null, null, null, null, null, null);
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(payOrder.getOut_trade_no(), payOrder.getU_id(), tenant);
//        RemoteResult<ChannelOrder> channelOrderResult = commonManager.queryChannelOrderCodeDetail(payOrder.getOut_trade_no(), payOrder.getU_id(), PeakConstant.MAIN_ORDER_FLAG, payOrder.getShop_id());
        String order_type = "";
        if (payPortalOrderRemoteResult.isSuccess()) {
            LOGGER.info("Get PayPortalOrder SUCCESS,PayPortalOrderRemoteResult[" + payPortalOrderRemoteResult + "]");
            paraMap.put("payPortalOrder", payPortalOrderRemoteResult.getT());
            order_type = payPortalOrderRemoteResult.getT().getOrderType();
        } else {
            LOGGER.info("Get PayPortalOrder FAIL, OrderMainCode[" + payOrder.getOut_trade_no() + "]");
            paraMap.put("resultReason", "订单处理异常，请到订单详情查询状态");
            return "syncback/b2c_wap_error";
        }
        this.buildReturnParaMap(paraMap, payOrder, merchantPayPlatView, payPortalOrderRemoteResult.getT());
        String returnURL;
        if (verifyFlag && (("TRADE_SUCCESS".equals(tradeStatus) || "TRADE_FINISHED".equals(tradeStatus) || "success".equals(tradeStatus)))) {
            returnURL = CommonMethod.getSuccessSyncReturnURLByShopIdTerminal(payOrder.getShop_id(), payOrder.getTerminal());
            LOGGER.info("TRADE_SUCCESS verifyFlag[" + verifyFlag + "],tradeStatus[" + tradeStatus + "],returnURL[" + returnURL + "]");
        } else {
            paraMap.put("resultReason", "支付失败");
            if (PeakConstant.ORDER_TYPE_DONGDE_CZ.equals(order_type)) {
                if (PeakConstant.TERMINAL_PC.equals(payOrder.getTerminal())) {
                    if(PeakConstant.SHOPID_LENOVO.equals(payOrder.getShop_id())){
                        returnURL = "syncback/dongde_pc_fail";
                    }else{
                        returnURL = "charge/epp_pc_charge_fail";
                    }
                } else {
                    if(PeakConstant.SHOPID_LENOVO.equals(payOrder.getShop_id())){
                        returnURL = "syncback/dongde_wap_error";
                    }else{
                        returnURL = "charge/epp_wap_charge_fail";
                    }
                }
            } else {
                returnURL = CommonMethod.getFailSyncReturnURLByShopIdTerminal(payOrder.getShop_id(), payOrder.getTerminal());
            }
            LOGGER.info("TRADE_FAIL verifyFlag[" + verifyFlag + "],tradeStatus[" + tradeStatus + "],returnURL[" + returnURL + "]");
        }
        if (PeakConstant.SHOPID_THINK.equals(payOrder.getShop_id())) {
            try {
                response.sendRedirect(returnURL);
            } catch (Exception e) {
                LOGGER.error("Response SendRedirect THINK EXCEPTION", e);
            }
            return null;
        } else {
            return returnURL;
        }
    }

    private void buildReturnParaMap(Map<String, Object> paraMap, PayOrder payOrder, MerchantPayPlatView merchantPayPlatView, PayPortalOrder payPortalOrder) {
        try {
            BigDecimal decimal = new BigDecimal(payOrder.getTotal_fee());
            decimal = decimal.movePointLeft(2);
            paraMap.put("totalFee", decimal);
            paraMap.put("pay_type", payOrder.getPay_type());
            paraMap.put("lenovoId", payOrder.getU_id());
            paraMap.put("shopId", payOrder.getShop_id());
            paraMap.put("terminal", payOrder.getTerminal());
            paraMap.put("outTradeNo", payOrder.getOut_trade_no());
            paraMap.put("totalFee", decimal);
            paraMap.put("plat", payOrder.getOs());
            if (!PeakConstant.ORDER_TYPE_DONGDE_CZ.equals(payPortalOrder.getOrderType())) {
                int leBean = Integer.parseInt(payPortalOrder.getRewardLedou());
                if (leBean != 0) {
                    paraMap.put("leBean", "恭喜您获得了" + String.valueOf(leBean) + "个乐豆，");
                } else {
                    paraMap.put("leBean", " ");
                }
                String delivery = payPortalOrder.getDeliveryInfo();
                if (StringUtils.isNotEmpty(delivery)) {
                    paraMap.put("delivery", delivery);
                } else {
                    paraMap.put("delivery", " ");
                }
            }
        } catch (Exception ex) {
            LOGGER.info("处理同步回调信息异常", ex);
        }
    }

    @RequestMapping("/weChatAliPayDirectWap")
    public String weChatAliPayDirectWap(HttpServletRequest request, HttpServletResponse response, Map<String, Object> weChatAliPayParaMap) {
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html");
        AliPayDirectWapModel aliPayDirectWapModel = (AliPayDirectWapModel) BaseModel.getModel(request);
        String orderMainCode = aliPayDirectWapModel.getOrderMainCode();
        String lenovoId = aliPayDirectWapModel.getLenovoId();
        String shopId = aliPayDirectWapModel.getShopId();
        String browser = aliPayDirectWapModel.getBrowser();
        LOGGER.info("HTTPS weChatAliPayDirectWap Ready To Go! OrderMainCode[" + orderMainCode + "],lenovoId[" + lenovoId + "],shopId[" + shopId + "],browser[" + browser + "]");
        Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(orderMainCode, lenovoId, tenant);
        if (payPortalOrderRemoteResult.isSuccess()) {
            RemoteResult<String> weChatAliPayResult = aliPayDirectWapManager.toDirectWapPay(request);
            if (weChatAliPayResult.isSuccess()) {
                PayPortalOrder payPortalOrder = payPortalOrderRemoteResult.getT();
                weChatAliPayParaMap.put("subject", payPortalOrder.getSubject());
                weChatAliPayParaMap.put("total_fee", payPortalOrder.getTotalFee());
                weChatAliPayParaMap.put("wxallipayurl", weChatAliPayResult.getT());
                LOGGER.info("Return WeChatAliPayParaMap[" + weChatAliPayParaMap + "]");
                return "weixin/alipay";
            } else {
                return this.getFailRedirect(shopId);
            }
        } else {
            return this.getFailRedirect(shopId);
        }
    }

    private String getFailRedirect(String shopId) {
        String redirectURL = null;
        if (PeakConstant.SHOPID_LENOVO.equals(shopId)) {
            redirectURL = "syncback/b2c_wap_error";
        } else if (PeakConstant.SHOPID_THINK.equals(shopId)) {
            redirectURL = "syncback/tk_wap_error";
        } else if (PeakConstant.SHOPID_EPP.equals(shopId)) {
            redirectURL = "syncback/epp_wap_error";
        } else {
            redirectURL = "syncback/b2c_wap_error";
        }
        return redirectURL;
    }

    public CommonCallBackManager getCommonCallBackManager() {
        return commonCallBackManager;
    }

    public void setCommonCallBackManager(CommonCallBackManager commonCallBackManager) {
        this.commonCallBackManager = commonCallBackManager;
    }

    public AliPayDirectWapManager getAliPayDirectWapManager() {
        return aliPayDirectWapManager;
    }

    public void setAliPayDirectWapManager(AliPayDirectWapManager aliPayDirectWapManager) {
        this.aliPayDirectWapManager = aliPayDirectWapManager;
    }

    public PayPortalOrderManager getPayPortalOrderManager() {
        return payPortalOrderManager;
    }

    public void setPayPortalOrderManager(PayPortalOrderManager payPortalOrderManager) {
        this.payPortalOrderManager = payPortalOrderManager;
    }

    public CommonManager getCommonManager() {
        return commonManager;
    }

    public void setCommonManager(CommonManager commonManager) {
        this.commonManager = commonManager;
    }
}
