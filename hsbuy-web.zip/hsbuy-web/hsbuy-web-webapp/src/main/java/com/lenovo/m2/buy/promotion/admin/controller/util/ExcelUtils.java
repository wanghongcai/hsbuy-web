package com.lenovo.m2.buy.promotion.admin.controller.util;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.lenovo.m2.buy.promotion.admin.domain.coupon.ExtErrorVo;
import com.lenovo.m2.couponV2.api.dubboModel.MemberExcelTempApi;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;


/**
 * excel 工具类 版本1
 * Created by wangyu46 on 2017/6/9.
 */
public class ExcelUtils<T> {

	private static Logger LOG = LoggerFactory.getLogger(ExcelUtils.class);

	private Class<T> clazz;

	public ExcelUtils(Class<T> clazz) {
		this.clazz = clazz;
	}

	/**
	 * 导出excel
	 * @param list  数据
	 * @param title excel工作表 表名
	 * @return XSSFWorkbook
	 */
	public XSSFWorkbook exportExcel(List<T> list, String title) {

		Field[] allFields = clazz.getDeclaredFields();// 得到所有定义字段
		List<Field> fields = new ArrayList<Field>();
		// 得到所有field并存放到一个list中.
		for (Field field : allFields) {
			// 如果被这个注解修饰
			if (field.isAnnotationPresent(ExcelAttribute.class)) {
				fields.add(field);
			}
		}

		XSSFWorkbook workbook = new XSSFWorkbook();// 产生工作薄对象

		try {
			// 生成一个工作表
			XSSFSheet sheet = workbook.createSheet(title);

			XSSFCellStyle createCellStyle = workbook.createCellStyle();
			// 设置格式
			createCellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			createCellStyle.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index); // 设置颜色为红色
			createCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

			// 产生表格标题行
			XSSFRow createRow = sheet.createRow(0);
			
			// 列头 ---
			
			for (int i = 0; i < fields.size(); i++) {
				Field field = fields.get(i);
				ExcelAttribute attribute = field.getAnnotation(ExcelAttribute.class);
				// 是否需要显示

				// 列名
				String name = attribute.name();
				// 创建列
				XSSFCell cell = createRow.createCell(i);
				
				// 列数据
				cell.setCellValue(name);
				cell.setCellStyle(createCellStyle);
				sheet.setColumnWidth(i, 5000);
			}

			// 数据
			for (int j = 0, size = list.size(); j < size; j++) {
				// 每一行.
				XSSFRow row = sheet.createRow(j + 1);

				for (int i = 0; i < fields.size(); i++) {
					Field field = fields.get(i);
					field.setAccessible(true);// class访问权限
					ExcelAttribute attribute = field.getAnnotation(ExcelAttribute.class);
					// 是否需要显示
					XSSFCell cell = row.createCell(i);// 单元格
					cell.setCellType(XSSFCell.CELL_TYPE_STRING);
					// 如果有值 就 设置 没有值 就用默认值
					T t = (T) list.get(j);
					Object object = field.get(t);
					String str = object == null ? attribute.isDefault() : String.valueOf(object);
					cell.setCellValue(str);
				}
			}

		} catch (Exception e) {
			LOG.error("excel表格生成异常", e);
		}

		return workbook;

	}

	public static int writeXSLXExcel(SXSSFWorkbook workbook, String[] excelHeader, List<Object[]> datas){
		int rowNum = 0;
		Sheet sheet = workbook.createSheet("sheet1");
		sheet.setDefaultColumnWidth(20);
		Row titleRow = sheet.createRow(0);
		Row dataRow;
		Cell cell;
		Font font = workbook.createFont();
		font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		CellStyle titleStyle = workbook.createCellStyle();
		titleStyle.setFont(font);
		titleStyle.setBorderTop(CellStyle.BORDER_THIN);
		titleStyle.setBorderBottom(CellStyle.BORDER_THIN);
		titleStyle.setBorderLeft(CellStyle.BORDER_THIN);
		titleStyle.setBorderRight(CellStyle.BORDER_THIN);

		CellStyle dataStyle = workbook.createCellStyle();
		dataStyle.setBorderTop(CellStyle.BORDER_THIN);
		dataStyle.setBorderBottom(CellStyle.BORDER_THIN);
		dataStyle.setBorderLeft(CellStyle.BORDER_THIN);
		dataStyle.setBorderRight(CellStyle.BORDER_THIN);

		for(int i = 0; i < excelHeader.length; i++){
			cell = titleRow.createCell(i);
			cell.setCellStyle(titleStyle);
			cell.setCellValue(excelHeader[i]);
		}
		rowNum++;
		if (datas == null || datas.size() <= 0) {
			return rowNum;
		}
		for(int i = 0; i < datas.size(); i++){
			Object[] data = datas.get(i);
			if (data == null || data.length <= 0) {
				continue;
			}
			dataRow = sheet.createRow(rowNum++);
			for (int j = 0; j < data.length; j++) {
				dataRow.createCell(j).setCellValue(String.valueOf(data[j] == null ? "" : data[j]));
			}
		}

		return rowNum;
	}

	public static Map<String,List> uploadExcelMember(MultipartFile file){
		String fileName = file.getOriginalFilename();
		Map<String,List> resultMap = new HashMap<String, List>();
		List<ExtErrorVo> errorVoList = new ArrayList<ExtErrorVo>();
		List<MemberExcelTempApi> memApiList = new ArrayList<MemberExcelTempApi>();
		List<MemberExcelTempApi> memlist = new ArrayList<MemberExcelTempApi>();
		Workbook workbook = null;
		fileName=fileName.toLowerCase();
		try {
			InputStream is = file.getInputStream();
			if (fileName.endsWith(".xls") ) {
				workbook = new HSSFWorkbook(is);
			} else if (fileName.endsWith(".xlsx")) {
				workbook = new XSSFWorkbook(is);
			}
			is.close();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateFlag = formatter.format(new Date());
			Sheet sheet = workbook.getSheetAt(0);
			for (int i = 0; i <= sheet.getLastRowNum(); i++) {
				Row row = sheet.getRow(i);
				if (row == null) {
					continue;
				}
				int rowNumber =i+1;
				insertRow(errorVoList,memlist,rowNumber,row);
			}
			if (!memlist.isEmpty()){
				for (MemberExcelTempApi memApi : memlist){
					memApiList.add(memApi);
				}
			}
		} catch (IOException e) {
			LOG.error(ExceptionUtil.getStackTrace(e));
		}
		resultMap.put("errorList", errorVoList);
		resultMap.put("memlist", memlist);
		return  resultMap;
	}
	public static void insertRow(List<ExtErrorVo> errorlist,List<MemberExcelTempApi> memlist,int rowNumber,Row row){
		MemberExcelTempApi member = new MemberExcelTempApi();
		Cell LenovoIdCell = row.getCell(0);
		Cell memberCodeCell = row.getCell(1);
		if (null != LenovoIdCell){
			String lenovoId = getStringValue(LenovoIdCell);
			if (StringUtils.isEmpty(lenovoId)){
				logError(errorlist,rowNumber,1,"第"+rowNumber+"行，第"+1+"lenovoId数据错误");
			}else {
				member.setLenovoid(lenovoId);
			}
		}else {
			logError(errorlist,rowNumber,1,"第"+rowNumber+"行，第"+1+"列lenovoId数据错误");
		}
		if (null != memberCodeCell){
			String memberCode = getStringValue(memberCodeCell);
			if (StringUtils.isEmpty(memberCode)){
				logError(errorlist,rowNumber,2,"第"+rowNumber+"行，第"+2+"列memberCode数据错误");
			}else {
				member.setMembercode(memberCode);
			}
		}else {
			logError(errorlist,rowNumber,2,"第"+rowNumber+"行，第"+2+"列memberCode数据错误");
		}
		if(!memlist.contains(member)) {
			memlist.add(member);
		}
	}
	public static void logError(List<ExtErrorVo> errorList, int rowNumber, int colNumber, String errorMessage){
		ExtErrorVo erVo = new ExtErrorVo();
		erVo.setRowNumber(rowNumber);
		erVo.setColnNumber(colNumber);
		erVo.setErrorMsg(errorMessage);
		errorList.add(erVo);
	}
	public static String getStringValue(Cell cell) {
		if (cell == null) {
			return "";
		}
		String cellvalue = "";
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		switch (cell.getCellType()) {
			case HSSFCell.CELL_TYPE_NUMERIC:
				if (HSSFDateUtil.isCellDateFormatted(cell)) {
					cellvalue = format.format(cell.getDateCellValue());
				} else {
					DecimalFormat df = new DecimalFormat("#.##");
					String strValue = df.format(cell.getNumericCellValue());
					if (strValue.endsWith(".0")) {
						cellvalue = strValue.substring(0, strValue.length() - 2);
					} else {
						cellvalue = strValue;
					}
				}
				break;
			case HSSFCell.CELL_TYPE_STRING:
				cellvalue = cell.getStringCellValue();
				break;
			case HSSFCell.CELL_TYPE_BOOLEAN:
				cellvalue = cell.getBooleanCellValue() + "";
				break;
			default:
				cellvalue = "";
				break;
		}

		if ("null".equalsIgnoreCase(cellvalue)){
			cellvalue = "";
		}
		return cellvalue.trim();
	}

//	public List<T> inportExcel(XSSFWorkbook workBook){
//		
//		
//		return null;
//	}
}
