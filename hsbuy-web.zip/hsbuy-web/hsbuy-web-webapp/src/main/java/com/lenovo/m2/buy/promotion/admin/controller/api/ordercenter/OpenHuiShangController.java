package com.lenovo.m2.buy.promotion.admin.controller.api.ordercenter;

import com.lenovo.m2.arch.framework.domain.*;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.buy.promotion.admin.controller.util.ExcelSAXHandler;
import com.lenovo.m2.buy.promotion.admin.domain.ordercenter.*;
import com.lenovo.m2.buy.promotion.admin.manager.ordercenter.OpenOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.ordercenter.OpenOrderRemote;
import com.lenovo.m2.hsbuy.common.order.OrderConstance;
import com.lenovo.m2.hsbuy.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderItem;
import com.lenovo.m2.hsbuy.domain.order.mainorder.MOrderMain;
import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;
import com.lenovo.m2.hsbuy.domain.order.mongo.PayRecords;
import com.lenovo.m2.hsbuy.domain.order.mongo.Product;
import com.lenovo.m2.hsbuy.domain.order.mongo.Receiver;
import com.lenovo.m2.hsbuy.domain.ordercenter.*;
import com.lenovo.m2.hsbuy.domain.throwengine.OrderItemHSVo;
import net.sf.json.JSONArray;
import org.apache.commons.collections.map.HashedMap;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 慧商对接开放平台接口
 */
@RestController
@RequestMapping("api/open/order/huishang")
public class OpenHuiShangController {
    private static final Logger LOGGER = Logger.getLogger(OpenHuiShangController.class);
    @Autowired
    private OpenOrderManager openOrderManager;
    @Autowired
    private OpenOrderRemote openOrderRemote;

    /**
     * 查询待审核订单列表
     *
     * @param request
     * @return
     */
    @RequestMapping(value = "/list", method = {RequestMethod.GET, RequestMethod.POST}, produces = "application/json; charset=UTF-8")
    public String getOrderList(ToAuditOrderListParam request, HttpServletResponse response) {
        LOGGER.info("http open api getOrderList ready go! request=[" + JsonUtil.toJson(request) + "]");
        RemoteResult remoteResult = new RemoteResult(false);
        if (request == null) {
            remoteResult.setResultCode(ResultCode.PARAMETER_ERROR);
            remoteResult.setResultMsg("请求参数有误");
            return JsonUtil.toJson(remoteResult);
        }
        if (CollectionUtils.isEmpty(request.getFaIds())) {
            remoteResult.setResultCode(ResultCode.TEMP);
            remoteResult.setResultMsg("没有分销商权限,请联系管理员");
            return JsonUtil.toJson(remoteResult);
        }
        try {
            PageQuery pageQuery = new PageQuery(request.getPageNum(), request.getPageSize());
            Map<String, Object> filterMap = request.getFilterMap() == null ? new HashedMap() : request.getFilterMap();
            List<String> faIds = request.getFaIds();
            String faId = (String)filterMap.get("faId");
            if (faIds.size() == 1 && StringUtils.isEmpty(faId)) {
                filterMap.put("faId", faIds.get(0));
            }
            filterMap.put("faIds", faIds);
            remoteResult = openOrderManager.getMongoOrderList(pageQuery, filterMap, request.getTenant());
        } catch(Exception t) {
            LOGGER.error("getOrderList error", t);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("获取审单列表失败");
        }
        LOGGER.info("http open api getOrderList result: [" + JsonUtil.toJson(remoteResult) + "]");
        return JsonUtil.toJson(remoteResult);
    }
    /**
     * 查询待审核订单列表
     *
     * @param request
     * @return
     */
    @RequestMapping(value = "/getHuiShangAuditList", method = {RequestMethod.GET, RequestMethod.POST}, produces = "application/json; charset=UTF-8")
    public String getHuiShangAuditList(ToAuditOrderListParam request, HttpServletResponse response) {
        LOGGER.info("http open api getHuiShangAuditList ready go! request=[" + JsonUtil.toJson(request) + "]");
        RemoteResult remoteResult = new RemoteResult(false);
        if (request == null) {
            remoteResult.setResultCode(ResultCode.PARAMETER_ERROR);
            remoteResult.setResultMsg("请求参数有误");
            return JsonUtil.toJson(remoteResult);
        }
        if (CollectionUtils.isEmpty(request.getFaIds())) {
            remoteResult.setResultCode(ResultCode.TEMP);
            remoteResult.setResultMsg("没有分销商权限,请联系管理员");
            return JsonUtil.toJson(remoteResult);
        }
        try {
            PageQuery pageQuery = new PageQuery(request.getPageNum(), request.getPageSize());
            Map<String, Object> filterMap = request.getFilterMap() == null ? new HashedMap() : request.getFilterMap();
            List<String> faIds = request.getFaIds();
            String faId = (String) filterMap.get("faId");
            if (faIds.size() == 1 && StringUtils.isEmpty(faId)) {
                filterMap.put("faId", faIds.get(0));
            }
            filterMap.put("faIds", faIds);
            filterMap.put("notSubmitOrderWay",2);
            remoteResult = openOrderManager.getMongoOrderList(pageQuery, filterMap, request.getTenant());
        } catch(Exception t) {
            LOGGER.error("getHuiShangAuditList error", t);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("获取审单列表失败");
        }
        LOGGER.info("http open api getHuiShangAuditList result: [" + JsonUtil.toJson(remoteResult) + "]");
        return JsonUtil.toJson(remoteResult);
    }

    /**
     * 查询审核订单详细信息
     *
     * @param request
     * @return
     */
    @RequestMapping(value = "/detail", method = {RequestMethod.GET, RequestMethod.POST}, produces = "application/json; charset=UTF-8")
    public String getOrderDetail(ToAuditOrderDetailParam request) {
        LOGGER.info("http open api getOrderDetail ready go! request=[" + JsonUtil.toJson(request) + "]");
        RemoteResult remoteResult = new RemoteResult(false);
        try {
            Map<String, Object> map = new HashedMap();
            map.put("orderId", request.getOrderId());
            remoteResult = openOrderManager.getMongoOrderDetail(map, request.getTenant());
        } catch(Exception t) {
            LOGGER.error("getOrderDetail error", t);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("获取审单详情失败");
        }
        return JsonUtil.toJson(remoteResult);
    }

    /**
     * 审核订单
     *
     * @param request
     * @return
     */
    @RequestMapping(value = "/audit", method = {RequestMethod.GET, RequestMethod.POST}, produces = "application/json; charset=UTF-8")
    public String auditOrderDetail(AuditOrderDetailParam request) {

        LOGGER.info("http open api auditOrderDetail ready go! request=[" + JsonUtil.toJson(request) + "]");
        RemoteResult remoteResult = new RemoteResult(false);
        if (request == null || request.getTenant() == null || StringUtils.isEmpty(request.getTenant().getCurrencyCode())) {
            remoteResult.setResultCode(ResultCode.PARAMETER_ERROR);
            remoteResult.setResultMsg("接入参数有误");
            return JsonUtil.toJson(remoteResult);
        }

        if (StringUtils.isEmpty(request.getAddress())
                || StringUtils.isEmpty(request.getAmountMoney())
                || StringUtils.isEmpty(request.getCreditLine())
                || StringUtils.isEmpty(request.getOrderId())
                || StringUtils.isEmpty(request.getProducts())
                || StringUtils.isEmpty(request.getCostItem()) || request.getAccountType() <= 0) {
            remoteResult.setResultCode(ResultCode.PARAMETER_ERROR);
            remoteResult.setResultMsg("请求详细参数有误");
            return JsonUtil.toJson(remoteResult);
        }
        if (!checkDouble(request.getCreditLine()) || !checkDouble(request.getAmountMoney()) || !checkDouble(request.getCostItem())) {
            remoteResult.setResultCode(ResultCode.PARAMETER_ERROR);
            remoteResult.setResultMsg("转换Money参数非Double类型");
            return JsonUtil.toJson(remoteResult);
        }
        try {
            MongoOrderDetail order = new MongoOrderDetail();
            String currencyCode = request.getTenant().getCurrencyCode();
            order.setAccountType(request.getAccountType());
            order.setAddonstr(request.getNote());
            order.setOrderCode(request.getOrderId());
            order.setAmountMoney(new Money(request.getAmountMoney(), currencyCode));
            order.setCreditLine(new Money(request.getCreditLine(), currencyCode));
            order.setCostItem(new Money(request.getCostItem(), currencyCode)); //订单总金额
            Receiver receiver = JsonUtil.fromJson(request.getAddress(), Receiver.class);
            List<Receiver> receivers = new ArrayList<Receiver>();
            receivers.add(receiver);
            order.setDeliveries(receivers);
            List<Product> products = new ArrayList<Product>();
            List<Map> productList = JsonUtil.fromJson(request.getProducts(), List.class);
            Map<String, Map> sumMap = new HashedMap();
            for(Map map : productList) {
                Product product = new Product();
                product.setProductCode((String) map.get("productCode"));
                product.setOrderItemId(Integer.parseInt(map.get("orderItemId").toString()));
                product.setProductNumber((String) map.get("productNumber"));
                product.setProductPay(new Money((String) map.get("productPay"), currencyCode));
                products.add(product);
            }
            order.setProducts(products);
            AuditOrderDetailRequest auditOrderDetailRequest = new AuditOrderDetailRequest();
            auditOrderDetailRequest.setOrder(order);
            auditOrderDetailRequest.setPass(request.getPass());

            remoteResult = openOrderManager.auditOrderDetail(auditOrderDetailRequest, request.getTenant());
        } catch(Exception t) {
            LOGGER.error("getOrderDetail error", t);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("审单失败");
        }
        return JsonUtil.toJson(remoteResult);
    }

    /**
     * 校验商品单价是否double类型
     *
     * @param remoteResult
     * @param productPay
     * @return
     */
    private boolean checkProductPay(RemoteResult remoteResult, String productPay) {
        if (!checkDouble(productPay)) {
            remoteResult.setResultCode(ResultCode.PARAMETER_ERROR);
            remoteResult.setResultMsg("商品单价转换Money参数非Double类型");
            return true;
        }
        return false;
    }


    /**
     * 校验是否double类型，主要是用于String转换Money前校验
     *
     * @param sContentValue
     * @return
     */
    private boolean checkDouble(String sContentValue) {
        if (sContentValue == null) {
            return false;
        }
        boolean bCheckResult = true;
        try {
            Double dCheckValue = Double.parseDouble(sContentValue);
            if (dCheckValue instanceof Double == false) {
                bCheckResult = false;
            }
        } catch(NumberFormatException e) {
            bCheckResult = false;
        }
        return bCheckResult;
    }

    /**
     * 抛单详情
     *
     * @param param
     * @return
     */
    @RequestMapping(value = "/throw/detail", method = {RequestMethod.GET, RequestMethod.POST}, produces = "application/json; charset=UTF-8")
    public String getHSThrowList(ThrowWareHouseListParam param) {
        LOGGER.info("http open api getHSThrowList ready go! request=[" + param + "]");
        RemoteResult remoteResult = new RemoteResult(false);
        if (param == null || param.getTenant() == null || StringUtils.isEmpty(param.getOrderId())) {
            remoteResult.setResultCode(ResultCode.PARAMETER_ERROR);
            remoteResult.setResultMsg("接入参数有误");
            return JsonUtil.toJson(remoteResult);
        }
        try {
            remoteResult = openOrderManager.getHSThrowList(param);
        } catch(Exception t) {
            LOGGER.error("getOrderDetail error", t);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("获取发货列表失败");
        }
        return JsonUtil.toJson(remoteResult);
    }




    @RequestMapping(value = "/cancelorder", method = {RequestMethod.GET, RequestMethod.POST}, produces = "application/json; charset=UTF-8")
    public String cancelOrder(CancelOrderParam param) {
        LOGGER.info("http open api cancelOrder ready go! request=[" + param + "]");
        RemoteResult remoteResult = new RemoteResult();
        try {
            remoteResult = openOrderRemote.cancelOrder(Long.valueOf(param.getOrderId()), 5, param.getTenant());
        } catch(Exception t) {
            LOGGER.error("cancelOrder error", t);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("取消订单失败");
        }
        return JsonUtil.toJson(remoteResult);
    }

    @RequestMapping(value = "/calculateOrderPrices", method = {RequestMethod.GET, RequestMethod.POST}, produces = "application/json; charset=UTF-8")
    public String calculateOrderPrices(CalculateOrderPricesParam param) {
        LOGGER.info("http open api calculateOrderPrices ready go! request=[" + param + "]");
        RemoteResult remoteResult = new RemoteResult();
        try {
            if (!checkDouble(param.getCreditLine())) {
                remoteResult.setResultCode(ResultCode.PARAMETER_ERROR);
                remoteResult.setResultMsg("转换Money参数非Double类型");
                return JsonUtil.toJson(remoteResult);
            }
            String currencyCode = param.getTenant().getCurrencyCode();
            List<Map> mapList = JsonUtil.fromJson(param.getOrderItems(), List.class);
            List<MOrderItem> mOrderItemList = new ArrayList<MOrderItem>();
            for(Map m : mapList) {
                MOrderItem mOrderItem = new MOrderItem();
                mOrderItem.setCurrencyCode(currencyCode);
                mOrderItem.setCode((String) m.get("code"));
                mOrderItem.setOrderItemId(Integer.parseInt(m.get("orderItemId").toString()));
                if (!checkDouble(String.valueOf(m.get("gPrice")))) {
                    remoteResult.setResultCode(ResultCode.PARAMETER_ERROR);
                    remoteResult.setResultMsg("转换Money参数非Double类型");
                    return JsonUtil.toJson(remoteResult);
                }
                mOrderItem.setGPrice(new Money(String.valueOf(m.get("gPrice")), currencyCode));
                mOrderItemList.add(mOrderItem);
            }
            MOrderMain orderMain = new MOrderMain();
            String creditLine = param.getCreditLine();
            orderMain.setCreditLine(new Money(param.getCreditLine(), currencyCode));
            orderMain.setOrderCode(Long.valueOf(param.getOrderId()));
            orderMain.setCurrencyCode(currencyCode);
            remoteResult = openOrderRemote.calculateOrderPrices(orderMain, mOrderItemList, param.getTenant());
        } catch(Exception t) {
            LOGGER.error("calculateOrderPrices error", t);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("计算价格失败");
        }
        return JsonUtil.toJson(remoteResult);
    }


    /**
     * 保存分配库存地的信息
     *
     * @param param
     * @return
     */
    @RequestMapping(value = "/saveItemsWareHouse", method = {RequestMethod.GET, RequestMethod.POST}, produces = "application/json; charset=UTF-8")
    public String saveItemsWareHouse(WareHouseUpdateParam param) {
        LOGGER.info("http open api saveItemsWareHouse ready go! request=[" + param + "]");
        RemoteResult remoteResult = new RemoteResult();
        try {
            if (StringUtils.isNotEmpty(param.getOrderItemsJson())) {
                JSONArray jsonArray = JSONArray.fromObject(param.getOrderItemsJson());
                List<OrderItemHSVo> list = (List<OrderItemHSVo>) JSONArray.toCollection(jsonArray, OrderItemHSVo.class);
                remoteResult = openOrderManager.saveItemsWareHouse(list, param.getShopId());
            } else {
                remoteResult.setResultCode(ResultCode.FAILURE);
                remoteResult.setResultMsg("传入参数有误");
                LOGGER.info("传入参数有误");
            }
        } catch(Exception t) {
            LOGGER.error("saveItemsWareHouse error", t);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("保存分配库存地失败");
        }
        return JsonUtil.toJson(remoteResult);
    }


    /**
     * 保存分配库存地并抛单
     * @param param
     * @return
     */
    @RequestMapping(value = "/saveItemsWareHouseAndThrowOrder", method = {RequestMethod.GET, RequestMethod.POST}, produces = "application/json; charset=UTF-8")
    public String saveItemsWareHouseAndThrowOrder(WareHouseUpdateParam param) {
        LOGGER.info("http open api saveItemsWareHouseAndThrowOrder ready go! request=[" + param + "]");
        RemoteResult remoteResult = new RemoteResult();
        try {
            if (StringUtils.isNotEmpty(param.getOrderItemsJson())) {
                OrderItemHSVo orderItemHSVo = JsonUtil.fromJson(param.getOrderItemsJson(), OrderItemHSVo.class);
                orderItemHSVo.setShopId(param.getShopId());
                remoteResult = openOrderManager.saveItemsWareHouseAndThrowOrder(orderItemHSVo);
            } else {
                remoteResult.setResultCode(ResultCode.FAILURE);
                remoteResult.setResultMsg("传入参数有误");
                LOGGER.info("传入参数有误");
            }
        } catch(Exception t) {
            LOGGER.error("updateHSThrowList error", t);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("保存分配库存地并抛单失败");
        }
        return JsonUtil.toJson(remoteResult);
    }


    /**
     * 查询慧商线下支付列表
     *
     * @param downlinePayParam
     * @return
     */
    @RequestMapping(value = "/queryDownlinePayList", method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public void queryDownlinePayList(DownlinePayListParam downlinePayParam, HttpServletResponse response) {
        try {
            LOGGER.info("http open api queryDownlinePayList ready go! downlinePayParam=[" + downlinePayParam.toString() + "]");
            Map<String, Object> map = downlinePayParam.genCondition();
            RemoteResult<PageModel2<PayRecords>> remoteResult = new RemoteResult<PageModel2<PayRecords>>();
            if (map.isEmpty()) {
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("获取登录用户信息失败");
                LOGGER.info("获取登录用户信息失败");
            } else {
                List<String> faIds = (List<String>) map.get("faIds");
                if(faIds==null ||faIds.size()<=0){
                    remoteResult.setSuccess(false);
                    remoteResult.setResultMsg("获取登录用户FAID信息失败");
                    LOGGER.info("获取登录用户FAID信息失败");
                }else{
                    downlinePayParam.setFaIds(faIds);
                    remoteResult=  openOrderManager.queryDownlinePayList(downlinePayParam);
                }
                LOGGER.info("response queryDownlinePayList finish remoteResult= " + remoteResult.toString());
            }
            response.setCharacterEncoding("UTF-8");
            response.getWriter().print(JsonUtil.toJson(remoteResult));
        } catch (Exception e) {
            LOGGER.error("查询慧商线下支付列表异常", e);
        }
    }

    @RequestMapping(value = "/savePayRecords", method = {RequestMethod.GET, RequestMethod.POST}, produces = "application/json; charset=UTF-8")
    public String savePayRecords(PayRecordsSaveParam param) {
        LOGGER.info("http open api savePayRecords ready go! request=[" + param + "]");
        RemoteResult remoteResult = new RemoteResult();
        try {
            if (StringUtils.isNotEmpty(param.getPayRecordsJson())) {
                PayRecords payRecords = JsonUtil.fromJson(param.getPayRecordsJson(), PayRecords.class);
                payRecords.setShopId(param.getShopId());
                remoteResult = openOrderRemote.savePayRecords(payRecords);
            } else {
                remoteResult.setResultCode(ResultCode.FAILURE);
                remoteResult.setResultMsg("传入参数有误");
                LOGGER.info("传入参数有误");
            }
        } catch(Exception t) {
            LOGGER.error("saveItemsWareHouseAndThrowOrder error", t);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("保存惠商线下打款凭证！");
        }
        return JsonUtil.toJson(remoteResult);
    }

    /**
     * 获取付款记录详情
     *
     * @param param
     * @return
     */
    @RequestMapping(value = "/payrecords/detail", method = {RequestMethod.GET, RequestMethod.POST}, produces = "application/json; charset=UTF-8")
    public String payRecordsDetail(PayRecordsDetailParam param) {
        LOGGER.info("http open api payRecordsDetail ready go! request=[" + JsonUtil.toJson(param) + "]");
        RemoteResult remoteResult = new RemoteResult();
        try {
            if (param == null
                    || param.getTenant() == null
                    || StringUtils.isEmpty(param.getPayId())
                    || StringUtils.isEmpty(param.getFaId())) {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("1000");
                remoteResult.setResultMsg("参数有误");
                return JsonUtil.toJson(remoteResult);
            }
            if (CollectionUtils.isEmpty(param.getFaIds()) || !param.getFaIds().contains(param.getFaId())) {
                remoteResult.setResultCode(ResultCode.TEMP);
                remoteResult.setResultMsg("登录用户没有该分销商权限,请联系管理员");
                return JsonUtil.toJson(remoteResult);
            }
            //线下银行转账记录详情
            RemoteResult<PayRecordsDetailResult> result = openOrderRemote.payRecordsDetail(param.getPayId(), param.getTenant());
            return JsonUtil.toJson(result);
        } catch(Exception e) {
            LOGGER.error("payRecordsDetail error", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("获取线下付款信息异常，请联系管理员");
            return JsonUtil.toJson(remoteResult);
        }

    }

    /**
     * 审核付款记录
     *
     * @param param
     * @return
     */
    @RequestMapping(value = "/payrecords/audit", method = {RequestMethod.GET, RequestMethod.POST}, produces = "application/json; charset=UTF-8")
    public String auditPayRecords(AuditPayRecordsParam param) {
        LOGGER.info("http open api payRecordsDetail ready go! request=[" + JsonUtil.toJson(param) + "]");
        RemoteResult remoteResult = new RemoteResult();
        try {
            //校验参数
            if (param == null
                    || param.getTenant() == null
                    || StringUtils.isEmpty(param.getPayRecordsJson())) {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("1000");
                remoteResult.setResultMsg("参数有误");
                return JsonUtil.toJson(remoteResult);
            }
            //转换对象
            PayRecords payRecords = JsonUtil.fromJson(param.getPayRecordsJson(), PayRecords.class);

            //校验参数
            if (payRecords == null) {
                remoteResult.setResultCode(ResultCode.TEMP);
                remoteResult.setResultMsg("参数转对象异常");
                return JsonUtil.toJson(remoteResult);
            }

            //校验权限
            if (CollectionUtils.isEmpty(param.getFaIds()) || !param.getFaIds().contains(payRecords.getFaId())) {
                remoteResult.setResultCode(ResultCode.TEMP);
                remoteResult.setResultMsg("登录用户没有该分销商权限,请联系管理员");
                return JsonUtil.toJson(remoteResult);
            }

            //校验参数
            if (StringUtils.isEmpty(payRecords.getPayId())
                    || payRecords.getStatus() == 0) {
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("1000");
                remoteResult.setResultMsg("参数有误");
                return JsonUtil.toJson(remoteResult);
            }
            //校验参数
            if (payRecords.getStatus() == OrderConstant.AUDIT_PASS
                    && (StringUtils.isEmpty(payRecords.getPayeeBank())
                    || StringUtils.isEmpty(payRecords.getPayeeVoucher())
                    || StringUtils.isEmpty(payRecords.getPayeePic()))) {
                remoteResult.setResultCode(ResultCode.TEMP);
                remoteResult.setResultMsg("收款信息为空");
                return JsonUtil.toJson(remoteResult);
            }
            //校验参数
            if (payRecords.getStatus() == OrderConstant.AUDIT_NOPASS && StringUtils.isEmpty(payRecords.getRemarks())) {
                remoteResult.setResultCode(ResultCode.TEMP);
                remoteResult.setResultMsg("审核拒绝理由为空");
                return JsonUtil.toJson(remoteResult);
            }


            payRecords.setUpdateBy(param.getUserId());
            payRecords.setAuditBy(param.getUserId());
            payRecords.setCurrencyCode(param.getTenant().getCurrencyCode());
            payRecords.setShopId(param.getShopId());

            //审核付款记录
            RemoteResult result = openOrderRemote.auditPaymentPayRecords(payRecords, param.getTenant());
            return JsonUtil.toJson(result);
        } catch(Exception e) {
            LOGGER.error("auditPayRecords error", e);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("审核付款记录异常，请联系管理员");
            return JsonUtil.toJson(remoteResult);
        }

    }

    /**
     * 对接开放平台
     * 惠商订单对账信息列表
     * @param request
     * @param response
     */
    @ResponseBody
    @RequestMapping(value = "/getOpenHSReconciliationList",method = {RequestMethod.POST, RequestMethod.GET})
    public void getOpenHSReconciliationList(OrderRequest request, HttpServletResponse response) {
        LOGGER.info("http getOpenHSReconciliationList go!!! shopId=[" + request.tenant().getShopId() + "], map=[" + request.genCondition().toString() + "]");
        Tenant tenant = request.tenant();
        Map<String, Object> map = request.genCondition();
        RemoteResult rs = openOrderRemote.getOpenHSReconciliationList(new PageQuery(request.getPageNum(), request.getPageSize()), map, tenant);
        try {
            //返回结果
            String json = JsonUtil.toJson(rs);
            LOGGER.info("http getOpenHSReconciliationList finish  shopId=[" + request.tenant().getShopId() + "], json " + json + "]");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().print(json);

        } catch(Exception e) {
            LOGGER.error(e);
        }
    }

    @ResponseBody
    @RequestMapping(value = "/openHSOrderReportList", method = {RequestMethod.POST, RequestMethod.GET})
    public void openHSOrderReportList(OrderRequest request, HttpServletResponse response) {
        LOGGER.info("httpRequest openHSOrderReportList go!!! shopId=[" + request.tenant().getShopId() + "], map=[" + request.genCondition().toString() + "]");
        try {
            Tenant tenant = request.tenant();
            Map<String, Object> map = request.genCondition();

            RemoteResult remoteResult = new RemoteResult();
            if (map.isEmpty()) {
                remoteResult.setSuccess(false);
                remoteResult.setResultMsg("获取登录用户信息失败");
                LOGGER.info("获取登录用户信息失败");
            } else {
                List<String> faIds = (List<String>) map.get("faIds");
                if (faIds == null || faIds.size() <= 0) {
                    remoteResult.setSuccess(false);
                    remoteResult.setResultMsg("获取登录用户FAID信息失败");
                    LOGGER.info("获取登录用户FAID信息失败");
                } else {
                    remoteResult = openOrderRemote.getOpenHSOrderReportList(new PageQuery(request.getPageNum(), request.getPageSize()), map, tenant);
                }
                LOGGER.info("httpResponse openHSOrderReportList finish remoteResult= " + remoteResult);
            }
            //返回结果
            response.setCharacterEncoding("UTF-8");
            response.getWriter().print(JsonUtil.toJson(remoteResult));
        } catch (Exception e) {
            LOGGER.error(e);
        }
    }

    private static final int WORKSIZE = 1000;//超过1000条数据使用缓存
    private static final int PAGESIZE = 1000;//pageSize 分页条数
    static String[] hsExcelHeader = {"订单编号", "订单金额", "是否信用支付", "审单类型", "分销商编码", "分销商名称", "经销商编码",
            "经销商名称", "现金支付金额", "信用支付金额", "优惠券金额", "积分支付金额", "支付平台", "银行流水单号", "信用合同号", "订单创建时间", "支付时间", "发票类型", "发票内容"};

    /**
     * 惠商订单报表导出
     */
    @RequestMapping(value = "/downHSOrderExport", method = RequestMethod.POST)
    public void downHSOrderReportExport(OrderRequest request, HttpServletResponse response) {

        SXSSFWorkbook workbook = new SXSSFWorkbook(WORKSIZE);
        workbook.setCompressTempFiles(true);
        RemoteResult rs = new RemoteResult(false);
        try {
            //产生工作表对象
            Sheet sheet = ExcelSAXHandler.createSheet(workbook, "惠商订单对账列表", hsExcelHeader);
            boolean hasDates = true;
            int pageNum = 1;
            int rowNum = 1;
            PageQuery pageQuery = new PageQuery(pageNum, PAGESIZE);
            Tenant tenant = request.tenant();
            Map<String, Object> map = request.genCondition();
            while (hasDates) {
                pageQuery.setPageNum(pageNum);
                RemoteResult<PageModel2<HSReportVo>> pm = openOrderRemote.getOpenHSOrderReportList(pageQuery, map, tenant);
                if (com.alibaba.dubbo.common.utils.CollectionUtils.isNotEmpty(pm.getT().getDatas()) && pm.getT().getDatas().size() < PAGESIZE) {
                    rowNum = buildDataForHSOrderList(sheet, pm.getT().getDatas(), rowNum);
                    hasDates = false;
                } else if (pm != null && com.alibaba.dubbo.common.utils.CollectionUtils.isEmpty(pm.getT().getDatas())) {
                    hasDates = false;
                } else {
                    rowNum = buildDataForHSOrderList(sheet, pm.getT().getDatas(), rowNum);
                    pageNum++;
                }
            }
            //上传到图片服务器
            String readURL = ExcelSAXHandler.uploadImage(workbook);

            sendToPage(readURL, rs, workbook, response);
        } catch (Exception e) {
            LOGGER.error("惠商订单报表导出异常", e);
            try {
                if (workbook != null) {
                    workbook.dispose();
                    workbook.close();

                }
            } catch (IOException e1) {
                LOGGER.error("惠商订单报表关闭workbook异常", e1);
            }
        }
    }

    /**
     * 封装订单列表excel数据
     *
     * @param sheet
     */
    private int buildDataForHSOrderList(Sheet sheet, List<HSReportVo> list, int rows) {
        for (int i = 0; i < list.size(); i++) {
            int firstCell = 0;
            HSReportVo hsReportVo = list.get(i);
            Row row = sheet.createRow(rows);//创建一行
            rows++;
            if (hsReportVo == null) {
                continue;
            }
            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getId()); //订单编号

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getTotalCost()); //订单金额

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getCreditLine().getAmount().compareTo(new BigDecimal(0.00)) > 0 ? "是" : "否"); //是否信用支付

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getAccountType() == 1 ? "对私" : "对公"); //审单类型

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getFaCode()); //分销商编码

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getFaName()); //分销商名称

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getLenovoId()); //经销商编码

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getBuyerCode()); //经销商名称

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getTotalPay()); //现金支付金额

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getCreditLine()); //信用支付金额

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getCashVoucher()); //优惠券金额

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getPayPoint()); //积分支付金额

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getPayment()); //支付平台

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getBankTraceNo()); //银行流水单号

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getPactCode()); //信用合同号

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getCreateTime()); //订单创建时间

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getPayTime()); //支付时间

            Integer invoiceTypeId = hsReportVo.getInvoiceTypeId();
            if (null == invoiceTypeId) {
                ExcelSAXHandler.setCellValue(firstCell++, row, ""); //发票类型
            } else {
                ExcelSAXHandler.setCellValue(firstCell++, row, OrderConstance.getInvoiceTypeDesc(invoiceTypeId)); //发票类型
            }

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getInvoiceContent()); //发票内容
        }
        return rows;
    }

    /**
     * 返回开放平台信息
     *
     * @param readURL
     * @param rs
     * @param response
     * @throws Exception
     */
    public void sendToPage(String readURL, RemoteResult rs, SXSSFWorkbook workbook, HttpServletResponse response) throws Exception {
        if (org.apache.commons.lang.StringUtils.isNotBlank(readURL)) {
            LOGGER.info("========sendToPage SUCCESS=============");
            rs.setSuccess(true);
            rs.setT(readURL);
            rs.setResultCode("1000");
            rs.setResultMsg("操作成功");
        }
        workbook.dispose();
        workbook.close();
        String json = JsonUtil.toJson(rs);
        response.setContentType("text/html;charset=utf-8");
        response.getWriter().print(json);
        response.getWriter().close();
    }

    static String[] hsPeaceExcelHeader = {"惠商订单号", "分销商名称", "经销商名称", "经销商编号", "商户号", "平安订单号", "交易金额", "交易时间", "手续费"};

    /**
     * 惠商平安对账报表导出
     */
    @RequestMapping(value = "/downHSPeaceOrderReportExport", method = RequestMethod.POST)
    public void downHSPeaceOrderReportExport(OrderRequest request, HttpServletResponse response) {
        LOGGER.info("httpRequest downHSPeaceOrderReportExport go!!! shopId=[" + request.tenant().getShopId() + "], map=[" + request.genCondition().toString() + "]");
        SXSSFWorkbook workbook = new SXSSFWorkbook(WORKSIZE);
        workbook.setCompressTempFiles(true);
        RemoteResult rs = new RemoteResult(false);
        try {
            //产生工作表对象
            Sheet sheet = ExcelSAXHandler.createSheet(workbook, "惠商平安对账列表", hsPeaceExcelHeader);
            boolean hasDates = true;
            int pageNum = 1;
            int rowNum = 1;
            PageQuery pageQuery = new PageQuery(pageNum, PAGESIZE);
            Tenant tenant = request.tenant();
            Map<String, Object> map = request.genCondition();
            while (hasDates) {
                pageQuery.setPageNum(pageNum);
                RemoteResult<PageModel2<OpenHSOrderReconciliationInfo>> pm = openOrderRemote.getOpenHSReconciliationList(pageQuery, map, tenant);
                if (com.alibaba.dubbo.common.utils.CollectionUtils.isNotEmpty(pm.getT().getDatas()) && pm.getT().getDatas().size() < PAGESIZE) {
                    rowNum = buildDataForHSPeaceOrderList(sheet, pm.getT().getDatas(), rowNum);
                    hasDates = false;
                } else if (pm != null && com.alibaba.dubbo.common.utils.CollectionUtils.isEmpty(pm.getT().getDatas())) {
                    hasDates = false;
                } else {
                    rowNum = buildDataForHSPeaceOrderList(sheet, pm.getT().getDatas(), rowNum);
                    pageNum++;
                }
            }
            //上传到图片服务器
            String readURL = ExcelSAXHandler.uploadImage(workbook);

            sendToPage(readURL, rs, workbook, response);
        } catch (Exception e) {
            LOGGER.error("惠商平安对账报表导出异常", e);
            try {
                if (workbook != null) {
                    workbook.dispose();
                    workbook.close();

                }
            } catch (IOException e1) {
                LOGGER.error("惠商平安对账报表关闭workbook异常", e1);
            }
        }
    }

    private int buildDataForHSPeaceOrderList(Sheet sheet, List<OpenHSOrderReconciliationInfo> list, int rows) {
        for (int i = 0; i < list.size(); i++) {
            int firstCell = 0;
            OpenHSOrderReconciliationInfo hsReportVo = list.get(i);
            Row row = sheet.createRow(rows);//创建一行
            rows++;
            if (hsReportVo == null) {
                continue;
            }
            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getOrderId()); //惠商订单号

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getDistributorName()); //分销商名称

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getDealerName()); //经销商名称

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getDealerCode()); //经销商编号

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getBusinessNumber()); //商户号

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getSafeOrderCode()); //平安订单号

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getTransactionAmount()); //交易金额

            ExcelSAXHandler.setCellValue(firstCell++, row, DateUtil.formatDate(hsReportVo.getTransactionTime())); //交易时间

            ExcelSAXHandler.setCellValue(firstCell++, row, hsReportVo.getHandingFee()); //手续费
        }
        return rows;
    }

    /**
     * 查询待审批订单
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/getHuiShangApprovalPendingList", method = {RequestMethod.GET, RequestMethod.POST}, produces = "application/json; charset=UTF-8")
    public String getHuiShangApprovalPendingList(ToAuditOrderListParam request, HttpServletResponse response) {
        LOGGER.info("http open api getHuiShangApprovalPendingList ready go! request=[" + JsonUtil.toJson(request) + "]");
        RemoteResult remoteResult = new RemoteResult(false);
        if (request == null) {
            remoteResult.setResultCode(ResultCode.PARAMETER_ERROR);
            remoteResult.setResultMsg("请求参数有误");
            return JsonUtil.toJson(remoteResult);
        }
        if (CollectionUtils.isEmpty(request.getFaIds())) {
            remoteResult.setResultCode(ResultCode.TEMP);
            remoteResult.setResultMsg("没有分销商权限,请联系管理员");
            return JsonUtil.toJson(remoteResult);
        }
        try {
            PageQuery pageQuery = new PageQuery(request.getPageNum(), request.getPageSize());
            Map<String, Object> filterMap = request.getFilterMap() == null ? new HashedMap() : request.getFilterMap();
            List<String> faIds = request.getFaIds();
            String faId = (String) filterMap.get("faId");
            if (faIds.size() == 1 && StringUtils.isEmpty(faId)) {
                filterMap.put("faId", faIds.get(0));
            }
            filterMap.put("faIds", faIds);
            filterMap.put("notSubmitOrderWay",2);
            filterMap.put("auditStatus",2);
            remoteResult = openOrderManager.getMongoOrderList(pageQuery, filterMap, request.getTenant());
        } catch(Exception t) {
            LOGGER.error("getHuiShangApprovalPendingList error", t);
            remoteResult.setResultCode(ResultCode.EXCEPTION);
            remoteResult.setResultMsg("获取待审批订单列表失败");
        }
        LOGGER.info("http open api getHuiShangAuditList result: [" + JsonUtil.toJson(remoteResult) + "]");
        return JsonUtil.toJson(remoteResult);
    }

}
