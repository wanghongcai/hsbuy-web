package com.lenovo.m2.buy.promotion.admin.controller.api.integral;

/**
 * Created by admin on 2017/3/2.
 */
public class ResultCode {

    public static final String PARAMS_FAIL = "2001";//参数不正确

    public static final String FAIL = "8888";//系统异常

}
