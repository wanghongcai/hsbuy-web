package com.lenovo.m2.buy.promotion.admin.controller.api.inventory;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSONArray;
import com.google.common.base.Strings;
import com.lenovo.admin.extra.client.AdminClientUtils;
import com.lenovo.admin.extra.client.vo.DataTypeVo;
import com.lenovo.admin.extra.client.vo.DataVo;
import com.lenovo.admin.extra.client.vo.SystemDataVo;
import com.lenovo.auth.util.AuthUtil;
import com.lenovo.fileclient.PrivateSpcaceManager;
import com.lenovo.fileclient.UploadImageClient;
import com.lenovo.fileclient.common.UploadResponse;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.TimeConvertUtil;

import com.lenovo.m2.hsbuy.common.util.JacksonUtil;
import com.lenovo.m2.hsbuy.common.util.PropertiesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by mayan3 on 2015/3/23.
 */
@Controller
@Scope("prototype")
public class BaseController {
    private static final Logger LOGGER = LoggerFactory.getLogger(BaseController.class);


    //获取页码
    public int getPage(HttpServletRequest request) {
        String page = request.getParameter("page");
        if (page == null) {
            return 1;
        }
        return Integer.parseInt(page);
    }

    //获取每页显示行数
    public int getRowNum(HttpServletRequest request) {
        String rowNum = request.getParameter("rows");
        if (rowNum == null) {
            return 20;
        }
        return Integer.parseInt(rowNum);
    }
    public Tenant getTenant(HttpServletRequest request){
        Tenant tenant = new Tenant();
        tenant.setShopId(getShopId(request)==null?null:Integer.parseInt(getShopId(request)));
        tenant.setCurrencyCode("CNY");
        return tenant;
    }
    public String getShopId(HttpServletRequest request){
        String shopid =  request.getHeader("X-Request-ShopId");
        LOGGER.info("X-Request-ShopId :" + shopid);
        return shopid;
    }
/*---------------------------------------------------全球化新后台接口-------------------------------------------------------*/
    //获取登录用户itcode
    public String getGlobalItcode(){
        return AuthUtil.getUserId();
//        return "yezy2";
    }
    //获取用户拥有的租户id权限
    public JSONArray getTenantIds(){
        JSONArray temp = AuthUtil.getAuthShopIds();
        if (temp==null){
            return new JSONArray();
        }
//        JSONArray temp = new JSONArray();
//        temp.add("1");
        return temp;
    }
    //获取用户拥有的faid权限
    public JSONArray getGlobalFaIds(){
        JSONArray temp = AuthUtil.getJSONArray("faId");
        if (temp==null){
            return new JSONArray();
        }
//        JSONArray temp = new JSONArray();
//        temp.add("7ef1d628-5bd3-4651-9530-793678cc02af");
        return temp;
    }
    //获取用户拥有的BU权限
    public JSONArray getGlobalBuOwners(){
        JSONArray temp = AuthUtil.getJSONArray("buOwner");
        if (temp==null){
            return new JSONArray();
        }
        return temp;
    }
    //获取用户拥有的公司Id权限
    public JSONArray getGlobalCompanyIds(){
        JSONArray temp = AuthUtil.getJSONArray("CompanyID");
        if (temp==null){
            return new JSONArray();
        }
        return temp;
    }
    //获取用户拥有的仓库id权限
    public JSONArray getGlobalWarehouseIds(){
        JSONArray temp = AuthUtil.getJSONArray("storeId");
        if (temp==null){
            return new JSONArray();
        }
//        JSONArray temp = new JSONArray();
//        temp.add(2);
//        temp.add(5);
//        temp.add(6);
//        temp.add(7);
//        temp.add(10);
        return temp;
    }
    /**
     * 根据数据权限key获取权限信息
     * @param key
     * @return
     */
    public JSONArray getAuthDataMap(String key){
        JSONArray authDataMap = AuthUtil.getAuthDataMap(key);
        if (authDataMap==null){
            return new JSONArray();
        }
        return authDataMap;
    }
    //获取页码
    public int getGlobalPage(HttpServletRequest request) {
        String page = request.getParameter("pageNum");
        if (page == null) {
            return 1;
        }
        return Integer.parseInt(page);
    }

    //获取每页显示行数
    public int getGlobalRowNum(HttpServletRequest request) {
        String rowNum = request.getParameter("pageSize");
        if (rowNum == null) {
            return 20;
        }
        return Integer.parseInt(rowNum);
    }
    public static String toUtf8String(String s) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 0 && c <= 255) {
                sb.append(c);
            } else {
                byte[] b;
                try {
                    b = Character.toString(c).getBytes("utf-8");
                } catch (Exception ex) {
                    LOGGER.error(ex.getMessage(), ex);
                    b = new byte[0];
                }
                for (int j = 0; j < b.length; j++) {
                    int k = b[j];
                    if (k < 0) k += 256;
                    sb.append("%" + Integer.toHexString(k).toUpperCase());
                }
            }
        }
        return sb.toString();
    }
    public static String getDate(Date aDate) {
        SimpleDateFormat df;
        String returnValue = "";
        if (aDate != null) {
            df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            returnValue = df.format(aDate);
        }
        return returnValue;
    }
    //根据不同租户返回相应时区相应格式的时间字符串
    public static String getDate(Date aDate,String shopId) {
        if (StringUtils.isEmpty(shopId)){
            return getDate(aDate);
        }
        Tenant tenant = Tenant.getTenant(Integer.parseInt(shopId));
        return TimeConvertUtil.convertTime(tenant.getTimeZone(), tenant.getTimeFormat(), aDate);
    }
    public boolean isNull(Object... obj){
        return !isNotNull(obj);
    }

    public boolean isNotNull(Object... obj){
        if(obj != null){
            for (Object o : obj) {
                if(o == null){
                    return false;
                }
            }
        }else{
            return false;
        }
        return true;
    }
    public static String salesType(int type) {
        String res = "";
        switch (type) {
            case 0:
                res = "普通";
                break;
            case 96:
                res = "C2O";
                break;
            case 97:
                res = "众筹";
                break;
            case 98:
                res = "O2O";
                break;
        }
        return res;
    }
    public static String activityType(int type) {
        String res = "";
        switch (type) {
            case 0:
                res = "普通";
                break;
            case 1:
                res = "团购";
                break;
            case 2:
                res = "闪购";
                break;
            case 3:
                res = "限时抢购";
                break;
        }
        return res;
    }

    /**
     * 调用云存储客户端上传文件并生成下载链接
     * @param file 文件的byte数组
     * @param fileName 文件名 “/目录/文件名.xx”
     * @return
     */
    public String uploadFileToCloud(byte[] file,String fileName){
        try {
            long timeStamp = System.currentTimeMillis();
            String appId = PropertiesUtil.getProperty("stock.appId");
            String appKey = PropertiesUtil.getProperty("stock.appKey");
            String url = PropertiesUtil.getProperty("stock.url");
            String domain = PropertiesUtil.getProperty("stock.domain");
            String token = UploadImageClient.getToken(appId, appKey, timeStamp, fileName, "0");
            UploadResponse uploadResponse = UploadImageClient.upload(appId, token, timeStamp, url + fileName, file, fileName, "0");
            String readURL = PrivateSpcaceManager.getReadURL(appId, appKey, domain, uploadResponse.getFilename());
            LOGGER.info("UploadResponse:"+ JacksonUtil.toJson(uploadResponse));
            LOGGER.info("UploadResponse url:"+ url);
            if ("001".equals(uploadResponse.getStatus())&& StringUtils.isNotEmpty(readURL)){
                return readURL;
            }
        }catch (Exception e){
            LOGGER.error(e.getMessage(),e);
        }
        return null;
    }
}
