package com.lenovo.m2.buy.promotion.pay.alipay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.StringParse;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayNotify;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayUtil;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCwgManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.MerchantPayPlatManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

/**
 * 支付宝纯网关支付异步回调
 * Created by MengQiang on 2015/5/23.
 */
@Controller
@Scope("prototype")
public class AliCwgCallBackController {
    Logger logger = Logger.getLogger(this.getClass());
    @Autowired
    private PayOrderApi payOrderApi;

    @Autowired
    private MerchantPayPlatManager merchantPayPlatManager;

    @Autowired
    private AliPayCwgManager aliPayCwgManager;

    /**
     * <br>
     * 支付宝纯网关支付完成后的服务器异步通知
     *
     * @param request
     * @param response
     * @return </br>
     */
    @RequestMapping("/aliCwgPayNotice")
    public void aliCwgPayNotice(HttpServletRequest request, HttpServletResponse response) {
        Map<String, String> params;
        Map<?, ?> requestParams = request.getParameterMap();
        PrintWriter out = null;
        try {
            out = response.getWriter();
        } catch (IOException e) {
            logger.error("GET PRINTWRITER ERROR!",e);
        }
        params = AlipayUtil.parseRequestParams(requestParams);
        logger.warn("支付宝纯网关支付完成之后的服务器异步通知返回的数据：" + params);
        String orderPrimaryId = params.get("out_trade_no");//商户网站唯一订单号
        String trade_status = params.get("trade_status");//交易状态
        String gmt_payment = params.get("gmt_payment");//交易付款时间
        gmt_payment = gmt_payment.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
        String trade_no = params.get("trade_no");//支付宝交易号
        String notifyId = params.get("notify_id");
        String bankSeqNo = params.get("bank_seq_no");//纯网关银行交易流水
        String extra_common_param = params.get("extra_common_param");//支付上送需支付宝回传参数
        String outChannelType = params.get("out_channel_type");//支付渠道组合信息
        logger.info("纯网关支付渠道组合信息out_channel_type==>" + outChannelType);
        String outChannelAmount = params.get("out_channel_amount");
        logger.info("纯网关支付金额组合信息out_channel_amount==>" + outChannelAmount);
        if (orderPrimaryId == null) {
            logger.warn("获取支付宝反馈订单号为空!");
        }
        logger.info("支付宝纯网关支付订单唯一标识==>" + orderPrimaryId);
        Map sParaMap = null;
        try {
            sParaMap = AlipayUtil.parseCommonParam(extra_common_param);
        } catch (Exception e) {
            logger.error("解析支付宝反馈数据异常", e);
        }
        logger.info("解析支付上传需要回调数据：" + sParaMap);
        String faid = (String) sParaMap.get("faid");
        String payType = (String) sParaMap.get("payType");
        String lenovoId = (String) sParaMap.get("lenovoId");
        RemoteResult<MerchantPayPlatView> remoteResult = null;
        if (faid == null || payType == null) {
            logger.warn("faid 或者 payType 为空!");
        }
        remoteResult = merchantPayPlatManager.getMerchantPayPlatByMerchantId(faid, StringParse.parseInt(payType));
        MerchantPayPlatView merchantPayPlatView = null;
        if (remoteResult.isSuccess()) {
            merchantPayPlatView = remoteResult.getT();
            logger.info("查询支付平台信息：" + merchantPayPlatView);
        } else {
            logger.warn("查询MerchantPayPlatView结果为空");
        }

        boolean verify_result = false;
        try {
            //logger.info("异步回调测试数据，验签名Key：" + merchantPayPlatView.getSignKey());
            verify_result = AlipayNotify.verifyNotify(params, merchantPayPlatView.getSignKey(), merchantPayPlatView.getMechId());
        } catch (Exception e1) {
            logger.error("签名验证异常!订单号：" + orderPrimaryId + "  支付宝交易流水：" + trade_no ,e1);
        }
        if (verify_result) {// 验证成功
            // 判断结果
            if (trade_status.equals("TRADE_FINISHED")
                    || trade_status.equals("TRADE_SUCCESS")) {
                logger.info("支付宝纯网关支付反馈支付成功，订单号：" + orderPrimaryId);
                // 更新订单信息成功
                try {
                    RemoteResult<Map<String, Object>> result = aliPayCwgManager.callUpdate(lenovoId,orderPrimaryId, trade_no, gmt_payment, faid, payType, merchantPayPlatView,notifyId,bankSeqNo);
                    //payOrderApi.updateAliPayNotifyState(out_trade_no, lenovoId, trade_no, 1, notifyId, 1,bankSeqNo);
                    if(result.isSuccess()){
                        out.println("success");
                    }
                } catch (Exception ex) {
                    logger.error("支付宝纯网关支付反馈支付成功，更新订单或通知支付结果失败，订单号：" + orderPrimaryId, ex);
                    //payOrderApi.updateAliPayNotifyState(out_trade_no, lenovoId, trade_no, 3, notifyId, 2,bankSeqNo);
                }

            } else {
                logger.info("支付宝纯网关支付反馈支付失败，订单号：" + orderPrimaryId);
                //payOrderApi.updateAliPayNotifyState(out_trade_no, lenovoId, trade_no, 3, notifyId, 2,bankSeqNo);
            }
        } else {
            //支付宝反馈结果验证签名失败
            logger.info("支付宝纯网关支付反馈MD5签名验签失败，订单号：" + orderPrimaryId);
            //payOrderApi.updateAliPayNotifyState(out_trade_no, lenovoId, trade_no, 3, notifyId, 2,bankSeqNo);
        }
    }

    public PayOrderApi getPayOrderApi() {
        return payOrderApi;
    }

    public void setPayOrderApi(PayOrderApi payOrderApi) {
        this.payOrderApi = payOrderApi;
    }

    public MerchantPayPlatManager getMerchantPayPlatManager() {
        return merchantPayPlatManager;
    }

    public void setMerchantPayPlatManager(MerchantPayPlatManager merchantPayPlatManager) {
        this.merchantPayPlatManager = merchantPayPlatManager;
    }

    public AliPayCwgManager getAliPayCwgManager() {
        return aliPayCwgManager;
    }

    public void setAliPayCwgManager(AliPayCwgManager aliPayCwgManager) {
        this.aliPayCwgManager = aliPayCwgManager;
    }
}
