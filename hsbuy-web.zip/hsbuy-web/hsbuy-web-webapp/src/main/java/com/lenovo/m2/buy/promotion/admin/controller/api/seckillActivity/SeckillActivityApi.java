package com.lenovo.m2.buy.promotion.admin.controller.api.seckillActivity;


import com.lenovo.fileclient.PrivateSpcaceManager;
import com.lenovo.fileclient.UploadImageClient;
import com.lenovo.fileclient.common.UploadResponse;
import com.lenovo.m2.arch.framework.domain.*;
import com.lenovo.m2.arch.tool.util.DateFormatUtils;
import com.lenovo.m2.buy.promotion.admin.controller.util.ExcelBean;
import com.lenovo.m2.buy.promotion.admin.controller.util.ExcelUpLoad;
import com.lenovo.m2.buy.promotion.admin.controller.util.ExcelUtil;
import com.lenovo.m2.buy.promotion.admin.controller.util.ThreadLocalObjs;
import com.lenovo.m2.buy.promotion.admin.domain.AuthData;
import com.lenovo.m2.buy.promotion.admin.domain.promotion.*;
import com.lenovo.m2.buy.promotion.admin.domain.web.ProductsPageQueryVO;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.*;
import com.lenovo.m2.buy.promotion.admin.soa.api.service.PromotionAdminRead;
import com.lenovo.m2.buy.promotion.admin.soa.api.service.PromotionAdminWrite;
import com.lenovo.m2.buy.promotion.admin.soa.api.service.SeckillActivityService;
import com.lenovo.m2.buy.promotion.admin.soa.enums.GloablErrorMessageEnum;
import com.lenovo.m2.buy.promotion.admin.soa.utils.BaseInfo;
import com.lenovo.m2.buy.promotion.admin.soa.utils.DateUtils;
import com.lenovo.m2.buy.promotion.admin.soa.utils.JsonUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.xssf.usermodel.*;
import org.mortbay.log.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.sql.Timestamp;
import java.util.*;

/**
 * @desc 提供给开放平台的api
 * Created by lihc5 on 2017-05-11.
 */
@Controller
@RequestMapping("/api/seckillActivity")
public class SeckillActivityApi {

    private static final String appId = "promotion";
    private static final String appKey = "yyPpuhmkbTR0TxD4";
    private static final String domain = "promotion.app.lefile.cn";
    private static String targetSeckillActivityReservationFilePath = "/seckillActivityReservation/";
    private static final String imageServerURL = "http://internal-up.lefile.cn/image/upload";

    // 限时折扣预约信息查看导出excel的title
     static String[] excelHeader = {"会员账号", "LenovoID", "手机号","商城","终端","预约时间"};

    @Autowired
    private PromotionAdminRead promotionAdminRead;
    @Autowired
    private PromotionAdminWrite promotionAdminWrite;
    @Autowired
    private SeckillActivityService seckillActivityService;

    private static Logger log = LoggerFactory.getLogger(SeckillActivityApi.class);

    /**
     * @desc 查询限时折扣列表
     * @author lihc5
     * @param request
     * @return
     */
     @RequestMapping("/list")   //testList
     @ResponseBody
     public RemoteResult seckillActivityList(SeckillActivityListQry request,HttpServletRequest servletRequest){
        log.info("request={}",request.toString());
         AuthData authData = ThreadLocalObjs.getAuthData();
         Tenant tenant = ThreadLocalObjs.getTenant();

         List<String> shopIds = authData.getShopIds();
         List<String> faIds = authData.getFaIds();

         Map<String,Object> map = request.toMap();
         map.put("shopIds",shopIds);
         map.put("faIds",faIds);
//         if(tenant != null && tenant.getShopId() != null){
//        	 map.put("shopId", tenant.getShopId());
//         } 
         map.put("shopId", tenant.getShopId());
         RemoteResult rr = new RemoteResult(false);
         try{
             PageQuery pq = new PageQuery(request.getPageNum(), request.getPageSize());
             RemoteResult<PageModel2<SeckillActivity>> list = new RemoteResult<>();
             list = seckillActivityService.getSeckillActivityList(tenant, pq, map);
             return list;
         }catch(Exception e){
             log.error("api getSeckillActivityList ERROR", e);
             rr.setSuccess(false);
             rr.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
             rr.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
             return rr;
         }
     }

    /**
     * @desc 添加限时折扣规则
     * @author lihc5
     * @param
     * @param
     * @return
     */
    @RequestMapping(value = "/add.jhtm", produces = "application/json; charset=UTF-8")
    @ResponseBody
    public RemoteResult addSeckillActivity(SeckillActivityForm seckillActivityForm){
        log.info("seckillActivityForm={}",JsonUtil.toJson(seckillActivityForm));
        //{"id":null,"activityName":"测试限时抢购512","activityType":2,"isReservation":0,"seckillStartTime":"2017-05-12 10:00:00","seckillEndTime":"2017-05-14 10:00:00","code":null,"name":null,"materialNumber":null,"faName":null,"thumbnail":null,"seckillMoney":0.0,"maxNum":0,"addDiscountCount":0,"reservationStartTime":null,"reservationEndTime":null,"noReservationSeckillStartTime":null,"terminal":0,"markeTable":0,"page":null,"rows":null,"productsStr":"[{\"id\":\"13c6ee5a-8cf8-4601-9890-154a93313a59\",\"gcode\":\"59878\",\"name\":\"测试商品1\",\"thumbnail\":\"/product/adminweb/2017/03/24/tVkxJgqIHvs2B5e9twMSU2HOb-3914.jpg\",\"faid\":\"2db66116-0cfc-4cbf-adbe-313d89d688b5\",\"faName\":null,\"mallType\":null,\"saleType\":null,\"addDiscountCount\":0,\"purchaseceiling\":\"1\",\"seckillMoney\":\"100.00\"}]"}
        RemoteResult  remoteResult = new RemoteResult(false);
        Tenant tenant = ThreadLocalObjs.getTenant();   //租户
        AuthData authData = ThreadLocalObjs.getAuthData();  //


        remoteResult = seckillActivityForm.check();

        if(!remoteResult.isSuccess()){
            return remoteResult;
        }

        //商品分页 对象							// 数据 组装 
        SeckillActivity seckillActivity = transfer(tenant, seckillActivityForm);

        if(seckillActivity == null){ //校验开始时间是否大于结束时间   //活动 时间  不能设置  小于  开始 时间
            log.info("param roles null or plrase check param time");
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("请检查时间日期参数");
            remoteResult.setSuccess(false);
            return  remoteResult;
        }
        //sessionUser
        SessionUser user = ThreadLocalObjs.getUser();

        //组装商品数据
        String productsStr = seckillActivityForm.getProductsStr();
        List<SeckillGoods> praList = JsonUtil.readValuesAsArrayList(productsStr, SeckillGoods.class);
        for(SeckillGoods goods: praList){
            goods.setGoodscode(goods.getGcode());
            goods.setGoodsname(goods.getName());
            goods.setCreateby(authData.getUserid());
        }

        try{
            remoteResult = seckillActivityService.saveOrUpdateSeckillActivity(tenant, user.getItcode(), seckillActivity, praList);
        }catch (Exception e){
            log.error("addSeckillActivity error", e);
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
            remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
            remoteResult.setSuccess(false);
            return  remoteResult;
        }
        return  remoteResult;
    }



    /**
     * @desc 提交修改的限时折扣规则
     * @author lihc5
     * @param seckillActivityForm
     * @return
     */
    @RequestMapping("/update")   //testUpdate
    @ResponseBody
    public RemoteResult saveSeckillActivity(SeckillActivityForm seckillActivityForm){
        log.info("saveSeckillActivity seckillActivityForm={}",JsonUtil.toJson(seckillActivityForm));
        RemoteResult remoteResult = new RemoteResult(false);

        remoteResult = seckillActivityForm.check();

        if(!remoteResult.isSuccess()){
            return remoteResult;
        }

        Tenant tenant = ThreadLocalObjs.getTenant();  //租户基础信息
        AuthData authData = ThreadLocalObjs.getAuthData();    //
        SeckillActivity seckillActivity = transfer(tenant, seckillActivityForm);//拼数据

        if(seckillActivity == null){ //校验开始时间是否大于结束时间
            log.info("param roles null,please check fromTime Greater than toTime");
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
            remoteResult.setSuccess(false);
            return  remoteResult;
        }

        //组装商品数据
        String productsStr = seckillActivityForm.getProductsStr();
        List<SeckillGoods> praList = JsonUtil.readValuesAsArrayList(productsStr, SeckillGoods.class);
        for(SeckillGoods goods: praList){
            goods.setGoodscode(goods.getGcode());
            goods.setGoodsname(goods.getName());
            goods.setCreateby(authData.getUserid());
        }

        SessionUser user = ThreadLocalObjs.getUser();
        try{								 
            remoteResult = seckillActivityService.saveOrUpdateSeckillActivity(tenant, user.getItcode(), seckillActivity, praList);
            
        }catch (Exception e){
            log.error("updateSeckillActivity Error", e);
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
            remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
            remoteResult.setSuccess(false);
        }
        return  remoteResult;
    }

    /**
     * @desc 查询单条的限时折扣信息
     * @author lihc5
     * @param id
     * @return
     */
    @RequestMapping("/get")    //testGet
    @ResponseBody
    public String getSeckillActivity(String id){
        RemoteResult remoteResult = new RemoteResult(false);
        if(id == null){
            log.info("param id null");
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
            return  JsonUtil.toJson(remoteResult);
        }
        Map<String,Object> resultMap = new HashMap<>();
        Tenant tenant = ThreadLocalObjs.getTenant();
        log.info("tenant shopId={}", tenant.getShopId());
        try{
            resultMap = promotionAdminRead.getSeckillActivity(tenant, Integer.valueOf(id));
            remoteResult.setSuccess(true);
            remoteResult.setResultCode("0");
            remoteResult.setT(resultMap);
        }catch (Exception e){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
            remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
        }
        return JsonUtil.toJson(remoteResult);
    }


    /**
     * @desc 查询限时折扣商品信息
     * @author lihc5
     * @param id
     * @return
     */
    @RequestMapping("/getGoods")
    @ResponseBody
    public String getGoods(String id){
        RemoteResult remoteResult = new RemoteResult(false);
        if(id == null){
            log.info("param id null");
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
            return  JsonUtil.toJson(remoteResult);
        }
        Tenant tenant = ThreadLocalObjs.getTenant();
        log.info("tenant shopId={}", tenant.getShopId());
        try{								//这个 只能 根据 id 查 seckillgoods表 
            List<SeckillGoods> resultList = promotionAdminRead.getGoodsBySeckillId(tenant, Integer.valueOf(id));
            remoteResult.setSuccess(true);
            remoteResult.setResultCode("0");
            remoteResult.setT(resultList);
        }catch (Exception e){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
            remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
        }
        return JsonUtil.toJson(remoteResult);
    }

    /**
     * @desc 删除限时折扣
     * @author lihc5
     * @param ids
     * @return
     */
    @RequestMapping("/delete")
    @ResponseBody
    public RemoteResult delSeckillActivity(String ids){
        RemoteResult result = new RemoteResult(false);

        AuthData authData = ThreadLocalObjs.getAuthData();

        String userId = authData.getUserid();

        if(StringUtils.isEmpty(ids) || StringUtils.isEmpty(userId)){
            result.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            result.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
            return result;
        }

        String[] idarr = ids.split(",");
        if(idarr.length <= 0){
            log.error("idarr={}", idarr);
            result.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            result.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
            return result;
        }

        Integer[] activityIds = new Integer[idarr.length];
        for(int i=0; i < idarr.length; i++){
            activityIds[i] = Integer.parseInt(idarr[i]);
        }

        try {
            BaseInfo ret = seckillActivityService.deletedDiscount(activityIds, userId);
            result.setT(ret.getMsg());
            result.setResultMsg(ret.getMsg());
            if (ret.getMsg() =="操作成功") {
                result.setResultCode("0");
                result.setSuccess(true);
            }else {
                result.setResultCode("1");
                result.setSuccess(false);
            }
           
            return result;
        } catch (Exception e) {
            log.error("deleteSeckillActivity Error", e);
            result.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
            result.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
            result.setSuccess(false);
            return result;
        }
    }

    /**
     * @desc 限时折扣停用/启用
     * @param ids
     * @param status
     * @return
     */
    @RequestMapping("/condition")
    @ResponseBody
    public RemoteResult condition(String ids, int status){
        RemoteResult remoteResult = new RemoteResult(false);
        if(StringUtils.isEmpty(String.valueOf(status))){
            log.error("status={}", status);
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
            return remoteResult;
        }

        String[] idarr = ids.split(",");
        if(idarr.length <= 0){
            log.error("idarr={}", idarr);
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
            return remoteResult;
        }

        Integer[] activityIds = new Integer[idarr.length];

        for(int i=0; i < idarr.length; i++){
            activityIds[i] = Integer.parseInt(idarr[i]);
        }

        Tenant tenant = ThreadLocalObjs.getTenant();
        AuthData authData = ThreadLocalObjs.getAuthData();
        String userId = authData.getUserid();
        BaseInfo baseInfo = new BaseInfo();
        try {
            if(status == 0){  //停用
                baseInfo = seckillActivityService.shiftOnOrOff(tenant, activityIds, false, userId);
            } else {    //启用
                baseInfo = seckillActivityService.shiftOnOrOff(tenant, activityIds, true, userId);
            }
            remoteResult.setResultCode(String.valueOf(baseInfo.getRc()));
            remoteResult.setResultMsg(baseInfo.getMsg());
            remoteResult.setSuccess(true);
        } catch (Exception e) {
            log.error("seckillActivity Condition Error-->", e);
            remoteResult.setResultCode(baseInfo.failed() + "");
            remoteResult.setResultMsg(baseInfo.getMsg());
            remoteResult.setSuccess(false);
        }
        return remoteResult;
    }

    /**
     * @desc 跳转到预约信息
     * @author lihc5
     * @param request
     * @return
     */
    @RequestMapping("/listSeckillActivityReservation")
    @ResponseBody
    public String listSeckillActivityReservation(ReservationQry request){
        RemoteResult remoteResult = new RemoteResult(false);

        String id = request.getId(); 
        String goodsCode = request.getGoodsCode(); //dingdan

        Tenant tenant = ThreadLocalObjs.getTenant();
        log.info("tenant shopId={}", tenant.getShopId());

        AuthData authData = ThreadLocalObjs.getAuthData();
        List<String> shopIds = authData.getShopIds();
        List<String> faIds = authData.getFaIds();
        
        try{																						
            PageModel2<Seckillreservation> resultList = seckillActivityService.getSeckillActivityReservationList(id, goodsCode, request.getPageNum(), request.getPageSize(), shopIds, faIds);
            remoteResult.setSuccess(true);
            remoteResult.setResultCode("0");
            remoteResult.setT(resultList);
        }catch (Exception e){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
            remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
            remoteResult.setSuccess(false);
        }
        return JsonUtil.toJson(remoteResult);
    }


    /**
     * 预约报表   改
     * @param request
     * @param response
     * @return
     */
    @RequestMapping("/downReservationExcel")
    @ResponseBody			//报表 导出
    public RemoteResult downReservationExcel(HttpServletRequest request, HttpServletResponse response) {
        RemoteResult remoteResult = new RemoteResult();
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        String readURL = null;
        try {
            // 产生工作簿对象
            String id = request.getParameter("id");
            String goodsCode = request.getParameter("goodsCode");

            SessionUser user = ThreadLocalObjs.getUser();
            List<String> shopIds = user.getShopIds();
            List<String> faIds = user.getFas();

            //封装查询参数
            RemoteResult<List<Seckillreservation>> re = seckillActivityService.getdownSeckillactivityReservationExcel(id, shopIds, faIds, goodsCode);
            Log.info("re.length = {}",re.getT().size());
            if (re != null && re.getT().size() > 0) {
            	
            	Map<String, ExcelBean> tmpMap = buildData();
            	// new 一个工具类
				ExcelUtil<Seckillreservation> excel = new ExcelUtil<>(Seckillreservation.class, tmpMap);
				// excel表
				XSSFWorkbook exportExcel = excel.exportExcel(re.getT(), "限时折扣预约信息查看");
				
				Log.info("excel表生成成功 ！");
				String fileName = "seckillActivityReservation.xlsx";

				ExcelUpLoad load = new ExcelUpLoad(fileName, appId, appKey, targetSeckillActivityReservationFilePath,
						imageServerURL, domain);
				readURL = load.getExcelUrl(exportExcel);
            }

        } catch (Exception e) {
            log.error("getdownSeckillactivityReservationExcel error",e);
        }
        remoteResult.setSuccess(true);
        remoteResult.setResultCode("0");
        remoteResult.setResultMsg("操作成功");
        remoteResult.setT(readURL);
        return remoteResult;
    }

    //预售报表  字段 规则
    private Map<String, ExcelBean> buildData() {
    	Map<String, ExcelBean> tmpMap = new HashMap<>();
    	
    	ExcelBean bean1 = new ExcelBean();
		bean1.setName(excelHeader[0]);
		bean1.setOrder(1);
		tmpMap.put("membercode", bean1);
    	
		ExcelBean bean2 = new ExcelBean();
		bean2.setName(excelHeader[1]);
		bean2.setOrder(2);
		tmpMap.put("lenovoid", bean2);
		
		ExcelBean bean3 = new ExcelBean();
		bean3.setName(excelHeader[2]);
		bean3.setOrder(3);
		tmpMap.put("phone", bean3);
		
		ExcelBean bean4 = new ExcelBean();
		bean4.setName(excelHeader[3]);
		bean4.setOrder(4);
		bean4.setIsMapper(1);
		bean4.setMapper(isShopIDView());
		bean4.setIsDefault("未找到对应商城");   	//默认
		tmpMap.put("shopid", bean4);
		
		ExcelBean bean5 = new ExcelBean();
		bean5.setName(excelHeader[4]);
		bean5.setOrder(5);
		bean5.setIsMapper(1);
		bean5.setMapper(isTerminalView());
		bean5.setIsDefault("无终端");
		tmpMap.put("terminal", bean5);
		
		ExcelBean bean6 = new ExcelBean();
		bean6.setName(excelHeader[5]);
		bean6.setOrder(6);
		tmpMap.put("reservationTime", bean6);
		return tmpMap;
	}

	private Map<String, Object> isTerminalView() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("1", "PC");
		map.put("2", "WAP");
		map.put("3", "APP");
		map.put("4", "微信");
		return map;
	}

	private Map<String, Object> isShopIDView() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("1", "联想商城");
		map.put("2", "Think商城");
		map.put("4", "Roaming商城");
		map.put("5", "MOTO商城");
		map.put("6", "懂的商城");
		map.put("7", "Think产品中心");
		map.put("8", "17商城");
		map.put("9", "17积分商城");
		return map;
	}

	/**
     * 封装excel数据
     *
     * @param sheet
     */			
    private void buildData(XSSFSheet sheet, List<Seckillreservation> list, int rows) {
        for (int i = 0; i < list.size(); i++) {
            Seckillreservation seckillreservation = list.get(i);

            XSSFRow row = sheet.createRow((int) i + rows);//创建一行
            XSSFCell cell = row.createCell((int) 0);//创建一列
            cell.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell.setCellValue(seckillreservation.getMembercode());

            XSSFCell cell1 = row.createCell((int) 1);//创建一列
            cell1.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell1.setCellValue(seckillreservation.getLenovoid());

            XSSFCell cell2 = row.createCell((int) 2);//创建一列
            cell2.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell2.setCellValue(seckillreservation.getPhone());

            XSSFCell cell3 = row.createCell((int) 3);//创建一列
            cell3.setCellType(HSSFCell.CELL_TYPE_STRING);
            if(seckillreservation.getShopid() == 1) {
                cell3.setCellValue("联想商城");
            }else if (seckillreservation.getShopid() == 2){
                cell3.setCellValue("Think商城");
            }else if (seckillreservation.getShopid() == 3){
                cell3.setCellValue("EPP商城");
            }else if (seckillreservation.getShopid() == 4){
                cell3.setCellValue("虚拟商城");
            } else{
                cell3.setCellValue("无商城");
            }

            XSSFCell cell4 = row.createCell((int) 4);//创建一列
            cell4.setCellType(HSSFCell.CELL_TYPE_STRING);
            if(seckillreservation.getTerminal() == 1) {
                cell4.setCellValue("PC");
            }else if (seckillreservation.getTerminal() == 2){
                cell4.setCellValue("WAP");
            }else if (seckillreservation.getTerminal() == 3){
                cell4.setCellValue("APP");
            }else if (seckillreservation.getTerminal() == 4){
                cell4.setCellValue("微信");
            } else{
                cell4.setCellValue("无终端");
            }

            XSSFCell cell5 = row.createCell((int) 5);//创建一列
            cell5.setCellType(HSSFCell.CELL_TYPE_STRING);
            if(seckillreservation.getReservationTime() != null){
                cell5.setCellValue(DateFormatUtils.format(seckillreservation.getReservationTime()));
            }
        }
    }

    									//终端  		 权限 			 活动
    public ProductsPageQueryVO transfer(Tenant tenant, AuthData authData, SeckillActivityForm seckillActivityForm){
        if(seckillActivityForm == null){
            return  null;
        }

        ProductsPageQueryVO productsPageQueryVO = new ProductsPageQueryVO();

        if (null != seckillActivityForm.getId()){
            productsPageQueryVO.setSeckillId(seckillActivityForm.getId());
        }
        		//时间
        productsPageQueryVO.setSeckillStartTime(DateUtils.getFormatDate(seckillActivityForm.getSeckillStartTime(), "yyyy-MM-dd HH:mm:ss"));
        productsPageQueryVO.setSeckillEndTime(DateUtils.getFormatDate(seckillActivityForm.getSeckillEndTime(), "yyyy-MM-dd HH:mm:ss"));

        if(null == productsPageQueryVO.getSeckillStartTime()){
            return null;
        }
        if(null == productsPageQueryVO.getSeckillEndTime()){
            return null;
        }
        if(productsPageQueryVO.getSeckillStartTime().after(productsPageQueryVO.getSeckillEndTime())){  // 校验开始时间是否大于结束时间
            return null;
        }
        			//名字  类型
        productsPageQueryVO.setActivityName(seckillActivityForm.getActivityName());
        productsPageQueryVO.setActivityType(seckillActivityForm.getActivityType() == 2 ? 2 : 3);  //2:闪购 3:限时抢购
        productsPageQueryVO.setIsReservation(seckillActivityForm.getIsReservation());
        if(StringUtils.isNotEmpty(seckillActivityForm.getReservationStartTime())) {
            productsPageQueryVO.setReservationStartTime(Timestamp.valueOf(seckillActivityForm.getReservationStartTime()));
        }
        if(StringUtils.isNotEmpty(seckillActivityForm.getReservationEndTime())) {
            productsPageQueryVO.setReservationEndTime(Timestamp.valueOf(seckillActivityForm.getReservationEndTime()));
        }
        if(StringUtils.isNotEmpty(seckillActivityForm.getNoReservationSeckillStartTime())) {
            productsPageQueryVO.setNoReservationSeckillStartTime(Timestamp.valueOf(seckillActivityForm.getNoReservationSeckillStartTime()));
        }
        productsPageQueryVO.setTerminal(seckillActivityForm.getTerminal());//终端
        productsPageQueryVO.setShopType(String.valueOf(tenant.getShopId())); //类型
        productsPageQueryVO.setMarkeTable(seckillActivityForm.getMarkeTable());  //是否启用
        return productsPageQueryVO;
    }


    private SeckillActivity transfer(Tenant tenant, SeckillActivityForm seckillActivityForm){
        if(seckillActivityForm == null){
            return  null;
        }

        SeckillActivity productsPageQueryVO = new SeckillActivity();

        if (null != seckillActivityForm.getId()){
            productsPageQueryVO.setId(seckillActivityForm.getId());
        }
        //时间
        productsPageQueryVO.setSeckillstarttime(DateUtils.getFormatDate(seckillActivityForm.getSeckillStartTime(), "yyyy-MM-dd HH:mm:ss"));
        productsPageQueryVO.setSeckillendtime(DateUtils.getFormatDate(seckillActivityForm.getSeckillEndTime(), "yyyy-MM-dd HH:mm:ss"));

        if(null == productsPageQueryVO.getSeckillstarttime()){
            return null;
        }
        if(null == productsPageQueryVO.getSeckillendtime()){
            return null;
        }
        if(productsPageQueryVO.getSeckillstarttime().after(productsPageQueryVO.getSeckillendtime())){  // 校验开始时间是否大于结束时间
            return null;
        }
        //名字  类型
        productsPageQueryVO.setActivityname(seckillActivityForm.getActivityName());
        productsPageQueryVO.setActivityType(seckillActivityForm.getActivityType() == 2 ? 2 : 3);  //2:闪购 3:限时抢购
        productsPageQueryVO.setIsreservation(seckillActivityForm.getIsReservation().byteValue());
        if(StringUtils.isNotEmpty(seckillActivityForm.getReservationStartTime())) {
            productsPageQueryVO.setReservationstarttime(Timestamp.valueOf(seckillActivityForm.getReservationStartTime()));
        }
        if(StringUtils.isNotEmpty(seckillActivityForm.getReservationEndTime())) {
            productsPageQueryVO.setReservationendtime(Timestamp.valueOf(seckillActivityForm.getReservationEndTime()));
        }
        if(StringUtils.isNotEmpty(seckillActivityForm.getNoReservationSeckillStartTime())) {
            productsPageQueryVO.setNoreservationseckillstarttime(Timestamp.valueOf(seckillActivityForm.getNoReservationSeckillStartTime()));
        }
        productsPageQueryVO.setTerminal(seckillActivityForm.getTerminal());//终端
        productsPageQueryVO.setShopId(tenant.getShopId()); //类型
        productsPageQueryVO.setMarketable(seckillActivityForm.getMarkeTable());  //是否启用

        productsPageQueryVO.setTerminal(seckillActivityForm.getTerminal());
        return productsPageQueryVO;
    }


}
