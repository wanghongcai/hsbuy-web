package com.lenovo.m2.buy.promotion.pay.orderfront;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.buy.promotion.admin.common.pay.orderfront.util.PayConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.orderfront.util.PaySubmit;
import com.lenovo.m2.buy.promotion.admin.common.pay.orderfront.util.SignUtil;
import com.lenovo.m2.buy.promotion.admin.domain.pay.orderfront.ReturnResult;
import com.lenovo.m2.buy.promotion.admin.remote.pay.orderfront.ToPayRemote;
import com.lenovo.m2.hsbuy.domain.order.Deliveries;
import com.lenovo.m2.hsbuy.domain.order.mongo.OrderFewInfo;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.baseInfo.OrderVo;
import com.lenovo.m2.hsbuy.middleware.OrderMiddlewareService;
import com.lenovo.m2.hsbuy.service.pay.ordersoa.ChannelPayCenterService;
import com.lenovo.ucenter.sso.client.util.SSOUserInfoUtil;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lijie on 2016/8/16.
 */
@Controller
@Scope("prototype")
public class ToPayController {

    private static Logger logger = Logger.getLogger(ToPayController.class);
    private static String URL = "toCashier.jhtm";
    @Autowired
    private ChannelPayCenterService payMainService;
    @Autowired
    private ToPayRemote toPayRemote;
    @Autowired
    private OrderMiddlewareService orderMiddlewareService;

    @RequestMapping("order/toPay")
    public String toPay(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {
        ReturnResult<String> returnResult = new ReturnResult<String>();
        long payTimeS = System.currentTimeMillis();
        String terminal = request.getParameter("terminal");
        String shopId = request.getParameter("shopId");
        String orderStr = request.getParameter("orderMainCode");
        String lenovoId = SSOUserInfoUtil.getLenovoId(request);
        logger.info("ToPayController toPay orderStr=" + orderStr+",shopId="+ shopId+",terminal="+ terminal+",lenovoId="+lenovoId);
        if(StringUtils.isEmpty(lenovoId)){
            logger.info("登录错误:" + orderStr);
            returnResult.setCode("80");
            returnResult.setData("支付异常，用户未登录！");
            map.put("rs", returnResult);
            return "pay/to_pay";
        }
        if (StringUtils.isEmpty(terminal) || StringUtils.isEmpty(shopId) || StringUtils.isEmpty(orderStr)) {
            logger.info("参数错误:" + orderStr);
            returnResult.setCode("90");
            returnResult.setData("支付异常，请重新发起支付！");
            map.put("rs", returnResult);
            return "pay/to_pay";
        }
        logger.info("获取参数："+orderStr);
        Map<String, String> paramMap = new LinkedHashMap<String, String>();
//        String urlIndex = toPayRemote.getPayUrl(shopId).getT();
        paramMap.put("service", PayConstant.PAY_SERVICE_NAME);
        paramMap.put("shop_id", shopId);
        paramMap.put("terminal", terminal);
        paramMap.put("notify_url", "");
        paramMap.put("return_url", "");
        paramMap.put("input_charset", PayConstant.INPUT_CHARSET);
        String[] orderS = orderStr.split(",");
        List<String> orderCodeList=new ArrayList<String>();
        for(String o1:orderS){
            orderCodeList.add(o1);
        }
        logger.info("获取订单数据开始");
        int flag = 1;
        long startTime = System.currentTimeMillis();
        RemoteResult<List<OrderVo>> rs = null;
        try {
            rs= payMainService.queryOrderMainDetail(orderCodeList,shopId,terminal,lenovoId);
            logger.info("payMainService.queryOrderMainDetail rs="+rs.getT());
            while (flag < 11 && (null == rs || !rs.isSuccess() || null == rs.getT())) {
                logger.info(orderStr + "Invoke queryChannelOrderCodeDetail ,ReTry Time -->" + flag);
                Thread.sleep(100);
                rs = payMainService.queryOrderMainDetail(orderCodeList,shopId,terminal,lenovoId);
                flag++;
            }
        } catch (Exception e) {
            returnResult.setCode("100");
            returnResult.setData("查询订单异常，请重新发起支付！");
            map.put("rs", returnResult);
            logger.info("Invoke queryChannelOrderCodeDetail Exception", e);
            return "pay/to_pay";
        }
        long endTime = System.currentTimeMillis();
        logger.info("获取订单数据结束,耗时："+(endTime-startTime)+"ms");
        List<OrderVo> orderList =null;
        List orderArray = new ArrayList();
        if (rs.isSuccess() && null != rs.getT() && rs.getT().size() > 0) {
            orderList = rs.getT();
            logger.info("组装订单，进行发票和地址信息查询");
            for (OrderVo vo : orderList) {
                orderArray.add(vo.getOrderCode());
            }
            logger.info("开始查询》》》");
            StringBuilder sb = new StringBuilder();
            startTime = System.currentTimeMillis();
            RemoteResult<Map<String, Object>> orderRs = null;
            boolean isOk=false;
            try {
                Tenant tenant=new Tenant();
                tenant.setShopId(Integer.parseInt(shopId.trim()));
                logger.info("获取收货地址信息请求shopId[" + tenant.getShopId() + "],lenovoId[" + lenovoId + "],orderCode[" + orderArray.get(0)+ "]");
                //TODO
                orderRs = orderMiddlewareService.receiveAddress(lenovoId, orderArray, tenant);
                logger.info("获取收货地址信息请求orderRs"+orderRs.getT());
                isOk=true;
            } catch (Exception e) {
                logger.info("Invoke receiveAddress Exception", e);
            }
            endTime = System.currentTimeMillis();
            logger.info("获取发票信息结束,耗时："+(endTime-startTime)+"ms");
                     Map addressMap =null;
                     if(isOk){
                         addressMap= orderRs.getT();
                     }
                try {
                    logger.info("查询完毕，开始组织订单完整数据");
                    for (OrderVo vo : orderList) {
                        if(isOk){
                            OrderFewInfo orderFewInfo = (OrderFewInfo) addressMap.get(vo.getOrderCode());
                            Deliveries deliveries = orderFewInfo.getDeliveries().get(0);
                            StringBuffer tempBuffer = new StringBuffer();
                            if (StringUtils.isNotEmpty(deliveries.getDeliverAreaName())) {
                                tempBuffer.append(deliveries.getDeliverAreaName() + "_");
                            }
                            if (StringUtils.isNotEmpty(deliveries.getShipCity())) {
                                tempBuffer.append(deliveries.getShipCity() + "_");
                            }
                            if (StringUtils.isNotEmpty(deliveries.getDeliverCounty())) {
                                tempBuffer.append(deliveries.getDeliverCounty() + "_");
                            }
                            if (StringUtils.isNotEmpty(deliveries.getShipAddr())) {
                                tempBuffer.append(deliveries.getShipAddr());
                            }
                            vo.setReceiveAddress(tempBuffer.toString());
                            if (StringUtils.isNotEmpty(deliveries.getShipName()) && null != deliveries.getShipName()) {
                                vo.setReceiveBuyer(deliveries.getShipName());
                            } else {
                                vo.setReceiveBuyer("");
                            }
                            if (StringUtils.isNotEmpty(deliveries.getShipMobile()) && null != deliveries.getShipMobile()) {
                                vo.setReceivePhone(deliveries.getShipMobile());
                            } else {
                                vo.setReceivePhone("");
                            }

                            if(shopId.equals(PayConstant.SHOPID_SMB)){
                                //smb订单 TODO
                                Deliveries taxDeliveries = orderFewInfo.getVatDeliveries().get(0);
                                vo.setTaxReceiveAddress(taxDeliveries.getShipAddr());
                                vo.setTaxReceiveBuyer(taxDeliveries.getShipName());
                                vo.setTaxReceivePhone(taxDeliveries.getShipMobile());
                            }
                            vo.setReceiveBuyer(deliveries.getShipName());
                            vo.setTaxInfo(orderFewInfo.getTaxCompany());
                            vo.setTaxType(orderFewInfo.getTaxType());
                        }
                        sb.append(vo.toString() + "&-&");
                    }
                    String tradeInfo = sb.toString().substring(0, sb.length() - 3);
                    String encodeInfo = null;
                    encodeInfo = URLEncoder.encode(tradeInfo, "UTF-8");
                    paramMap.put("payment_type", orderList.get(0).getPaymentType());
                    paramMap.put("currency_code",orderList.get(0).getCurrencyCode());
                    paramMap.put("trade_info", encodeInfo);
                    String signStr = SignUtil.getSign(paramMap, PayConstant.SIGN_KEY);
                    paramMap.put("sign_type", PayConstant.SIGN_TYPE);
                    paramMap.put("sign", signStr);
                    String returnStr = PaySubmit.buildRequest(paramMap, URL, "post", "自动提交");
                    returnResult.setCode("0");
                    returnResult.setMsg("success");
                    returnResult.setData(returnStr);
                    map.put("rs", returnResult);
                    logger.info("组织数据完毕："+returnResult.getData().toString());
                } catch (Exception e) {
                    logger.error("encode失败" + e);
                    paramMap.put("trade_info", null);
                    try {
                        response.sendRedirect(URL+SignUtil.createLinkString(paramMap));
                    } catch (IOException ex) {
                        logger.error("跳转异常:",ex);
                    }
                    return "pay/to_pay";
                }
        }else{
            paramMap.put("trade_info", null);
            logger.info("未查到订单数据");
            try {
                response.sendRedirect(URL+SignUtil.createLinkString(paramMap));
            } catch (IOException e) {
                logger.error("跳转异常:", e);
            }
        }
        long payTimeE = System.currentTimeMillis();
        logger.info("去支付流程结束,耗时："+(payTimeE-payTimeS)+"ms");
        return "pay/to_pay";
    }
}
