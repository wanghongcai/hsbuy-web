package com.lenovo.m2.buy.promotion.pay.allinpay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.LePayConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayJsManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.allinpay.AllinpayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * 通联回调接口
 * Created by zhangqy10 on 2016/11/2.
 */
@Controller
@Scope("prototype")
public class AllinpayController {
    private final Logger LOGGER = Logger.getLogger(this.getClass());

    @Autowired
    private CommonCallBackManager commonCallBackManager;

    @Autowired
    private AllinpayManager allinpayManager;

    @Autowired
    private PayPortalOrderManager payPortalOrderManager;

    @Autowired
    private CommonManager commonManager;

    @Autowired
    private AliPayCommonManager aliPayCommonManager;

    @Autowired
    private PayOrderApi payOrderApi;

    @Autowired
    private AliPayJsManager aliPayJsManager;

    /**
     * 接收通联支付异步回调
     *
     * @param request
     * @param response
     */
    @RequestMapping("/allinpayNotifyUrl")
    public void allinpayNotifyUrl(HttpServletRequest request, HttpServletResponse response) {
        String transactionId = request.getParameter("paymentOrderId");
        String orderId = request.getParameter("orderNo");
        String payType = request.getParameter("payType");
        String errorCode = request.getParameter("errorCode");
        boolean isTest = aliPayCommonManager.isTestPay("isAllinPayTest");
        LOGGER.info("通联支付异步回调=======================> 商户订单号:[" + orderId + "]，通联订单号:[" + transactionId + "]" + "支付类型" + payType);
        PayOrder payOrder = null;
        RemoteResult<MerchantPayPlatView> merchantPayPlatRemoteResult = null;
        MerchantPayPlatView merchantPayPlatView = null;
        try {
            if (StringUtils.isNotEmpty(orderId)) {
                payOrder = commonCallBackManager.getPayOrderById(orderId);
                LOGGER.info("Allinpay Original PayOrder [" + payOrder + "]");
            } else {
                LOGGER.info("Allinpay Original PayOrder Is Null");
                return;
            }
            if (payOrder != null) {
                merchantPayPlatRemoteResult = commonCallBackManager.getMerchantPayPlatById(payOrder.getMerchant_id());
            } else {
                LOGGER.info("Allinpay Original PayOrder Is Null, orderId[" + orderId + "]");
                return;
            }
            if (merchantPayPlatRemoteResult.isSuccess()) {
                merchantPayPlatView = merchantPayPlatRemoteResult.getT();
                LOGGER.info("Allinpay Original MerchantPayPlat [" + merchantPayPlatView + "]");
            } else {
                LOGGER.info("Allinpay Original MerchantPayPlat Is Null");
                return;
            }
        } catch (Exception e) {
            LOGGER.info("通联支付异步回调获取订单平台信息异常 Error Cause By :",e);
            return;
        }
        String certPath = "";
        if (isTest) {
            certPath = aliPayCommonManager.getAliPropValue("allinpay_certPath_uat");
        } else {
            certPath = aliPayCommonManager.getAliPropValue("allinpay_certPath_pro");
        }
        if ("33".equals(payType)) {
            certPath = aliPayCommonManager.getAliPropValue("allinpay_certPath_pro");
        }
        try {
            boolean verifyFlag = allinpayManager.verifyNotify(request, merchantPayPlatView, certPath);
            if (verifyFlag && LePayConstant.TRADE_SUCC_ALLINPAY.equals(request.getParameter("payResult"))) {
                LOGGER.info("Allinpay TRADE_SUCCESS ,orderId[" + orderId + "]");
                RemoteResult<String> result = null;
                Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
                Map<String, String> paraMap = new HashMap<String, String>();
                paraMap.put("tradeStatus", "TRADE_SUCCESS");
                paraMap.put("tradeNo", orderId);
                paraMap.put("gmtPayment", request.getParameter("payDatetime"));
                paraMap.put("notifyId", request.getParameter("orderDatetime"));
                paraMap.put("payType", String.valueOf(payOrder.getPay_type()));
                paraMap.put("bankSeqNo", transactionId);
                if (PeakConstant.TRADE_SUCCESS == payOrder.getTrade_state() && PeakConstant.MFLAG_SUCC == payOrder.getMerchant_flag()) {
                    LOGGER.info("通联支付异步已回调====>订单,orderId[" + orderId + "]，" + "订单交易状态："+payOrder.getTrade_state());
                } else {
                    if(CommonMethod.checkInShopId(payOrder.getShop_id())){
                        LOGGER.info("通联支付异步回调，支付系统通过dubbo通知商户系统，shopId[" + payOrder.getShop_id() + "],orderId[" + orderId + "]");
                        result = aliPayJsManager.callUpdate(payOrder.getU_id(), orderId, transactionId, paraMap.get("gmtPayment"), merchantPayPlatView.getMerchantId(), String.valueOf(payOrder.getPay_type()), merchantPayPlatView, paraMap.get("notifyId"), null);
                    }else{
                        LOGGER.info("通联支付异步回调，支付系统通过HTTP通知商户系统，shopId[" + payOrder.getShop_id() + "],orderId[" + orderId + "]");
                        result = commonCallBackManager.callOutUpdate(payOrder, merchantPayPlatView, paraMap, commonParam);
                    }
                    if (result.isSuccess()) {
                        LOGGER.info("通联支付异步回调通知外部系统成功！orderId[" + orderId + "]");
                        payOrderApi.updateAliPayNotifyState(String.valueOf(payOrder.getId()), payOrder.getU_id(), transactionId, PeakConstant.MFLAG_SUCC, paraMap.get("notifyId"), PeakConstant.TRADE_SUCCESS, paraMap.get("bankSeqNo"), Integer.parseInt(paraMap.get("payType")));
                    } else {
                        LOGGER.info("通联支付异步回调通知外部系统失败！orderId[" + orderId + "]");
                        payOrderApi.updateAliPayNotifyState(String.valueOf(payOrder.getId()), payOrder.getU_id(), transactionId, PeakConstant.MFLAG_REPEAT, paraMap.get("notifyId"), PeakConstant.TRADE_SUCCESS, paraMap.get("bankSeqNo"), Integer.parseInt(paraMap.get("payType")));
                    }
                }
            } else {
                LOGGER.info("Allinpay Check Signature FAIL，orderId[" + orderId + "],errorCode="+errorCode);
                return;
            }
        } catch (Exception e) {
            LOGGER.info("Allinpay Notify Check Signature EXCEPTION，orderId[" + orderId + "],transactionId[" + transactionId + "] Error Cause By :" + e);
            return;
        }
    }

    /**
     * 接收通联支付同步回调
     *
     * @param request
     * @param response
     */
    @RequestMapping("/allinpayReturnUrl")
    public String allinpayReturnUrl(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        String tradeNo = request.getParameter("paymentOrderId");
        String orderPrimaryId = request.getParameter("orderNo");
        String terminal = request.getParameter("ext2");
        String payType = request.getParameter("payType");
        LOGGER.info("通联支付同步回调=======================> 商户订单号:[" + orderPrimaryId + "]，通联订单号:[" + tradeNo + "],客户端:" + terminal + "支付类型：" + payType);
        boolean isTest = aliPayCommonManager.isTestPay("isAllinPayTest");

        PayOrder payOrder = null;
        RemoteResult<MerchantPayPlatView> merchantPayPlatRemoteResult;
        MerchantPayPlatView merchantPayPlatView;
        try {
            if (StringUtils.isNotEmpty(orderPrimaryId)) {
                payOrder = commonCallBackManager.getPayOrderById(orderPrimaryId);
                LOGGER.info("Allinpay Original PayOrder [" + payOrder + "]");
            } else {
                LOGGER.info("Allinpay Original PayOrder Is Null");
                paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
                return CommonMethod.getOutPayFailPage(terminal);
            }
            if (payOrder != null) {
                merchantPayPlatRemoteResult = commonCallBackManager.getMerchantPayPlatById(payOrder.getMerchant_id());
            } else {
                LOGGER.info("Allinpay Original PayOrder Is Null, OrderPrimaryId[" + orderPrimaryId + "]");
                paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
                return CommonMethod.getOutPayFailPage(terminal);
            }
            if (merchantPayPlatRemoteResult.isSuccess()) {
                merchantPayPlatView = merchantPayPlatRemoteResult.getT();
                LOGGER.info("Allinpay Original MerchantPayPlat [" + merchantPayPlatView + "]");
            } else {
                LOGGER.info("Allinpay Original MerchantPayPlat Is Null");
                paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
                return CommonMethod.getOutPayFailPage(terminal);
            }
        } catch (Exception e) {
            LOGGER.info("通联支付同步回调获取订单平台信息异常 Error Cause By :" + e);
            paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
            return CommonMethod.getOutPayFailPage(terminal);
        }
        boolean verifyFlag;
        String certPath = "";
        if (isTest) {
            certPath = aliPayCommonManager.getAliPropValue("allinpay_certPath_uat");
        } else {
            certPath = aliPayCommonManager.getAliPropValue("allinpay_certPath_pro");
        }
        if ("33".equals(payType)) {
            certPath = aliPayCommonManager.getAliPropValue("allinpay_certPath_pro");
        }
        try {
            verifyFlag = allinpayManager.verifyNotify(request, merchantPayPlatView, certPath);
        } catch (Exception e) {
            LOGGER.info("Allinpay Notify Check Signature EXCEPTION，OrderPrimaryId[" + orderPrimaryId + "],TradeNo[" + tradeNo + "] Error Cause By :" + e);
            paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
            return CommonMethod.getOutPayFailPage(terminal);
        }
        if (verifyFlag && LePayConstant.TRADE_SUCC_ALLINPAY.equals(request.getParameter("payResult"))) {
            LOGGER.info("Allinpay TRADE_SUCCESS ,OrderPrimaryId[" + orderPrimaryId + "]");
            try {
                Tenant tenant = CommonMethod.buildTenant(payOrder.getShop_id(), null, null, null, null, null, null);
                RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByShowTradeNo(String.valueOf(payOrder.getOut_trade_no()), null, tenant);
                //同步通知外部系统
                if (payPortalOrderRemoteResult.isSuccess()) {
                    Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
                    return CommonMethod.getOutSyncReturnForm(payOrder, merchantPayPlatView, payPortalOrderRemoteResult.getT(), paraMap, commonParam, "TRADE_SUCCESS", String.valueOf(payOrder.getId()));
                }
            } catch (Exception e) {
                LOGGER.info("Allinpay Call MiddleWare FAIL, OrderPrimaryId[" + orderPrimaryId + "] Error Cause By :" + e);
            }
        } else {
            LOGGER.info("Allinpay Check Signature FAIL，OrderPrimaryId[" + orderPrimaryId + "]");
        }
        paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
        return CommonMethod.getOutPayFailPage(terminal);
    }

    public CommonCallBackManager getCommonCallBackManager() {
        return commonCallBackManager;
    }

    public void setCommonCallBackManager(CommonCallBackManager commonCallBackManager) {
        this.commonCallBackManager = commonCallBackManager;
    }

    public AllinpayManager getAllinpayManager() {
        return allinpayManager;
    }

    public void setAllinpayManager(AllinpayManager allinpayManager) {
        this.allinpayManager = allinpayManager;
    }

    public PayPortalOrderManager getPayPortalOrderManager() {
        return payPortalOrderManager;
    }

    public void setPayPortalOrderManager(PayPortalOrderManager payPortalOrderManager) {
        this.payPortalOrderManager = payPortalOrderManager;
    }

    public CommonManager getCommonManager() {
        return commonManager;
    }

    public void setCommonManager(CommonManager commonManager) {
        this.commonManager = commonManager;
    }
}
