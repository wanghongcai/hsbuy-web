package com.lenovo.m2.buy.promotion.admin.controller.util;


import java.lang.annotation.RetentionPolicy; 
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 *  excel导出注解
 * @author wangyu46 on 2017/6/9.
 */
@Retention(RetentionPolicy.RUNTIME)  
@Target( { java.lang.annotation.ElementType.FIELD }) 
public @interface ExcelAttribute {

	/**
	 * 对应的列明
	 * @return
	 */
	public String name();

//	/**
//	 * 此字段是否需要导出    
//	 * @return
//	 */
//	public boolean isExport();

	/**
	 * 字段数据默认 ""
	 * @return
	 */
	public abstract String isDefault() 
	 	default "";

	
	
	
}
