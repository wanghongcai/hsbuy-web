package com.lenovo.m2.buy.promotion.admin.filter;

import com.alibaba.dubbo.rpc.RpcContext;
import com.lenovo.admin.extra.client.AdminClientUtils;
import com.lenovo.admin.extra.client.vo.DataTypeVo;
import com.lenovo.admin.extra.client.vo.DataVo;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.enums.GloablErrorMessageEnum;
import com.lenovo.m2.buy.promotion.admin.controller.util.ThreadLocalObjs;
import com.lenovo.m2.buy.promotion.admin.domain.AuthData;
import com.lenovo.m2.buy.promotion.admin.remote.cerp.CerpService;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.SessionUser;
import com.lenovo.m2.buy.promotion.admin.soa.utils.JsonUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author wangrq1
 *
 */
public class InitUserInterceptor extends HandlerInterceptorAdapter{


	@Autowired
	private CerpService cerpService;

	
	private static Logger log = LoggerFactory.getLogger(InitUserInterceptor.class);

	private static final String PROMOTION_URI = "/api/promotion";
	private static final String SECKILL_ACTIVITY_URI = "/api/seckillActivity";

	/*
	 * 
	 * (non-Javadoc)
	 * @see org.springframework.web.servlet.handler.HandlerInterceptorAdapter#preHandle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object)
	 */
	@Override
	public boolean preHandle(HttpServletRequest servletRequest, HttpServletResponse response, Object target) throws Exception {
		//url
		String uri = servletRequest.getRequestURI();
		if(StringUtils.isNotBlank(uri) && (uri.startsWith(PROMOTION_URI) || uri.startsWith(SECKILL_ACTIVITY_URI))) {
			if(uri.contains("toRedis")){
				return true;
			}
			log.info("http admin login start!");
			return setApiContext(servletRequest,response);
		}/*else{
			return setWebContext(servletRequest);
		}*/
		return true;
	}


			//333    设置 API 环境 
	private boolean setApiContext(HttpServletRequest servletRequest,HttpServletResponse response){
		//设置shopid
		initTenantInfo(servletRequest);
		
		Tenant tenant = ThreadLocalObjs.getTenant();
		if(tenant == null || tenant.getShopId() == null){
			
			log.warn("shopid==null");
			RemoteResult remoteResult = new RemoteResult(false);
			
			remoteResult.setResultMsg("shopId不可用或为null");
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
			try {
				response.setCharacterEncoding("UTF-8");
				response.setHeader("Content-Type", "text/html;charset=UTF-8");
				PrintWriter writer = response.getWriter();
				writer.println(JsonUtil.toJson(remoteResult));
				writer.flush();
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return false;
		}
		
		String authData = servletRequest.getParameter("authdata");
		log.info("authData={}",authData);
		if(StringUtils.isEmpty(authData)){
			log.warn("api authData is null");
			//return false;
			return true;
		}
		AuthData authDataObj = JsonUtil.fromJson(authData, AuthData.class);

		if(authDataObj == null){
			log.warn("parse authDataObj failed, tenantObj={}", authDataObj);
			return  false;
		}
		//设置 参数
		ThreadLocalObjs.setAuthData(authDataObj);
		RpcContext.getContext().setAttachment("shopIds", JsonUtil.toJson(authDataObj.getShopIds()));
		RpcContext.getContext().setAttachment("fas", JsonUtil.toJson(authDataObj.getFaIds()));

		SessionUser user = new SessionUser();
		user.setItcode(authDataObj.getUserid());
		user.setShopIds(authDataObj.getShopIds());
		user.setFas(authDataObj.getFaIds());
		ThreadLocalObjs.setUser(user);

		return true;
	}

	private boolean setWebContext(HttpServletRequest servletRequest){
		String itcode = AdminClientUtils.getInstance().getCurrItcode(servletRequest);
		log.info("itcode={}", itcode);  //null

		SessionUser user = new SessionUser();
		user.setItcode(itcode);
		user.setShopIds(getShopIds(servletRequest));
		user.setFas(getFas(servletRequest));
		ThreadLocalObjs.setUser(user);

		initTenantInfo(servletRequest);

		RpcContext.getContext().setAttachment("shopIds", JsonUtil.toJson(user.getShopIds()));
		RpcContext.getContext().setAttachment("fas", JsonUtil.toJson(user.getFas()));

		log.info("set webcontext success");
		return true;
	}




	//数据类别FA
	public List<String> getFas(HttpServletRequest request) {
		List<DataVo> dataVos = getDataVos(request, "FA");
		List<String> fas = new ArrayList<String>();
		if (CollectionUtils.isNotEmpty(dataVos)){
			for (DataVo dataVo : dataVos){
				fas.add(dataVo.getCode());
			}
		}
		return fas;
	}

	//数据类别ShopId
	public List<String> getShopIds(HttpServletRequest request) {
		List<DataVo> dataVos = getDataVos(request, "ShopId");
		List<String> shopids = new ArrayList<String>();
		if (CollectionUtils.isNotEmpty(dataVos)){
			for (DataVo dataVo : dataVos){
				shopids.add(dataVo.getCode());
			}
		}
		return shopids;
	}

	//根据具体的数据类别获取数据权限list
	private List<DataVo> getDataVos(HttpServletRequest request, String dataType){
			//权限
		List<DataTypeVo> DataTypeVos = AdminClientUtils.getInstance().getSystemDataReq(request);
		if (CollectionUtils.isNotEmpty(DataTypeVos)){
			for (DataTypeVo dataTypeVo : DataTypeVos){
				if (dataType.equals(dataTypeVo.getTypeName())){
					return dataTypeVo.getDataVo();
				}
			}
		}
		return null;
	}
	
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		super.postHandle(request, response, handler, modelAndView);
		ThreadLocalObjs.removeUser();
		ThreadLocalObjs.removeTenant();
		ThreadLocalObjs.removeAuthData();
		RpcContext.getContext().remove("shopIds");
		RpcContext.getContext().remove("fas");
	}


				//222
	public void initTenantInfo(HttpServletRequest servletRequest){
		String shopId = servletRequest.getParameter("shopId");
		log.info("shopId==={}", shopId);  //租户id
		if(StringUtils.isEmpty(shopId)){
			shopId = servletRequest.getParameter("shopid");
		}
        if(StringUtils.isEmpty(shopId)){
            //搜索页shopId
            shopId = servletRequest.getParameter("filter[shopid]");
        }
        if(StringUtils.isEmpty(shopId)){
            //搜索页shopId
            shopId = servletRequest.getParameter("filter[shopId]");
        }


		log.info("shopId={}", shopId);

		if(StringUtils.isNotEmpty(shopId)){
//			Tenant tenant = cerpService.getTenantByShopId(Integer.parseInt(shopId));
			Tenant tenant =  Tenant.getTenant(Integer.valueOf(shopId));
			//从租户sku中获得基本信息  如果 信息为没null  就为null   
//			tenant.setShopId(Integer.parseInt(shopId));
//			tenant.setCurrencyCode("CNY");
			ThreadLocalObjs.setTenant(tenant);  //设置了 shopID
		}
		
		
	}

}
