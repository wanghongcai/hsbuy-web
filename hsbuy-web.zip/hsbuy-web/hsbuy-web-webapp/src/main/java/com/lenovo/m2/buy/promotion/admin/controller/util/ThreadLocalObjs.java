package com.lenovo.m2.buy.promotion.admin.controller.util;


import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.domain.AuthData;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.SessionUser;

/**
 * @author wangrq1
 * 
 */
public class ThreadLocalObjs {

    private static ThreadLocal<SessionUser> localUser = new ThreadLocal<SessionUser>();
    private static ThreadLocal<Tenant> localTenant = new ThreadLocal<Tenant>();
    //api公共参数
    private static ThreadLocal<AuthData> authData = new ThreadLocal<AuthData>();



    public static SessionUser getUser() {
        return localUser.get();
    }
    
    public static void setUser(SessionUser req) {
    	localUser.set(req);
    }
    
    public static void removeUser(){
    	localUser.remove();
    }



    public static void setTenant(Tenant tenant){
        localTenant.set(tenant);
    }


    public static Tenant getTenant(){
        return localTenant.get();
    }

    public static void removeTenant(){
        localTenant.remove();
    }



    public static void setAuthData(AuthData data){
        authData.set(data);
    }


    public static AuthData getAuthData(){
        return authData.get();
    }

    public static void removeAuthData(){
        authData.remove();
    }


}
