package com.lenovo.m2.buy.promotion.admin.controller.api.ordercenter;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.ordercenter.OpenOrderRemote;
import com.lenovo.m2.hsbuy.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.domain.order.logistics.OpenPlatRequestForMsg;
import com.lenovo.m2.hsbuy.domain.order.logistics.SmbRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * smb发货，推轨迹信息
 * update by licy13 on 2017/4/17
 */
@Controller
@RequestMapping({"/openPlat"})
public class SmbController {
    private static final Logger LOGGER = LogManager.getLogger(SmbController.class.getName());

    @Autowired
    private OpenOrderRemote openOrderRemote;

    /**
     * 订单物流号推送
     *
     * @param smbRequest
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateLogistics", produces = "plain/text; charset=UTF-8")
    public String updateLogisticsCode(SmbRequest smbRequest) {
        LOGGER.info("updateLogisticsCode smbRequest={}", JsonUtil.toJson(smbRequest));
        RemoteResult result = openOrderRemote.updateLogisticsCode(smbRequest);
        LOGGER.info("updateLogisticsCode logiNo={}, result={}", smbRequest.getLogistics(), JsonUtil.toJson(result));
        return JsonUtil.toJson(result);


    }

    /**
     * 订单物流轨迹推送
     *
     * @param openPlatRequestForMsg
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updateLogisticsMessage", produces = "plain/text; charset=UTF-8")
    public String updateLogisticsMessage(OpenPlatRequestForMsg openPlatRequestForMsg) {
        LOGGER.info("updateLogisticsMessage OpenPlatRequestForMsg={}", JsonUtil.toJson(openPlatRequestForMsg));
        RemoteResult result = openOrderRemote.updateLogisticsMessage(openPlatRequestForMsg);
        LOGGER.info("updateLogisticsMessage logiNo={}, result={}", openPlatRequestForMsg.getLogiNo(), JsonUtil.toJson(result));
        return JsonUtil.toJson(result);
    }

}