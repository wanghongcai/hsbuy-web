package com.lenovo.m2.buy.promotion.admin.controller.api.promotion;

import com.lenovo.fileclient.PrivateSpcaceManager;
import com.lenovo.fileclient.UploadImageClient;
import com.lenovo.fileclient.common.UploadResponse;
import com.lenovo.m2.arch.framework.domain.*;
import com.lenovo.m2.arch.tool.util.DateFormatUtils;
import com.lenovo.m2.buy.promotion.admin.common.excelgen.ExcelGen;
import com.lenovo.m2.buy.promotion.admin.common.excelgen.ExcelGenConfig;
import com.lenovo.m2.buy.promotion.admin.common.excelgen.formatter.DateFormater;
import com.lenovo.m2.buy.promotion.admin.controller.util.ExcelBean;
import com.lenovo.m2.buy.promotion.admin.controller.util.ThreadLocalObjs;
import com.lenovo.m2.buy.promotion.admin.domain.AuthData;
import com.lenovo.m2.buy.promotion.admin.domain.promotion.PromoForm;
import com.lenovo.m2.buy.promotion.admin.domain.promotion.PromoSku;
import com.lenovo.m2.buy.promotion.admin.domain.promotion.PromotionListQry;
import com.lenovo.m2.buy.promotion.admin.domain.promotion.ReservationListQry;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.*;
import com.lenovo.m2.buy.promotion.admin.soa.api.service.PromotionAdminRead;
import com.lenovo.m2.buy.promotion.admin.soa.api.service.PromotionAdminWrite;
import com.lenovo.m2.buy.promotion.admin.soa.enums.GloablErrorMessageEnum;
import com.lenovo.m2.buy.promotion.admin.soa.utils.BaseInfo;
import com.lenovo.m2.buy.promotion.admin.soa.utils.JsonUtil;
import com.lenovo.m2.buy.promotion.admin.soa.utils.StringUtil;
import com.lenovo.m2.buy.promotion.admin.soa.enums.ShopIdEnum;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @desc 提供给开放平台的api Created by lihc5 on 2017-05-11.
 */
@Controller("PromotionAdminApi")
@RequestMapping("/api/promotion")
public class PromotionApi extends PromotionApiBase {

	private static final String appId = "promotion";
	private static final String appKey = "yyPpuhmkbTR0TxD4";
	private static final String domain = "promotion.app.lefile.cn";
	private static String targetEppPromotionFilePath = "/eppPromotionCheck/";
	private static String targetReconciliationFilePath = "/reconciliation/";
	private static String targetPromotionListFilePath = "/promotionlist/";
	private static String targetReservationFilePath = "/reservation/";
	private static final String imageServerURL = "http://internal-up.lefile.cn/image/upload";

	// epp促销规则审核导出excel的title
	static String[] excelHeader = { "促销规则名称", "审核人", "通过时间", "审核状态", "驳回原因" };

	//通用Excel表格生成类ExcelGen，导出促销列表信息的header设置
	static String excelGen_PromotionList_Header = "促销名称-PromotionName,促销类型-PromotionType,规则描述-Description,启用状态-Disabled,促销平台-terminalName,状态-Status,商城-shopid,分销商名称-faName,主品物料编号-mainProductMaterial,促品物料编号-relProductMaterial,创建时间-createTime,开始时间-fromtime,结束时间-totime";
	
	@Autowired
	private PromotionAdminRead promotionAdminRead;
	@Autowired
	private PromotionAdminWrite promotionAdminWrite;

	private static Logger log = LoggerFactory.getLogger(PromotionApi.class);

	/**
	 * @desc 查询促销的列表
	 * @author lihc5
	 * @param request
	 * @return
	 */
	@RequestMapping("/list")
	@ResponseBody
	public RemoteResult promList(PromotionListQry request) {
		log.info("request={}", JsonUtil.toJson(request));
		AuthData authData = ThreadLocalObjs.getAuthData();
		Tenant tenant = ThreadLocalObjs.getTenant();

		List<String> shopIds = authData.getShopIds();
		List<String> faIds = authData.getFaIds();

		Map map = request.toMap();
		map.put("shopIds", shopIds);
		map.put("faIds", faIds);

		map.put("shopid", tenant.getShopId());
		RemoteResult rr = new RemoteResult(false);
		try {
			PageQuery pq = new PageQuery(request.getPageNum(), request.getPageSize());
			RemoteResult<PageModel2<PromotionInfoVO>> list = new RemoteResult<>();
			list = promotionAdminRead.getPromotionList(tenant, pq, map, tenant.getShopId());
			return list;
		} catch (Exception e) {
			log.error("api promList ERROR", e);
			rr.setResultMsg(GloablErrorMessageEnum.ERROR_OPERATIONDATA.getCommon());
			rr.setResultCode(GloablErrorMessageEnum.ERROR_OPERATIONDATA.getCode());
			rr.setSuccess(false);
			return rr;
		}
	}

	/**
	 * @desc 添加促销规则
	 * @author lihc5
	 * @param
	 * @param
	 * @return
	 */
	@RequestMapping("/add")
	@ResponseBody
	public RemoteResult addPromotion(PromoForm promoForm) {
		log.info("promoForm={}", JsonUtil.toJson(promoForm));
		RemoteResult remoteResult = new RemoteResult(false);
		Tenant tenant = ThreadLocalObjs.getTenant();
		AuthData authData = ThreadLocalObjs.getAuthData();
		Integer shopId = tenant.getShopId(); // shopid
		String currencyCode = tenant.getCurrencyCode();
		//数据拼装
		SalesGoodsPromotionRoles roles = transfer(tenant, authData, promoForm);

		if (roles == null) { // 校验开始时间是否大于结束时间
			log.info("param roles null or plrase check param time");
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
			remoteResult.setResultMsg("请检查时间日期参数");
			return remoteResult;
		} else {
			remoteResult = roles.check(); // 校验是否非空
			log.info(
					"param null promotionname={},promotiontype={},disabled={},shopid={},fromtime={},totime={},terminal={},terminalName={}",
					new Object[] { roles.getPromotionname(), roles.getPromotiontype(), roles.getDisabled(),
							roles.getShopid(), roles.getFromtime(), roles.getTotime(), roles.getTerminal(),
							roles.getTerminalName() });
			if (!remoteResult.isSuccess()) {
				return remoteResult;
			}
		}
		// 主品列表
		List<PromoSku> mainSkus = JsonUtil.readValuesAsArrayList(promoForm.getMainProducts(), PromoSku.class);
		if (CollectionUtils.isEmpty(mainSkus)) {
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
			remoteResult.setResultMsg("主品信息不能为空");
			remoteResult.setSuccess(false);
			return remoteResult;
		}

		// 关联品列表
		List<PromoSku> relSkus = null;
		if (StringUtils.isNotEmpty(promoForm.getRelProducts())) {
			relSkus = JsonUtil.readValuesAsArrayList(promoForm.getRelProducts(), PromoSku.class);
		}

		List<SalesGoodsPromotionRoleTails> roleDetails = new ArrayList<SalesGoodsPromotionRoleTails>();
		// 组装原接口对象
		for (PromoSku promoSku : mainSkus) {
			if (CollectionUtils.isEmpty(relSkus)) {
				// 只拼装主品
				SalesGoodsPromotionRoleTails detail = makeDetail(promoSku, shopId, currencyCode);
				roleDetails.add(detail);
			} else {

				for (PromoSku relSku : relSkus) {
					SalesGoodsPromotionRoleTails detail = makeDetail(promoSku, relSku, currencyCode);
					roleDetails.add(detail);
				}
			}
		}
		log.info("roleDetails={}", JsonUtil.toJson(roleDetails));

		SessionUser sessionUser = ThreadLocalObjs.getUser();
		try {
			if (shopId == ShopIdEnum.HS.getType() || shopId == ShopIdEnum.HSJF.getType()) {// EPP 商城 或者 惠商商城
				if (StringUtil.isEmpty(promoForm.getGroup())) {
					remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
					remoteResult.setResultMsg("用户组编码不能为空！");
					remoteResult.setSuccess(false);
					return remoteResult;
				}
				if (StringUtil.isEmpty(promoForm.getGroupName())) {
					remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
					remoteResult.setResultMsg("用户组名称不能为空！");
					remoteResult.setSuccess(false);
					return remoteResult;
				}
				//  租户,epp数据 ,商品（主or从）,用户组,用户组名称,回话
				remoteResult = promotionAdminWrite.eppSave(tenant, roles, JsonUtil.toJson(roleDetails),
						promoForm.getGroup(), promoForm.getGroupName(), sessionUser);
			} else {//促销
				remoteResult = promotionAdminWrite.btSave(tenant, roleDetails, roles, sessionUser);
			}
			BaseInfo baseInfo = (BaseInfo) remoteResult.getT();
			if (!remoteResult.isSuccess()) {
				remoteResult.setResultCode(String.valueOf(baseInfo.getRc())); //
				remoteResult.setResultMsg(baseInfo.getMsg()); // 提示语
			}
		} catch (Exception e) {
			log.error("addPromotion error", e);
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
			remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
			remoteResult.setSuccess(false);
			return remoteResult;
		}
		return remoteResult;
	}

	/**
	 * @desc 提交修改的促销规则
	 * @author lihc5
	 * @param promoForm
	 * @return
	 */
	@RequestMapping("/update")
	@ResponseBody
	public RemoteResult savePromotion(PromoForm promoForm) {
		RemoteResult result = new RemoteResult(false);

		Tenant tenant = ThreadLocalObjs.getTenant();
		AuthData authData = ThreadLocalObjs.getAuthData();
		Integer shopId = tenant.getShopId();
		String currencyCode = tenant.getCurrencyCode();
		SalesGoodsPromotionRoles roles = transfer(tenant, authData, promoForm);

		if (roles == null) { // 校验开始时间是否大于结束时间
			log.info("param roles null,please check fromTime Greater than toTime");
			result.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
			result.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
			return result;
		} else {
			result = roles.checkEdit(); // 校验是否非空
			log.info(
					"param null id={},promotionname={},promotiontype={},disabled={},shopid={},fromtime={},totime={},promotiontype={},terminal={},status={},terminalName={}",
					new Object[] { roles.getId(), roles.getPromotionname(), roles.getPromotiontype(),
							roles.getDisabled(), roles.getShopid(), roles.getFromtime(), roles.getTotime(),
							roles.getPromotiontype(), roles.getTerminal(), roles.getStatus(),
							roles.getTerminalName() });
			if (!result.isSuccess()) {
				return result;
			}
		}

		// 主品列表
		List<PromoSku> mainSkus = JsonUtil.readValuesAsArrayList(promoForm.getMainProducts(), PromoSku.class);
		String jsonMainSkus = JsonUtil.toJson(mainSkus);

		// 关联品列表
		List<PromoSku> relSkus = null;
		if (StringUtils.isNotEmpty(promoForm.getRelProducts())) {
			relSkus = JsonUtil.readValuesAsArrayList(promoForm.getRelProducts(), PromoSku.class);
		}

		List<SalesGoodsPromotionRoleTails> roleDetails = new ArrayList<SalesGoodsPromotionRoleTails>();
		// 组装原接口对象
		for (PromoSku promoSku : mainSkus) {
			if (CollectionUtils.isEmpty(relSkus)) {
				// 只拼装主品
				SalesGoodsPromotionRoleTails detail = makeDetail(promoSku, shopId, currencyCode);
				roleDetails.add(detail);
			} else {

				for (PromoSku relSku : relSkus) {
					SalesGoodsPromotionRoleTails detail = makeDetail(promoSku, relSku, currencyCode);
					roleDetails.add(detail);
				}
			}
		}
		log.info("修改人[itcode={}]修改的促销[id={}]", roles.getUserId(), roles.getId());

		try {
			SessionUser sessionUser = ThreadLocalObjs.getUser();
			if (shopId == ShopIdEnum.HS.getType() || shopId == ShopIdEnum.HSJF.getType()) { // EPP 商城或者惠商商城
				if (StringUtil.isEmpty(promoForm.getGroup())) {
					result.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
					result.setResultMsg("用户组编码不能为空！");
					result.setSuccess(false);
					return result;
				}
				if (StringUtil.isEmpty(promoForm.getGroupName())) {
					result.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
					result.setResultMsg("用户组名称不能为空！");
					result.setSuccess(false);
					return result;
				}
				// epp修改
				result = promotionAdminWrite.eppUpdate(tenant, roles, JsonUtil.toJson(roleDetails),
						promoForm.getGroup(), promoForm.getGroupName(), sessionUser);
			} else {
				// bt修改
				result = promotionAdminWrite.btUpdate(tenant, roleDetails, roles, sessionUser);
			}

		} catch (Exception e) {
			log.error("updatePromotion Error", e);
			result.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
			result.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
			result.setSuccess(false);
		}
		return result;
	}

	/**
	 * @desc 查询单条的促销规则用于修改
	 * @author lihc5
	 * @param id
	 * @return
	 */
	@RequestMapping("/get")
	@ResponseBody
	public RemoteResult getPromotion(String id) {
		RemoteResult result = new RemoteResult(false);
		if (id == null) {
			log.info("param id null");
			result.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
			result.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
			return result;
		}

		Tenant tenant = ThreadLocalObjs.getTenant();
		log.info("tenant shopId={}", tenant.getShopId());
		AuthData authData = ThreadLocalObjs.getAuthData();
		try {
			if (tenant.getShopId() == ShopIdEnum.HS.getType() || tenant.getShopId() == ShopIdEnum.HSJF.getType()) {
				// 商城或者惠商商城
				result = promotionAdminRead.getEditData(tenant, id, tenant.getShopId());
			} else {
				result = promotionAdminRead.getEditData(tenant, id, null);
			}
		} catch (Exception e) {
			result.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
			result.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
			result.setSuccess(false);
		}
		return result;
	}

	/**
	 * @desc 删除促销规则
	 * @author lihc5
	 * @param ids
	 * @return
	 */
	@RequestMapping("/delete")
	@ResponseBody
	public RemoteResult delPromotion(String ids) {
		// log.info("api deletePromotion ids={}",ids);
		RemoteResult result = new RemoteResult(false);

		AuthData authData = ThreadLocalObjs.getAuthData();

		if (StringUtils.isEmpty(ids) || StringUtils.isEmpty(authData.getUserid())) {
			result.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
			result.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
			return result;
		}
		try {
			Tenant tenant = ThreadLocalObjs.getTenant();
			// 商城或者惠商商城
			result = promotionAdminWrite.eppDelete(tenant, ids.split(","), authData.getUserid());
			return result;
		} catch (Exception e) {
			log.error("deletePromotion Error", e);
			result.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
			result.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
			return result;
		}
	}


	/**
	 * promotionListExcel
	 * 促销列表Excel文件导出
	 * @author jiangxy7
	 * @param request
	 * @return
	 */
	@RequestMapping("/downPromotionListExcel")
	@ResponseBody
	public RemoteResult downPromotionListExcel(PromotionListQry request) {
		log.info("downPromotionListExcel = {}", com.lenovo.m2.buy.promotion.common.util.JsonUtil.toJson(request));
		RemoteResult remoteResult = new RemoteResult();
		AuthData authData = ThreadLocalObjs.getAuthData();
		Tenant tenant = ThreadLocalObjs.getTenant();
		try {
			List<String> shopIds = authData.getShopIds();
			List<String> faIds = authData.getFaIds();
			Map<String, Object> map = request.toMap();

			map.put("shopIds", shopIds);
			map.put("faIds", faIds);
			map.put("shopid", tenant.getShopId());
			
			// 封装查询参数
			PageQuery pq = new PageQuery(true);
			pq.setPageSize((int) 0);
			RemoteResult<PageModel2<PromotionInfoVO>> res =
					promotionAdminRead.getPromotionList(tenant, pq, map, tenant.getShopId());

			log.info("getPromotionList return={}", com.lenovo.m2.buy.promotion.common.util.JsonUtil.toJson(res));

			if(!res.isSuccess()){
				return res;
			}

			HSSFWorkbook workbook = new HSSFWorkbook();
			
			//获得对应Excel表格配置实例
			ExcelGenConfig instance = ExcelGenConfig.instance;
			
			//对要生成的Excel表格进行相关的配置
			instance.addProp(ExcelGenConfig.SHEET_NAME, "促销详情");//设置Excel工作表表名
			instance.defaultConfig();//启用默认配置————如果对应POJO类中有名为Date的属性，自动进行日期格式的转换
			instance.addProp(DateFormater.FORMATTER_PATTEN, "yyyy-MM-dd hh:mm:ss");//配置日期转换格式
			//配置POJO类中日期相关属性，注意要与与header中对应的属性大小写一致
			instance.registerFormatter("createTime", DateFormater.getInstance());
			instance.registerFormatter("fromtime", DateFormater.getInstance());
			instance.registerFormatter("totime", DateFormater.getInstance());
			
			if (res.getT() != null && res.getT().getDatas().size() > 0) {
				//使用excelgen工具类生成Excel表格
				workbook = ExcelGen.gen(instance, PromotionApi.excelGen_PromotionList_Header,res.getT().getDatas());
			}
			
			//上传Excel到文件服务器
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			workbook.write(byteArrayOutputStream);
			String fileName = "Promotionlist.xls";
			long timeStamp = System.currentTimeMillis();
			String token = UploadImageClient.getToken(appId, appKey, timeStamp,
					targetPromotionListFilePath + fileName, "1");

			UploadResponse uploadResponse = UploadImageClient.upload(appId, token, timeStamp,
					imageServerURL + targetPromotionListFilePath + fileName, byteArrayOutputStream.toByteArray(),
					fileName, "1");
			
			log.info("promotionList uploadResponse={}", JsonUtil.toJson(uploadResponse));
			String readURL = PrivateSpcaceManager.getReadURL(appId, appKey, domain,
					targetPromotionListFilePath + fileName);
			log.info("readURL={}", readURL);

			remoteResult.setSuccess(true);
			remoteResult.setResultCode("0");
			remoteResult.setResultMsg("操作成功");
			remoteResult.setT(readURL);
			return remoteResult;

		} catch (Exception e) {
			log.error("downEppPromotionCheckExcel error={}", e);
			remoteResult.setSuccess(false);
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
			remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
			return remoteResult;
		}
	}
	
	
	
	private void assembleData(HSSFSheet sheet, HSSFCellStyle dateCellStyle, List<PromotionInfoVO> datas, int rows) {
		for (int i = 0; i < datas.size(); i++) {
			
			PromotionInfoVO promotionInfoVO = datas.get(i);
			HSSFRow row = sheet.createRow((int) i + rows);// 创建一行
			HSSFCell PromotionName_cell = row.createCell((int) 0);// 创建促销名称列
			PromotionName_cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			PromotionName_cell.setCellValue(promotionInfoVO.getPromotionName());

			HSSFCell PromotionType_cell = row.createCell((int) 1);// 创建促销类型列
			PromotionType_cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			PromotionType_cell.setCellValue(promotionInfoVO.getPromotionType());

			HSSFCell Description_cell = row.createCell((int) 2);// 创建规则描述列
			Description_cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			Description_cell.setCellValue(promotionInfoVO.getDescription());

			HSSFCell Disabled_cell = row.createCell((int) 3);// 创建启用状态列
			Disabled_cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			Disabled_cell.setCellValue(promotionInfoVO.getDisabled());

			HSSFCell terminalName_cell = row.createCell((int) 4);// 创建促销平台列
			terminalName_cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			terminalName_cell.setCellValue(promotionInfoVO.getTerminalName());
			
			HSSFCell status_cell = row.createCell((int) 5);// 创建状态列
			status_cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			status_cell.setCellValue(promotionInfoVO.getStatus());

			HSSFCell shopid_cell = row.createCell((int) 6);// 创建商城列
			shopid_cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			shopid_cell.setCellValue(isShopIDView().get(promotionInfoVO.getShopid()+"").toString());

			HSSFCell faname_cell = row.createCell((int) 7);// 创建分销商名称列
			faname_cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			faname_cell.setCellValue(promotionInfoVO.getFaName());

			HSSFCell mainProductMaterial_cell = row.createCell((int) 8);// 创建主品物料编号列
			mainProductMaterial_cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			mainProductMaterial_cell.setCellValue(promotionInfoVO.getMainProductMaterial());
			
			HSSFCell refProductMaterial_cell = row.createCell((int) 9);// 创建促品物料编号列
			refProductMaterial_cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			refProductMaterial_cell.setCellValue(promotionInfoVO.getRelProductMaterial());
			
			
			HSSFCell createTime_cell = row.createCell((int) 10);// 创建促销创建时间列
			createTime_cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			createTime_cell.setCellStyle(dateCellStyle);
			createTime_cell.setCellValue(promotionInfoVO.getCreateTime());
			
			HSSFCell fromTime_cell = row.createCell((int) 11);// 创建促销开始时间列
			fromTime_cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			fromTime_cell.setCellStyle(dateCellStyle);
			fromTime_cell.setCellValue(promotionInfoVO.getFromtime());
			
			HSSFCell toTime_cell = row.createCell((int) 12);// 创建促销结束时间列
			toTime_cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			toTime_cell.setCellStyle(dateCellStyle);
			toTime_cell.setCellValue(promotionInfoVO.getTotime());
			
		}
		
	}

	/**
	 * epp excel导出 不改
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/downEppPromotionCheckExcel")
	@ResponseBody
	public RemoteResult downEppPromotionCheckExcel(HttpServletRequest request, HttpServletResponse response) {
		RemoteResult remoteResult = new RemoteResult();
		Tenant tenant = ThreadLocalObjs.getTenant();
		response.setContentType("application/vnd.ms-excel");
		// OutputStream fOut = null;
		HSSFWorkbook workbook = new HSSFWorkbook();
		String readURL = null;
		try {
			// 产生工作簿对象

			HSSFSheet sheet = workbook.createSheet("Epp促销规则审核信息");

			HSSFRow row = sheet.createRow((int) 0);
			HSSFCellStyle style = workbook.createCellStyle();
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index); // 设置颜色为红色
			style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			for (int i = 0; i < excelHeader.length; i++) {
				HSSFCell cell = row.createCell(i);
				cell.setCellValue(excelHeader[i]);
				cell.setCellStyle(style);
				// sheet.autoSizeColumn(i);
				sheet.setColumnWidth(i, 3000);
			}

			Map<String, Object> conditionMap = new HashMap<String, Object>();

			String id = request.getParameter("id");
			String promotionName = request.getParameter("promotionName");
			String name = request.getParameter("name");
			String createTime = request.getParameter("createTime");
			String checkPostTime = request.getParameter("checkPostTime");
			Integer checkStatus = request.getParameter("checkStatus") == null ? 100
					: Integer.parseInt(request.getParameter("checkStatus"));
			String rejectReason = request.getParameter("rejectReason");
			String shopId = request.getParameter("shopId");

			AuthData authData = ThreadLocalObjs.getAuthData();
			List<String> shopIds = authData.getShopIds();
			List<String> faIds = authData.getFaIds();

			conditionMap.put("id", id);
			conditionMap.put("promotionName", promotionName);
			conditionMap.put("name", name);
			conditionMap.put("createTime", createTime);
			conditionMap.put("checkPostTime", checkPostTime);
			conditionMap.put("checkStatus", checkStatus);
			conditionMap.put("rejectReason", rejectReason);

			conditionMap.put("shopIds", shopIds);
			conditionMap.put("faIds", faIds);
			conditionMap.put("shopId", shopId);

			// 封装查询参数
			RemoteResult<List<SalesGoodsPromotionRoleCheck>> re = promotionAdminRead
					.getdownEppPromotionCheckExcel(tenant, conditionMap);
			if (re.isSuccess()) {
				if (re.getT() != null && re.getT().size() > 0) {
					buildData(sheet, re.getT(), 1);

					ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
					workbook.write(byteArrayOutputStream);

					String fileName = "EppPromotionCheck.xls";
					long timeStamp =System.currentTimeMillis();
					String token = UploadImageClient.getToken(appId, appKey, timeStamp,
							targetEppPromotionFilePath + fileName, "1");

					UploadResponse uploadResponse = UploadImageClient.upload(appId, token, timeStamp,
							imageServerURL + targetEppPromotionFilePath + fileName, byteArrayOutputStream.toByteArray(),
							fileName, "1");
					log.info("epp uploadResponse={}", JsonUtil.toJson(uploadResponse));
					readURL = PrivateSpcaceManager.getReadURL(appId, appKey, domain,
							targetEppPromotionFilePath + fileName);
					log.info("readURL={}", readURL);

				}
			}

		} catch (Exception e) {
			log.error("downEppPromotionCheckExcel error", e);
		}
		remoteResult.setSuccess(true);
		remoteResult.setResultCode("0");
		remoteResult.setResultMsg("操作成功");
		remoteResult.setT(readURL);
		return remoteResult;
	}


	/**
	 * epp excel数据 规则 新
	 *
	 * @return
	 */
	private Map<String, ExcelBean> buildData() {
		Map<String, ExcelBean> tmpMap = new HashMap<String, ExcelBean>();

		ExcelBean bean1 = new ExcelBean();
		bean1.setName(excelHeader[0]);
		bean1.setOrder(1);
		tmpMap.put("promotionName", bean1);

		ExcelBean bean2 = new ExcelBean();
		bean2.setName(excelHeader[1]);
		bean2.setOrder(2);
		tmpMap.put("checkpersonid", bean2);

		ExcelBean bean3 = new ExcelBean();
		bean3.setName(excelHeader[2]);
		bean3.setOrder(3);
		tmpMap.put("checkposttime", bean3);

		ExcelBean bean4 = new ExcelBean();
		bean4.setName(excelHeader[3]);
		bean4.setOrder(4);
		bean4.setIsMapper(1);
		Map<String, Object> mapper = new HashMap<>();
		mapper.put("0", "新建");
		mapper.put("1", "待审核");
		mapper.put("2", "审核通过");
		mapper.put("3", "审核未通过");
		bean4.setMapper(mapper);
		tmpMap.put("checkstatus", bean4);

		ExcelBean bean5 = new ExcelBean();
		bean5.setName(excelHeader[4]);
		bean5.setOrder(5);
		tmpMap.put("rejectreason", bean5);
		return tmpMap;
	}

	/**
	 * 封装excel数据
	 *
	 * @param sheet
	 */
	private void buildData(HSSFSheet sheet, List<SalesGoodsPromotionRoleCheck> list, int rows) {
		for (int i = 0; i < list.size(); i++) {
			SalesGoodsPromotionRoleCheck salesGoodsPromotionRoleCheck = list.get(i);
			HSSFRow row = sheet.createRow((int) i + rows);// 创建一行
			HSSFCell cell = row.createCell((int) 0);// 创建一列
			cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			cell.setCellValue(salesGoodsPromotionRoleCheck.getPromotionName());

			HSSFCell cell1 = row.createCell((int) 1);// 创建一列
			cell1.setCellType(HSSFCell.CELL_TYPE_STRING);
			cell1.setCellValue(salesGoodsPromotionRoleCheck.getCheckpersonid());

			HSSFCell cell2 = row.createCell((int) 2);// 创建一列
			cell2.setCellType(HSSFCell.CELL_TYPE_STRING);
			if (salesGoodsPromotionRoleCheck.getCheckposttime() != null) {
				cell2.setCellValue(DateFormatUtils.format(salesGoodsPromotionRoleCheck.getCheckposttime()));
			}

			HSSFCell cell3 = row.createCell((int) 3);// 创建一列
			cell3.setCellType(HSSFCell.CELL_TYPE_STRING);
			if (salesGoodsPromotionRoleCheck.getCheckstatus() == 0) {
				cell3.setCellValue("新建");
			} else if (salesGoodsPromotionRoleCheck.getCheckstatus() == 1) {
				cell3.setCellValue("待审核");
			} else if (salesGoodsPromotionRoleCheck.getCheckstatus() == 2) {
				cell3.setCellValue("审核通过");
			} else {
				cell3.setCellValue("审核未通过");
			}

			HSSFCell cell4 = row.createCell((int) 4);// 创建一列
			cell4.setCellType(HSSFCell.CELL_TYPE_STRING);
			cell4.setCellValue(salesGoodsPromotionRoleCheck.getRejectreason());

		}
	}

	public SalesGoodsPromotionRoles transfer(Tenant tenant, AuthData authData, PromoForm promoForm) {
		if (promoForm == null) {
			return null;
		}

		Date now = new Date();
		SalesGoodsPromotionRoles role = new SalesGoodsPromotionRoles();

		role.setFromtime(parseDate(promoForm.getBeginTime()));
		role.setTotime(parseDate(promoForm.getEndTime()));
		if (null == role.getFromtime()) {
			return null;
		}
		if (null == role.getTotime()) {
			return null;
		}
		if (role.getFromtime().after(role.getTotime())) { // 校验开始时间是否大于结束时间
			return null;
		}

		role.setId(promoForm.getId());
		role.setCreateby(authData.getUserid());
		role.setCreatetime(now);
		role.setCurrencyCode(tenant.getCurrencyCode());
		role.setDescription(promoForm.getDescription());
		role.setDisabled(promoForm.getEnable() == 0 ? 0 : 1);
		role.setPromotionname(promoForm.getName());
		role.setPromotiontype(promoForm.getPromotionType());
		role.setShopid(tenant.getShopId());
		role.setShowInList(promoForm.getShowInList());
		
		// 计算terminal;
		int terminal = terminalConvert(promoForm.getTerminal());
		role.setTerminal(terminal);

		role.setTerminalName(promoForm.getTerminalName());
		role.setUserId(authData.getUserid());
		role.setStatus(promoForm.getStatus());

		return role;
	}

	/**
	 * 终端计算转换 terminals 转换前终端 pc 1,wap 2 app 3 wechat 4 return terminal 转换后终端
	 */

	private Integer terminalConvert(String terminals) {
		String[] tmp = terminals.split(",");
		int terminal = 0;
		for (int l = 0; l < tmp.length; l++) {
			int tmpNum = Integer.parseInt(tmp[l]);
			if (tmpNum == 1) {// PC
				terminal = terminal + 8;
			} else if (tmpNum == 2) {// WAP
				terminal = terminal + 4;
			} else if (tmpNum == 3) {// APP
				terminal = terminal + 2;
			} else if (tmpNum == 4) {// WECHAT
				terminal = terminal + 1;
			}
		}
		return terminal;
	}

	private SalesGoodsPromotionRoleTails makeDetail(PromoSku mainSku, Integer shopId, String currencyCode) {
		SalesGoodsPromotionRoleTails detail = new SalesGoodsPromotionRoleTails();
		if (null != mainSku.getDiscount()) {
			Money discount = new Money(mainSku.getDiscount(), currencyCode);
			detail.setAmount(discount);
			detail.setDiscountamount(discount);
		}

		detail.setFaId(mainSku.getFaId());
		detail.setCurrencyCode(currencyCode);

		detail.setMainCode(Integer.parseInt(mainSku.getGcode()));
		detail.setMainMaterialType(mainSku.getMaterialType());
		detail.setMainName(mainSku.getName());
		detail.setMainProductMaterial(mainSku.getMaterialNumber());
		detail.setProductgroupId(mainSku.getProductGroup());
		detail.setQuantity(mainSku.getQuantity());
		detail.setProductid1(mainSku.getProductid1());
		detail.setShopId(shopId);
		detail.setFaName(mainSku.getFaName());
		
		return detail;
	}

	private SalesGoodsPromotionRoleTails makeDetail(PromoSku mainSku, PromoSku relSku, String currencyCode) {
		SalesGoodsPromotionRoleTails detail = new SalesGoodsPromotionRoleTails();

		if (null != relSku.getDiscount()) {
			Money discount = new Money(relSku.getDiscount(), currencyCode);
			detail.setAmount(discount);
			detail.setDiscountamount(discount);
		}
		detail.setFaId(mainSku.getFaId());
		detail.setCurrencyCode(currencyCode);
		detail.setMainCode(Integer.parseInt(mainSku.getGcode()));
		detail.setMainMaterialType(mainSku.getMaterialType());
		detail.setMainName(mainSku.getName());
		detail.setProductid1(mainSku.getProductid1());
		detail.setFaName(mainSku.getFaName());
		
		detail.setMainProductMaterial(mainSku.getMaterialNumber());
		detail.setProductgroupId(mainSku.getProductGroup());
		detail.setQuantity(relSku.getQuantity());

		detail.setRelCode(Integer.parseInt(relSku.getGcode()));
		detail.setRelName(relSku.getName());
		detail.setRelMaterialType(relSku.getMaterialType());
		detail.setRelProductMaterial(relSku.getMaterialNumber());
		detail.setProductid2(relSku.getProductid2());

		return detail;
	}

	private Date parseDate(String standardDate) { // 校验日期参数合法性
		String patten = "yyyy-MM-dd HH:mm:ss";
		try {
			return new SimpleDateFormat(patten).parse(standardDate);
		} catch (Exception e) {
			log.error("parse data error " + standardDate, e);
			return null;
		}
	}

	/**
	 * 赠品封装excel 规则 新
	 *
	 * @return
	 */
	private Map<String, ExcelBean> buildDatasGift() {
		// {"主物料编号", "主商品名称", "主商品编码","关联品名称", "关联品物料号", "关联品编码","赠品数量", "开始时间",
		// "截止时间","商城", "促销名称","促销平台","是否启用","状态"}
		Map<String, ExcelBean> tmpMap = new HashMap<>();

		ExcelBean bean1 = new ExcelBean();
		bean1.setName("主物料编号");
		bean1.setOrder(1);
		tmpMap.put("mainProductMaterial", bean1);

		ExcelBean bean2 = new ExcelBean();
		bean2.setName("主商品名称");
		bean2.setOrder(2);
		tmpMap.put("mainName", bean2);

		ExcelBean bean3 = new ExcelBean();
		bean3.setName("主商品编码");
		bean3.setOrder(3);
		tmpMap.put("mainCode", bean3);

		ExcelBean bean4 = new ExcelBean();
		bean4.setName("关联品名称");
		bean4.setOrder(4);
		tmpMap.put("relName", bean4);

		ExcelBean bean5 = new ExcelBean();
		bean5.setName("关联品物料号");
		bean5.setOrder(5);
		tmpMap.put("relProductMaterial", bean5);

		ExcelBean bean6 = new ExcelBean();
		bean6.setName("关联品编码");
		bean6.setOrder(6);
		tmpMap.put("relCode", bean6);

		ExcelBean bean7 = new ExcelBean();
		bean7.setName("赠品数量");
		bean7.setOrder(7);
		tmpMap.put("quantity", bean7);

		ExcelBean bean8 = new ExcelBean();
		bean8.setName("开始时间");
		bean8.setOrder(8);
		tmpMap.put("fromtime", bean8);

		ExcelBean bean9 = new ExcelBean();
		bean9.setName("截止时间");
		bean9.setOrder(9);
		tmpMap.put("totime", bean9);

		ExcelBean bean10 = new ExcelBean();
		bean10.setName("商城");
		bean10.setOrder(10);
		bean10.setIsMapper(1); // 设置映射
		bean10.setMapper(isShopIDView());
		bean10.setIsDefault("未找到对应商城");
		tmpMap.put("shopid", bean10);

		ExcelBean bean11 = new ExcelBean();
		bean11.setName("促销名称");
		bean11.setOrder(11);
		tmpMap.put("promotionName", bean11);

		ExcelBean bean12 = new ExcelBean();
		bean12.setName("促销平台");
		bean12.setOrder(12);
		tmpMap.put("terminalName", bean12);

		ExcelBean bean13 = new ExcelBean();
		bean13.setName("状态");
		bean13.setOrder(13);
		bean13.setIsMapper(1);

		Map<String, Object> map13 = new HashMap<String, Object>();
		map13.put("0", "新建");
		map13.put("1", "待审核");
		map13.put("2", "审核通过");
		map13.put("3", "审核驳回");
		bean13.setMapper(map13);
		bean13.setIsDefault("未知");
		tmpMap.put("status", bean13);

		ExcelBean bean14 = new ExcelBean();
		bean14.setName("是否启用");
		bean14.setOrder(14);
		bean14.setIsMapper(1);
		Map<String, Object> map14 = new HashMap<String, Object>();
		map14.put("0", "否");
		map14.put("1", "是");
		bean14.setMapper(map14);
		tmpMap.put("disabled", bean14);

		return tmpMap;
	}

	// 商城映射
	private Map<String, Object> isShopIDView() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("1", "联想商城");
		map.put("2", "Think商城");
		map.put("4", "Roaming商城");
		map.put("5", "MOTO商城");
		map.put("6", "懂的商城");
		map.put("7", "Think产品中心");
		map.put("8", "17商城");
		map.put("9", "17积分商城");
		map.put("10", "17ask");
		map.put("11", "PCSD商城");
		map.put("12", "moto美国商城");
		map.put("13", "moto加拿大商城");
		map.put("14", "惠商");
		map.put("15", "惠商积分");
		return map;

	}
	
	//映射促销信息状态
	private Map<String, Object> isStatusOk() {
		Map<String, Object> mapper = new HashMap<>();
		mapper.put("0", "新建");
		mapper.put("1", "待审核");
		mapper.put("2", "审核通过");
		mapper.put("3", "审核未通过");
		return mapper;
	}

	/**
	 * 封装excel数据 套餐 选件搭售 新
	 *
	 * @return
	 */
	private Map<String, ExcelBean> buildDatas() {
		// "主物料编号", "主商品名称", "主商品编码","主品优惠金额","关联品名称", "关联品物料号",
		// "关联品编码","关联品优惠金额", "开始时间", "截止时间","商城", "促销名称","促销平台","是否启用","状态"
		Map<String, ExcelBean> tmpMap = new HashMap<>();

		ExcelBean bean1 = new ExcelBean();
		bean1.setName("主物料编号");
		bean1.setOrder(1);
		tmpMap.put("mainProductMaterial", bean1);

		ExcelBean bean2 = new ExcelBean();
		bean2.setName("主商品名称");
		bean2.setOrder(2);
		tmpMap.put("mainName", bean2);

		ExcelBean bean3 = new ExcelBean();
		bean3.setName("主商品编码");
		bean3.setOrder(3);
		tmpMap.put("mainCode", bean3);

		ExcelBean bean4 = new ExcelBean();
		bean4.setName("主品优惠金额");
		bean4.setOrder(4);
		tmpMap.put("discountAmount", bean4);

		ExcelBean bean5 = new ExcelBean();
		bean5.setName("关联品名称");
		bean5.setOrder(5);
		tmpMap.put("relName", bean5);

		ExcelBean bean6 = new ExcelBean();
		bean6.setName("关联品物料号");
		bean6.setOrder(6);
		tmpMap.put("relProductMaterial", bean6);

		ExcelBean bean7 = new ExcelBean();
		bean7.setName("关联品编码");
		bean7.setOrder(7);
		tmpMap.put("relCode", bean7);

		ExcelBean bean8 = new ExcelBean();
		bean8.setName("关联品优惠金额");
		bean8.setOrder(8);
		tmpMap.put("relDiscountAmount", bean8);

		ExcelBean bean9 = new ExcelBean();
		bean9.setName("开始时间");
		bean9.setOrder(9);
		tmpMap.put("fromtime", bean9);

		ExcelBean bean10 = new ExcelBean();
		bean10.setName("截止时间");
		bean10.setOrder(10);
		tmpMap.put("totime", bean10);

		ExcelBean bean11 = new ExcelBean();
		bean11.setName("商城");
		bean11.setOrder(11);
		bean11.setIsMapper(1);
		bean11.setIsDefault("未找到对应商城");
		bean11.setMapper(isShopIDView());
		tmpMap.put("shopid", bean11);

		ExcelBean bean12 = new ExcelBean();
		bean12.setName("促销名称");
		bean12.setOrder(12);
		tmpMap.put("promotionName", bean12);

		ExcelBean bean13 = new ExcelBean();
		bean13.setName("促销平台");
		bean13.setOrder(13);
		tmpMap.put("terminalName", bean13);

		ExcelBean bean14 = new ExcelBean();
		bean14.setName("是否启用");
		bean14.setOrder(14);
		bean14.setIsMapper(1);
		Map<String, Object> map14 = new HashMap<String, Object>();
		map14.put("0", "否");
		map14.put("1", "是");
		bean14.setMapper(map14);
		tmpMap.put("disabled", bean14);

		ExcelBean bean15 = new ExcelBean();
		bean15.setName("状态");
		bean15.setOrder(15);
		bean15.setIsMapper(1);
		Map<String, Object> map15 = new HashMap<String, Object>();
		map15.put("0", "新建");
		map15.put("1", "待审核");
		map15.put("2", "审核通过");
		map15.put("3", "审核驳回");
		bean15.setMapper(map15);
		bean15.setIsDefault("未知");
		tmpMap.put("status", bean15);
		return tmpMap;
	}

	/**
	 * 封装excel数据 新 满减 新
	 *
	 * @param
	 */
	private Map<String, ExcelBean> buildDataFullcut() {
		// "物料编号", "主商品名称", "主商品编号","满减金额", "开始时间", "截止时间","商城", "促销名称",
		// "促销类型","促销平台", "是否启","状态"
		Map<String, ExcelBean> tmpMap = new HashMap<>();

		ExcelBean bean1 = new ExcelBean();
		bean1.setName("物料编号");
		bean1.setOrder(1);
		tmpMap.put("mainProductMaterial", bean1);

		ExcelBean bean2 = new ExcelBean();
		bean2.setName("主商品名称");
		bean2.setOrder(2);
		tmpMap.put("mainName", bean2);

		ExcelBean bean3 = new ExcelBean();
		bean3.setName("主商品编号");
		bean3.setOrder(3);
		tmpMap.put("mainCode", bean3);

		ExcelBean bean4 = new ExcelBean();
		bean4.setName("满减金额");
		bean4.setOrder(4);
		tmpMap.put("fullset", bean4);

		ExcelBean bean5 = new ExcelBean();
		bean5.setName("开始时间");
		bean5.setOrder(5);
		tmpMap.put("fromtime", bean5);

		ExcelBean bean6 = new ExcelBean();
		bean6.setName("截止时间");
		bean6.setOrder(6);
		tmpMap.put("totime", bean6);

		ExcelBean bean7 = new ExcelBean();
		bean7.setName("商城");
		bean7.setOrder(7);
		bean7.setIsMapper(1);
		bean7.setIsDefault("未找到对应商城");
		bean7.setMapper(isShopIDView());
		tmpMap.put("shopid", bean7);

		ExcelBean bean8 = new ExcelBean();
		bean8.setName("促销名称");
		bean8.setOrder(8);
		tmpMap.put("promotionName", bean8);

		ExcelBean bean9 = new ExcelBean();
		bean9.setName("促销类型");
		bean9.setOrder(9);
		bean9.setIsMapper(1);
		bean9.setMapper(isPromotionType());
		tmpMap.put("promotionType", bean9);

		ExcelBean bean10 = new ExcelBean();
		bean10.setName("促销平台");
		bean10.setOrder(10);
		tmpMap.put("terminalName", bean10);

		ExcelBean bean11 = new ExcelBean();
		bean11.setName("是否启用");
		bean11.setOrder(11);
		bean11.setIsMapper(1);
		Map<String, Object> map11 = new HashMap<String, Object>();
		map11.put("0", "否");
		map11.put("1", "是");
		bean11.setMapper(map11);
		tmpMap.put("disabled", bean11);

		ExcelBean bean12 = new ExcelBean();
		bean12.setName("状态");
		bean12.setOrder(12);
		bean12.setIsMapper(1);
		Map<String, Object> map12 = new HashMap<String, Object>();
		map12.put("0", "新建");
		map12.put("1", "待审核");
		map12.put("2", "审核通过");
		map12.put("3", "审核驳回");
		bean12.setMapper(map12);
		bean12.setIsDefault("未知");
		tmpMap.put("status", bean12);
		return tmpMap;
	}

	// 返回促销类型 映射
	private Map<String, Object> isPromotionType() {
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("-1", "普通商品");
		map.put("0", "选件搭售");
		map.put("1", "赠品");
		map.put("3", "套餐");
		map.put("6", "满减");
		map.put("5", "赠品可选");
		map.put("7", "下单立减");
		map.put("8", "限时抢购");
		map.put("9", "折扣专区");

		return map;
	}

	/**
	 * 封装excel数据 新 下单立减 新
	 *
	 * @param
	 */
	private Map<String, ExcelBean> buildDataUnderorder() {
		// "物料编号", "主商品名称", "商品编号","下单立减金额", "开始时间", "结束时间","商城", "促销名称",
		// "促销类型","促销平台", "是否启用","状态"
		Map<String, ExcelBean> tmpMap = new HashMap<>();

		ExcelBean bean1 = new ExcelBean();
		bean1.setName("物料编号");
		bean1.setOrder(1);
		tmpMap.put("mainProductMaterial", bean1);

		ExcelBean bean2 = new ExcelBean();
		bean2.setName("主商品名称");
		bean2.setOrder(2);
		tmpMap.put("mainName", bean2);

		ExcelBean bean3 = new ExcelBean();
		bean3.setName("商品编号");
		bean3.setOrder(3);
		tmpMap.put("mainCode", bean3);

		ExcelBean bean4 = new ExcelBean();
		bean4.setName("下单立减金额");
		bean4.setOrder(4);
		tmpMap.put("discountAmount", bean4);

		ExcelBean bean5 = new ExcelBean();
		bean5.setName("开始时间");
		bean5.setOrder(5);
		tmpMap.put("fromtime", bean5);

		ExcelBean bean6 = new ExcelBean();
		bean6.setName("截止时间");
		bean6.setOrder(6);
		tmpMap.put("totime", bean6);

		ExcelBean bean7 = new ExcelBean();
		bean7.setName("商城");
		bean7.setOrder(7);
		bean7.setIsMapper(1);
		bean7.setIsDefault("未找到对应商城");
		bean7.setMapper(isShopIDView());
		tmpMap.put("shopid", bean7);

		ExcelBean bean8 = new ExcelBean();
		bean8.setName("促销名称");
		bean8.setOrder(8);
		tmpMap.put("promotionName", bean8);

		ExcelBean bean9 = new ExcelBean();
		bean9.setName("促销类型");
		bean9.setOrder(9);
		bean9.setIsMapper(1);
		Map<String, Object> map9 = new HashMap<String, Object>();
		bean9.setMapper(isPromotionType());
		tmpMap.put("promotionType", bean9);

		ExcelBean bean10 = new ExcelBean();
		bean10.setName("促销平台");
		bean10.setOrder(10);
		tmpMap.put("terminalName", bean10);

		ExcelBean bean11 = new ExcelBean();
		bean11.setName("是否启用");
		bean11.setOrder(11);
		bean11.setIsMapper(1);
		Map<String, Object> map11 = new HashMap<String, Object>();
		map11.put("0", "否");
		map11.put("1", "是");
		bean11.setMapper(map11);
		tmpMap.put("disabled", bean11);

		ExcelBean bean12 = new ExcelBean();
		bean12.setName("状态");
		bean12.setOrder(12);
		bean12.setIsMapper(1);
		Map<String, Object> map12 = new HashMap<String, Object>();
		map12.put("0", "新建");
		map12.put("1", "待审核");
		map12.put("2", "审核通过");
		map12.put("3", "审核驳回");
		bean12.setMapper(map12);
		bean12.setIsDefault("未知");
		tmpMap.put("status", bean12);
		return tmpMap;
	}

	/**
	 * @desc 预约信息列表
	 * @author lihc5
	 * @param request
	 * @return
	 */
	@RequestMapping("/reservation")
	@ResponseBody
	public RemoteResult reservation(ReservationListQry request) {
		log.info("reservation request={}", JsonUtil.toJson(request));

		RemoteResult rr = new RemoteResult(false);
		AuthData authData = ThreadLocalObjs.getAuthData();
		Tenant tenant = ThreadLocalObjs.getTenant();

		List<String> shopIds = authData.getShopIds();
		List<String> faIds = authData.getFaIds();

		Map map = request.toMap();
		map.put("shopIds", shopIds);
		map.put("faIds", faIds);

		map.put("shopId", tenant.getShopId()); // 如果没有shopid 就直接返回

		try {
			PageQuery pq = new PageQuery(request.getPageNum(), request.getPageSize());
			RemoteResult<PageModel2<Seckillreservation>> list = null;
			list = promotionAdminRead.getSeckillReservationMainPage(tenant, pq, map);
			return list;
		} catch (Exception e) {
			log.error("api reservation ERROR", e);
			return rr;
		}
	}


    /**
     * 重新缓存reids
     */
	@RequestMapping("/toRedis")
	@ResponseBody
	public RemoteResult reservation() {
	    log.info("toredis");
        RemoteResult<BaseInfo> result = new RemoteResult<>(false);
        try {
            result = promotionAdminWrite.toRedis();
        } catch (Exception e) {
            log.error("toredis error ",e);
        }
        return result;
    }
}