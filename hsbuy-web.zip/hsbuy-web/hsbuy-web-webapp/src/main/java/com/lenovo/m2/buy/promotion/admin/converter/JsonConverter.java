package com.lenovo.m2.buy.promotion.admin.converter;

import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.lenovo.m2.arch.framework.domain.Money;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

import java.util.Arrays;

/**
 * Created by wangrq1 on 2017/1/17.
 */
public class JsonConverter extends MappingJackson2HttpMessageConverter {


    public JsonConverter(){
        Jackson2ObjectMapperBuilder builder = Jackson2ObjectMapperBuilder.json();
        ObjectMapper mapper = builder.build();
        //post configure
        SimpleModule module = new SimpleModule("money", Version.unknownVersion());
        module.addSerializer(Money.class, new MoneySerializer());
        mapper.registerModule(module);

        this.objectMapper = mapper;

        setSupportedMediaTypes(Arrays.asList(new MediaType("application", "json", DEFAULT_CHARSET),
                new MediaType("application", "*+json", DEFAULT_CHARSET)));
    }



}
