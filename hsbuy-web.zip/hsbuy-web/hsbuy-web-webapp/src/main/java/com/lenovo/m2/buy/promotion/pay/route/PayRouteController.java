package com.lenovo.m2.buy.promotion.pay.route;

import com.alibaba.fastjson.JSON;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.SSOUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.JacksonUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PayConfig;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.ReturnCode;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.StringUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.BaseInfo;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.DateUtil;
import com.lenovo.m2.buy.promotion.admin.domain.pay.FakePayModel;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.*;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.PayFakeRulesManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayFakeRules;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 支付入口，根据payType分发
 * Created by MengQiang on 2015/5/18.
 */
@Controller
@Scope("prototype")
public class PayRouteController {
    private final Logger LOGGER = Logger.getLogger(PayRouteController.class);

    @Autowired
    private AliPayJsManager aliPayJsManager;
    @Autowired
    private AliPaySjManager aliPaySjManager;
    @Autowired
    private AliPayDirectWapManager aliPayDirectWapManager;
    @Autowired
    private AliPayCwgManager aliPayCwgManager;
    @Autowired
    private AliPayCommonManager aliPayCommonManager;

    @Autowired
    private PayOrderApi payOrderApi;

    //@Autowired
    //private CashierManager cashierManager;
    @Autowired
    private CommonManager commonManager;
    @Autowired
    private PayFakeRulesManager payFakeRulesManager;
    @Autowired
    private PayPortalOrderManager payPortalOrderManager;
    @Autowired
    private CommonCallBackManager commonCallBackManager;

    //@Autowired
    //private UmpayManager umpayManager;

    @RequestMapping(value = "/pay", produces = {"text/html;charset=UTF-8"})
    @ResponseBody
    public String pay(HttpServletRequest request, HttpServletResponse response) {
        String payType = request.getParameter("paymentTypeCode");
        String orderMainCode = request.getParameter("orderMainCode");
        String directbank = request.getParameter("directbank");
        String callback = request.getParameter("callback");
        String merchantCode = request.getParameter("merchantCode");
        String shopId = request.getParameter("shopId");
        String terminal = request.getParameter("terminal");
        String plat = request.getParameter("plat");
        if (StringUtils.isEmpty(plat)) {
            plat = CommonMethod.getPlatFromShopIdTerminal(shopId, terminal);
        }
        LOGGER.info("Https Pay Router Ready To Go! payType[" + payType + "],orderMainCode[" + orderMainCode + "],merchantCode[" + merchantCode + "],shopId[" + shopId + "],terminal[" + terminal + "],directBank[" + directbank + "],plat[" + plat + "],callback[" + callback + "]");
        Map<String, Object> paraMap = PropertiesHelper.loadToMap("pay_switch.properties");
        String returnInfo = "";
        if (SSOUtil.isSsoSwitch() && "4".equals(plat)) {
            if (SSOUtil.islogin(request)) {
                if (isFakePay(request, paraMap)) {
                    returnInfo = fakePay(request, callback);
                } else {
                    response.setCharacterEncoding("UTF-8");
                    response.setContentType("text/html");
                    RemoteResult<String> returnResult = new RemoteResult<String>();
                    returnInfo = realPay(payType, request, returnResult, response, callback, merchantCode,terminal);
                }
                LOGGER.info("Invoke Pay Router Finish ! orderMainCode[" + orderMainCode + "],returnInfo[" + returnInfo + "]");
                return returnInfo;
            } else {
                return SSOUtil.ssoLoginUrl(orderMainCode, payType, callback, directbank);
            }
        } else {
            if (isFakePay(request, paraMap)) {
                returnInfo = fakePay(request, callback);
            } else {
                response.setCharacterEncoding("UTF-8");
                response.setContentType("text/html");
                RemoteResult<String> returnResult = new RemoteResult<String>();
                returnInfo = realPay(payType, request, returnResult, response, callback, merchantCode,terminal);
            }
            LOGGER.info("Invoke Pay Router Finish ! orderMainCode[" + orderMainCode + "],returnInfo[" + returnInfo + "]");
            return returnInfo;
        }
    }


    public String realPay(String payType, HttpServletRequest request, RemoteResult<String> returnResult, HttpServletResponse response, String callback, String merchantCode, String terminal) {
        try {
            String plat = request.getParameter("plat");
            String termial = request.getParameter("terminal");

            if (PeakConstant.PAY_TYPE_ALJS.equals(payType)) {
                returnResult = aliPayJsManager.toAliJsPay(request);
                LOGGER.info("支付宝默认支付Form表单:");
            }else if (PeakConstant.PAY_TYPE_ALCWG.equals(payType)) {
                returnResult = aliPayCwgManager.toAliCwgPay(request);
                LOGGER.info("支付宝纯网关支付Form表单:");
            }else {
                LOGGER.info("订单支付类型错误！[" + payType + "]");
                returnResult.setSuccess(false);
                returnResult.setResultCode("30009");
                returnResult.setResultMsg("支付类型错误");
            }
            if (returnResult.isSuccess()) {
                LOGGER.info("表单信息[" + returnResult.getT() + "],merchantCode[" + merchantCode + "]");
                if (StringUtils.isNotEmpty(merchantCode) && "roaming".equals(merchantCode)) {
                    LOGGER.info("Roaming Return");
                    return JacksonUtil.toJson(new BaseInfo(0, returnResult.getT().toString()));
                }
                return callback + "(" + JacksonUtil.toJson(new BaseInfo(0, returnResult.getT().toString())) + ")";
            } else {
                LOGGER.info("merchantCode[" + merchantCode + "]");
                response.setContentType("application/json; charset=UTF-8");
                if (StringUtils.isNotEmpty(merchantCode) && "roaming".equals(merchantCode)) {
                    LOGGER.info("Roaming Return");
                    return JacksonUtil.toJson(new BaseInfo(1, returnResult.getResultMsg()));
                }
                return callback + "(" + JacksonUtil.toJson(new BaseInfo(1, returnResult.getResultMsg())) + ")";
            }
        } catch (Exception oe) {
            LOGGER.error("MerchantCode[" + merchantCode + "],支付的过程中出现异常", oe);
            response.setContentType("application/json; charset=UTF-8");
            returnResult.setSuccess(false);
            returnResult.setResultCode(ReturnCode.PayParamError.getCode());
            returnResult.setResultMsg(ReturnCode.PayParamError.getMessage());
            if (StringUtils.isNotEmpty(merchantCode) && "roaming".equals(merchantCode)) {
                LOGGER.info("Roaming Return");
                return JacksonUtil.toJson(new BaseInfo(2006, returnResult.getResultMsg()));
            }
            return callback + "(" + JacksonUtil.toJson(new BaseInfo(2006, returnResult.getResultMsg())) + ")";
        }
    }


    private boolean isFakePay(HttpServletRequest request, Map paySwitchMap) {
        try {
            String isFakePay = (String) paySwitchMap.get("fakepaySwitch");
            Map<String, Object> resouceMap = PayConfig.loadToMap();
            String payEnvironment = (String) resouceMap.get("PAY_ENVIRONMENT");
            String merchantCode = request.getParameter("merchantCode");
            LOGGER.info("Https CheckFakePay Ready To GO! isFakePay[" + isFakePay + "],payEnvironment[" + payEnvironment + "],merchantCode[" + merchantCode + "]");
            if ("0".equals(isFakePay) || "pro".equals(payEnvironment) || ("roaming".equals(merchantCode))) {
                return false;
            }
            String lenovoId = request.getParameter("lenovoId");
            String payType = request.getParameter("paymentTypeCode");
            String orderMainCode = request.getParameter("orderMainCode");
            String shopId = request.getParameter("shopId");
            if(PeakConstant.PAY_TYPE_WECHAT.equals(payType)|| PeakConstant.PAY_TYPE_WECHAT_JSAPI.equals(payType)|| PeakConstant.PAY_TYPE_WECHAT_H5.equals(payType)|| PeakConstant.PAY_TYPE_WECHAT_APP.equals(payType)){
                return false;
            }
            int count = orderMainCode.split(",").length;
            if (count > 1) {
                orderMainCode = orderMainCode.split(",")[0];
            }
            Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
            RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(orderMainCode, lenovoId, tenant);
            PayPortalOrder payPortalOrder;
            MerchantPayPlatView merchantPayPlatView;
            if (payPortalOrderRemoteResult.isSuccess()) {
                payPortalOrder = payPortalOrderRemoteResult.getT();
                LOGGER.info("Check FakePay Get PayPortalOrder SUCCESS[" + payPortalOrder + "]");
            } else {
                LOGGER.info("Check FakePay Get PayPortalOrder Fail, Go RealPay");
                return false;
            }
            if (StringUtil.isEmpty(payPortalOrder.getOutTradeNo())) {
                LOGGER.info("Check FakePay Get PayPortalOrder Fail, Go RealPay");
                return false;
            }
            if ("1".equals(payPortalOrder.getPaymentWay())) {
                commonManager.getLedgerFAID(payPortalOrder);
            }
            RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult = aliPayCommonManager.getMerchantPayPlatView(payPortalOrder.getFaId(), payType);
            if (merchantPayPlatViewRemoteResult.isSuccess()) {
                LOGGER.info("Check FakePay Get MerchantPayPlat SUCCESS");
                merchantPayPlatView = merchantPayPlatViewRemoteResult.getT();
            } else {
                LOGGER.info("Check FakePay Get merchantPayPlatView Fail, Go RealPay");
                return false;
            }
            if (StringUtil.isEmpty(merchantPayPlatView.getMerchantId())) {
                LOGGER.info("Get Fake merchantPayPlatView Fail, Go RealPay");
                return false;
            }
            RemoteResult<List<PayFakeRules>> payFakeRulesListResult = payFakeRulesManager.queryFakePayList(lenovoId);
            PayFakeRules payFakeRules;
            String merchantId = merchantPayPlatView.getMerchantId();
            if (payFakeRulesListResult.isSuccess() && payFakeRulesListResult.getT().size() > 0) {
                payFakeRules = payFakeRulesListResult.getT().get(0);
            } else {
                LOGGER.info("Get Fake payFakeRules Fail, Go RealPay");
                return false;
            }
            if (StringUtil.isEmpty(payFakeRules.getFakeRules())) {
                LOGGER.info("Get Fake payFakeRules Fail, Go RealPay");
                return false;
            }
            List<FakePayModel> fakeRuleList = JSON.parseArray(payFakeRules.getFakeRules(), FakePayModel.class);
            String fakePayType = "";
            for (FakePayModel fakePayModel : fakeRuleList) {
                if (fakePayModel.getFakeFaID().equals(merchantId)) {
                    fakePayType = fakePayModel.getFakePayType();
                    break;
                }
            }
            if (fakePayType.contains(payType)) {
                LOGGER.info("Go FakePay, OrderMainCode[" +orderMainCode+ "]");
                return true;
            } else {
                LOGGER.info("Go RealPay, OrderMainCode[" +orderMainCode+ "]");
                return false;
            }
        } catch (Exception e) {
            LOGGER.error("Check FakePay Exception, Go RealPay" ,e);
            return false;
        }
    }

    private String fakePay(HttpServletRequest request, String callback) {
        String orderMainCode = request.getParameter("orderMainCode");
        String lenovoId = request.getParameter("lenovoId");
        String plat = request.getParameter("plat");
        String payType = request.getParameter("paymentTypeCode");
        String gmt_payment = DateUtil.formatDate(new Date(), "yyyyMMddHHmmss");
        String defaultbank = request.getParameter("directbank");
        String shopId = request.getParameter("shopId");
        String terminal = request.getParameter("terminal");
        LOGGER.info("Https FakePay Ready To GO! orderMainCode[" + orderMainCode + "],lenovoId[" + lenovoId + "],plat[" + plat + "]"+ "],payType[" + payType + "]"+ "],gmt_payment[" + gmt_payment + "]"+ "],defaultbank[" + defaultbank + "]"+ "],shopId[" + shopId + "]"+ "],terminal[" + terminal + "]");
        String payTransactionId;
        String total_fee = null;
        StringBuffer returnStringBuffer = new StringBuffer();
        Map<String, Object> aliPayMap = PropertiesHelper.loadToMap("ali_pay.properties");
        String fakePayReturnURL = null;
        if(PeakConstant.SHOPID_SMB.equals(shopId)){
            fakePayReturnURL = (String) aliPayMap.get("FAKE_PAY_SMB_RETURN");
        } else {
            fakePayReturnURL = (String) aliPayMap.get("FAKE_PAY_RETURN");
        }
        try {
            Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
            RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(orderMainCode, lenovoId, tenant);
            PayPortalOrder payPortalOrder;
            if (payPortalOrderRemoteResult.isSuccess()) {
                payPortalOrder = payPortalOrderRemoteResult.getT();
                LOGGER.info("FakePay Get PayPortalOrder SUCCESS ,PayPortalOrder[" + payPortalOrderRemoteResult + "]");
            } else {
                LOGGER.info("Get FakePay PayPortalOrder Fail");
                return callback + "(" + JacksonUtil.toJson(new BaseInfo(1, "查询订单失败")) + ")";
            }
            if ("1".equals(payPortalOrder.getPaymentWay())) {
                commonManager.getLedgerFAID(payPortalOrder);
            }
            total_fee = String.valueOf(payPortalOrder.getTotalFee().getAmount());
            String currencyCode = payPortalOrder.getCurrencyCode();
            RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult = aliPayCommonManager.getMerchantPayPlatView(payPortalOrder.getFaId(), payType);
            LOGGER.info("FakePay MerchantPayPlatResult[" + merchantPayPlatViewRemoteResult +"]");
            RemoteResult<List<PayOrder>> orderListResult = new RemoteResult<List<PayOrder>>();
            RemoteResult<String> savePayOrderRemoteResult;
            try {
                orderListResult = aliPayCommonManager.getOrderListByPayType(orderMainCode, Integer.parseInt(payType));
            } catch (Exception e) {
                LOGGER.error("Check PayOrder Exist Fail，OrderMainCode[" + orderMainCode + "]");
            }
            if (orderListResult != null && orderListResult.isSuccess() && orderListResult.getT().size() > 0) {
                payTransactionId = String.valueOf(orderListResult.getT().get(0).getId());
                LOGGER.info("Check PayOrder Already Exist，PrimaryId[" + payTransactionId + "]");
            } else {
                savePayOrderRemoteResult = commonManager.savePayOrder(lenovoId,plat,payType,orderMainCode,total_fee,"假支付","",0,"",request.getParameter("merchantCode"),defaultbank,shopId,terminal,merchantPayPlatViewRemoteResult.getT(),currencyCode);
                payTransactionId = savePayOrderRemoteResult.getT();
                LOGGER.info("Check PayOrder Not Exist, PrimaryId[" + payTransactionId + "]");
            }
            String payTime = DateUtil.formatDate(new Date(), PeakConstant.CALL_MIDDLEWARE_PAY_TYPE);
            Map<String, String> paraMap = new HashMap<String, String>();
            paraMap.put("payTime", payTime);
            paraMap.put("payment", payType);
            paraMap.put("payAcc", "fakeBuyer");
            // 改为从数据库获取
            PayOrder payOrder = payOrderApi.getPayOrderByPrimaryId(Long.valueOf(payTransactionId));
            payOrder.setTransation_id("fake" + payTransactionId);
            payOrder.setU_id(payPortalOrder.getLenovoId());
            payOrder.setOut_trade_no(orderMainCode);
            RemoteResult<String> remoteResult = commonCallBackManager.paidCallback(payPortalOrder, payOrder, merchantPayPlatViewRemoteResult.getT(), paraMap);
            LOGGER.info("Call MiddleWare Return[" + remoteResult + "]");
            PayPortalOrder updatePayPortalOrder = this.getUpdatePayPortalOrder(orderMainCode, lenovoId, payTransactionId, payType, shopId);
            RemoteResult<Integer> updatePayPortalOrderResult = payPortalOrderManager.updatePayPortalOrderPayStatus(updatePayPortalOrder);
            LOGGER.info("Update PayPortalOrder Return[" + updatePayPortalOrderResult + "]");
            payOrderApi.updateAliPayNotifyState(payTransactionId, lenovoId, "fake" + payTransactionId, PeakConstant.MFLAG_SUCC, "fake" + payTransactionId, PeakConstant.TRADE_SUCCESS, null, Integer.parseInt(payType));
            returnStringBuffer.append("<script>");
            returnStringBuffer.append("window.location ='" + fakePayReturnURL + "?out_trade_no=" + payTransactionId + "&trade_status=" + "TRADE_SUCCESS&total_fee=" + total_fee + "'");
            returnStringBuffer.append("</script>");
        } catch (Exception e) {
            LOGGER.error("Call FakePay Exception -->", e);
            returnStringBuffer.append("<script>");
            returnStringBuffer.append("window.location ='" + fakePayReturnURL + "?out_trade_no=" + orderMainCode + "&trade_status=" + "FAKEPAY_FAIL&total_fee=" + total_fee + "'");
            returnStringBuffer.append("</script>");
        }
        LOGGER.info("Call Fake Return URL[" + returnStringBuffer.toString() + "]");

        return callback + "(" + JacksonUtil.toJson(new BaseInfo(0, returnStringBuffer.toString())) + ")";
    }




    @RequestMapping("/pay_wxAlipay")
    public String payWxAlipay(HttpServletRequest request, HttpServletResponse response, Map<String, Object> alipaymap) {
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html");
        RemoteResult returnResult = aliPaySjManager.toAliSjPayWxAlipay(request, alipaymap);
        if (returnResult.isSuccess()) {
            alipaymap = (HashMap) returnResult.getT();
            LOGGER.info("微信下支付宝请求-->" + alipaymap.get("wxallipayurl"));
            return "weixin/alipay";
        } else {
            return "403";
        }
    }

    private PayPortalOrder getUpdatePayPortalOrder(String orderMainCode, String lenovoId, String payTransactionId, String payType, String shopId) {
        PayPortalOrder updatePayPortalOrder = new PayPortalOrder();
        updatePayPortalOrder.setOutTradeNo(orderMainCode);
        updatePayPortalOrder.setLenovoId(lenovoId);
        updatePayPortalOrder.setPayment(Integer.parseInt(payType));
        updatePayPortalOrder.setTransationId("fake" + payTransactionId);
        updatePayPortalOrder.setPayStatus(1);
        updatePayPortalOrder.setShopId(shopId);
        updatePayPortalOrder.setPayTime(new Date());
        return updatePayPortalOrder;
    }
}
