package com.lenovo.m2.buy.promotion.pay.umpay;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.LePayConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.LePayUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayJsManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import com.lenovo.utils.StringUtils;
import com.umpay.api.common.ReqRule;
import com.umpay.api.exception.ParameterCheckException;
import com.umpay.api.paygate.v40.Plat2Mer_v40;
import com.umpay.api.util.ServiceMapUtil;
import com.umpay.api.util.SignUtil;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * 联动优势平台回调控制器
 * Created by tianchuyang on 2016/11/9.
 */
@Controller
@Scope("prototype")
@RequestMapping(value = "/umpay")
public class UmPayController {

    private final Logger logger = Logger.getLogger(this.getClass());

    @Autowired
    private CommonCallBackManager commonCallBackManager;

    @Autowired
    private PayPortalOrderManager payPortalOrderManager;

    @Autowired
    private PayOrderApi payOrderApi;

    @Autowired
    private AliPayJsManager aliPayJsManager;

    /**
     * 同步回调
     *
     * @param request
     * @param response
     * @return 结果页面url
     */
    @RequestMapping(value = "/payRsltPage")
    public String syncCallback(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {

        String orderId = request.getParameter("order_id");    // 商户唯一订单号
        String terminal = request.getParameter("mer_priv");    // 商户拓展字段
        logger.info("联动优势支付同步回调=========================>商户订单号:"+orderId+", 终端号："+terminal);
        PayOrder payOrder = null;
        RemoteResult<MerchantPayPlatView> merchantPayPlatRemoteResult = null;
        MerchantPayPlatView merchantPayPlatView = null;
        // 根据订单号查询订单状态
        if (StringUtils.isNotEmpty(orderId)) {
            payOrder = commonCallBackManager.getPayOrderById(orderId);
        } else {
            paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
            logger.info("支付结果返回的参数错误！");
            return CommonMethod.getOutPayFailPage(terminal);
        }
        logger.info("Umpay Original PayOrder [" + payOrder + "]");
        if (null != payOrder) {
            merchantPayPlatRemoteResult = commonCallBackManager.getMerchantPayPlatById(payOrder.getMerchant_id());
        } else {
            paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
            logger.info("UmPay Original PayOrder Is Null, OrderPrimaryId[" + orderId + "]");
            return CommonMethod.getOutPayFailPage(terminal);
        }
        if (merchantPayPlatRemoteResult.isSuccess()) {
            merchantPayPlatView = merchantPayPlatRemoteResult.getT();
            logger.info("UmPay Original MerchantPayPlat [" + merchantPayPlatView + "]");
        } else {
            logger.info("UmPay Original MerchantPayPlat Is Null");
            paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
            return CommonMethod.getOutPayFailPage(terminal);
        }
        Map paramsMap = new HashMap();
        String name = "";
        String values = "";
        for (Enumeration names = request.getParameterNames(); names.hasMoreElements(); paramsMap.put(name, values)) {
            name = (String) names.nextElement();
            values = request.getParameter(name);
        }
        try {
            Plat2Mer_v40.getPlatNotifyData(paramsMap); // 验签
            if (LePayConstant.TRADE_SUCC_UMPAY.equals(request.getParameter("trade_state"))) {
                logger.info("Umpay TRADE_SUCCESS ,orderId[" + orderId + "]");
                try {
                    Tenant tenant = CommonMethod.buildTenant(payOrder.getShop_id(), null, null, null, null, null, null);
                    RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByShowTradeNo(String.valueOf(payOrder.getOut_trade_no()), null, tenant);
                    if (payPortalOrderRemoteResult.isSuccess()) {
                        Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
                        return CommonMethod.getOutSyncReturnForm(payOrder, merchantPayPlatView, payPortalOrderRemoteResult.getT(), paraMap, commonParam, "TRADE_SUCCESS", String.valueOf(payOrder.getId()));
                    }else {
                        logger.info("Umpay Sync CallBack Invoke queryPayPortalOrderByShowTradeNo Fail! out_trade_no=" + payOrder.getOut_trade_no());
                        paraMap.put("error_msg", "支付异常,未查询到有效订单");
                        return CommonMethod.getOutPayFailPage(terminal);
                    }
                } catch (Exception e) {
                    logger.info("Umpay Call MiddleWare FAIL, OrderPrimaryId[" + orderId + "] Error Cause By :" + e);
                    paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
                    return CommonMethod.getOutPayFailPage(terminal);
                }
            } else {
                logger.info("Umpay trade fail ! Umpay trade_state=" + paramsMap.get("trade_state"));
                paraMap.put("error_msg", "订单支付失败");
            }
        } catch (Exception e) {
            //如果验签失败，则抛出异常，返回ret_code=1111
            logger.info("联动优势支付同步回调验证签名发生异常 Error Cause By :" + e);
            paraMap.put("error_msg", "支付结果异常,请确认订单状态后重试");
        }
        return CommonMethod.getOutPayFailPage(terminal);
    }

    /**
     * 联动优势支付异步回调接口
     *
     * @param request
     * @param response
     */
    @RequestMapping(value = "/payRsltMsg")
    public void asyncCallback(HttpServletRequest request, HttpServletResponse response) {

        String orderId = request.getParameter("order_id");    // 商户唯一订单号
        String transactionId = request.getParameter("trade_no");    // U付交易号
        String paySeq = request.getParameter("pay_seq");    // 银行流水
        logger.info("联动优势支付异步回调=========================>orderId["+orderId+"],transactionId["+transactionId+"],paySeq["+paySeq+"]");
        PayOrder payOrder = null;
        OutputStream out = null;
        RemoteResult<MerchantPayPlatView> merchantPayPlatRemoteResult = null;
        MerchantPayPlatView merchantPayPlatView = null;
        // 根据订单号查询订单状态
        if (StringUtils.isNotEmpty(orderId)) {
            payOrder = commonCallBackManager.getPayOrderById(orderId);
        } else {
            logger.info("支付结果返回的参数错误！商户订单号："+orderId);
            return;
        }
        logger.info("Umpay Original PayOrder [" + payOrder + "]");
        if (null != payOrder) {
            merchantPayPlatRemoteResult = commonCallBackManager.getMerchantPayPlatById(payOrder.getMerchant_id());
        } else {
            logger.info("UmPay Original PayOrder Is Null, OrderPrimaryId[" + orderId + "]");
            return;
        }
        if (merchantPayPlatRemoteResult.isSuccess()) {
            merchantPayPlatView = merchantPayPlatRemoteResult.getT();
            logger.info("UmPay Original MerchantPayPlat [" + merchantPayPlatView + "]");
        } else {
            logger.info("UmPay Original MerchantPayPlat Is Null");
            return;
        }
        //获取联动平台支付结果通知数据（商户应采取循环遍历方式获取平台通知数据,不应采取固定编码的方式获取固定字段，
        Map paramsMap = new HashMap();
        String name = "";
        String values = "";
        for (Enumeration names = request.getParameterNames(); names.hasMoreElements(); paramsMap.put(name, values)) {
            name = (String) names.nextElement();
            values = request.getParameter(name);
        }
        try {
            Plat2Mer_v40.getPlatNotifyData(paramsMap);
            // 交易成功
            if (LePayConstant.TRADE_SUCC_UMPAY.equals(request.getParameter("trade_state"))) {
                logger.info("Umpay TRADE_SUCCESS ,OrderPrimaryId[" + orderId + "]");
                out = response.getOutputStream();
                RemoteResult<String> result = null;
                Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
                Map<String, String> paraMap = new HashMap<String, String>();
                paraMap.put("tradeStatus", request.getParameter("trade_state"));
                paraMap.put("tradeNo",orderId);  // 商户下单时提交的order_id
                paraMap.put("gmtPayment", request.getParameter("pay_date")+ LePayUtil.getDate().substring(8));
                paraMap.put("notifyId", request.getParameter("mer_date"));  // 商户订单日期
                paraMap.put("payType", String.valueOf(payOrder.getPay_type()));
                paraMap.put("bankSeqNo",transactionId); // U付交易号
                logger.info("联动优势支付异步回调通知外部系统,orderId[" + orderId + "]"+"tradeStatus[" + request.getParameter("trade_state") + "]"+"bankSeqNo[" + request.getParameter("pay_seq"));
                if (PeakConstant.TRADE_SUCCESS == payOrder.getTrade_state() && PeakConstant.MFLAG_SUCC == payOrder.getMerchant_flag()) {
                    logger.info("通联支付异步已回调====>订单,orderPrimaryId[" + orderId + "]，" + "订单交易状态："+payOrder.getTrade_state());
                    out.write(buildRespUmpayStr(request,true).getBytes("UTF-8"));
                    out.close();
                } else {
                    if(CommonMethod.checkInShopId(payOrder.getShop_id())){
                        logger.info("通联支付异步回调，支付系统通过dubbo通知商户系统，shopId[" + payOrder.getShop_id() + "],orderPrimaryId[" + orderId + "]");
                        result = aliPayJsManager.callUpdate(payOrder.getU_id(), orderId, transactionId, paraMap.get("gmtPayment"), merchantPayPlatView.getMerchantId(), String.valueOf(payOrder.getPay_type()), merchantPayPlatView, paraMap.get("notifyId"), null);
                    }else{
                        logger.info("通联支付异步回调，支付系统通过HTTP通知商户系统，shopId[" + payOrder.getShop_id() + "],orderPrimaryId[" + orderId + "]");
                        result = commonCallBackManager.callOutUpdate(payOrder, merchantPayPlatView, paraMap, commonParam);
                    }
                    if (result.isSuccess()) {
                        logger.info("通联支付异步回调通知外部系统成功！orderPrimaryId[" + orderId + "]");
                        payOrderApi.updateAliPayNotifyState(String.valueOf(payOrder.getId()), payOrder.getU_id(), transactionId, PeakConstant.MFLAG_SUCC, paraMap.get("notifyId"), PeakConstant.TRADE_SUCCESS, paySeq, Integer.parseInt(paraMap.get("payType")));
                        out.write(buildRespUmpayStr(request,true).getBytes("UTF-8"));
                        out.close();
                    } else {
                        logger.info("通联支付异步回调通知外部系统失败！orderPrimaryId[" + orderId + "]");
                        payOrderApi.updateAliPayNotifyState(String.valueOf(payOrder.getId()), payOrder.getU_id(), transactionId, PeakConstant.MFLAG_REPEAT, paraMap.get("notifyId"), PeakConstant.TRADE_SUCCESS, paySeq, Integer.parseInt(paraMap.get("payType")));
                        out.write(buildRespUmpayStr(request,false).getBytes("UTF-8"));
                        out.close();
                    }
                }
            }else {
                logger.info("联动优势验签失败！======================>,order_id[" + orderId + "]");
            }
        } catch (Exception e) {
            logger.info("联动优势支付结果异步回调验证签名发生异常 Error Cause By :",e);
            try {
                out.write(buildRespUmpayStr(request,false).getBytes("UTF-8"));
            } catch (IOException e1) {
                logger.info("联动优势支付通知平台异常！ Error Cause By:",e);
            }finally {
                try {
                    out.close();
                } catch (IOException e1) {
                    logger.info("联动优势支付通知平台关闭输出流异常！ Error Cause By:",e);
                }
            }
        }
    }

    private String buildRespUmpayStr(HttpServletRequest request, boolean success){
        Map<String,String> resData = new HashMap<String, String>();
        if (success){
            resData.put("ret_code","0000");
            resData.put("ret_msg", "success");
        }else {
            resData.put("ret_code","1111");
            resData.put("ret_msg", "failed");
        }
        resData.put("mer_id", request.getParameter("mer_id"));
        resData.put("sign_type", request.getParameter("sign_type"));
        resData.put("version", request.getParameter("version"));
        resData.put("mer_date", request.getParameter("mer_date"));
        Map<String,String> resMap = conMeta(resData);
        StringBuffer sb = new StringBuffer();
        sb.append("<META NAME=\"MobilePayPlatform\" CONTENT=\"").append(resMap.get("plain")).append("&sign=").append(resMap.get("sign")).append("\" />");
        return sb.toString();
    }

    private Map<String,String> conMeta(Map<String,String> map) throws ParameterCheckException {
        logger.info("商户请求map:" + map);
        Object[] obj = map.keySet().toArray();
        Object object = null;
        Map ruleMap = ServiceMapUtil.getReqRule();
        Arrays.sort(obj);
        String value = null;
        StringBuffer plainString = new StringBuffer();
        StringBuffer signString = new StringBuffer();
        ReqRule rq = null;

        String plain;
        String sign;
        try {
            for(int returnMap = 0; returnMap < obj.length; ++returnMap) {
                String str = obj[returnMap].toString();
                value = map.get(str).toString();
                object = ruleMap.get(str);
                if(object == null) {
                    logger.info("商户请求的字段名：" + str + "在规范文档中不存在！");
                    plainString.append(str).append("=").append(value).append("&");
                    signString.append(str).append("=").append(value).append("&");
                } else {
                    rq = (ReqRule)object;
                    if(!"".equals(rq.getRegex()) && !Pattern.matches(rq.getRegex(), value)) {
                        logger.info("请求字段中" + str + "字段的值不满足字段规则" + rq.getRegex() + "字段值为：" + value);
                        throw new ParameterCheckException("请求字段" + str + "在进行规则校验发生异常");
                    }

                    if(rq.getLength() > 0 && value.length() > rq.getLength()) {
                        logger.info("请求字段中" + str + "字段的值不满足字段长度规则：" + rq.getLength());
                        throw new ParameterCheckException("请求字段" + str + "在进行规则校验发生异常");
                    }

                    if("sign_type".equals(str)) {
                        plainString.append(str).append("=").append(value).append("&");
                    } else {
                        plainString.append(str).append("=").append(value).append("&");
                        signString.append(str).append("=").append(value).append("&");
                    }
                }
            }
            plain = plainString.subSequence(0, plainString.length() - 1).toString();
            sign = signString.substring(0, signString.length() - 1).toString();
            logger.info("请求数据获得的加密明文串为：" + sign);
            sign = SignUtil.sign(sign,"3959000");
            logger.info("请求数据获得的加密串为：" + sign);
        } catch (Exception var12) {
            logger.info("进行字段规则校验发生异常" + var12);
            throw new ParameterCheckException("组织商户返回平台数据发生异常" + var12);
        }
        HashMap<String,String> resMap = new HashMap();
        resMap.put("plain", plain);
        resMap.put("sign", sign);
        return resMap;
    }
}