package com.lenovo.m2.buy.promotion.admin.controller.api.promotion;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lenovo.m2.buy.promotion.admin.common.utils.DateUtils;
import com.lenovo.m2.buy.promotion.admin.controller.util.ThreadLocalObjs;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.SalesGoodsPromotionRoles;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.SessionUser;

import java.util.Arrays;

/**
 * Created by luqian on 2016-04-07.
 */
public class PromotionApiBase {

    private static Logger log = LoggerFactory.getLogger(PromotionApiBase.class);
    /**
     * @desc 初始化用户信息
     * @author luqian
     * @param userId
     * @return
     */
    protected SessionUser initUser(String userId) {
        SessionUser sessionUser =   new SessionUser();
        sessionUser.setItcode(userId);
        sessionUser.setFas((Arrays.asList("79d23d96-4ef1-11e5-8c07-0017fa00093d", "373a20db-31a6-4549-adb6-284b95add7b7", "79d274a2-4ef1-11e5-8c07-0017fa00093d", "423b264c-cbf8-11e4-924a-fa163ebedc0f", "4d0070a9-40c9-4580-a99c-40aec8e3f1b7", "79d28f7a-4ef1-11e5-8c07-0017fa00093d", "79d26732-4ef1-11e5-8c07-0017fa00093d", "79d29647-4ef1-11e5-8c07-0017fa00093d", "423b5dd4-cbf8-11e4-924a-fa163ebedc0f", "423b2568-cbf8-11e4-924a-fa163ebedc0f")));
        sessionUser.setShopIds(Arrays.asList("1","2","3","4","5","6","7","8"));
        ThreadLocalObjs.setUser(sessionUser);
        return ThreadLocalObjs.getUser();
    }

    /**
     * @author luqian
     * @param roles
     * @param request
     * @return
     */
    public SalesGoodsPromotionRoles toSalesPromo(SalesGoodsPromotionRoles roles,HttpServletRequest request){
        String shopid = request.getParameter("shopId");
        String begin_time = request.getParameter("begin_time");
        String end_time = request.getParameter("end_time");
        String disable = request.getParameter("disable");
        String promotiontype = request.getParameter("promotionType");
        String name = request.getParameter("name");
        roles.setShopid(Integer.valueOf(shopid));
        roles.setDisabled(Integer.valueOf(disable));
        roles.setPromotiontype(Integer.valueOf(promotiontype));
        roles.setFromtime(DateUtils.getFormatDate(begin_time,"yyyy-MM-ddHH:mm:ss"));
        roles.setTotime(DateUtils.getFormatDate(end_time, "yyyy-MM-ddHH:mm:ss"));
        roles.setPromotionname(name);
        return  roles;
    }

}
