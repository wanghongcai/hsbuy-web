package com.lenovo.m2.buy.promotion.admin.controller.api.inventory;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSONArray;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.remote.inventory.StockRemoteService;
import com.lenovo.m2.hsbuy.common.util.JacksonUtil;
import com.lenovo.m2.hsbuy.domain.inventory.FaBaseInfo;
import com.lenovo.m2.hsbuy.domain.inventory.StockInfo;
import com.lenovo.m2.hsbuy.domain.inventory.StockInfoParam;
import com.lenovo.m2.hsbuy.inventory.constants.StockResultCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2017/2/3.
 */
@Controller
@Scope("prototype")
@RequestMapping("/api/inventory")
public class ActivityStockGlobalController extends BaseController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivityStockGlobalController.class);
    @Autowired
    private StockRemoteService stockRemoteService;
    /**
     * 添加活动库存
     *
     * @return
     */
    @RequestMapping(value = "/addActivityStockInfo",produces = "text/json;charset=UTF-8", method = {RequestMethod.POST})
    @ResponseBody
    public String addActivityOnlineStockInfo(HttpServletRequest request, HttpServletResponse response, StockInfoParam param) {
        RemoteResult re = new RemoteResult(false);
        try {
            JSONArray faIds = getGlobalFaIds();
            JSONArray shopids = getTenantIds();
            String itcode = getGlobalItcode();
            LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:"+faIds.toString()+"，shopIds:"+shopids.toString());
            LOGGER.info("addActivityStockInfo 请求参数：" + JacksonUtil.toJson(param));

            //是否创建过活动库存
            List<StockInfo> stockInfoList = stockRemoteService.checkStockExist(new StockInfo(param.getProductCode(), param.getActivityType()));
            if (null == stockInfoList || stockInfoList.size() == 0) {
                RemoteResult<StockInfo> stockInfoRemoteResult = stockRemoteService.getStockInfoById(param.getStockId());

                if (stockInfoRemoteResult.isSuccess()) {
                    StockInfo stockInfo = stockInfoRemoteResult.getT();
                    int faType = 0;
                    String faId = stockInfo.getFaid();
                    String shopid = String.valueOf(stockInfo.getShopid());
                    if (CollectionUtils.isNotEmpty(faIds) && faIds.contains(faId) && CollectionUtils.isNotEmpty(shopids) && shopids.contains(shopid)) {
                        RemoteResult<FaBaseInfo> remoteResult = stockRemoteService.getFaBaseInfoById(stockInfo.getFaid());
                        if (remoteResult.isSuccess()) {
                            FaBaseInfo faBaseInfo = remoteResult.getT();
                            int type = faBaseInfo.getType();
                            //0是非直营 1是直营
                            faType = (type == 0 || type == 3 ? 1 : 0);
                        }

                        param.setUpdateFlag("add");
                        param.setGoodsCode(stockInfo.getGoodsCode());
                        param.setFaid(faId);
                        param.setType(faType);
                        param.setShopid(shopid);
                        param.setStoreId(stockInfo.getStoreId());
                        re = stockRemoteService.addActivityStock(param, itcode);

                    } else {
                        re.setResultMsg("无权创建活动库存！");
                        re.setResultCode(StockResultCode.STOCK_NOT_MEET);
                    }
                }
            } else {
                re.setResultMsg("活动库存已存在！");
                re.setResultCode(StockResultCode.STOCK_MORE);
            }
        }catch (Exception e){
            re.setResultCode(StockResultCode.STOCK_ERROR);
            re.setResultMsg("系统异常");
            LOGGER.error(e.getMessage(),e);
        }
        return JacksonUtil.toJson(re);
    }
    /**
     * 修改活动库存
     *
     * @return
     */
    @RequestMapping(value = "/updateActivityOnlineStock",produces = "text/json;charset=UTF-8", method = {RequestMethod.POST})
    @ResponseBody
    public String updateActivityOnlineStock(HttpServletRequest request, HttpServletResponse response, StockInfoParam param) {
        RemoteResult re = new RemoteResult(false);
        try {
            JSONArray faIds = getGlobalFaIds();
            JSONArray shopids = getTenantIds();
            String itcode = getGlobalItcode();
            LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:"+faIds.toString()+"，shopIds:"+shopids.toString());
            LOGGER.info("updateActivityOnlineStock 请求参数：" + JacksonUtil.toJson(param));

            RemoteResult<StockInfo> stockInfoRemoteResult = stockRemoteService.getStockInfoById(param.getStockId());

            if (stockInfoRemoteResult.isSuccess()) {

                StockInfo stockInfo = stockInfoRemoteResult.getT();
                int faType = 0;
                String faId = stockInfo.getFaid();
                String shopid = String.valueOf(stockInfo.getShopid());
                if (CollectionUtils.isNotEmpty(faIds) && faIds.contains(faId) &&CollectionUtils.isNotEmpty(shopids) && shopids.contains(shopid)) {
                    RemoteResult<FaBaseInfo> remoteResult = stockRemoteService.getFaBaseInfoById(stockInfo.getFaid());
                    if (remoteResult.isSuccess()) {
                        FaBaseInfo faBaseInfo = remoteResult.getT();
                        int type = faBaseInfo.getType();
                        //0是非直营 1是直营
                        faType = (type == 0 || type == 3 ? 1 : 0);
                    }
                    String updateFlag = param.getUpdateFlag();
                    if ("0".equals(updateFlag)){
                        param.setUpdateFlag("les");
                    }else if ("1".equals(updateFlag)){
                        param.setUpdateFlag("add");
                    }
                    param.setType(faType);
                    param.setShopid(shopid);
                    param.setStoreId(stockInfo.getStoreId());
                    param.setProductCode(stockInfo.getProductCode());
                    param.setActivityType(stockInfo.getActivityType());
                    param.setGoodsCode(stockInfo.getGoodsCode());
                    re = stockRemoteService.updateActivityStock(param, itcode);
                } else {
                    re.setResultMsg("无权修改活动库存！");
                    re.setResultCode(StockResultCode.STOCK_NOT_MEET);
                }
            }
        }catch (Exception e){
            re.setResultCode(StockResultCode.STOCK_ERROR);
            re.setResultMsg("系统异常");
            LOGGER.error(e.getMessage(),e);
        }
        return JacksonUtil.toJson(re);
    }
    @RequestMapping(value = "/queryActiveStock",produces = "text/json;charset=UTF-8")
    @ResponseBody
    public String queryMbgStock(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map) {

        RemoteResult<PageModel2<StockInfo>> re = new RemoteResult<PageModel2<StockInfo>>(false);
        try {
            JSONArray faIds = getGlobalFaIds();
            JSONArray shopids = getTenantIds();
            String itcode = getGlobalItcode();
            LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:"+faIds.toString()+"，shopIds:"+shopids.toString());
            if (CollectionUtils.isNotEmpty(faIds) && CollectionUtils.isNotEmpty(shopids)) {
                Map<String, Object> conditionMap = new HashMap<String, Object>();
                StockInfo backVo = new StockInfo();
                String faid = request.getParameter("faId");
                String goodsCode = request.getParameter("goodsCode");
                String createTime_start = request.getParameter("createTimeStart");
                String createTime_end = request.getParameter("createTimeEnd");
                String onlineUpdateTime_start = request.getParameter("onlineUpdateTimeStart");
                String onlineUpdateTime_end = request.getParameter("onlineUpdateTimeEnd");
                String productCode = request.getParameter("productCode");
                String salesTypeS = request.getParameter("salesType");
                String activityTypeS = request.getParameter("activityType");
                String isValidS = request.getParameter("isValid");
                String isEntityS = request.getParameter("isEntity");
                String isPutawayS = request.getParameter("isPutaway");
                Integer salesType = 100;
                Integer activityType = 100;
                Integer isValid = 100;
                Integer isEntity = 100;
                Integer isPutaway = 100;
                if (StringUtils.isNotEmpty(salesTypeS)){
                    salesType = Integer.parseInt(salesTypeS);
                }
                if (StringUtils.isNotEmpty(activityTypeS)){
                    activityType = Integer.parseInt(activityTypeS);
                }
                if (StringUtils.isNotEmpty(isValidS)){
                    isValid = Integer.parseInt(isValidS);
                }
                if (StringUtils.isNotEmpty(isEntityS)){
                    isEntity = Integer.parseInt(isEntityS);
                }
                if (StringUtils.isNotEmpty(isPutawayS)){
                    isPutaway = Integer.parseInt(isPutawayS);
                }
                conditionMap.put("faid", faid);
                conditionMap.put("goodsCode", goodsCode);
                conditionMap.put("salesType", salesType);
                conditionMap.put("activityType", activityType);
                conditionMap.put("createTime_start", createTime_start);
                conditionMap.put("createTime_end", createTime_end);
                conditionMap.put("isValid", isValid);
                conditionMap.put("onlineUpdateTime_start", onlineUpdateTime_start);
                conditionMap.put("onlineUpdateTime_end", onlineUpdateTime_end);
                conditionMap.put("isEntity", isEntity);
                conditionMap.put("isPutaway", isPutaway);
                conditionMap.put("productCode", productCode);
                if (CollectionUtils.isNotEmpty(faIds)) {
                    conditionMap.put("FAInfos", faIds);
                }
                conditionMap.put("shopids", shopids);
                backVo.setFaid(faid);
                backVo.setGoodsCode(goodsCode);
                backVo.setSalesType(salesType);
                backVo.setSalesType(activityType);
                backVo.setCreateTime_start(createTime_start);
                backVo.setCreateTime_end(createTime_end);
                backVo.setIsValid(isValid);
                backVo.setOnlineUpdateTime_start(onlineUpdateTime_start);
                backVo.setOnlineUpdateTime_end(onlineUpdateTime_end);
                backVo.setIsEntity(isEntity);
                backVo.setProductCode(productCode);
                request.setAttribute("backVo", backVo);//条件设置
                LOGGER.info("queryActiveStock 请求参数：" + JacksonUtil.toJson(conditionMap));

                PageQuery pageQuery = new PageQuery(getGlobalPage(request), getGlobalRowNum(request));
                re = stockRemoteService.getActiveStockInfoPage(pageQuery, conditionMap);
            } else {
                re.setResultMsg("无权查询！");
                re.setResultCode(StockResultCode.STOCK_NOT_MEET);
            }
        }catch (Exception e){
            re.setResultCode(StockResultCode.STOCK_ERROR);
            re.setResultMsg("系统异常");
            LOGGER.error(e.getMessage(),e);
        }
        return JacksonUtil.toJson(re);
    }
}
