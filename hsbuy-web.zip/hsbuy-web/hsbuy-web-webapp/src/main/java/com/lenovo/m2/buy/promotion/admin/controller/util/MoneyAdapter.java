package com.lenovo.m2.buy.promotion.admin.controller.util;

import com.google.gson.*;
import com.lenovo.m2.arch.framework.domain.Money;
import org.apache.log4j.Logger;

import java.lang.reflect.Type;

/**
 * Created by fenglg1 on 2016/12/26.
 */
public class MoneyAdapter implements JsonSerializer<Money>, JsonDeserializer<Money> {

    protected static Logger logger = Logger.getLogger(MoneyAdapter.class);
    private final String separator = "||";

    @Override
    public Money deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext jsonDeserializationContext) throws JsonParseException {
        if(jsonElement == null){
            return null;
        }
        String[] properties = jsonElement.toString().split(separator);
        Money money = new Money(properties[0], properties[1]);
        return money;
    }

    @Override
    public JsonElement serialize(Money money, Type type, JsonSerializationContext jsonSerializationContext) {
        if(money == null){
            return new JsonPrimitive("");
        }
       return new JsonPrimitive(money.getAmount()+separator+money.getCurrencyCode());
        /*return new JsonPrimitive(money.getAmount());*/
    }
}
