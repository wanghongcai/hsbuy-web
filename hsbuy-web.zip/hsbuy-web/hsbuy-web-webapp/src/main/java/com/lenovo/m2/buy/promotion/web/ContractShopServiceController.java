package com.lenovo.m2.buy.promotion.web;


import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.hsbuy.common.order.JacksonUtil;
import com.lenovo.m2.hsbuy.common.order.JsonUtil;
import com.lenovo.m2.hsbuy.domain.smb17.AddContractInfoParam;
import com.lenovo.m2.hsbuy.domain.smb17.Contract;
import com.lenovo.m2.hsbuy.smb17.ContractApiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by xuweihua on 2016/6/27.
 */
@Controller
@Scope("prototype")
@RequestMapping("/api/contract")
public class ContractShopServiceController {
    private static final Logger logger = LoggerFactory.getLogger("com.lenovo.invoice.service.impl.contract");
    @Autowired
    private ContractApiService contractApiService;

    /**
     * SMB调用此接口生成百应合同，数据由SMB传入
     * @param request
     * @return
     */
    @RequestMapping(value = "/addContractInfo")
    @ResponseBody
    public String addContractInfo(HttpServletRequest request) {
        RemoteResult remoteResult= new RemoteResult();
        logger.info("addContractInfo》》"+ JsonUtil.toJson(request.getParameterMap()));
        try {
            AddContractInfoParam addContractInfoParam=new AddContractInfoParam();
            EncapsulationParam.getObjectFromRequest(addContractInfoParam, request);
            if(StringUtils.isEmpty(addContractInfoParam.getLenovoId())){
                addContractInfoParam.setLenovoId(request.getParameter("userId"));
            }
            remoteResult = contractApiService.addContractInfo(addContractInfoParam);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return JacksonUtil.toJson(remoteResult);
    }

    @RequestMapping(value = "/getContractInfo")
    @ResponseBody
    public String getContractInfo(HttpServletRequest request) {
        RemoteResult<Contract> remoteResult1=new RemoteResult<Contract>();
        logger.info("getContractInfo》》"+JacksonUtil.toJson(request.getParameterMap()));
        try {
            String lenovoId =request.getParameter("lenovoId");
            String cId =request.getParameter("contractNo");
            if(StringUtils.isEmpty(lenovoId)){
                lenovoId=request.getParameter("userId");
            }
            remoteResult1=contractApiService.getContractInfo(lenovoId,cId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return JacksonUtil.toJson(remoteResult1);
    }

}
