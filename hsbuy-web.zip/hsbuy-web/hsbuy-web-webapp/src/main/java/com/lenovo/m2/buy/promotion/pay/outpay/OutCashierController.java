package com.lenovo.m2.buy.promotion.pay.outpay;

import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.LePayConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.LePayUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PaySignUtils;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.domain.pay.outpay.OutPayType;
import com.lenovo.m2.buy.promotion.admin.domain.pay.outpay.PayChannel;
import com.lenovo.m2.buy.promotion.admin.domain.pay.outpay.Points;
import com.lenovo.m2.buy.promotion.admin.manager.pay.outpay.PayChannelManager;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 惠商支付路由
 * Created by tianchuyang on 2017/1/10.
 */
@Controller
@Scope("prototype")
@RequestMapping("/cashier")
public class OutCashierController {

    private Logger logger = Logger.getLogger(this.getClass());

    @Autowired
    private PayChannelManager payChannelManager;

    @RequestMapping(value = "/getSupportPaymentChannel",method = RequestMethod.POST)
    @ResponseBody
    public Object getgSupportPaymentChannel(HttpServletRequest request) throws Exception {
        Long startTime = System.currentTimeMillis();
        logger.info("HTTPS Invoke Start Time===>"+startTime);
        PayChannel payChannel = new PayChannel();
        String service = request.getParameter("service");
        String signType = request.getParameter("sign_type");
        String sign = request.getParameter("sign");
        String shopId = request.getParameter("shop_id");
        String faId = request.getParameter("fa_id");
        String billAmount = request.getParameter("bill_amount");
        String accountType = request.getParameter("account_type"); //业务类型 B2C/B2B
        String outTradeNo =  request.getParameter("out_trade_no"); //
        String lenovoId = request.getParameter("lenovo_id");
        logger.info("HTTPS Invoke Invoke HSPayRouteController getSupportBanks：service["
                +service+"]signType["+signType+"]sign["+sign+"]shopId["+shopId+"]faId["
                +faId+"]billAmount["+billAmount+"]accountType["+accountType+"] outTradeNo["+outTradeNo+"] lenovoId["+lenovoId+"]");
        if(LePayUtil.isParamsEmpty(sign,signType,faId,billAmount,accountType)){
            logger.info("获取支付方式，必要参数为空！");
            return getPayChannel(false,"请求参数错误!");
        }
        // 验签
        Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
        String signKey = (String) commonParam.get(shopId);
        Map<String, String> signMap = new HashMap<String, String>();
        signMap.put("service", service);
        signMap.put("fa_id", faId);
        signMap.put("shop_id", shopId);
        signMap.put("bill_amount", billAmount);
        signMap.put("account_type", accountType);
        if(shopId.equals(PeakConstant.SHOPID_HUISHANG)){
            signMap.put("out_trade_no", outTradeNo);
            signMap.put("lenovo_id", lenovoId);
        }
        boolean checkSign = PaySignUtils.checkSignKey(sign, signMap, signType, signKey);
        BigDecimal amount = null;
        if (checkSign){
            logger.info("HTTPS Invoke Invoke HSPayRouteController getSupportBanks Success.");
            try {
                amount = new BigDecimal(billAmount);
                if (amount.compareTo(new BigDecimal("0")) < 0){
                    logger.info("HTTPS Invoke Invoke HSPayRouteController getSupportBanks failure.reason:" + "Bill Amount Error!amount="+amount);
                    return this.getPayChannel(payChannel,false,"订单金额错误!",null,null);
                }
            }catch (Exception e){
                logger.info("HTTPS Invoke Invoke HSPayRouteController getSupportBanks failure.reason: bill Amount Error!amount="+amount+" Error Cause By :",e);
                return this.getPayChannel(payChannel,false,"订单金额错误!",null,null);
            }
            if (!isCorrectAccountType(accountType)){
                return this.getPayChannel(payChannel,false,"账户类型错误!",null,null);
            }
            // 查询数据
            try {
                payChannel = payChannelManager.getPayChannel(faId,shopId,amount,accountType,outTradeNo,lenovoId);

            }catch (Exception e){
                logger.error("HTTPS Invoke Invoke HSPayRouteController getSupportBanks failure.reason: getPayChannel Error!faId="+faId+" Error Cause By :" ,e);
                return this.getPayChannel(payChannel,false,"服务器发生异常!",null,null);
            }
        }else {
            logger.info("HTTPS Invoke Invoke HSPayRouteController getSupportBanks failure.reason:signature " +
                    "verification failure.");
            return this.getPayChannel(payChannel,false,"签名验证失败!",null,null);
        }
        Long endTime = System.currentTimeMillis();
        logger.info("HTTPS Invoke Use Time===>"+(endTime - startTime) + " ms");
        return payChannel;
    }

    /**
     * 返回支付渠道信息
     * @param success
     * @param resultMessage
     * @return
     */
    public PayChannel getPayChannel(boolean success, String resultMessage){
        PayChannel payChannel = new PayChannel();
        payChannel.setSuccess(success);
        payChannel.setResultMessage(resultMessage);
        return payChannel;
    }
    /**
     * 验证交易类型
     * @param accountType 账户类型
     * @return 是否是正确的交易类型
     */
    public boolean isCorrectAccountType(String accountType){
        boolean flag = false;
        Integer type = null;
        try {
            type = Integer.valueOf(accountType);
            if (LePayConstant.ACCOUNT_TYPE_NONE.equals(type) || LePayConstant.ACCOUNT_TYPE_B2C.equals(type) || LePayConstant.ACCOUNT_TYPE_B2B.equals(type) || LePayConstant.ACCOUNT_TYPE_OTHER.equals(type)){
                flag = true;
            }else {
                logger.info("HTTPS Invoke Invoke HSPayRouteController getSupportBanks failure.reason:" +
                        "bill accountType Error!accountType="+accountType);
            }
        }catch (Exception e){
            logger.error("HTTPS Invoke Invoke HSPayRouteController getSupportBanks failure.reason:" +
                    "bill accountType Error!accountType="+accountType+ " Error Cause By :" ,e);
        }
        return flag;
    }

    /**
     * 入参校验
     * @param faId
     * @param billAmount
     * @param accountType
     * @return
     */
    public boolean hasEmptySupportPaymentParams(String faId, String billAmount, String accountType) {
        return StringUtils.isEmpty(faId) || StringUtils.isEmpty(billAmount) || StringUtils.isEmpty(accountType) ;
    }

    private PayChannel getPayChannel(PayChannel payChannel, boolean success, String resultMessage, List<OutPayType> outPayTypes, Points points) {
        payChannel.setSuccess(success);
        payChannel.setResultMessage(resultMessage);
        payChannel.setPay_type_list(outPayTypes);
        payChannel.setPoints(points);
        return payChannel;
    }
}
