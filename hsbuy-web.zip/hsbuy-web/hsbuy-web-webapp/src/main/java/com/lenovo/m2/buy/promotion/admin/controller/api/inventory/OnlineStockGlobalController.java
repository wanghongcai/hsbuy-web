package com.lenovo.m2.buy.promotion.admin.controller.api.inventory;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSONArray;
import com.google.common.base.Strings;
import com.lenovo.fis.model.FaBaseInfoes;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.common.utils.ErrorUtils;
import com.lenovo.m2.buy.promotion.admin.manager.inventory.FaBaseInfoManager;
import com.lenovo.m2.buy.promotion.admin.remote.inventory.StockRemoteService;
import com.lenovo.m2.hsbuy.common.util.JacksonUtil;
import com.lenovo.m2.hsbuy.domain.inventory.FaBaseInfo;
import com.lenovo.m2.hsbuy.domain.inventory.OrderAndStock;
import com.lenovo.m2.hsbuy.domain.inventory.StockInfo;
import com.lenovo.m2.hsbuy.domain.inventory.StockInfoParam;
import com.lenovo.m2.hsbuy.inventory.constants.StockResultCode;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by yezhenyue on 2017/2/3.
 */
@Controller
@Scope("prototype")
@RequestMapping("/api/inventory")
public class OnlineStockGlobalController extends BaseController{
    private static final Logger LOGGER = LoggerFactory.getLogger(OnlineStockGlobalController.class);
    @Autowired
    private StockRemoteService stockRemoteService;
    @Autowired
    private FaBaseInfoManager faBaseInfoManager;
    // 库存导出excel的title
    static String[] excelHeader = {"物料编号", "商品名称","商品ID","商城", "是否上架","销售公司", "销售类型","库存类型", "库存", "占用", "冻结", "产品组", "是否实物", "创建时间"};
    /**
     * 创建库存
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/addStockInfo",produces = "text/json;charset=UTF-8", method = {RequestMethod.POST})
    @ResponseBody
    public String addStockInfo(HttpServletRequest request, HttpServletResponse response) {
        RemoteResult re = new RemoteResult(false);
        try {
            JSONArray faIds = getGlobalFaIds();
            JSONArray shopids = getTenantIds();
            String itcode = getGlobalItcode();
            String faid = request.getParameter("saveFaId");
            String shopid = request.getParameter("saveShopId");

            LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:"+faIds.toString()+"，shopIds:"+shopids.toString());
            if (CollectionUtils.isNotEmpty(faIds) && faIds.contains(faid)&&CollectionUtils.isNotEmpty(shopids) && shopids.contains(shopid)) {

                StockInfo info = new StockInfo();   //封装 库存 需要的信息

                info.setStockNumber(Integer.parseInt(request.getParameter("saveStockNumber")));
                info.setSalesNumber(info.getStockNumber());
                info.setBusinessUnit(request.getParameter("saveBusinessUnit"));
                info.setBuOwner(request.getParameter("saveBuOwner"));
                info.setGoodsCode(request.getParameter("saveGoodsCode"));
                info.setGoodsName(request.getParameter("saveGoodsName"));
                info.setSalesCompanyName(request.getParameter("saveSalesCompanyName"));

                String save_isEntity=request.getParameter("saveIsEntity");
                info.setIsEntity(Integer.parseInt(Strings.isNullOrEmpty(save_isEntity)?"0":save_isEntity));
                info.setSalesType(Integer.parseInt(request.getParameter("saveSalesType")));
                info.setProductGroup(request.getParameter("saveProductGroup"));
                info.setProductGroupNo(request.getParameter("saveProductGroupNo"));
                info.setProductCode(request.getParameter("saveProductCode"));
                info.setActivityType(0);
                info.setFaid(faid);
                info.setIsPutaway(Integer.parseInt(request.getParameter("saveIsPutaway")));
                info.setOperator(itcode);
                info.setShopid(Integer.parseInt(shopid));
                LOGGER.info("增加新库存 信息:" + info);

                int faType = 0;
                RemoteResult<FaBaseInfo> remoteResult = stockRemoteService.getFaBaseInfoById(faid);
                if (remoteResult.isSuccess()) {
                    FaBaseInfo faBaseInfo = remoteResult.getT();
                    int type = faBaseInfo.getType();
                    LOGGER.info("AddStockInfo获取Fa信息接口: faid:"+faid+"  fatype:"+type);
                    //0是非直营 1是直营
                    faType = (type == 0 || type == 3 ? 1 : 0);
                }
                re = stockRemoteService.addStockInfo(info, faType);
            } else {
                re.setResultCode(StockResultCode.STOCK_NOT_MEET);
                re.setResultMsg("无权添加库存信息！");
                LOGGER.error("AddStockInfo接口:" + itcode + "无权添加" + faid + "库存信息");
            }
        } catch (Exception e) {
            re.setResultCode(StockResultCode.STOCK_ERROR);
            re.setResultMsg("系统异常！");
            LOGGER.error(e.getMessage(), e);
        }
        return JacksonUtil.toJson(re);
    }
    /**
     * 修改在线库存
     *
     * @return
     */
    @RequestMapping(value = "/updateStockInfo",produces = "text/json;charset=UTF-8", method = {RequestMethod.POST})
    @ResponseBody
    public String updateOnlineStockInfo(HttpServletRequest request, HttpServletResponse response, long stockId,
                                      int operNum,int salesNum, String updateFlag) {

        RemoteResult re = new RemoteResult(false);
        try {
            if (operNum == 0) {
                re.setResultCode(StockResultCode.STOCK_EMPTY);
                re.setResultMsg("参数有误！操作数量必须大于0");
            } else {
                JSONArray faIds = getGlobalFaIds();
                JSONArray shopids = getTenantIds();
                String itcode = getGlobalItcode();
                LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:" + faIds.toString() + "，shopIds:" + shopids.toString());
                RemoteResult<StockInfo> stockInfoRemoteResult = stockRemoteService.getStockInfoById(stockId);

                if (stockInfoRemoteResult.isSuccess()) {
                    StockInfo selectedStock = stockInfoRemoteResult.getT();
                    String faId = selectedStock.getFaid();
                    String shopid = String.valueOf(selectedStock.getShopid());
                    if (CollectionUtils.isNotEmpty(faIds) && faIds.contains(faId)&&CollectionUtils.isNotEmpty(shopids) && shopids.contains(shopid)) {

                        //获取fa_base_info
                        FaBaseInfoes faBaseInfoes = faBaseInfoManager.getFaBaseInfo(faId);
                        if (faBaseInfoes != null) {
                            int type = 0;

                            int faType = faBaseInfoes.getFaType();
                            if (faType == 0 || faType == 3) {
                                type = 1;
                            }

                            StockInfoParam stockInfoParam = new StockInfoParam();
                            stockInfoParam.setType(type);
                            if ("0".equals(updateFlag)){
                                stockInfoParam.setUpdateFlag("les");
                            }else if ("1".equals(updateFlag)){
                                stockInfoParam.setUpdateFlag("add");
                            }
                            stockInfoParam.setProductCode(selectedStock.getProductCode());
                            stockInfoParam.setActivityType(0);
                            stockInfoParam.setOperNum(operNum);
                            stockInfoParam.setSalesNum(salesNum);
                            stockInfoParam.setGoodsCode(selectedStock.getGoodsCode());
                            stockInfoParam.setShopid(shopid);
                            stockInfoParam.setStoreId(selectedStock.getStoreId());
                            re = stockRemoteService.updateStockInfo(stockInfoParam, itcode);
                        } else {
                            re.setResultMsg("FA信息不存在");
                            re.setResultCode(ErrorUtils.ERR_NONEXIST_FA);
                        }
                    } else {
                        re.setResultCode(StockResultCode.STOCK_NOT_MEET);
                        re.setResultMsg("无权修改库存信息！");
                    }
                } else {
                    re.setResultCode(StockResultCode.STOCK_NOTHINH);
                    re.setResultMsg("库存不存在！");
                }
            }
        } catch (Exception e) {
            re.setResultMsg("系统异常！");
            re.setResultCode(StockResultCode.STOCK_ERROR);
            LOGGER.error(e.getMessage(), e);
        }
        return JacksonUtil.toJson(re);
    }
    /**
     * 分页查询在线平台库存信息
     *
     * @return
     */
    @RequestMapping(value = "/queryOnlineStock",produces = "text/json;charset=UTF-8")
    @ResponseBody
    public String queryOnlineStock(HttpServletRequest request, HttpServletResponse response) {
        RemoteResult<PageModel2<StockInfo>> re = new RemoteResult<PageModel2<StockInfo>>(false);
        try{
            JSONArray faIds = getGlobalFaIds();
            JSONArray shopids = getTenantIds();
            String itcode = getGlobalItcode();
            LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:"+faIds.toString()+"，shopIds:"+shopids.toString());
            if (CollectionUtils.isNotEmpty(faIds)&& CollectionUtils.isNotEmpty(shopids)) {
                Map<String, Object> conditionMap = new HashMap<String, Object>();
                StockInfo backVo = new StockInfo();
                String faid = request.getParameter("faId");
                String productCode = request.getParameter("productCode");
                String goodsCode = request.getParameter("goodsCode");
                String salesTypeS = request.getParameter("salesType");
                String isValidS = request.getParameter("isValid");
                String isEntityS = request.getParameter("isEntity");
                String isPutawayS = request.getParameter("isPutaway");
                Integer salesType = 100;
                Integer isValid = 100;
                Integer isEntity = 100;
                Integer isPutaway = 100;
                if (StringUtils.isNotEmpty(salesTypeS)){
                    salesType = Integer.parseInt(salesTypeS);
                }
                if (StringUtils.isNotEmpty(isValidS)){
                    isValid = Integer.parseInt(isValidS);
                }
                if (StringUtils.isNotEmpty(isEntityS)){
                    isEntity = Integer.parseInt(isEntityS);
                }
                if (StringUtils.isNotEmpty(isPutawayS)){
                    isPutaway = Integer.parseInt(isPutawayS);
                }
                String createTime_start = request.getParameter("createTimeStart");
                String createTime_end = request.getParameter("createTimeEnd");
                String onlineUpdateTime_start = request.getParameter("onlineUpdateTimeStart");
                String onlineUpdateTime_end = request.getParameter("onlineUpdateTimeEnd");
                conditionMap.put("faid", faid);
                conditionMap.put("productCode", productCode);
                conditionMap.put("goodsCode", goodsCode);
                conditionMap.put("activityType", 0);
                conditionMap.put("salesType", salesType);
                conditionMap.put("createTime_start", createTime_start);
                conditionMap.put("createTime_end", createTime_end);
                conditionMap.put("isValid", isValid);
                conditionMap.put("updateTime_start", onlineUpdateTime_start);
                conditionMap.put("updateTime_end", onlineUpdateTime_end);
                conditionMap.put("isEntity", isEntity);
                conditionMap.put("isPutaway", isPutaway);
                if (CollectionUtils.isNotEmpty(faIds))
                    conditionMap.put("FAInfos", faIds);
                conditionMap.put("shopids",shopids);
                backVo.setProductCode(productCode);
                backVo.setSalesType(salesType);
                backVo.setCreateTime_start(createTime_start);
                backVo.setCreateTime_end(createTime_end);
                backVo.setIsValid(isValid);
                backVo.setActivityType(0);
                backVo.setOnlineUpdateTime_start(onlineUpdateTime_start);
                backVo.setOnlineUpdateTime_end(onlineUpdateTime_end);
                backVo.setIsEntity(isEntity);
                backVo.setGoodsCode(goodsCode);
                request.setAttribute("backVo", backVo);//条件设置
                PageQuery pageQuery = new PageQuery(getGlobalPage(request), getGlobalRowNum(request));
                LOGGER.info("conditionMap:"+conditionMap.toString());
                re = stockRemoteService.getStockInfoPage(pageQuery, conditionMap);
            }else {
                re.setResultMsg("无权查询！");
                re.setResultCode(StockResultCode.STOCK_NOT_MEET);
            }
        }catch (Exception e) {
            re.setResultMsg("系统异常！");
            re.setResultCode(StockResultCode.STOCK_ERROR);
            LOGGER.error(e.getMessage(), e);
        }
        //将数据格式以json返回
        return JacksonUtil.toJson(re);
    }


    @RequestMapping(value = "/downOnlineStockExcel",produces = "text/json;charset=UTF-8")
    @ResponseBody
    public String downOnlineStockExcel(HttpServletRequest request, HttpServletResponse response) {
        RemoteResult<String> remoteResult = new RemoteResult<>(false);
        byte[] bytes = null;
        ByteArrayOutputStream fOut = null;
        HSSFWorkbook workbook = new HSSFWorkbook();
        try {
            JSONArray faIds = getGlobalFaIds();
            JSONArray shopids = getTenantIds();
            String itcode = getGlobalItcode();
            LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:" + faIds.toString() + "，shopIds:" + shopids.toString());
            //产生工作表对象
            HSSFSheet sheet = workbook.createSheet("库存信息");

            HSSFRow row = sheet.createRow((int) 0);
            HSSFCellStyle style = workbook.createCellStyle();
            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);    //设置颜色为红色
            style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
            for (int i = 0; i < excelHeader.length; i++) {
                HSSFCell cell = row.createCell(i);
                cell.setCellValue(excelHeader[i]);
                cell.setCellStyle(style);
                //     sheet.autoSizeColumn(i);
                sheet.setColumnWidth(i, 3000);
            }

            if (CollectionUtils.isNotEmpty(faIds)&&CollectionUtils.isNotEmpty(shopids)) {
                Map<String, Object> conditionMap = new HashMap<String, Object>();
                String faid = request.getParameter("faId");
                String goodsCode = request.getParameter("goodsCode");
                String productCode = request.getParameter("productCode");
                String salesTypeS = request.getParameter("salesType");
                String isValidS = request.getParameter("isValid");
                String isEntityS = request.getParameter("isEntity");
                String isPutawayS = request.getParameter("isPutaway");
                Integer salesType = 100;
                Integer isValid = 100;
                Integer isEntity = 100;
                Integer isPutaway = 100;
                if (StringUtils.isNotEmpty(salesTypeS)){
                    salesType = Integer.parseInt(salesTypeS);
                }
                if (StringUtils.isNotEmpty(isValidS)){
                    isValid = Integer.parseInt(isValidS);
                }
                if (StringUtils.isNotEmpty(isEntityS)){
                    isEntity = Integer.parseInt(isEntityS);
                }
                if (StringUtils.isNotEmpty(isPutawayS)){
                    isPutaway = Integer.parseInt(isPutawayS);
                }
                String createTime_start = request.getParameter("createTimeStart");
                String createTime_end = request.getParameter("createTimeEnd");
                Integer isGift = request.getParameter("isGift") == null ? 100 : Integer.parseInt(request.getParameter("isGift"));
                String onlineUpdateTime_start = request.getParameter("onlineUpdateTimeStart");
                String onlineUpdateTime_end = request.getParameter("onlineUpdateTimeEnd");
                conditionMap.put("faid", faid);
                conditionMap.put("goodsCode", goodsCode);
                conditionMap.put("productCode", productCode);
                conditionMap.put("salesType", salesType);
                conditionMap.put("createTime_start", createTime_start);
                conditionMap.put("createTime_end", createTime_end);
                conditionMap.put("isValid", isValid);
                conditionMap.put("isGift", isGift);
                conditionMap.put("updateTime_start", onlineUpdateTime_start);
                conditionMap.put("updateTime_end", onlineUpdateTime_end);
                conditionMap.put("isEntity", isEntity);
                conditionMap.put("isPutaway", isPutaway);
                if (CollectionUtils.isNotEmpty(faIds)) {
                    conditionMap.put("FAInfos", faIds);
                }
                conditionMap.put("shopids",shopids);
                LOGGER.info("downOnlineStockExcel 请求参数：" + JacksonUtil.toJson(conditionMap));

                //封装查询参数
                RemoteResult<List<StockInfo>> re = stockRemoteService.getStockInfoList(conditionMap);
                List<StockInfo> list = re.getT();
                if (list != null && list.size() > 0) {
                    buildData(sheet, list, 1,0);
                }
                fOut = new ByteArrayOutputStream();
                workbook.write(fOut);
                bytes = fOut.toByteArray();//excle的byte数组
                //调用云存储client上传excle生产下载链接
                long timestamp = System.currentTimeMillis();
                String url = uploadFileToCloud(bytes, "/stock/onlineStock_"+timestamp+".xls");
                if (StringUtils.isNotEmpty(url)){
                    remoteResult.setResultCode(StockResultCode.STOCK_SUCCESS);
                    remoteResult.setResultMsg("success");
                    remoteResult.setT(url);
                    remoteResult.setSuccess(true);
                    return JacksonUtil.toJson(remoteResult);
                }
            }

        } catch (Exception e1) {
            LOGGER.error(e1.getMessage(), e1);
        } finally {
            try {
                if (fOut!=null){
                    fOut.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        remoteResult.setResultCode(StockResultCode.STOCK_ERROR);
        remoteResult.setResultMsg("系统异常");
        return JacksonUtil.toJson(remoteResult);
    }

    /**
     * 封装excel数据
     *
     * @param sheet
     */
    private void buildData(HSSFSheet sheet, List<StockInfo> list, int rows,Integer salesType) {
        for (int i = 0; i < list.size(); i++) {
            StockInfo stock = list.get(i);
            HSSFRow row = sheet.createRow((int) i + rows);//创建一行
            HSSFCell cell = row.createCell((int) 0);//创建一列
            cell.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell.setCellValue(stock.getGoodsCode());

            HSSFCell cell1 = row.createCell((int) 1);//创建一列
            cell1.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell1.setCellValue(stock.getGoodsName());

            HSSFCell cell2 = row.createCell((int) 2);//创建一列
            cell2.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell2.setCellValue(stock.getProductCode());

            HSSFCell cell3 = row.createCell((int) 3);//创建一列
            cell3.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell3.setCellValue(stock.getBusinessUnit());

            HSSFCell cell4 = row.createCell((int) 4);//创建一列
            cell4.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell4.setCellValue(stock.getIsPutaway() == 0 ? "否" : "是");
//            "物料编号", "商品名称","商品ID","商城", "是否上架","销售公司", "销售类型","库存类型", "库存", "占用", "冻结", "产品组", "是否实物", "创建时间"

            HSSFCell cell5 = row.createCell((int) 5);//创建一列
            cell5.setCellType(HSSFCell.CELL_TYPE_STRING);
            if (salesType==98) {
                cell5.setCellValue(stock.getStoreName());
            }else {
                cell5.setCellValue(stock.getSalesCompanyName());
            }
            HSSFCell cell6 = row.createCell((int) 6);//创建一列
            cell6.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell6.setCellValue(salesType(stock.getSalesType()));

            HSSFCell cell7 = row.createCell((int) 7);//创建一列
            cell7.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell7.setCellValue(activityType(stock.getActivityType()));

            HSSFCell cell8 = row.createCell((int) 8);//创建一列
            cell8.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell8.setCellValue(stock.getSalesNumber());

            HSSFCell cell9 = row.createCell((int) 9);//创建一列
            cell9.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell9.setCellValue(stock.getWaitPayNumber());

            HSSFCell cell10 = row.createCell((int) 10);//创建一列
            cell10.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell10.setCellValue(stock.getPaidNumber());

            HSSFCell cell11 = row.createCell((int) 11);//创建一列
            cell11.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell11.setCellValue(stock.getProductGroup());

            HSSFCell cell12 = row.createCell((int) 12);//创建一列
            cell12.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell12.setCellValue(stock.getIsEntity() == 0 ? "否" : "是");

            HSSFCell cell13 = row.createCell((int) 13);//创建一列
            cell13.setCellType(HSSFCell.CELL_TYPE_STRING);
            cell13.setCellValue(getDate(stock.getCreateTime()));

        }
    }
    /**
     * 获取库存订单信息
     *
     * @return
     */
    @RequestMapping(value = "/getOrderInfoPage",produces = "text/json;charset=UTF-8")
    @ResponseBody
    public String getOrderInfoPage(HttpServletRequest request, HttpServletResponse response, Map<String, Object> map, long stockId, Integer orderState) {
        Map<String, Object> conditionMap = new HashMap<>();
        RemoteResult<PageModel2<OrderAndStock>> re = new RemoteResult<>(false);
        conditionMap.put("stock_info_id", stockId);
        conditionMap.put("order_state", orderState);//1:占用；2:冻结
        String itcode = getGlobalItcode();
        if (Strings.isNullOrEmpty(itcode)){
            re.setResultCode("401");
            re.setResultMsg("请先登录！");
            return JacksonUtil.toJson(re);
        }
        LOGGER.info("getOrderInfoPage param:[stockId:"+stockId+",orderState:"+orderState+"]");
        try {
            PageQuery pageQuery = new PageQuery(getGlobalPage(request), getGlobalRowNum(request));
            re = stockRemoteService.getOrderInfoPage(pageQuery, conditionMap);
            return JacksonUtil.toJson(re);
        }catch (Exception e){
            LOGGER.error(e.getMessage(),e);
            re.setResultCode(StockResultCode.STOCK_ERROR);
            re.setResultMsg("系统异常！");
        }
        return JacksonUtil.toJson(re);
    }
    /**
     * 创建库存
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/getStockInfoById",produces = "text/json;charset=UTF-8")
    @ResponseBody
    public String getStockInfoById(HttpServletRequest request, HttpServletResponse response,long stockId) {
        RemoteResult<StockInfo> re = new RemoteResult<>(false);
        try {
            JSONArray faIds = getGlobalFaIds();
            JSONArray shopids = getTenantIds();
            String itcode = getGlobalItcode();
            LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:"+faIds.toString()+"，shopIds:"+shopids.toString());
            RemoteResult<StockInfo> stockInfoRemoteResult = stockRemoteService.getStockInfoById(stockId);
            if (stockInfoRemoteResult.isSuccess()&&stockInfoRemoteResult.getT()!=null) {
                StockInfo selectedStock = stockInfoRemoteResult.getT();
                String faId = selectedStock.getFaid();
                String shopid = String.valueOf(selectedStock.getShopid());
                if (CollectionUtils.isNotEmpty(faIds) && faIds.contains(faId) && CollectionUtils.isNotEmpty(shopids) && shopids.contains(shopid)) {
                    re.setResultCode(StockResultCode.STOCK_SUCCESS);
                    re.setSuccess(true);
                    re.setT(selectedStock);
                    re.setResultMsg("success");
                } else {
                    re.setResultCode(StockResultCode.STOCK_NOT_MEET);
                    re.setResultMsg("无权修改库存信息！");
                    LOGGER.error("getStockInfoById 接口:" + itcode + "无权修改库存信息");
                }
            }
        } catch (Exception e) {
            re.setResultCode(StockResultCode.STOCK_ERROR);
            re.setResultMsg("系统异常！");
            LOGGER.error(e.getMessage(), e);
        }
        return JacksonUtil.toJson(re);
    }
}
