package com.lenovo.m2.buy.promotion.admin.controller.api.ordercenter;

import com.alibaba.fastjson.JSONArray;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.controller.util.ExcelSAXHandler;
import com.lenovo.m2.buy.promotion.admin.remote.ordercenter.OpenOrderRemote;
import com.lenovo.m2.hsbuy.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.domain.order.OrderMain;
import com.lenovo.m2.hsbuy.domain.order.logistics.RemoteLogistic;
import com.lenovo.m2.hsbuy.domain.ordercenter.*;
import com.lenovo.m2.ordercenter.soa.common.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.math.BigDecimal;
import java.util.*;

/**
 * @author : 朝阳
 * @version : v1.0
 * @email : licy13@lenovo.com
 * @time : 2017/11/30 17:34
 */
@Controller
@RequestMapping("api/order")
public class OpenOrderController {
    private static final Logger LOGGER = Logger.getLogger(OpenOrderController.class);


    int SYNC_ORDER_STATUS_FROM_SELLER = 1;
    int SYNC_ORDER_STATUS_FROM_NOTIFICATION = 2;
    @Autowired
    private OpenOrderRemote openOrderRemote;

    @ResponseBody
    @RequestMapping(value = "/bogusPay/{orderCode}", method = {RequestMethod.GET})
    public RemoteResult bogusPay(@PathVariable("orderCode") String orderCode) {
        RemoteResult remoteResult = openOrderRemote.bogusPay(orderCode);
        LOGGER.info("orderCode=" + orderCode + " ,假支付 remoteResult=" + JsonUtil.toJson(remoteResult));
        return remoteResult;
    }

    /**
     * 更新订单状态推送接口
     *
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/updatestatus", method = {RequestMethod.POST})
    public RemoteResult syncOrderStatus(OrderStatusRequest request) {
        LOGGER.info("http open api syncOrderStatus ready go! request=[" + request + "]");
        request.setShopId(8);
        RemoteResult response = openOrderRemote.syncOrderStatus(request, SYNC_ORDER_STATUS_FROM_NOTIFICATION);
        LOGGER.info("http open api syncOrderStatus finish! request=[" + request + "], response=[" + response + "]");
        return response;
    }

    /**
     * 签收
     *
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/sign", method = {RequestMethod.POST, RequestMethod.GET})
    public void sign(OrderIdRequest request, HttpServletResponse response) {
        String orderId = request.getOrderId();
        String operator = request.getUserId();
        LOGGER.info("http  sign go!  orderId=[" + orderId + "], operator=[" + operator + "]");
        RemoteResult remoteResult = new RemoteResult(false);
        remoteResult.setResultCode(OrderConstant.RESULT_MSG_FAIL);

        RemoteResult<OrderMain> rs = openOrderRemote.getOrderByOrderCode(orderId);
        if (rs.isSuccess()) {
            OrderMain orderMain = rs.getT();
            int shipStatus = orderMain.getStatus();
            if (shipStatus == OrderConstant.STATUS_UN_SHIPPED) {
                remoteResult.setResultMsg("未发货");
            } else if (shipStatus == OrderConstant.STATUS_SIGNED) {
                remoteResult.setResultMsg("已签收");
            } else if (shipStatus == OrderConstant.STATUS_RETURNED) {
                remoteResult.setResultMsg("已退货");
            } else if (shipStatus == OrderConstant.STATUS_SHIPPED) {
                //签收之后的后续操作调用dubbo接口
                RemoteResult result = openOrderRemote.updateOrderConfirm(String.valueOf(orderMain.getId()), orderMain.getLenovoId() + "", Tenant.getTenant(orderMain.getShopId()));
                LOGGER.info("orderId: " + orderMain.getId() + "  返回参数result:" + result.toString() + "返回信息" + result.getResultMsg());
                if (result.isSuccess()) {
                    remoteResult.setResultMsg(OrderConstant.RESULT_MSG_SUCCESS);
                    remoteResult.setResultCode(OrderConstant.RESULT_COD_SUCCESS);
                    remoteResult.setSuccess(true);
                } else {
                    remoteResult.setResultMsg("sign interface error");
                }
            }
        } else {
            remoteResult.setResultMsg(OrderConstant.RESULT_MSG_TEMP);
            remoteResult.setResultCode(OrderConstant.RESULT_COD_TEMP);
        }
        String json = JsonUtil.toJson(remoteResult);
        LOGGER.info("http  sign finish  orderId=[" + orderId + "], json=[" + json + "]");
        try {
            response.setCharacterEncoding("UTF-8");
            response.getWriter().print(json);
        } catch(Exception e) {
            LOGGER.error("getLogisticTrack error", e);
        }
    }

    /**
     * 查看物流
     *
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/getLogisticTrack", method = {RequestMethod.POST, RequestMethod.GET})
    public void getLogisticTrack(OrderIdRequest request, HttpServletResponse response) {
        String orderCode = request.getOrderId();
        String logisticsNo = request.getLogisticsNo();
        LOGGER.info("http logistics go! orderCode=[" + orderCode + "] logisticsNo=[" + logisticsNo + "]");
        RemoteResult<List<OrderLogistics>> remoteResult = openOrderRemote.getLogisticTrack(orderCode, logisticsNo);
        String json = JsonUtil.toJson(remoteResult);
        LOGGER.info("http logistics finish orderCode=[" + orderCode + "], json=[" + json + "]");
        response.setContentType("text/html;charset=utf-8");
        try {
            response.getWriter().print(json);
        } catch(Exception e) {
            LOGGER.error("getLogisticTrack error", e);
        }

    }
    /**
     * 对接开放平台
     * 查询订单详情 订单信息
     *
     * @param request
     * @param response
     */
    @ResponseBody
    @RequestMapping(value = "/getOpenOrderLogistics", method = {RequestMethod.POST, RequestMethod.GET})
    public void getOpenOrderLogistics(HttpServletRequest request, HttpServletResponse response) {
        String orderCode = request.getParameter("orderCode");
        LOGGER.info("======into  getOpenOrderLogistics  ready go ! param orderCode=" + orderCode + "   =========");
        RemoteResult<List<OrderLogistics>> responseRemote = new RemoteResult<List<OrderLogistics>>();
        if (StringUtils.isEmpty(orderCode)) {
            responseRemote.setResultMsg("orderCode参数不对");
            responseRemote.setSuccess(false);
            responseRemote.setResultCode(OrderConstant.PARAM_COD_ERROR);
        } else {
            responseRemote = openOrderRemote.getOrderLogisticsByOrderCenter(orderCode);
        }
        String jsonOpenOrderMain = JsonUtil.toJson(responseRemote);
        LOGGER.info("====== getOpenOrderLogistics finish! orderCode=" + orderCode + " ,json=" + jsonOpenOrderMain + "  =========");
        response.setContentType("text/html;charset=utf-8");
        try {
            response.getWriter().print(jsonOpenOrderMain);
        } catch (IOException e) {
            LOGGER.error(e);
        }
    }
    /**
     * 查询物流公司码表
     */
    @ResponseBody
    @RequestMapping(value = "/getLogiInfo", method = {RequestMethod.POST, RequestMethod.GET})
    public void getLogiInfo(HttpServletResponse response) {
        RemoteResult<List<LogisticsPlatform>> rs = openOrderRemote.getLogiInfo();
        LOGGER.info("http getLogiInfo go! ");
        String json = JsonUtil.toJson(rs);
        LOGGER.info("http getLogiInfo finish json=[" + json + "]");
        response.setContentType("text/html;charset=utf-8");
        try {
            response.getWriter().print(json);
        } catch(Exception e) {
            LOGGER.error("getLogiInfo error", e);
        }
    }

    /**
     * 发货
     *
     * @param request
     * @param response
     */
    @ResponseBody
    @RequestMapping(value = "/sendGoods", method = {RequestMethod.POST, RequestMethod.GET})
    public void sendGoods(SendGoodsRequest request, HttpServletResponse response) {
        RemoteResult remoteResult = new RemoteResult(false);

        String companyCode = request.getCompanyCode();
        String logisticsNo = request.getLogisticsNo();
        String systemRemark = request.getSystemRemark();//发货备注
        String orderId = request.getOrderId();
        String itCode = request.getUserId();
        LOGGER.info("http sendGoods go!  companyCode=[" + companyCode + "], logisticsNo=[" + logisticsNo + "], orderId=[" + orderId + "], itCode=[" + itCode + "], systemRemark=[" + systemRemark + "]");
        if (orderId == null) {
            remoteResult.setResultCode(ResultCode.FAILURE);
            remoteResult.setResultMsg("前台传入OrderCode为空");
            LOGGER.info("前台传入OrderCode为空");
        } else if (StringUtils.isEmpty(logisticsNo)) {
            remoteResult.setResultCode(ResultCode.FAILURE);
            remoteResult.setResultMsg("物流单号不能为空！");
            LOGGER.info("物流单号不能为空！orderCode=[" + orderId + "]");
        } else if (StringUtils.isEmpty(companyCode)) {
            remoteResult.setResultCode(ResultCode.FAILURE);
            remoteResult.setResultMsg("物流公司不能为空！");
            LOGGER.info("物流公司不能为空！orderCode=[" + orderId + "]");
        } else {
            RemoteLogistic remoteLogistic = new RemoteLogistic();
            remoteLogistic.setLogiNo(logisticsNo);
            remoteLogistic.setLogiName(companyCode);
            remoteLogistic.setOrderCode(orderId);
            remoteLogistic.setOrderType(OrderConstant.ORDER_TYPE_NORMAL);
            remoteLogistic.setShipDate(DateUtil.formatDate(new Date()));
            remoteLogistic.setLogiType("0");
            remoteLogistic.setShipStatus(OrderConstant.ORDER_DELIVER_SHIPPED + "");
            remoteLogistic.setLogiPhone(request.getLogisticsPhone());
            remoteResult = openOrderRemote.logisticsDelivery(remoteLogistic, "indirect");
            String json = JsonUtil.toJson(remoteResult);

            LOGGER.info("http sendGoods finish   companyCode=[" + companyCode + "], logisticsNo=[" + logisticsNo + "], orderId=[" + orderId + "], json=[" + json + "]");
            response.setContentType("text/html;charset=utf-8");
            try {
                response.getWriter().print(json);
            } catch(Exception e) {
                LOGGER.error("sendGoods error", e);
            }
        }
    }

    //baiying的分页和导出接口
    /**
     * 提供业务导出CPS订单数据接口
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/cps/exportOrderToExcel",method = {RequestMethod.POST,RequestMethod.GET})
    public void exportOrderToExcel(HttpServletRequest request, HttpServletResponse response){
        String[] excelHeader = {"订单编号","活动ID","下单时间","商品数量","商品金额","商品名称","更新时间","商品编号","商品类别",
                "佣金类型","优惠额","优惠码","订单状态","支付状态","支付方式"};
        String resultInfo;
        SXSSFWorkbook wb = new SXSSFWorkbook();
        try {
            String cid = request.getParameter("cid");
            String orderNo = request.getParameter("orderNo");
            String orderStartTime = request.getParameter("orderStartTime");
            String orderEndTime = request.getParameter("orderEndTime");
            LOGGER.info("RpcController exportOrderToExcel param：cid="+cid+",orderNo="+orderNo+",orderStartTime="+orderStartTime+"orderEndTime="+orderEndTime);
            resultInfo = openOrderRemote.exportOrderToExcel(cid,orderNo,orderStartTime,orderEndTime);

            List<Map<String, Object>> list = (List<Map<String, Object>>)(JSONArray.parse(resultInfo));
            List<Row> rowList =new ArrayList<Row>() ;
            wb.setCompressTempFiles(true);
            RemoteResult rs = new RemoteResult(false);
            Sheet sheet = ExcelSAXHandler.createSheet(wb, "百应CPS订单", excelHeader);

            if(!list.isEmpty()){
                int i=1;
                for (Map<String, Object> map : list) {
                    //int lastRowNum = sheet.getLastRowNum();
                    Row createRow = sheet.createRow(i);
                    createRow.createCell(0).setCellValue((String)map.get("orderNo"));
                    createRow.createCell(1).setCellValue((String)map.get("campaignId"));
                    //createRow.createCell(2).setCellValue((String)map.get("feedback"));
                    createRow.createCell(2).setCellValue((String)map.get("orderTime"));
                    createRow.createCell(3).setCellValue((String)map.get("amount"));
                    createRow.createCell(4).setCellValue(((BigDecimal)map.get("price")).toString());
                    createRow.createCell(5).setCellValue((String)map.get("name"));
                    createRow.createCell(6).setCellValue((String)map.get("updateTime"));
                    createRow.createCell(7).setCellValue((String)map.get("productNo"));
                    createRow.createCell(8).setCellValue((String)map.get("category"));
                    createRow.createCell(9).setCellValue((String)map.get("commissionType"));
                    //createRow.createCell(11).setCellValue((String)map.get("fare"));
                    createRow.createCell(10).setCellValue(((BigDecimal)map.get("favorable")).toString());
                    createRow.createCell(11).setCellValue((String)map.get("favorableCode"));
                    createRow.createCell(12).setCellValue((String)map.get("orderStatus"));
                    createRow.createCell(13).setCellValue((String)map.get("paymentStatus"));
                    createRow.createCell(14).setCellValue((String)map.get("paymentType"));
                    rowList.add(createRow);
                    i++;
                }
            }
            //上传到图片服务器
            String readURL = ExcelSAXHandler.uploadImage(wb);
            sendToPage(readURL, rs, wb, response);
        } catch (Exception e) {
            LOGGER.error("cps订单报表导出异常", e);
            try {
                if (wb != null) {
                    wb.dispose();
                    wb.close();
                }
            } catch (IOException e1) {
                LOGGER.error("cps订单报表关闭workbook异常", e1);
            }
        }
    }

    /**
     * 返回开放平台信息
     *
     * @param readURL
     * @param rs
     * @param response
     * @throws Exception
     */
    public void sendToPage(String readURL, RemoteResult rs, SXSSFWorkbook workbook, HttpServletResponse response) throws Exception {
        if (org.apache.commons.lang.StringUtils.isNotBlank(readURL)) {
            LOGGER.info("========sendToPage SUCCESS=============");
            LOGGER.info("sendToPage readURL:"+readURL);
            rs.setSuccess(true);
            rs.setT(readURL);
            rs.setResultCode("1000");
            rs.setResultMsg("操作成功");
        }
        LOGGER.info("========export excel SUCCESS=============");
        workbook.dispose();
        workbook.close();
        String json = JsonUtil.toJson(rs);
        response.setContentType("text/html;charset=utf-8");
        response.getWriter().print(json);
        response.getWriter().close();
    }


    /**
     * 分页查询CPS订单
     * @param request
     * @param cid
     * @param orderNo
     * @param orderStartTime
     * @param orderEndTime
     * @return
     */
    @RequestMapping(value = "/cps/getCpsOrderInfoByPage",produces = "application/json;charset=UTF-8",method = {RequestMethod.POST,RequestMethod.GET})
    @ResponseBody
    public String getCpsOrderInfoByPage(HttpServletRequest request,String cid,String orderNo,String orderStartTime,String orderEndTime){
        int pageNum = Integer.parseInt(request.getParameter("pageNum")==null?"1":request.getParameter("pageNum"));
        int pageSize = Integer.parseInt(request.getParameter("pageSize")==null?"10":request.getParameter("pageSize"));
        LOGGER.info("RpcController getCpsOrderInfoByParam 分页param：pageNum="+pageNum+",pageSize="+pageSize);
        PageQuery pageQuery = new PageQuery(pageNum,pageSize);
        RemoteResult<Map<String,Object>> remoteResult = openOrderRemote.getCpsOrderInfoByPage(cid,orderNo,orderStartTime,orderEndTime,pageQuery);
        Long totalCount = 0L;
        int totalPageNum = 0;
        if(remoteResult.getT().get("pageQuery")!=null){
            totalCount = ((PageQuery)remoteResult.getT().get("pageQuery")).getTotalCount();
            totalPageNum = ((PageQuery)remoteResult.getT().get("pageQuery")).getTotalPageNum();
        }
        LOGGER.info("RpcController getCpsOrderInfoByParam 分页param：totalCount="+totalCount+",totalPageNum="+totalPageNum);
        Map<String,Object> map = new HashMap<>();
        map.put("resultData",remoteResult.getT().get("messageList")==null?new ArrayList<Map<String,Object>>():remoteResult.getT().get("messageList"));
        map.put("isSuccess",remoteResult.isSuccess());
        map.put("resultCode",remoteResult.getResultCode());
        map.put("resultMsg",remoteResult.getResultMsg());
        map.put("totalCount",totalCount);
        map.put("totalPageNum",totalPageNum);
        return JsonUtil.toJson(map);
    }
}
