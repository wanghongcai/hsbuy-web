package com.lenovo.m2.buy.promotion.pay.outpay;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.pay.common.util.JsonUtil;
import com.lenovo.m2.arch.pay.common.util.ReturnCode;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.LePayUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PaySignUtils;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.AlipayUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.StringUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.DateUtil;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayDirectWapManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayJsManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.allinpay.AllinpayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonPayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.PayPointRulesManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.pingan.PingAnPayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.umpay.UmpayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.wxpay.WxPayManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.buy.promotion.pay.ppcloud.ParameterRequestWrapper;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.baseInfo.PayPointRules;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.*;

/**
 * 外部支付接口
 * Created by MengQiang on 2016/10/21.
 */
@Controller
public class OutPayController {

    private Logger LOGGER = Logger.getLogger(this.getClass());

    @Autowired
    private PayPortalOrderManager payPortalOrderManager;

    @Autowired
    private AliPayJsManager aliPayJsManager;

    @Autowired
    private AllinpayManager allinpayManager;

    @Autowired
    private AliPayDirectWapManager aliPayDirectWapManager;


    @Autowired
    private PingAnPayManager pingAnPayManager;

    @Autowired
    private UmpayManager umpayManager;
    @Autowired
    private PayPointRulesManager payPointRulesManager;

    @Autowired
    private CommonManager commonManager;

    @Autowired
    private CommonPayManager commonPayManager;

    @Autowired
    private CommonCallBackManager commonCallBackManager;

    @Autowired
    private PayOrderApi payOrderApi;

    @Autowired
    private AliPayCommonManager aliPayCommonManager;

    @RequestMapping("/directPay")
    public String directPay(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        Map<?, ?> requestParams = request.getParameterMap();
        Map<String, String> paras = AlipayUtil.parseRequestParams(requestParams);
        List<String> keys = new ArrayList(paras.keySet());
        for (String key : keys) {
            LOGGER.info("DirectPay,Key[" + key + "],Value[" + paras.get(key) + "]");
        }
        String service = request.getParameter("service");
        String signType = request.getParameter("sign_type");
        String sign = request.getParameter("sign");
        String notifyUrl = request.getParameter("notify_url");
        String returnUrl = request.getParameter("return_url");
        String exceptionUrl = request.getParameter("exception_url");
        String inputCharset = request.getParameter("input_charset");
        String payment = request.getParameter("payment");
        String qrPayMode = request.getParameter("qr_pay_mode");
        String shopId = request.getParameter("shop_id");
        String terminal = request.getParameter("terminal");
        String currencyCode = request.getParameter("currency_code");
        String tradeInfo = request.getParameter("trade_info");
        String failTradeInfo = tradeInfo;
        LOGGER.info("Https Invoke OutPayController DirectPay! service[" + service + "],signType[" + signType + "],sign[" + sign + "],notifyUrl[" +
                notifyUrl + "],returnUrl[" + returnUrl + "],exceptionUrl[" + exceptionUrl + "],inputCharset[" + inputCharset + "],payment[" +
                payment + "],qrPayMode[" + qrPayMode + "],shopId[" + shopId + "],terminal[" + terminal + "],tradeInfo[" +
                tradeInfo + "],currencyCode[" + currencyCode + "]");
        LOGGER.info("DirectPay Check PayPortalOrder QueryString[" + request.getQueryString() + "]");
        Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
        String signKey = (String) commonParam.get(shopId);
        if (StringUtils.isEmpty(signKey) || "null".equals(signKey)) {
            LOGGER.info("DirectPay SignKey IS NULL OR Illegal");
            paraMap.put("error_code", "ILLEGAL_SHOP_ID");
            paraMap.put("error_msg", "非法商户");
            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
        }
        String plat = CommonMethod.getPlatFromShopIdTerminal(shopId, terminal);
        paraMap.put("plat", plat);
        paraMap.put("shopId", shopId);
        paraMap.put("terminal", terminal);
        paraMap.put("merchantCode", "out");
        if (StringUtils.isEmpty(tradeInfo)) {
            LOGGER.info("DirectPay TradeInfo IS NULL");
            paraMap.put("error_code", "ILLEGAL_TRADE_INFO");
            paraMap.put("error_msg", "支付参数异常trade_info");
            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
        }

        Map<String, String> signMap = new HashMap<String, String>();
        signMap.put("service", service);
        signMap.put("notify_url", notifyUrl);
        signMap.put("return_url", returnUrl);
        signMap.put("exception_url", exceptionUrl);
        signMap.put("input_charset", inputCharset);
        signMap.put("payment", payment);
        signMap.put("qr_pay_mode", qrPayMode);
        signMap.put("shop_id", shopId);
        signMap.put("terminal", terminal);
        if (StringUtils.isNotEmpty(currencyCode)) {
            signMap.put("currency_code", currencyCode);
        } else {
            currencyCode = "CNY";
        }
        signMap.put("trade_info", tradeInfo);
        if (StringUtils.isEmpty(sign) || StringUtils.isEmpty(signType)) {
            LOGGER.info("DirectPay Sign Or SignType IS NULL");
            paraMap.put("error_code", "ILLEGAL_SIGN_OR_SIGN_TYPE");
            paraMap.put("error_msg", "支付参数异常，Sign/SignType为空");
            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
        }
        boolean checkSign = PaySignUtils.checkSignKey(sign, signMap, signType, signKey);
        if (checkSign) {
            LOGGER.info("Check Signature SUCCESS");
        } else {
            LOGGER.info("DirectPay Check Signature FAIL");
            paraMap.put("error_code", "ILLEGAL_SIGN");
            paraMap.put("error_msg", "非法请求，签名错误");
            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
        }
        Map<String, String> tradeInfoMap;
        try {
            tradeInfoMap = LePayUtil.parseTradeInfo(tradeInfo);
        } catch (Exception e) {
            paraMap.put("error_code", "ILLEGAL_TRADE_INFO");
            paraMap.put("error_msg", "tradeInfoMap 支付参数异常,tradeInfo格式错误");
            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
        }
        try {
            tradeInfo = URLDecoder.decode(tradeInfo, "UTF-8");
            LOGGER.info("DirectPay URLDECODER tradeInfo[" + tradeInfo + "]");
        } catch (UnsupportedEncodingException e) {
            LOGGER.info("URLDecode TradeInfo Fail", e);
            paraMap.put("error_code", "ILLEGAL_TRADE_INFO");
            paraMap.put("error_msg", "支付参数异常,tradeInfo格式错误");
            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
        }

        String lenovoId = tradeInfoMap.get("lenovo_id");
        String faId = tradeInfoMap.get("fa_id");
        String rewardPoint = tradeInfoMap.get("reward_point");
        Tenant tenant = CommonMethod.buildTenant(shopId, currencyCode, null, null, null, null, null);
        List<PayPortalOrder> payPortalOrderList = new ArrayList<PayPortalOrder>();
        List<String> outTradeNoList = new ArrayList<String>();
        String[] payPortalOrderArray = tradeInfo.split("&\\-&");
        for (String payPortalOrderInfo : payPortalOrderArray) {
            try {
                LOGGER.info("PayPortalOrderInfo[" + payPortalOrderInfo + "]");
                String[] payPortalOrderParamArray = payPortalOrderInfo.split("&\\+&");
                if (payPortalOrderParamArray.length == 0) {
                    LOGGER.info("URLDecode TradeInfo Fail");
                    paraMap.put("error_code", "ILLEGAL_TRADE_INFO");
                    paraMap.put("error_msg", "支付参数异常,tradeInfo格式错误");
                    return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
                }
                Map<String, String> requestParam = new HashMap<String, String>();
                for (String payPortalOrderParam : payPortalOrderParamArray) {
                    if (StringUtils.isNotEmpty(payPortalOrderParam)) {
                        String[] kvs = payPortalOrderParam.split("=");
                        if (kvs != null && kvs.length == 2) {
                            if ("null".equals(kvs[1])) {
                                LOGGER.info("Illegal Value, Key is[" + kvs[0] + "],Value is [" + kvs[1] + "]");
                            } else {
                                requestParam.put(kvs[0], kvs[1]);
                            }
                        } else {
                            LOGGER.info("KVS is NULL Or Kvs Length Illegal");
                        }
                    } else {
                        LOGGER.info("Analysis PayPortalOrderParam IS NULL");
                    }
                }
                RemoteResult<String> checkRequestParamResult = CommonMethod.checkRequestParam(requestParam);
                PayPortalOrder payPortalOrder;

                if (checkRequestParamResult.isSuccess()) {
                    //-------------------------------------------------积分验证
                    double pointMoney = 0;//积分兑换后 金额
                    LOGGER.info("Check RequestParam SUCCESS");
                    LOGGER.info("rewardPoint==========" + rewardPoint + "],outTradeNo" + tradeInfoMap.get("out_trade_no") + "],shopId=[" + shopId + "]");
                    if (shopId.equals(PeakConstant.SHOPID_HUISHANG) && StringUtil.isNotBlank(rewardPoint) && !"0".equals(rewardPoint)) {//存在积分
                        String totalFee = tradeInfoMap.get("total_fee");
                        String outTradeNo = tradeInfoMap.get("out_trade_no");
                        LOGGER.info("积分入参验证 total_fee=[" + totalFee + "], faId=[" + faId + "], lenovoId=[" + lenovoId + "], rewardPoint=[" + rewardPoint + "],outTradeNo=[" + outTradeNo + "]");
                        RemoteResult<PayPointRules> payPointRulesRemoteResult = payPointRulesManager.getPayPointRulesByfaId(faId);
                        if (!payPointRulesRemoteResult.isSuccess()) { //积分是否可用
                            LOGGER.info("Check RequestParam rewardPoint is_able  FAIL faId=[" + faId + "],outTradeNo=[" + outTradeNo + "]");
                            paraMap.put("error_code", "POINT_IS_ABLE_NO");
                            paraMap.put("error_msg", "积分不可用  ");
                            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
                        }


                        PayPointRules payPointRules = payPointRulesRemoteResult.getT();
                        Integer pointRate = payPointRules.getPointRate();//积分比例
                        Integer rewardPoinInt = Integer.parseInt(rewardPoint); //积分数量
                        pointMoney = rewardPoinInt / pointRate;//积分兑换现金
                        double permitTotalFeeMax = Double.parseDouble(totalFee) * payPointRules.rateDouble();
                        if (pointMoney > Double.parseDouble(totalFee) || pointMoney > permitTotalFeeMax) {
                            LOGGER.info("积分兑换大于总金额或超出积分使用上限 lenovoId=[" + lenovoId + "],outTradeNo=[" + outTradeNo + "],totalFee=[" + totalFee + "],pointMoney=[" + pointMoney + "],permitTotalFeeMax=[" + permitTotalFeeMax + "]");
                            paraMap.put("error_code", "POINT_TOTAlFEE_ERROR_PARAM_");
                            paraMap.put("error_msg", "积分兑换大于总金额或超出积分使用上限");
                            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
                        }

                    }

                    payPortalOrder = this.buildPayPortalOrderFromRequestParam(requestParam, shopId, terminal, currencyCode, pointMoney);
                } else {
                    LOGGER.info("Check RequestParam FAIL");
                    paraMap.put("error_code", "ILLEGAL_REQUEST_PARAM_" + checkRequestParamResult.getResultCode().toUpperCase());
                    paraMap.put("error_msg", "支付参数异常" + checkRequestParamResult.getResultCode().toUpperCase());
                    return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
                }
                if (payPortalOrder != null) {
                    payPortalOrderList.add(payPortalOrder);
                    outTradeNoList.add(payPortalOrder.getOutTradeNo());
                }
            } catch (Exception e) {
                LOGGER.info("处理单条PayPortalOrder信息异常,PayPortalOrderInfo[" + payPortalOrderInfo + "]", e);
            }
        }
        try {
            if (payPortalOrderList != null && payPortalOrderList.size() > 0) {
                //TODO Check Exist PayPortalOrder
                RemoteResult<List<PayPortalOrder>> existPayPortalOrderList = payPortalOrderManager.queryPayPortalOrderListByOutTradeNoList(outTradeNoList, null, tenant);
                List<PayPortalOrder> savePayPortalOrderList = new ArrayList<PayPortalOrder>();
                List<PayPortalOrder> updatePayPortalOrderList = new ArrayList<PayPortalOrder>();
                Map<String, PayPortalOrder> existPayPortalOrderMap = new HashMap<String, PayPortalOrder>();
                if (existPayPortalOrderList.isSuccess()) {
                    LOGGER.info("DirectPay PayPortalOrder Exist[" + existPayPortalOrderList + "]");
                    for (PayPortalOrder existPayPortalOrder : existPayPortalOrderList.getT()) {//存在订单
                        existPayPortalOrderMap.put(existPayPortalOrder.getOutTradeNo(), existPayPortalOrder);
                        if (PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(existPayPortalOrder.getOrderStatus()))) {
                            LOGGER.info("DirectPay Illegal Status,PayPortalOrder[" + existPayPortalOrder + "],OrderStatus[" + existPayPortalOrder.getOrderStatus() + "]");
                            paraMap.put("error_code", "ILLEGAL_ORDER_STATUS");
                            paraMap.put("error_msg", "订单已失效");
                            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
                        }


                        if (PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(existPayPortalOrder.getPayStatus()))) {
                            LOGGER.info("DirectPay Illegal Status,PayPortalOrder[" + existPayPortalOrder + "],PayStatus[" + existPayPortalOrder.getPayStatus() + "]");
                            paraMap.put("error_code", "ORDER_ALREADY_PAID");
                            paraMap.put("error_msg", "订单已支付");
                            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
                        }
                        //传入积分
                        Integer usePonitsParam = payPortalOrderList.get(0).getPoint();
                        //已存积分
                        Integer usePonitsExist = existPayPortalOrder.getPoint();
                        LOGGER.info("lenovoId=[" + lenovoId + "],传入积分 =[" + usePonitsParam + "], 已存在积分 =[" + usePonitsExist + "]");
                        if (usePonitsParam > 0 || usePonitsExist > 0) {
                            if (usePonitsExist != 0 && !usePonitsParam.equals(usePonitsExist)) {
                                LOGGER.info("DirectPay Illegal Status,usePonitsParam=[" + usePonitsParam + "],usePonitsExist =[" + usePonitsExist + "]");
                                paraMap.put("error_code", "ORDER_USEPONITS_ERROR");
                                paraMap.put("error_msg", "积分前后不一致");
                                return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
                            }
                        }

                    }
                } else {
                    LOGGER.info("DirectPay PayPortalOrder Not Exist");
                }
                for (PayPortalOrder payPortalOrder : payPortalOrderList) {
                    payPortalOrder.setReturnUrl(returnUrl);
                    payPortalOrder.setNotifyUrl(notifyUrl);
                    payPortalOrder.setExceptionUrl(exceptionUrl);
                    if (existPayPortalOrderMap.containsKey(payPortalOrder.getOutTradeNo())) {
                        payPortalOrder.setId(existPayPortalOrderMap.get(payPortalOrder.getOutTradeNo()).getId());
                        updatePayPortalOrderList.add(payPortalOrder);
                    } else {
                        savePayPortalOrderList.add(payPortalOrder);
                    }
                }
                if (savePayPortalOrderList.size() == 0 && updatePayPortalOrderList.size() == 0) {
                    LOGGER.info("DirectPay SavePayPortalOrderList And UpdatePayPortalOrderList ARE BOTH NULL");
                    paraMap.put("error_code", "ILLEGAL_ORDER");
                    paraMap.put("error_msg", "解析订单信息异常，请重新发起");
                    return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
                }

                RemoteResult<Boolean> saveUpdatePayPortalOrderRemoteResult = payPortalOrderManager.saveOrUpdatePayPortalOrderList(savePayPortalOrderList, updatePayPortalOrderList);
                if (saveUpdatePayPortalOrderRemoteResult.isSuccess()) {
                    LOGGER.info("DirectPay SaveOrUpdate payPortalOrderList SUCCESS");
                    PayPortalOrder payPortalOrder = null;
                    //首次支付
                    if (PeakConstant.SHOPID_HUISHANG.equals(shopId)
                            && !savePayPortalOrderList.isEmpty() && savePayPortalOrderList.size() > 0
                            && savePayPortalOrderList.get(0).getPoint() > 0) {
                        String outTradeNo = tradeInfoMap.get("out_trade_no");
                        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(outTradeNo, lenovoId, tenant);
                        payPortalOrder = payPortalOrderRemoteResult.getT();
                        if (!LePayUtil.writePointMppay(payPortalOrder, paraMap)) {
                            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
                        }

                        //重复支付
                    } else if (PeakConstant.SHOPID_HUISHANG.equals(shopId)
                            && !updatePayPortalOrderList.isEmpty() && updatePayPortalOrderList.size() > 0
                            && updatePayPortalOrderList.get(0).getPoint() > 0
                            && existPayPortalOrderMap.containsKey(updatePayPortalOrderList.get(0).getOutTradeNo())) {   //重复支付
                        PayPortalOrder payPortalOrderExist = existPayPortalOrderMap.get(updatePayPortalOrderList.get(0).getOutTradeNo());
                        payPortalOrder = updatePayPortalOrderList.get(0);
                        if (payPortalOrderExist.getPoint() == 0) {
                            if (!LePayUtil.writePointMppay(payPortalOrder, paraMap)) {
                                return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
                            }
                        }

                    }
                    //判断惠商0元订单
                    if (null != payPortalOrder
                            && PeakConstant.SHOPID_HUISHANG.equals(shopId)
                            && payPortalOrder.getTotalFee().equals(new Money(0, currencyCode))
                            && payPortalOrder.getPoint() > 0) {
                        return zeroPay( payPortalOrder, paraMap, commonParam);

                    }


                } else {
                    LOGGER.info("DirectPay SaveOrUpdate payPortalOrderList FAIL");
                    paraMap.put("error_code", "SYSTEM_ERROR");
                    paraMap.put("error_msg", "服务器异常，请重新发起");
                    return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
                }

            } else {
                LOGGER.info("DirectPay Build SaveOrUpate PayPortalOrderList FAIL, PayPortalOrderList IS NULL");
                paraMap.put("error_code", "SYSTEM_ERROR");
                paraMap.put("error_msg", "服务器异常，请重新发起");
                return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
            }
        } catch (Exception saveOrUpdateException) {
            LOGGER.info("Save Or Update PayPortalOrder Excepion", saveOrUpdateException);
            paraMap.put("error_code", "SYSTEM_ERROR");
            paraMap.put("error_msg", "服务器异常，请重新发起");
            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
        }


        //TODO 基于Payment构建支付请求
        Map<String, String[]> requestMap = new HashMap<String, String[]>(request.getParameterMap());
        requestMap.put("paymentTypeCode", new String[]{payment});
        requestMap.put("qrPayMode", new String[]{qrPayMode});
        requestMap.put("merchantCode", new String[]{"out"});
        requestMap.put("os", new String[]{plat});
        requestMap.put("plat", new String[]{plat});
        requestMap.put("shopId", new String[]{shopId});
        requestMap.put("terminal", new String[]{terminal});
        requestMap.put("orderMainCode", new String[]{payPortalOrderList.get(0).getOutTradeNo()});
        request = new ParameterRequestWrapper(request, requestMap);
        LOGGER.info("DirectPay Go Route QueryString[" + request.getQueryString() + "]");
        LOGGER.info("DirectPay Go Route orderMainCode[" + request.getParameter("orderMainCode") + "]");

        try {
            RemoteResult<String> returnResult = new RemoteResult<String>();
            if (PeakConstant.PAY_TYPE_ALJS.equals(payment)) {
                returnResult = aliPayJsManager.toAliJsPay(request);
                LOGGER.info("DirectPay Invoke AliPay DirectPay, result[" + returnResult + "]");
            } else if (PeakConstant.PAY_TYPE_ALSJ.equals(payment)) {
                returnResult = aliPayDirectWapManager.toDirectWapPay(request);
                LOGGER.info("DirectPay Invoke AliPay DirectWAPPay, result[" + returnResult + "]");
            } else if (PeakConstant.PAY_TYPE_ALLINPAY.equals(payment)) {
                //通联支付
                returnResult = allinpayManager.toPay(request);
                LOGGER.info("DirectPay Invoke Allinpay DirectPay, result[" + returnResult + "]");
            } else if (PeakConstant.PAY_TYPE_ALLINPAY_AUTH_PAY.equals(payment)) {
                //通联移动认证支付
                returnResult = allinpayManager.toPay(request);
                LOGGER.info("DirectPay Invoke AllinpayWap DirectPay, result[" + returnResult + "]");
            } else if (PeakConstant.PAY_TYPE_PINGAN.equals(payment)) {
                //平安支付
                returnResult = pingAnPayManager.toPay(request);
                LOGGER.info("DirectPay Invoke PingAn DirectPay, result[" + returnResult + "]");
            } else if (PeakConstant.PAY_TYPE_PINGAN_WAP.equals(payment)) {
                //平安手机支付
                returnResult = pingAnPayManager.toPay(request);
                LOGGER.info("DirectPay Invoke PingAn Wap DirectPay, result[" + returnResult + "]");
            } else if (PeakConstant.PAY_TYPE_UMPAY.equals(payment)) {
                // 联动优势支付
                returnResult = umpayManager.toUmPay(request);
                LOGGER.info("DirectPay Invoke UnionMobilePay Fro PC, result[" + returnResult + "]");
            } else if (PeakConstant.PAY_TYPE_UMPAY_WAP.equals(payment)) {
                // 联动优势支付Wap(H5)
                returnResult = umpayManager.toUmPay(request);
                LOGGER.info("DirectPay Invoke UnionMobilePay For WAP, result[" + returnResult + "]");
            } else if (PeakConstant.PAY_TYPE_ALLINPAY_SHORTCUT.equals(payment)) {
                // 通联H5快捷支付
                returnResult = allinpayManager.toPay(request);
                LOGGER.info("DirectPay Invoke Allinpay Shortcut Pay For H5, result[" + returnResult + "]");

            }else {
               paraMap.put("error_code", "SYSTEM_ERROR");
               paraMap.put("error_msg", "服务器异常，请重新发起！");
               return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);

            }
            if (returnResult.isSuccess()) {
                paraMap.put("postForm", returnResult.getT());
                return "outpay/outpay_gotobank";
            } else {
                LOGGER.info("DirectPay Build HTML Request FAIL");
                paraMap.put("error_code", "SYSTEM_ERROR");
                paraMap.put("error_msg", "服务器异常，请重新发起");
                return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
            }
        } catch (Exception e) {
            LOGGER.info("Build HTML Request Excepion", e);
            paraMap.put("error_code", "SYSTEM_ERROR");
            paraMap.put("error_msg", "服务器异常，请重新发起");
            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
        }
    }

    private String buildWeChatQueryKey(String outTradeNo, String shopId, String payment, Map<String, Object> commonParam) {
        LOGGER.info("Invoke buildWeChatQueryKey, outTradeNo[" + outTradeNo + "],shopId[" + shopId + "],payment[" + payment + "]");
        Map<String, String> signMap = new HashMap<String, String>();
        signMap.put("outTradeNo", outTradeNo);
        signMap.put("shopId", shopId);
        signMap.put("payment", payment);
        String signKey = (String) commonParam.get(shopId);
        String sign = PaySignUtils.buildSignKey(signMap, "MD5", signKey);
        return sign;
    }


    /**
     * 0元支付
     * @param payPortalOrder
     * @param paraMap
     * @param commonParam
     * @return
     */
    private String zeroPay(PayPortalOrder payPortalOrder, Map<String, Object> paraMap, Map<String, Object> commonParam) {
        String shopId = payPortalOrder.getShopId();
        PayOrder payOrder = new PayOrder();
        payOrder.setId(Long.valueOf("0000"));
        payOrder.setPay_type(payPortalOrder.getPayment());
        payOrder.setShop_id(payPortalOrder.getShopId());
        payOrder.setCurrencyCode(payPortalOrder.getCurrencyCode());
        payOrder.setOut_trade_no(payPortalOrder.getOutTradeNo());
        payOrder.setTerminal(payPortalOrder.getTerminal());
        if (CommonMethod.checkInShopId(shopId)) {
            LOGGER.info("0元 ，支付系统通过dubbo通知商户系统 shopId=[" + shopId + "], outTradeNo=[" + payPortalOrder.getOutTradeNo() + "]");
            RemoteResult<String> result = zeroCallUpdate(payPortalOrder, payOrder);
            LOGGER.info("0元 ，支付系统通过dubbo通知商户系统 返回结果=" + JsonUtil.toJson(result));
        } else {
            LOGGER.error(" 0元 ，支付系统通过HTTP通知商户系统，shopId[" + payOrder.getShop_id() + "], outTradeNo=[" + payPortalOrder.getOutTradeNo() + "]");
        }

        return CommonMethod.getOutSyncReturnForm(payOrder, null, payPortalOrder, paraMap, commonParam, "TRADE_SUCCESS", String.valueOf(payOrder.getId()));

    }

    /**
     * 0元支付回调
     * @param payPortalOrder
     * @param payOrder
     * @return
     */
    public  RemoteResult<String> zeroCallUpdate(PayPortalOrder payPortalOrder,PayOrder payOrder){
        RemoteResult<String> result = new RemoteResult<String>();
        String shopId  = payPortalOrder.getShopId();
        LOGGER.info("payPortalOrder==============" + JsonUtil.toJson(payPortalOrder));
        try{

            PayPortalOrder updatePayPortalOrder = CommonMethod.buildUpdatePayPortalOrder("0000", payPortalOrder.getOutTradeNo(), payPortalOrder.getLenovoId(), (null == payPortalOrder.getPayment()) ? 43 : payPortalOrder.getPayment(), PeakConstant.PAY_STATUS_ALREADY_PAID, payPortalOrder.getShopId(), new Date());
            RemoteResult<Integer> updatePayPortalOrderResult = payPortalOrderManager.updatePayPortalOrderPayStatus(updatePayPortalOrder);
            if (updatePayPortalOrderResult.isSuccess()) {
                LOGGER.info("0 Update PayPortalOrder SUCCESS，outTradeNo[" + payPortalOrder.getOutTradeNo() + "]");
            } else {
                LOGGER.error("0 Update PayPortalOrder FAIL，outTradeNo[" + payPortalOrder.getOutTradeNo() + "]");
            }
            MerchantPayPlatView merchantPayPlatView = new MerchantPayPlatView();
            merchantPayPlatView.setPayType(payPortalOrder.getPayment());

            result = commonCallBackManager.payCallback(merchantPayPlatView, 16, null, payOrder.getOut_trade_no(), "0000", DateUtil.formatDate(new Date(), PeakConstant.CALL_MIDDLEWARE_PAY_TYPE), payPortalOrder.getPayment().toString(), payPortalOrder.getLenovoId(), "0000", payOrder);
            LOGGER.info("0元支付 更新订单状态 shopId=" + shopId + ", 返回信息=" + JsonUtil.toJson(result));
            if(!result.isSuccess()){
                LOGGER.error("0元支付 更新订单状态失败 orderId=[" + payOrder.getOut_trade_no() + "], shopId=[" + shopId + "], 返回结果信息=[" + JsonUtil.toJson(result) + "]");
            }

        }catch (Exception e){
            result.setSuccess(false);
            result.setResultCode(ReturnCode.InNotifyFail.getCode());
            result.setResultMsg(ReturnCode.InNotifyFail.getMessage());
            LOGGER.error("Excep--->" ,e);
        }
        return result;
    }

    private String pointZeroPay(String lenovoId, String plat, String currencyCode, PayPortalOrder payPortalOrder, Map<String, String> tradeInfoMap, String service, String payment, String failTradeInfo, String shopId, String terminal, String exceptionUrl, Map<String, Object> paraMap, Map<String, Object> commonParam) {
        String orderMainCode = payPortalOrder.getOutTradeNo();
        MerchantPayPlatView merchantPayPlatView;
        //查询支付平台信息
        Integer accountType = Integer.parseInt(tradeInfoMap.get("account_type"));
        RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult = commonPayManager.getMerchantPayPlatByAccountType(payPortalOrder.getFaId(), payment, accountType);
        if (merchantPayPlatViewRemoteResult != null && merchantPayPlatViewRemoteResult.isSuccess()) {
            merchantPayPlatView = merchantPayPlatViewRemoteResult.getT();
            LOGGER.info("MerchantPayPlatView[" + merchantPayPlatView + "],OrderMainCode[" + orderMainCode + "]");
        } else {
            LOGGER.error("惠商0元支付 ,查询支付平台信息失败，订单号[" + orderMainCode + "]");
            paraMap.put("error_code", "HS FIND MERCHANTPAYPLAT_ERROR");
            paraMap.put("error_msg", "惠商0元支付查询支付平台信息异常");
            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
        }

        String prodName = CommonMethod.getProductName(payPortalOrder.getSubject());
        //保存wx pay order 更新已支付状态
        RemoteResult<String> returnResult = commonManager.savePayOrder(lenovoId, plat, payment, orderMainCode, String.valueOf(payPortalOrder.getTotalFee().getAmount()), prodName, "", 0, "", "out", "", shopId, terminal, merchantPayPlatView, currencyCode);
        if (!returnResult.isSuccess()) {
            LOGGER.error("HS TOTALFEE = 0 Save AliPay PayOrder FAIL");
            paraMap.put("error_code", "HS 0 TOTALFEE ERROR");
            paraMap.put("error_msg", "惠商0元支付保存订单失败");
            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
        }
        RemoteResult<List<PayOrder>> payOrderRs = commonManager.getPayOrderListByPayType(orderMainCode, Integer.parseInt(payment));
        if (null == payOrderRs && payOrderRs.getT().size() != 1) {
            LOGGER.error("hs 0元 wxPatOrder 查询失败 out_trade_no = " + orderMainCode);
            paraMap.put("error_code", "HS 0 wxPatOrder ERROR");
            paraMap.put("error_msg", "惠商0元支付查询wxPatOrder异常");
            return getFailRedirect(service, payment, failTradeInfo, shopId, terminal, exceptionUrl, paraMap, commonParam);
        }
        PayOrder payOrder = payOrderRs.getT().get(0);
        Long orderPrimaryId = payOrder.getId();

        Map<String, String> paraHsMap = new HashMap<String, String>();
        paraHsMap.put("tradeStatus", "TRADE_SUCCESS");
        paraHsMap.put("tradeNo", String.valueOf(orderPrimaryId));
        paraHsMap.put("gmtPayment", DateUtil.formatDate(new Date(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
        paraHsMap.put("notifyId", DateUtil.formatDate(new Date(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
        paraHsMap.put("payType", String.valueOf(payOrder.getPay_type()));
        paraHsMap.put("bankSeqNo", DateUtil.formatDate(new Date(), PeakConstant.CALL_MIDDLEWARE_PAY_TYPE) + orderMainCode);
        RemoteResult<String> result;
        if (CommonMethod.checkInShopId(shopId)) {
            LOGGER.info("HS 0元 ，支付系统通过dubbo通知商户系统，shopId[" + shopId + "],orderPrimaryId[" + orderPrimaryId + "]");
            result = aliPayJsManager.callUpdate(payOrder.getU_id(), String.valueOf(orderPrimaryId), "通联订单号", String.valueOf(paraHsMap.get("gmtPayment")), merchantPayPlatView.getMerchantId(), String.valueOf(payOrder.getPay_type()), merchantPayPlatView, String.valueOf(paraHsMap.get("notifyId")), null);
        } else {
            LOGGER.info("HS 0元 ，支付系统通过HTTP通知商户系统，shopId[" + payOrder.getShop_id() + "],orderPrimaryId[" + orderPrimaryId + "]");
            result = commonCallBackManager.callOutUpdate(payOrder, merchantPayPlatView, paraHsMap, commonParam);
        }
        if (result.isSuccess()) {
            LOGGER.info("HS 0元  通知外部系统成功！orderPrimaryId[" + orderPrimaryId + "]");
            payOrderApi.updateAliPayNotifyState(String.valueOf(orderPrimaryId), payOrder.getU_id(), String.valueOf(orderPrimaryId), PeakConstant.MFLAG_SUCC, String.valueOf(paraHsMap.get("notifyId")), PeakConstant.TRADE_SUCCESS, String.valueOf(paraHsMap.get("bankSeqNo")), payOrder.getPay_type());
        } else {
            LOGGER.info("HS 0元 通知外部系统失败！orderPrimaryId[" + orderPrimaryId + "]");
            payOrderApi.updateAliPayNotifyState(String.valueOf(orderPrimaryId), payOrder.getU_id(), String.valueOf(orderPrimaryId), PeakConstant.MFLAG_REPEAT, String.valueOf(paraHsMap.get("notifyId")), PeakConstant.TRADE_SUCCESS, String.valueOf(paraHsMap.get("bankSeqNo")), payOrder.getPay_type());
        }
        return CommonMethod.getOutSyncReturnForm(payOrder, null, payPortalOrder, paraMap, commonParam, "TRADE_SUCCESS", String.valueOf(payOrder.getId()));

    }


    private PayPortalOrder buildPayPortalOrderFromRequestParam(Map<String, String> requestParam, String shopId, String terminal, String currencyCode, double pointMoney) {
        try {
            String agent_business_merchants = aliPayCommonManager.getAliPropValue("agent_business_merchants");
            List<String> merchants = Arrays.asList(agent_business_merchants.split(";"));
            if (requestParam == null || requestParam.size() == 0) {
                LOGGER.info("Build PayPortalOrder From RequestParam FAIL, RequestParam IS NULL");
                return null;
            }
            PayPortalOrder payPortalOrder = new PayPortalOrder();
            payPortalOrder.setOutTradeNo(requestParam.get("out_trade_no"));
            if (StringUtils.isEmpty(requestParam.get("show_trade_no"))) {
                payPortalOrder.setShowTradeNo(requestParam.get("out_trade_no"));
            } else {
                payPortalOrder.setShowTradeNo(requestParam.get("show_trade_no"));
            }
            if (StringUtils.isNotEmpty(requestParam.get("lenovo_id"))) {
                payPortalOrder.setLenovoId(requestParam.get("lenovo_id"));
            }
            payPortalOrder.setFaId(requestParam.get("fa_id"));
            StringBuffer receiverInfo = new StringBuffer();
            String receiveBuyer = requestParam.get("receive_buyer");
            if (StringUtils.isNotEmpty(receiveBuyer)) {
                receiverInfo.append(receiveBuyer + " ");
            }
            String receivePhone = requestParam.get("receive_phone");
            if (StringUtils.isNotEmpty(receivePhone)) {
                receivePhone = receivePhone.substring(0, 3) + "****" + receivePhone.substring(7);
                receiverInfo.append(receivePhone + " ");
            }
            String receiveAddress = requestParam.get("receive_address");
            if (StringUtils.isNotEmpty(receiveAddress)) {
                receiverInfo.append(receiveAddress);
            }
            if (StringUtils.isNotEmpty(receiverInfo.toString())) {
                payPortalOrder.setDeliveryInfo(receiverInfo.toString());
            }
            payPortalOrder.setTaxType(requestParam.get("tax_type"));
            payPortalOrder.setTaxInfo(requestParam.get("tax_info"));
            StringBuffer taxReceiverInfo = new StringBuffer();
            String taxReceiveBuyer = requestParam.get("tax_receive_buyer");
            if (StringUtils.isNotEmpty(taxReceiveBuyer)) {
                taxReceiverInfo.append(taxReceiveBuyer + " ");
            }
            String taxReceivePhone = requestParam.get("tax_receive_phone");
            if (StringUtils.isNotEmpty(taxReceivePhone)) {
                taxReceivePhone = taxReceivePhone.substring(0, 3) + "****" + taxReceivePhone.substring(7);
                taxReceiverInfo.append(taxReceivePhone + " ");
            }
            String taxReceiveAddress = requestParam.get("tax_receive_address");
            if (StringUtils.isNotEmpty(taxReceiveAddress)) {
                taxReceiverInfo.append(taxReceiveAddress);
            }
            if (StringUtils.isNotEmpty(taxReceiverInfo.toString())) {
                payPortalOrder.setTaxDeliveryInfo(taxReceiverInfo.toString());
            }
            payPortalOrder.setSubject(requestParam.get("subject"));
            payPortalOrder.setNotifyUrl(requestParam.get("notify_url"));
            payPortalOrder.setReturnUrl(requestParam.get("return_url"));
            payPortalOrder.setExceptionUrl(requestParam.get("exception_url"));
            payPortalOrder.setBody(requestParam.get("body"));

            if (merchants.contains(requestParam.get("fa_id"))){
                payPortalOrder.setPaymentWay("1");
            }else {
                payPortalOrder.setPaymentWay(requestParam.get("payment_way"));
            }

            payPortalOrder.setOrderType(requestParam.get("order_type"));
            if (StringUtils.isEmpty(requestParam.get("reward_ledou")) || "null".equals(requestParam.get("reward_ledou"))) {
                payPortalOrder.setRewardLedou("0");
            } else {
                payPortalOrder.setRewardLedou(requestParam.get("reward_ledou"));
            }
            if (StringUtils.isEmpty(currencyCode)) {
                currencyCode = "CNY";
            }

            payPortalOrder.setCurrencyCode(currencyCode);
            if (StringUtils.isNotEmpty(requestParam.get("payment"))) {
                payPortalOrder.setPayment(Integer.parseInt(requestParam.get("payment")));
            }

            Money totalFeeMoney = new Money(requestParam.get("total_fee"), currencyCode);
            if (shopId.equals(PeakConstant.SHOPID_HUISHANG) && pointMoney != 0) {
                payPortalOrder.setTotalFee(totalFeeMoney.subtract(new Money(pointMoney, currencyCode)));
                payPortalOrder.setPoint(Integer.parseInt(requestParam.get("reward_point")));
            } else {
                payPortalOrder.setTotalFee(totalFeeMoney);
            }
//            if(totalFeeMoney.equals(new Money(0,currencyCode))){
//                payPortalOrder.setPayment(Integer.valueOf(PeakConstant.PAY_TYPE_ZERO));
//            }
            if((totalFeeMoney.subtract(new Money(pointMoney, currencyCode))).equals(new Money(0,currencyCode))){
                payPortalOrder.setPayment(Integer.valueOf(PeakConstant.PAY_TYPE_ZERO));
            }

            String itBPay = requestParam.get("it_b_pay");
            if (StringUtils.isNotEmpty(itBPay) && !("null".equals(itBPay))) {
                payPortalOrder.setItBPay(requestParam.get("it_b_pay"));
                try {
                    String itBPayStr = itBPay.substring(0, itBPay.length() - 1);
                    Integer itBPayInt = Integer.parseInt(itBPayStr);
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(new Date());
                    if (itBPay.endsWith("m")) {
                        calendar.add(Calendar.MINUTE, itBPayInt);
                    } else if (itBPay.endsWith("h")) {
                        calendar.add(Calendar.HOUR, itBPayInt);
                    } else if (itBPay.endsWith("d")) {
                        calendar.add(Calendar.DATE, itBPayInt);
                    }
                    payPortalOrder.setFailureTime(calendar.getTime());
                } catch (Exception itBPayException) {
                    LOGGER.info("build OutPay PayPortalOrder FailureTime Exception", itBPayException);
                }
            }
            payPortalOrder.setExtendParam(requestParam.get("extend_param"));
            payPortalOrder.setPaymentTypeId(0);
            payPortalOrder.setShopId(shopId);
            payPortalOrder.setTerminal(terminal);
            Money refundMoney = new Money("0", currencyCode);
            payPortalOrder.setRefundMoney(refundMoney);
            payPortalOrder.setOrderStatus(0);
            payPortalOrder.setPayStatus(0);

            payPortalOrder.setOrderTime(new Date());
            payPortalOrder.setCreateTime(new Date());
            return payPortalOrder;
        } catch (Exception e) {
            LOGGER.info("Build PayPortalOrder From RequestParam Exception", e);
            return null;
        }
    }

    private String getFailRedirect(String service, String payment, String failTradeInfo, String shopId, String terminal, String exceptionUrl, Map<String, Object> paraMap, Map<String, Object> commonParam) {
        if (StringUtils.isNotEmpty(exceptionUrl)) {
            LOGGER.info("DirectPay Go FailRedirect, ExceptionUrl[" + exceptionUrl + "],service[" + service + "],tradeInfo[" + failTradeInfo + "],shopId[" + shopId + "],terminal[" + terminal + "]");
            Map<String, String> postMap = new HashMap<String, String>();
            postMap.put("service", service);
            postMap.put("payment", payment);
            postMap.put("shop_id", shopId);
            postMap.put("terminal", terminal);
            postMap.put("input_charset", "UTF-8");
            postMap.put("trade_info", failTradeInfo);
            postMap.put("error_code", (String) paraMap.get("error_code"));
            String signKey = (String) commonParam.get(shopId);
            String sign = PaySignUtils.buildSignKey(postMap, "MD5", signKey);
            postMap.put("sign", sign);
            postMap.put("sign_type", "MD5");
            String bodyHtml = PaySignUtils.buildRequest(postMap, exceptionUrl, "post");
            bodyHtml = "<html>" + "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>outPay</title></head>" + "<body>"
                    + bodyHtml + "</body></html>";
            LOGGER.info("DirectPay Go FailRedirect,HTML[" + bodyHtml + "]");
            paraMap.put("postForm", bodyHtml);
            return "outpay/outpay_gotobank";
        } else {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                LOGGER.info("DirectPay Go FailRedirect, URL[outpay/outpay_pc_fail]");
                return "outpay/outpay_pc_fail";
            } else {
                LOGGER.info("DirectPay Go FailRedirect, URL[outpay/outpay_wap_fail]");
                return "outpay/outpay_wap_fail";
            }
        }
    }

    /**
     * 单笔订单退款
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/singleOrderRefund", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public Object singleOrderRefund(HttpServletRequest request, HttpServletResponse response){
        RemoteResult<String> result = new RemoteResult<String>();
        String service = request.getParameter("service");
        String inputCharset = request.getParameter("input_charset");
        String signType = request.getParameter("sign_type");
        String sign = request.getParameter("sign");
        String notifyUrl = request.getParameter("notify_url");
        String faId = request.getParameter("fa_id");
        String shopId = request.getParameter("shop_id");
        String outTradeNo = request.getParameter("out_trade_no");
        LOGGER.info("singleOrderRefund request params: service["+service+"],inputCharset["+inputCharset+"],signType["+signType+"],sign["+sign+"],notifyUrl["+notifyUrl+"],faId["+faId+"],shopId["+shopId+"],outTradeNo["+outTradeNo+"]");
        if (LePayUtil.isParamsEmpty(service,inputCharset,signType,sign,faId,shopId,outTradeNo)){
            LOGGER.info("singleOrderRefund request params not valid!");
            return LePayUtil.getRemoteResult(result,"request params not valid!",false,"1001","request params not valid!");
        }
        Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
        String signKey = (String) commonParam.get(shopId);
        if (StringUtils.isEmpty(signKey)){
            LOGGER.info("singleOrderRefund signKey is null!");
            return LePayUtil.getRemoteResult(result,"request params not valid!",false,"1001","request params not valid!");
        }
        Map<String,String> signMap = new HashMap<String, String>();
        signMap.put("service",service);
        signMap.put("input_charset",inputCharset);
        signMap.put("fa_id",faId);
        signMap.put("shop_id",shopId);
        signMap.put("out_trade_no",outTradeNo);
        boolean checkSign = PaySignUtils.checkSignKey(sign, signMap, signType, signKey);
        if (!checkSign){
            LOGGER.info("singleOrderRefund Signature invalid!");
            return LePayUtil.getRemoteResult(result,"Signature invalid !",false,"1001","Signature invalid !");
        }
        RemoteResult<List<PayOrder>> payOrderResults = payOrderApi.getOrderListByOrderCode(outTradeNo);
        if (!payOrderResults.isSuccess() && null == payOrderResults.getT()){
            LOGGER.info("singleOrderRefund order can not found!");
            return LePayUtil.getRemoteResult(result,"Order can not found !",false,"1001","Order can not found !");
        }
//        RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult =
        return result;
    }

    public PayPointRulesManager getPayPointRulesManager() {
        return payPointRulesManager;
    }

    public void setPayPointRulesManager(PayPointRulesManager payPointRulesManager) {
        this.payPointRulesManager = payPointRulesManager;
    }
}
