package com.lenovo.m2.buy.promotion.admin.controller.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.mortbay.log.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.lenovo.m2.arch.tool.util.DateFormatUtils;
import com.lenovo.m2.buy.promotion.admin.soa.utils.JsonUtil;

/**
 * excel 工具类 版本2 Created by wangyu46 on 2017/6/9.
 */
public class ExcelUtil<T> {

	private static Logger LOG = LoggerFactory.getLogger(ExcelUtils.class);

	private Class<T> clazz;

	/**
	 * 初始化excel
	 * @param clazz 对象类型
	 * @param noteMappre excel 字段 与列名  映射 规则
	 */
	public ExcelUtil(Class<T> clazz, Map<String, ExcelBean> noteMappre) {
		this.clazz = clazz;
		this.noteMappre = noteMappre;
		// 初始化
		initMapper();
	}

	/**
	 * 参数
	 */
	private Map<String, ExcelBean> noteMappre = new HashMap<>();

	/**
	 * 扔出去的对象
	 */
//	private Map<String, ExcelBean> tmpMap = new TreeMap<>();
	private Map<ExcelBean, String> tmpMap = new TreeMap<>();

	/*
	 * 初始化 对象映射
	 */
	public void initMapper() {
		// 实体类所有字段
		Field[] declaredFields = clazz.getDeclaredFields();

		try {
			// 取出设置的对应 映射关系
			for (Field field : declaredFields) {
				// 每个字段名称
				String name = field.getName();
				// 每个字段 对应的 数据
				ExcelBean obj = noteMappre.get(name);

				if (obj == null) {
					continue;
				}
				//
				String isName = obj.getName();
				//
				String isIsDefault = obj.getIsDefault();

				Map<String, Object> mapper = obj.getMapper();
				int isMapper = obj.getIsMapper();
				int isOrder = obj.getOrder();
				ExcelBean bean = new ExcelBean();
				// 对应列的 名称
				if (isName != null) {
					bean.setName(isName);
				}
				// 设置默认值
				if (isIsDefault != null) {
					bean.setIsDefault(isIsDefault);
				}
				if (isOrder != 0) {
					bean.setOrder(isOrder);
				}
				if(isMapper != 0){
					bean.setIsMapper(isMapper);
					bean.setMapper(mapper);
				}
				// 字段 and 属性
				tmpMap.put(bean, name);
			}
			Log.info("tmpMap = {}",JsonUtil.toJson(tmpMap));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 导出excel
	 * 
	 * @param list
	 *            数据
	 * @param title
	 *            excel工作表 表名
	 * @return XSSFWorkbook
	 */
	public XSSFWorkbook exportExcel(List<T> list, String title) {

		Field[] allFields = clazz.getDeclaredFields();// 得到所有定义字段

		XSSFWorkbook workbook = new XSSFWorkbook();// 产生工作薄对象

		try {
			// 生成一个工作表
			XSSFSheet sheet = workbook.createSheet(title);

			// 这是excel样式
			XSSFCellStyle createCellStyle = upExcelStyle(workbook);

			// 产生表格标题行
			XSSFRow createRow = sheet.createRow(0);

			Set<Entry<ExcelBean, String>> entrySet = tmpMap.entrySet();
			
			// 按照顺序显示 列
			int i = 0;
			for (Entry<ExcelBean, String> entry : entrySet) {
				//字段名
//				String fieldName = entry.getKey();
				//规则
				ExcelBean bean = entry.getKey();
				// 创建列
				XSSFCell cell = createRow.createCell(i);
				// 列数据
				cell.setCellValue(bean.getName());
				cell.setCellStyle(createCellStyle);
				sheet.setColumnWidth(i, 5000);
				i ++;
			}
			
			
			
			// 所有数据
			for (int j = 0, size = list.size(); j < size; j++) {
				// 每一行.
				XSSFRow row = sheet.createRow(j + 1);
				
				int index = 0;
				//存在 并需要设置的字段
				for (Entry<ExcelBean, String> entry : entrySet) {
					String value = entry.getValue();
					for (Field field : allFields) {
						String Bean = field.getName();
						//需要设置
						if(value.equals(Bean)){
							ExcelBean excelBean = entry.getKey();
							
							XSSFCell cell = row.createCell(index ++);// 单元格
							cell.setCellType(XSSFCell.CELL_TYPE_STRING);
			
							field.setAccessible(true);// class访问权限
							// 如果有值 就 设置 没有值 就用默认值
							T t = (T) list.get(j);
							Object object = field.get(t);
							//单元格数据
							String str = upCellData(excelBean, object);
							cell.setCellValue(str);
							
							continue;
						}
					}
				}
			}
			

		} catch (Exception e) {
			LOG.error("excel表格生成异常", e);
		}

		return workbook;

	}

	private String upCellData(ExcelBean excelBean, Object object) {
		String str = object == null ? excelBean.getIsDefault() : String.valueOf(object);
		//---- 条件
		//如果是时间类型
		if(object instanceof Date){
			str = DateFormatUtils.format((Date)object);
		}
		//如果需要单独校验
		if(excelBean.getIsMapper() == 1){
			Map<String, Object> mapper = excelBean.getMapper();
			Object obj = mapper.get(String.valueOf(object));
			if(obj == null){
				obj = excelBean.getIsDefault(); 
			}
			str = String.valueOf(obj);
		}
		return str;
	}

	private XSSFCellStyle upExcelStyle(XSSFWorkbook workbook) {
		XSSFCellStyle createCellStyle = workbook.createCellStyle();
		// 设置格式
		createCellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		createCellStyle.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index); // 设置颜色为红色
		createCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		return createCellStyle;
	}

}
