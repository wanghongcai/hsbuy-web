package com.lenovo.m2.buy.promotion.pay.notify;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.JacksonUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.DateUtil;
import com.lenovo.m2.buy.promotion.admin.manager.pay.alipay.AliPayCommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonCallBackManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonPayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayMailApi;
import com.lenovo.m2.buy.promotion.admin.remote.pay.PayOrderApi;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * SMB线下支付状态回写
 * Created by MengQiang on 2016/7/26.
 */
@Controller
public class SMBNotifyController {

    private Logger LOGGER = Logger.getLogger(this.getClass());

    @Autowired
    private CommonManager commonManager;
    @Autowired
    private CommonPayManager commonPayManager;
    @Autowired
    private AliPayCommonManager aliPayCommonManager;
    @Autowired
    private CommonCallBackManager commonCallBackManager;
    @Autowired
    private PayPortalOrderManager payPortalOrderManager;
    @Autowired
    private PayOrderApi payOrderApi;
    @Autowired
    private PayMailApi payMailApi;
    /**
     * @param request  request
     * @param response response
     * @return JSON
     */
    @RequestMapping(value = "/api/pay/notify/payStatusNotify", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String smbPayStatusNotify(HttpServletRequest request, HttpServletResponse response) {
        String smbTradeNo = request.getParameter("tradeNo");
        String orderStatus = request.getParameter("orderStatus");
        String lenovoId = request.getParameter("lenovoId");
        //String shopId = request.getParameter("shopId");
        String shopId = "8";
        String terminal = request.getParameter("terminal");
        String transactionId = request.getParameter("transactionId");
        String payAcc = request.getParameter("payAcc");
        String payType = request.getParameter("payType");
        String payDept = request.getParameter("payDept");
        LOGGER.info("HTTPS smbPayStatusNotify Ready TO GO! smbTradeNo[" + smbTradeNo + "],lenovoId[" + lenovoId + "],shopId[" + shopId + "],terminal[" + terminal + "],orderStatus[" + orderStatus + "],transactionId[" + transactionId + "],payAcc[" + payAcc + "],payType[" + payType + "],payDept[" + payDept + "]");
        try {
            Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
            RemoteResult<PayPortalOrder> payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByShowTradeNo(smbTradeNo, lenovoId, tenant);
            PayPortalOrder payPortalOrder;
            String orderMainCode;
            if (payPortalOrderRemoteResult.isSuccess()) {
                payPortalOrder = payPortalOrderRemoteResult.getT();
                orderMainCode = payPortalOrder.getOutTradeNo();
                LOGGER.info("SMB Offline Payment Get ChannelOrder SUCCESS, Result[" + payPortalOrderRemoteResult + "]");
            } else {
                LOGGER.info("SMB Offline Payment Get ChannelOrder FAIL, Result[" + payPortalOrderRemoteResult + "]");
                return returnJsonResult(false, "1001", "查询订单失败", "FAIL");
            }
            String _total_fee = String.valueOf(payPortalOrder.getTotalFee());
            String prodName = CommonMethod.getProductName(payPortalOrder.getSubject());
            String currencyCode = payPortalOrder.getCurrencyCode();
            RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult = commonPayManager.getMerchantPayPlat(payPortalOrder.getFaId(), payType);
            MerchantPayPlatView merchantPayPlatView;
            if (merchantPayPlatViewRemoteResult != null && merchantPayPlatViewRemoteResult.isSuccess()) {
                LOGGER.info("SMB Offline Get MerchantPayPlat SUCCESS");
                merchantPayPlatView = merchantPayPlatViewRemoteResult.getT();
            } else {
                merchantPayPlatView = new MerchantPayPlatView();
                merchantPayPlatView.setId(0);
            }
            String orderPrimaryId;
            RemoteResult<List<PayOrder>> orderListResult = aliPayCommonManager.getOrderListByPayType(orderMainCode, Integer.parseInt(payType));
            if (orderListResult.isSuccess() && orderListResult.getT().size() > 0) {
                orderPrimaryId = String.valueOf(orderListResult.getT().get(0).getId());
                LOGGER.info("SMB Offline Payment PayOrder ALREADY EXIST, OrderPrimaryId[" + orderPrimaryId + "]");
            } else {
                RemoteResult<String> savePayOrderResult = commonManager.savePayOrder(payPortalOrder.getLenovoId(), shopId, payType, orderMainCode, _total_fee, prodName, "", 0, "", "smb", "", shopId, terminal, merchantPayPlatView, currencyCode);
                if (!savePayOrderResult.isSuccess()) {
                    LOGGER.warn("Save SMB Offline Payment PayOrder FAIL");
                    return returnJsonResult(false, "1001", "保存支付平台订单记录失败", "FAIL");
                }
                orderPrimaryId = savePayOrderResult.getT();
                LOGGER.info("Save SMB Offline Payment PayOrder SUCCESS, OrderPrimaryId[" + orderPrimaryId + "]");
            }
            PayPortalOrder updatePayPortalOrder = CommonMethod.buildUpdatePayPortalOrder(orderPrimaryId, orderMainCode, payPortalOrder.getLenovoId(), Integer.parseInt(payType), PeakConstant.PAY_STATUS_ALREADY_PAID, shopId ,new Date());
            try {
                RemoteResult<Integer> updatePayPortalOrderResult = payPortalOrderManager.updatePayPortalOrderPayStatus(updatePayPortalOrder);
                if (updatePayPortalOrderResult.isSuccess()) {
                    payOrderApi.updateAliPayNotifyState(orderPrimaryId, lenovoId, transactionId, PeakConstant.MFLAG_SUCC, "", PeakConstant.TRADE_SUCCESS,"", Integer.parseInt(payType));
                    LOGGER.info("更新PayPortalOrder订单成功，订单号==>" + orderMainCode);
                } else {
                    LOGGER.info("更新PayPortalOrder订单失败，订单号==>" + orderMainCode);
                }
            } catch (Exception updatePayPortalOrderException) {
                LOGGER.info("更新PayPortalOrder订单失败 ，订单号==>" + orderMainCode, updatePayPortalOrderException);
            }
            //TODO CALL MiddleWare
            String payTime = DateUtil.formatDate(new Date(), PeakConstant.CALL_MIDDLEWARE_PAY_TYPE);
            Map<String, String> paraMap = new HashMap<String, String>();
            paraMap.put("payTime", payTime);
            paraMap.put("payment", PeakConstant.PAY_TYPE_SMB_OFFLINE);
            paraMap.put("payAcc", payAcc);
            // 改为从数据库获取
            PayOrder payOrder = payOrderApi.getPayOrderByPrimaryId(Long.valueOf(orderPrimaryId));
            payOrder.setU_id(payPortalOrder.getLenovoId());
            payOrder.setOut_trade_no(orderMainCode);
            RemoteResult<String> remoteResult = commonCallBackManager.paidCallback(payPortalOrder, payOrder, merchantPayPlatView, paraMap);
            if (remoteResult.isSuccess()) {
                LOGGER.info("SMB Offline Call MiddleWare SUCCESS, OrderMainCode[" + orderMainCode + "]");
                return returnJsonResult(true, "1000", "处理成功", "SUCCESS");
            } else {
                LOGGER.info("SMB Offline Call MiddleWare FAIL, OrderMainCode[" + orderMainCode + "]");
                return returnJsonResult(false, "1001", "处理线下支付通知失败", "FAIL");
            }
        } catch (Exception e) {
            LOGGER.info("SMB线下支付异常", e);
            return returnJsonResult(false, "1001", "处理线下支付通知异常", "FAIL");
        }
    }

    /**
     * 处理支付返回
     * @param flag flag
     * @param resultCode resultCode
     * @param resultMsg resultMsg
     * @param info info
     * @return String
     */
    private String returnJsonResult(boolean flag, String resultCode, String resultMsg, String info) {
        RemoteResult<String> returnResult = new RemoteResult<String>();
        returnResult.setSuccess(flag);
        returnResult.setResultCode(resultCode);
        returnResult.setResultMsg(resultMsg);
        returnResult.setT(info);
        String returnJson = JacksonUtil.toJson(returnResult);
        LOGGER.info("ReturnJson[" + returnJson + "]");
        return returnJson;
    }

    public CommonManager getCommonManager() {
        return commonManager;
    }

    public void setCommonManager(CommonManager commonManager) {
        this.commonManager = commonManager;
    }

    public CommonPayManager getCommonPayManager() {
        return commonPayManager;
    }

    public void setCommonPayManager(CommonPayManager commonPayManager) {
        this.commonPayManager = commonPayManager;
    }

    public AliPayCommonManager getAliPayCommonManager() {
        return aliPayCommonManager;
    }

    public void setAliPayCommonManager(AliPayCommonManager aliPayCommonManager) {
        this.aliPayCommonManager = aliPayCommonManager;
    }

    public CommonCallBackManager getCommonCallBackManager() {
        return commonCallBackManager;
    }

    public void setCommonCallBackManager(CommonCallBackManager commonCallBackManager) {
        this.commonCallBackManager = commonCallBackManager;
    }

    public PayOrderApi getPayOrderApi() {
        return payOrderApi;
    }

    public void setPayOrderApi(PayOrderApi payOrderApi) {
        this.payOrderApi = payOrderApi;
    }

    public PayMailApi getPayMailApi() {
        return payMailApi;
    }

    public void setPayMailApi(PayMailApi payMailApi) {
        this.payMailApi = payMailApi;
    }

    public PayPortalOrderManager getPayPortalOrderManager() {
        return payPortalOrderManager;
    }

    public void setPayPortalOrderManager(PayPortalOrderManager payPortalOrderManager) {
        this.payPortalOrderManager = payPortalOrderManager;
    }
}
