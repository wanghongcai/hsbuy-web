package com.lenovo.m2.buy.promotion.admin.controller.api.promotion;

import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.controller.util.JsonUtil;
import com.lenovo.m2.buy.promotion.admin.controller.util.ThreadLocalObjs;
import com.lenovo.m2.buy.promotion.admin.domain.AuthData;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.SalesGoodsPromotionRoleCheck;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.SessionUser;
import com.lenovo.m2.buy.promotion.admin.soa.api.service.PromotionAdminRead;
import com.lenovo.m2.buy.promotion.admin.soa.api.service.PromotionAdminWrite;
import com.lenovo.m2.buy.promotion.admin.soa.enums.GloablErrorMessageEnum;
import com.lenovo.m2.buy.promotion.admin.soa.enums.ShopIdEnum;
import com.lenovo.m2.buy.promotion.admin.soa.utils.StringUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Controller
@RequestMapping("/api/promotion")
public class PromotionCheckApi extends  PromotionApiBase{

	private static final String appId = "promotion";
	private static final String appKey = "yyPpuhmkbTR0TxD4";
	private static final String domain = "promotion.app.lefile.cn";
	private static String targetPromotionFilePath = "/promotionCheck/";
	private static final String imageServerURL = "http://internal-up.lefile.cn/image/upload";

	// 促销规则审核导出excel的title
	static String[] excelHeader = {"促销规则ID", "审核人ID","商城", "创建时间", "通过时间", "审核状态", "驳回原因"};

	@Autowired
	private PromotionAdminRead promotionAdminRead;
	@Autowired
	private PromotionAdminWrite promotionAdminWrite;

	private static Logger log = LoggerFactory.getLogger(PromotionApi.class);


	/**
	 * @desc 提交审核
	 * @param ids
	 * @return
	 */
	@RequestMapping("/submitAudit")
	@ResponseBody
	public RemoteResult promSubmitCheck(String ids){
		log.info("api promSubmitCheck ids={}", ids);
        RemoteResult remoteResult = new RemoteResult(false);

		Tenant tenant = ThreadLocalObjs.getTenant();
		AuthData authData = ThreadLocalObjs.getAuthData();

		String userId = authData.getUserid();
		if(StringUtils.isEmpty(ids) || StringUtils.isEmpty(userId)){
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
			remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
			return remoteResult;
		}
		SessionUser sessionUser = initUser(userId);
		try {
			if(tenant.getShopId() == ShopIdEnum.HS.getType() ||tenant.getShopId() == ShopIdEnum.HSJF.getType()){//EPP 商城或者惠商商城
				remoteResult =  promotionAdminWrite.eppSubmitCheck(tenant, sessionUser,ids.split(","));
			}else {
				remoteResult = promotionAdminWrite.btSubmitCheck(tenant, sessionUser,ids.split(","));
			}
		} catch (Exception e) {
			log.error("promSubmitCheck Error-->", e);
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
			remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
		}
		log.info("submitCheck result-->" , JsonUtil.toJson(remoteResult));
		return remoteResult;
	}

	/**
	 * @desc 促销审核   0 驳回  1 通过
	 * @param status
	 * @param ids
	 * @return
     * 是否Epp 惠商 soa处理
	 */
	@RequestMapping("/audit")
	@ResponseBody
	public RemoteResult promCheckPass(String ids, int status, String rejectReason){
		log.info("api promCheckPass ids={},status={},rejectReason={}", ids, status, rejectReason);

		Tenant tenant = ThreadLocalObjs.getTenant();
		AuthData authData = ThreadLocalObjs.getAuthData();

		String userId = authData.getUserid();
		log.info("userId={}",userId);
		RemoteResult remoteResult = new RemoteResult(false);
		if(StringUtils.isEmpty(ids) || StringUtils.isEmpty(userId) ){
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
			remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
			return remoteResult;
		}
		SessionUser sessionUser = initUser(userId);
		try {
			if(status == 0){
				if(StringUtil.isEmpty(rejectReason)){
					remoteResult.setSuccess(false);
					remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
					remoteResult.setResultMsg("拒绝原因不能为空");
				}else{
					remoteResult = promotionAdminWrite.updateCheckReject(tenant, sessionUser, ids, rejectReason, tenant.getShopId());
				}
			}else{
				remoteResult = promotionAdminWrite.updateCheckPass(tenant, sessionUser, ids.split(","), tenant.getShopId());
			}
			
		} catch (Exception e) {
			log.error("promotion audit error", e);
			remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCode());
			remoteResult.setResultMsg(GloablErrorMessageEnum.ERROR_SYSTEM_ERROR.getCommon());
		}
		return remoteResult;
	}

    /**
	 * 根据促销规则审核表id 获取对应的促销规则
	 * @param auditId
     * @return
     */
    @RequestMapping("/getAudit")
    @ResponseBody
    public RemoteResult<SalesGoodsPromotionRoleCheck> getPromCheck(String auditId){
    	log.info("根据促销规则审核表id，获取对应的促销规则 -->"+auditId);
		Tenant tenant = ThreadLocalObjs.getTenant();
        RemoteResult<SalesGoodsPromotionRoleCheck> result = new RemoteResult<SalesGoodsPromotionRoleCheck>(false);

        if(StringUtils.isEmpty(auditId)|| tenant == null){
			result.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
			result.setResultMsg(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCommon());
			return result;
		}

		result = promotionAdminRead.getPromotionCheckById(tenant, auditId, tenant.getShopId());
        log.info("getPromCheck 返回结果={}",result);
        return result;
    }

    /**
     * 获取审核列表
	 * @param pageNum
     * @param pageSize
	 * @return
	 */
    @RequestMapping("/auditList")
    @ResponseBody
    public RemoteResult promCheckList(int pageNum, int pageSize){
		AuthData authData = ThreadLocalObjs.getAuthData();
		Tenant tenant = ThreadLocalObjs.getTenant();

		List<String> shopIds = authData.getShopIds();
		List<String> faIds = authData.getFaIds();

		PageQuery pageQuery = new PageQuery();
        pageQuery.setPageNum(pageNum);
        pageQuery.setPageSize(pageSize);

        Map map = new HashMap();
        map.put("shopId", tenant.getShopId());
		map.put("shopIds",shopIds);
		map.put("faIds",faIds);
		log.info("促销审核列表请求参数 pageNum={}, pageSize={}, paramMap={}", pageNum, pageSize, JsonUtil.toJson(map));
        RemoteResult<PageModel2<SalesGoodsPromotionRoleCheck>> getCheckList = new RemoteResult<>();
        getCheckList = promotionAdminRead.getCheckList(tenant, tenant.getShopId(), pageQuery, map);
        return getCheckList;
    }

}
