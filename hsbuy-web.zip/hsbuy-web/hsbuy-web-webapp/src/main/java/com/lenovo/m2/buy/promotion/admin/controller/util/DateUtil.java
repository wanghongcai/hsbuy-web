package com.lenovo.m2.buy.promotion.admin.controller.util;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import org.apache.log4j.Logger;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by zhaocl1 on 2016/1/20.
 */
public class DateUtil {

    private static Logger logger = Logger.getLogger(DateUtil.class);
    /**
     * 时间格式：yyyyMMddHHmmss'.
     */
    private static String dateTime14Fmt = "yyyyMMddHHmmss";

    /**
     * 时间格式：yyyyMMdd'.
     */
    private static String dateTime8Fmt = "yyyyMMdd";

    /**
     * 时间格式：yyyy-MM-dd'.
     */
    private static String full8fmt = "yyyy-MM-dd";

    /**
     * 时间格式：yyyy-MM-dd' 'HH:mm:ss'.
     */
    private static String full14fmt = "yyyy-MM-dd HH:mm:ss";


    /**
     * 将字符串转换为yyyy-MM-dd HH:mm:ss 格式的日期
     * @param dateStr
     * @return
     */
    public static Date parseDate(String dateStr){
        SimpleDateFormat sdf = new SimpleDateFormat(full14fmt);
        try {
            Date d = sdf.parse(dateStr);
            return new Date(d.getTime());
        } catch (ParseException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
            return null;
        }
    }

    /**
     * 将日期转换为yyyy-MM-dd 格式的字符串
     * @param date
     * @return
     */
    public static String formatString(Date date){
        if(date == null)
            return "";
        SimpleDateFormat sdf = new SimpleDateFormat(full8fmt);
        try {
            return sdf.format(date);
        } catch (Exception e) {
            logger.error(ExceptionUtil.getStackTrace(e));
            return null;
        }
    }

    public static String formatString(Date date, String format){
        SimpleDateFormat sf = null;
        if(date == null)
            return "";
        try {
            if(StringUtils.isEmpty(format)){
                sf = new SimpleDateFormat(full14fmt);
            }else {
                sf = new SimpleDateFormat(format);
            }
            return sf.format(date);
        } catch (Exception e) {
            logger.error(ExceptionUtil.getStackTrace(e));
        }
        return "";
    }


    /**
     * 将字符串转为指定格式的日期
     * @param dateStr
     * @param format
     * @return
     */
    public static Date parseDate4format(String dateStr,String format){
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        try {
            return sdf.parse(dateStr);
        } catch (ParseException e) {
            logger.error(ExceptionUtil.getStackTrace(e));
            return null;
        }
    }

    /**
     * 将01/20/2016 10:14:17 转换为 2016-01-20 10:14:17 格式的字符串
     * @param dateStr
     * @return
     */
    public static String format4easyui(String dateStr){
        Date d1 = DateUtil.parseDate4format(dateStr,"yyyy-MM-dd");
        String s2  = DateUtil.formatString(d1);
        return s2;
    }


    public static void main(String[] args){

        System.out.println(DateUtil.format4easyui("01/20/2016 10:14:17"));
    }
}
