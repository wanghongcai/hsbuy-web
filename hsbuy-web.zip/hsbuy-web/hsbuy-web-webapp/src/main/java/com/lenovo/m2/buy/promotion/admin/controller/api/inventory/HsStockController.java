package com.lenovo.m2.buy.promotion.admin.controller.api.inventory;

import com.alibaba.dubbo.common.utils.CollectionUtils;
import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSONArray;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.tool.util.DateFormatUtils;
import com.lenovo.m2.buy.promotion.admin.controller.util.JsonUtil;
import com.lenovo.m2.buy.promotion.admin.remote.inventory.HsStockRemoteService;
import com.lenovo.m2.hsbuy.common.pruchase.util.StringUtil;
import com.lenovo.m2.hsbuy.common.util.JacksonUtil;
import com.lenovo.m2.hsbuy.domain.inventory.HsStock;
import com.lenovo.m2.hsbuy.domain.inventory.HsWaterLevelStock;
import com.lenovo.m2.hsbuy.domain.ordercenter.BeeOrderApi;
import com.lenovo.m2.hsbuy.inventory.constants.StockResultCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by yezhenyue on 2017/2/16.
 */
@Controller
@Scope("prototype")
@RequestMapping("/api/hs")
public class HsStockController extends BaseController {
    private static final Logger LOGGER = LoggerFactory.getLogger(HsStockController.class);
    @Autowired
    private HsStockRemoteService hsStockRemoteService;

    /**
     * 创建水位库存
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/addWaterLevelStock", produces = "text/json;charset=UTF-8", method = {RequestMethod.POST})
    @ResponseBody
    public String addWaterLevelStock(HttpServletRequest request, HttpServletResponse response) {
        RemoteResult re = new RemoteResult(false);
        try {
            JSONArray faIds = getGlobalFaIds();
            JSONArray shopids = getTenantIds();
            String itcode = getGlobalItcode();
            LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:" + faIds.toString() + "，shopIds:" + shopids.toString());

            String fxsno = request.getParameter("fxsNo");
            String faid = request.getParameter("faId");
            String waterLevel = request.getParameter("waterLevel");
            String fxsname = request.getParameter("fxsName");

            if (CollectionUtils.isNotEmpty(faIds) && faIds.contains(faid)) {
                RemoteResult<HsWaterLevelStock> result = hsStockRemoteService.getHsWaterLevelStockByFaid(faid);
                if (result.isSuccess() && result.getT() != null) {
                    re.setResultCode(StockResultCode.FIND_STOCK_EXIST);
                    re.setResultMsg("水位库存已存在");
                } else {
                    HsWaterLevelStock info = new HsWaterLevelStock();   //封装 库存 需要的信息

                    info.setWaterLevel(Integer.parseInt(waterLevel));
                    info.setFxsname(fxsname);
                    info.setFxsno(fxsno);
                    info.setFaid(faid);
                    info.setCreateTime(new Date());
                    info.setOperator(itcode);
                    LOGGER.info("增加新水位库存 信息:" + info);
                    re = hsStockRemoteService.addHsWaterLevelStock(info);
                }
            } else {
                re.setResultCode(StockResultCode.STOCK_NOT_MEET);
                re.setResultMsg("无权添加水位库存信息！");
                LOGGER.error("addWaterLevelStock接口:" + itcode + "无权添加水位库存信息");
            }
        } catch (Exception e) {
            re.setResultCode(StockResultCode.STOCK_ERROR);
            re.setResultMsg("系统异常！");
            LOGGER.error(e.getMessage(), e);
        }
        return JacksonUtil.toJson(re);
    }

    /**
     * 修改水位库存
     *
     * @return
     */
    @RequestMapping(value = "/updateWaterLevelStock", produces = "text/json;charset=UTF-8", method = {RequestMethod.POST})
    @ResponseBody
    public String updateWaterLevelStock(HttpServletRequest request, HttpServletResponse response, long stockId,
                                        int waterLevel) {

        RemoteResult re = new RemoteResult(false);
        try {
            if (waterLevel == 0) {
                re.setResultCode(StockResultCode.STOCK_EMPTY);
                re.setResultMsg("参数有误！水位库存必须大于0");
            } else {
                JSONArray faIds = getGlobalFaIds();
                JSONArray shopids = getTenantIds();
                String itcode = getGlobalItcode();
                LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:" + faIds.toString() + "，shopIds:" + shopids.toString());
                RemoteResult<HsWaterLevelStock> remoteResult = hsStockRemoteService.getHsWaterLevelStockById(stockId);

                if (remoteResult.isSuccess()) {
                    HsWaterLevelStock selectedStock = remoteResult.getT();
//                    String fxsno = selectedStock.getFxsno();
                    String faid = selectedStock.getFaid();
                    if (CollectionUtils.isNotEmpty(faIds) && faIds.contains(faid)) {
                        selectedStock.setWaterLevel(waterLevel);
                        selectedStock.setOperator(itcode);
                        selectedStock.setUpdateTime(new Date());
                        re = hsStockRemoteService.updateHsWaterLevelStock(selectedStock);

                    } else {
                        re.setResultCode(StockResultCode.STOCK_NOT_MEET);
                        re.setResultMsg("无权修改水位库存信息！");
                    }
                } else {
                    re.setResultCode(StockResultCode.STOCK_NOTHINH);
                    re.setResultMsg("水位库存不存在！");
                }
            }
        } catch (Exception e) {
            re.setResultMsg("系统异常！");
            re.setResultCode(StockResultCode.STOCK_ERROR);
            LOGGER.error(e.getMessage(), e);
        }
        return JacksonUtil.toJson(re);
    }

    /**
     * 分页查询水位库存信息
     *
     * @return
     */
    @RequestMapping(value = "/queryWaterLevelStock", produces = "text/json;charset=UTF-8")
    @ResponseBody
    public String queryWaterLevelStock(HttpServletRequest request, HttpServletResponse response) {
        RemoteResult<PageModel2<HsWaterLevelStock>> re = new RemoteResult<PageModel2<HsWaterLevelStock>>(false);
        try {
            JSONArray faIds = getGlobalFaIds();
            JSONArray shopids = getTenantIds();
            String itcode = getGlobalItcode();
            LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:" + faIds.toString() + "，shopIds:" + shopids.toString());
            if (CollectionUtils.isNotEmpty(faIds)) {
                Map<String, Object> conditionMap = new HashMap<String, Object>();
                String fxsno = request.getParameter("fxsNo");
                String faid = request.getParameter("faId");
                String fxsName = request.getParameter("fxsName");
                String createTime_start = request.getParameter("createTimeStart");
                String createTime_end = request.getParameter("createTimeEnd");
                String onlineUpdateTime_start = request.getParameter("onlineUpdateTimeStart");
                String onlineUpdateTime_end = request.getParameter("onlineUpdateTimeEnd");
                conditionMap.put("fxsno", fxsno);
                conditionMap.put("faid", faid);
                conditionMap.put("fxsname", fxsName);
                conditionMap.put("createTime_start", createTime_start);
                conditionMap.put("createTime_end", createTime_end);
                conditionMap.put("updateTime_start", onlineUpdateTime_start);
                conditionMap.put("updateTime_end", onlineUpdateTime_end);
                conditionMap.put("FAInfos", faIds);
                PageQuery pageQuery = new PageQuery(getGlobalPage(request), getGlobalRowNum(request));
                re = hsStockRemoteService.getHsWaterLevelStockPage(pageQuery, conditionMap);
            } else {
                re.setResultMsg("无权查询！");
                re.setResultCode(StockResultCode.STOCK_NOT_MEET);
            }
        } catch (Exception e) {
            re.setResultMsg("系统异常！");
            re.setResultCode(StockResultCode.STOCK_ERROR);
            LOGGER.error(e.getMessage(), e);
        }
        //将数据格式以json返回
        return JacksonUtil.toJson(re);
    }

    /**
     * 分页查询小蜜蜂订单信息
     *
     * @return
     */
    @RequestMapping(value = "/queryOrdersByOrderTime", produces = "text/json;charset=UTF-8")
    @ResponseBody
    public String queryOrdersByOrderTime(HttpServletRequest request, HttpServletResponse response) {
        RemoteResult<PageModel2<BeeOrderApi>> re = new RemoteResult<PageModel2<BeeOrderApi>>(false);
        try {
            Map<String, Object> conditionMap = new HashMap<String, Object>();
            String orderTime_start = request.getParameter("orderTimeStart");
            String orderTime_end = request.getParameter("orderTimeEnd");
            String paymentStatus = request.getParameter("paymentStatus");//0未支付，1已支付
            if (!isValidDate(orderTime_start)||!isValidDate(orderTime_end)){
                re.setResultMsg("日期参数错误，请检查是否为 yyyy-MM-dd HH:mm:ss 格式！");
                re.setResultCode("2001");
                return JsonUtil.toJson(re);
            }
            conditionMap.put("orderTime_start", orderTime_start);
            conditionMap.put("orderTime_end", orderTime_end);
            conditionMap.put("type", 3);//type=3 小蜜蜂订单
            if (StringUtils.isNotEmpty(paymentStatus)){
                conditionMap.put("paymentStatus",paymentStatus);
            }
            PageQuery pageQuery = new PageQuery(getGlobalPage(request), getGlobalRowNum(request));
            re = hsStockRemoteService.getBeeOrderPage(pageQuery, conditionMap);
        } catch (Exception e) {
            re.setResultMsg("系统异常！");
            re.setResultCode(StockResultCode.STOCK_ERROR);
            LOGGER.error(e.getMessage(), e);
        }
        //将数据格式以json返回
        return JsonUtil.toJson(re);
    }
    /**
     * 创建自有库存
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/addHsOwnStock", produces = "text/json;charset=UTF-8", method = {RequestMethod.POST})
    @ResponseBody
    public String addHsOwnStock(HttpServletRequest request, HttpServletResponse response) {
        RemoteResult re = new RemoteResult(false);
        try {
            JSONArray faIds = getGlobalFaIds();
            JSONArray shopids = getTenantIds();
            String itcode = getGlobalItcode();
            LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:" + faIds.toString() + "，shopIds:" + shopids.toString());

            String fxsno = request.getParameter("fxsNo");//分销商编号
            String faid = request.getParameter("faId");//faid
            String goodsCode = request.getParameter("goodsCode");//物料编号
            String fxsname = request.getParameter("fxsName");//分销商名称
            String productGroup = request.getParameter("productGroup");//产品组名称
            String productGroupNo = request.getParameter("productGroupNo");//产品组编号
            String stockNum = request.getParameter("stockNum");//库存数
            if (StringUtil.isEmpty(faid, fxsno, goodsCode, productGroupNo, stockNum)||Integer.parseInt(stockNum)<0){
                re.setResultCode(StockResultCode.STOCK_EMPTY);
                re.setResultMsg("参数有误");
                return JacksonUtil.toJson(re);
            }
            if (CollectionUtils.isNotEmpty(faIds) && faIds.contains(faid)) {
                RemoteResult<HsStock> result = hsStockRemoteService.getHsOwnStock(faid, goodsCode, productGroupNo);
                if (result.isSuccess() && result.getT() != null) {
                    re.setResultCode(StockResultCode.FIND_STOCK_EXIST);
                    re.setResultMsg("自有库存已存在");
                } else {
                    HsStock info = new HsStock();   //封装 库存 需要的信息

                    info.setStockNumber(Integer.parseInt(stockNum));
                    info.setFaname(fxsname);
                    info.setFacode(fxsno);
                    info.setFaid(faid);
                    info.setProductGroupNo(productGroupNo);
                    info.setProductGroup(productGroup);
                    info.setWarehousename("自有仓");
                    info.setWarehouse("xxxxx");
                    info.setCreateby(itcode);
                    info.setStocktype(2);
                    info.setCreatetime(DateFormatUtils.format(new Date()));
                    LOGGER.info("增加自有库存 信息:" + JsonUtil.toJson(info));
                    re = hsStockRemoteService.addHsOwnStock(info);
                }
            } else {
                re.setResultCode(StockResultCode.STOCK_NOT_MEET);
                re.setResultMsg("无权添加自有库存信息！");
                LOGGER.error("addHsOwnStock接口:" + itcode + "无权添加自有库存信息");
            }
        } catch (Exception e) {
            re.setResultCode(StockResultCode.STOCK_ERROR);
            re.setResultMsg("系统异常！");
            LOGGER.error(e.getMessage(), e);
        }
        return JacksonUtil.toJson(re);
    }
    /**
     * 修改自有库存
     *
     * @return
     */
    @RequestMapping(value = "/updateHsOwnStock", produces = "text/json;charset=UTF-8", method = {RequestMethod.POST})
    @ResponseBody
    public String updateHsOwnStock(HttpServletRequest request, HttpServletResponse response, long stockId,
                                        int stockNum) {

        RemoteResult re = new RemoteResult(false);
        try {
            if (stockNum < 0) {
                re.setResultCode(StockResultCode.STOCK_EMPTY);
                re.setResultMsg("参数有误！自有库存数不能小于0");
            } else {
                JSONArray faIds = getGlobalFaIds();
                JSONArray shopids = getTenantIds();
                String itcode = getGlobalItcode();
                LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:" + faIds.toString() + "，shopIds:" + shopids.toString());
                RemoteResult<HsStock> remoteResult = hsStockRemoteService.getHsOwnStockById(stockId);

                if (remoteResult.isSuccess()&&remoteResult.getT()!=null) {
                    HsStock selectedStock = remoteResult.getT();
//                    String fxsno = selectedStock.getFxsno();
                    String faid = selectedStock.getFaid();
                    if (CollectionUtils.isNotEmpty(faIds) && faIds.contains(faid)) {
                        selectedStock.setStockNumber(stockNum);
                        selectedStock.setCreateby(itcode);
                        re = hsStockRemoteService.updateHsOwnStock(selectedStock);
                    } else {
                        re.setResultCode(StockResultCode.STOCK_NOT_MEET);
                        re.setResultMsg("无权修改自有库存信息！");
                    }
                } else {
                    re.setResultCode(StockResultCode.STOCK_NOTHINH);
                    re.setResultMsg("自有库存不存在！");
                }
            }
        } catch (Exception e) {
            re.setResultMsg("系统异常！");
            re.setResultCode(StockResultCode.STOCK_ERROR);
            LOGGER.error(e.getMessage(), e);
        }
        return JacksonUtil.toJson(re);
    }
    /**
     * 分页查询自有库存信息
     *
     * @return
     */
    @RequestMapping(value = "/queryHsOwnStock", produces = "text/json;charset=UTF-8")
    @ResponseBody
    public String queryHsOwnStock(HttpServletRequest request, HttpServletResponse response) {
        RemoteResult<PageModel2<HsStock>> re = new RemoteResult<PageModel2<HsStock>>(false);
        try {
            JSONArray faIds = getGlobalFaIds();
            JSONArray shopids = getTenantIds();
            String itcode = getGlobalItcode();
            LOGGER.info("登录信息[" + itcode + "]，用户权限 faIds:" + faIds.toString() + "，shopIds:" + shopids.toString());
            if (CollectionUtils.isNotEmpty(faIds)) {
                Map<String, Object> conditionMap = new HashMap<String, Object>();
                String fxsno = request.getParameter("fxsNo");
                String faid = request.getParameter("faId");
                String fxsName = request.getParameter("fxsName");
                String goodsCode = request.getParameter("goodsCode");
                String createTime_start = request.getParameter("createTimeStart");
                String createTime_end = request.getParameter("createTimeEnd");
                conditionMap.put("facode", fxsno);
                conditionMap.put("faid", faid);
                conditionMap.put("faname", fxsName);
                conditionMap.put("goodsCode", goodsCode);
                conditionMap.put("createTime_start", createTime_start);
                conditionMap.put("createTime_end", createTime_end);
                conditionMap.put("FAInfos", faIds);
                PageQuery pageQuery = new PageQuery(getGlobalPage(request), getGlobalRowNum(request));
                re = hsStockRemoteService.getHsOwnStockPage(pageQuery, conditionMap);
            } else {
                re.setResultMsg("无权查询！");
                re.setResultCode(StockResultCode.STOCK_NOT_MEET);
            }
        } catch (Exception e) {
            re.setResultMsg("系统异常！");
            re.setResultCode(StockResultCode.STOCK_ERROR);
            LOGGER.error(e.getMessage(), e);
        }
        //将数据格式以json返回
        return JacksonUtil.toJson(re);
    }
    public static boolean isValidDate(String str) {
        boolean convertSuccess=true;
        // 指定日期格式
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
           // 设置lenient为false. 否则SimpleDateFormat会比较宽松地验证日期，比如2007/02/29会被接受，并转换成2007/03/01
            format.setLenient(false);
            format.parse(str);
        } catch (ParseException e) {
            // 如果throw java.text.ParseException或者NullPointerException，就说明格式不对
            convertSuccess=false;
        }
        return convertSuccess;
    }
}
