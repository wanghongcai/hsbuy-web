package com.lenovo.m2.buy.promotion.admin.controller.api.ordercenter;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.domain.ordercenter.ResultLogistics;
import com.lenovo.m2.buy.promotion.admin.remote.ordercenter.OpenOrderRemote;
import com.lenovo.m2.hsbuy.common.util.JsonUtil;
import com.lenovo.m2.hsbuy.domain.order.logistics.NoticeResponse;
import com.lenovo.m2.hsbuy.domain.order.logistics.TaskRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * update by licy13 on 2017/4/17
 */
@Controller
public class Kuaidi100Controller {

    private static final Logger LOGGER = LogManager.getLogger(Kuaidi100Controller.class.getName());

    @Autowired
    private OpenOrderRemote openOrderRemote;

    /**
     * 上传物流信息，订阅物流
     *
     * @param taskRequest
     * @return
     */
    @RequestMapping("/poll")
    @ResponseBody
    public String poll(TaskRequest taskRequest) {
        LOGGER.info("poll taskRequest={} ", JsonUtil.toJson(taskRequest));
        RemoteResult result = openOrderRemote.poll(taskRequest);
        LOGGER.info("poll orderId={},result={}", taskRequest.getOrderCode(), JsonUtil.toJson(result));
        return JsonUtil.toJson(new ResultLogistics(result));
    }

    /**
     * K100回调
     *
     * @param request
     * @param response
     */
    @RequestMapping("/connect/kuaidi100")
    public void callback(HttpServletRequest request, HttpServletResponse response) {
        try {
            String param = request.getParameter("param");
            RemoteResult result = openOrderRemote.callback(param);
            response.getWriter().print(JsonUtil.toJson(new NoticeResponse(result)));
        } catch(Exception e) {
            LOGGER.error("connect/kuaidi100 callback error", e);
        }
    }

}
