package com.lenovo.m2.buy.promotion.web;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.enums.GloablErrorMessageEnum;
import com.lenovo.m2.buy.promotion.admin.common.enums.Terminal;
import com.lenovo.m2.buy.promotion.admin.common.exception.BusinessException;
import com.lenovo.m2.buy.promotion.admin.common.utils.JsonUtil;
import com.lenovo.m2.buy.promotion.api.domain.Activity;
import com.lenovo.m2.buy.promotion.api.domain.GoodsPromotion;
import com.lenovo.m2.buy.promotion.api.domain.SalesGoodsPromotionInfo;
import com.lenovo.m2.buy.promotion.api.service.ActivityService;
import com.lenovo.m2.buy.promotion.api.service.PromotionService;
import com.lenovo.price.model.PriceInfo;
import com.lenovo.price.model.ProductDetail;
import com.lenovo.products.cache.ProductRedis;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 */
@Controller("PromotionApi")
@RequestMapping("/api")
public class PromotionApi {

	@Autowired
	private PromotionService promotionService;
	
	@Autowired
	private ActivityService activityService;

    private static Logger log = LoggerFactory.getLogger(PromotionApi.class);


    private void initProductInfo(GoodsPromotion promotions, int terminal){
    	
    	String relCodes = promotions.getRelGcodes();
    	if(StringUtils.isEmpty(relCodes)){
    		return;
    	}
    	
    	String[] tmp = relCodes.split(",");
    	if(tmp.length <= 0){
    		return;
    	}
    	
    	Integer[] codes = new Integer[tmp.length];  
    	for(int i = 0 ; i < tmp.length ; i++){
    		codes[i] = Integer.parseInt(tmp[i]);
    	}
    	
    	Map<Integer, ProductDetail> detailMap = new HashMap<>(codes.length);
    	Map<Integer, PriceInfo> priceMap = new HashMap<>(codes.length);

		ProductDetail[] details = new ProductDetail[0];
		log.info("codes={}", codes);
		try {
			long getDetailsStart = System.currentTimeMillis();
			details = ProductRedis.getProductDetails(codes);
			log.debug("details={}", JsonUtil.toJson(details));

			log.info("getProductDetails================================================================={}", System.currentTimeMillis()-getDetailsStart);
		} catch (Exception e) {
			log.error("查询商品缓存失败", e);
			return;
		}
		if(details == null){
			log.warn("查询商品缓存失败 codes={}",codes);
			return;
		}

		for(ProductDetail detail: details){
    		if(detail == null){
    			continue ;
    		}
    		detailMap.put(detail.getCode(), detail);
    	}
    	log.debug("detailsMap={}", JsonUtil.toJson(detailMap));
		PriceInfo[] prices = new PriceInfo[0];
		log.info("codes={}", codes);
		try {
			long getPricesStart = System.currentTimeMillis();
			prices = ProductRedis.getPrices(codes);
			log.debug("prices={}", JsonUtil.toJson(prices));
			log.info("getPrices================================================================={}", System.currentTimeMillis()-getPricesStart);
		} catch (Exception e) {
			log.error("查询商品缓存失败", e);
			return;
		}
		if(prices == null){
			log.warn("查询商品缓存失败 codes={}",codes);
			return;
		}

    	for(PriceInfo detail: prices){
    		if(detail == null){
    			continue ;
    		}
    		priceMap.put(detail.getCode(), detail);
    	}
    	log.info("priceMap={}", JsonUtil.toJson(priceMap));
    	
    	if(promotions.getOption() != null){
			for(SalesGoodsPromotionInfo sale: promotions.getOption()){
				ProductDetail detail = detailMap.get(Integer.parseInt(sale.getCode()));
				if(detail == null){
					log.info("获取商品信息失败, {}", sale.getCode());
					throw new BusinessException(GloablErrorMessageEnum.ERROR_GET_PRODUCT_DETAIL);
				}
				
				sale.setPath(detail.getThumbnailsURL());
				
				PriceInfo price = priceMap.get(Integer.parseInt(sale.getCode()));
				if(price == null){
					log.info("获取商品价格失败, {}", sale.getCode());
					throw new BusinessException(GloablErrorMessageEnum.ERROR_GET_PRODUCT_DETAIL);
				}
				sale.setProductPrice(Double.valueOf(getTerminalPrice(terminal, price).toString()));
				
			}
		}
		
		if(promotions.getGifts() != null){
			for(SalesGoodsPromotionInfo sale: promotions.getGifts()){
				ProductDetail detail = detailMap.get(Integer.parseInt(sale.getCode()));
				if(detail != null){
					sale.setPath(detail.getThumbnailsURL());
				}
			}
		}
		
		
		if(promotions.getPacks() != null){
			for(List<SalesGoodsPromotionInfo> sales: promotions.getPacks().values()){
				BigDecimal total = BigDecimal.ZERO;
				BigDecimal totalDiscount = BigDecimal.ZERO;
				for(SalesGoodsPromotionInfo sale: sales){
					ProductDetail detail = detailMap.get(Integer.parseInt(sale.getCode()));
					if(detail == null){
						log.info("获取商品信息失败, {}", sale.getCode());
						throw new BusinessException(GloablErrorMessageEnum.ERROR_GET_PRODUCT_DETAIL);
					}
					sale.setPath(detail.getThumbnailsURL());
					PriceInfo price = priceMap.get(Integer.parseInt(sale.getCode()));
					if(price == null){
						log.info("获取商品价格失败, {}", sale.getCode());
						throw new BusinessException(GloablErrorMessageEnum.ERROR_GET_PRODUCT_DETAIL);
					}
					sale.setProductPrice(Double.valueOf(getTerminalPrice(terminal, price).toString()));
					total = total.add(new BigDecimal(sale.getProductPrice().toString()));
					totalDiscount = totalDiscount.add(new BigDecimal(sale.getDiscountAmount().toString()));
				}
				
				for(SalesGoodsPromotionInfo sale: sales){
					sale.setTotalDiscountAmount(String.valueOf(totalDiscount.setScale(2, BigDecimal.ROUND_HALF_UP)));
					sale.setTotalPrice(total.setScale(2, BigDecimal.ROUND_HALF_UP).toString());
				}
				
			}
		}
		
		if(promotions.getGiftsSelectable() != null){
			for(SalesGoodsPromotionInfo sale: promotions.getGiftsSelectable()){
				ProductDetail detail = detailMap.get(Integer.parseInt(sale.getCode()));
				if(detail != null){
					sale.setPath(detail.getThumbnailsURL());
				}
			}
		}
    }
    
	private Money getTerminalPrice(int terminal, PriceInfo price) {
		//TODO  从商品类中取 暂时传CNY
		Money terminalPrice = null;
		if (terminal == Terminal.PC.getType()) {
			terminalPrice = new Money(price.getPc(),"CNY");
		} else if (terminal == Terminal.WAP.getType()) {
			terminalPrice = new Money(price.getWap(),"CNY");
		} else if (terminal == Terminal.APP.getType()) {
			terminalPrice = new Money(price.getApp(),"CNY");
		} else if (terminal == Terminal.WECHAT.getType()) {
			terminalPrice = new Money(price.getWeixin(),"CNY");
		} else {
			throw new BusinessException(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL);
		}
		if(terminalPrice == null){
			throw new BusinessException(GloablErrorMessageEnum.ERROR_PLAT_PRICE);
		}
		
		
		return terminalPrice;
	}

	/**
	 * 批量查询活动信息
	 * gcodes多个商品编码使用,分隔
	 * @param shopid
	 * @param gcodes
	 * @param terminal
	 * @return
	 */
    @RequestMapping("/getActivityBatch")
    @ResponseBody
    public String getActivityBatch(Integer shopid, String gcodes, Integer terminal){

    	log.info("get activity req: shopId={},gcode={},terminal={}",
    			new Object[]{shopid, gcodes, terminal});
    	Tenant tenant = new Tenant();
		tenant.setShopId(shopid);
		return JsonUtil.toJson(activityService.getActivities(tenant,terminal,gcodes));

    }

    /**
     * app 获取满减信息列表
     * @param shopId
     * @param callbackparam
     * @param mainCodes
     * @return
     */
   /* @RequestMapping(value="/getAppfullReductionList", produces = "application/json; charset=UTF-8")
    @ResponseBody
    public String getAppfullReductionList(Integer shopId, String mainCodes,Integer terminal, String callbackparam){
        log.info("getAppfullReductionList shopId={},mainCodes={}",shopId,mainCodes);
       Tenant tenant = new Tenant();
		tenant.setShopId(shopId);
		return  getAppfullReductionList(tenant,mainCodes,terminal,callbackparam);
    }*/


	/***************************************国际化*************************************************/
	@RequestMapping(value="/getPromotion", produces = "application/json; charset=UTF-8")
	@ResponseBody
	public RemoteResult<GoodsPromotion> getPromotion(Tenant tenant,Integer shopid, String gcode, Integer terminal, String group, String lenovoId){
		if(tenant.getCurrencyCode() == null){
			tenant.setCurrencyCode("CNY");
		}

		if(tenant.getShopId() == null){
			tenant.setShopId(shopid);
		}
		log.info("get promotion req: shopId={},gcode={},terminal={}, group={}, lenovoId={}",
				new Object[]{tenant.getShopId(), gcode, terminal, group, lenovoId});
		RemoteResult<GoodsPromotion> rr = new RemoteResult<>();
		rr.setSuccess(true);
		rr.setResultCode("0");

		try{
			long getPromoStart = System.currentTimeMillis();
			RemoteResult<GoodsPromotion> promotions = promotionService.getGoodsPromotinByGcodeAndGroup(tenant, gcode, terminal, group, lenovoId);
			log.info("getGoodsPromotinByGcodeAndGroup========================================={}",System.currentTimeMillis()-getPromoStart);
			if(promotions.isSuccess()){
				long getProduStart = System.currentTimeMillis();
				initProductInfo(promotions.getT(), terminal);
				log.info(JsonUtil.toJson(promotions.getT()));
				log.info("initProductInfo========================================={}",System.currentTimeMillis()-getProduStart);
				rr.setT(promotions.getT());
				return rr;
			}else {
				return  promotions;
			}

		}catch(BusinessException e){
			log.error("", e);
			rr.setSuccess(false);
			rr.setResultCode(e.getErrno());
			rr.setResultMsg(e.getMessage());
			return rr;
		}catch (Exception e) {
			log.error("", e);
			rr.setSuccess(false);
			rr.setResultCode("0");
			return rr;
		}

	}


	@RequestMapping("/getActivity")
	@ResponseBody
	public RemoteResult<Activity> getActivity(Tenant tenant,Integer shopid,  String gcode, Integer terminal){
		if(tenant.getShopId() == null){
			tenant.setShopId(shopid);
		}
		if(tenant.getCurrencyCode() == null){
			tenant.setCurrencyCode("CNY");
		}
		log.info("get activity req: shopId={},gcode={},terminal={}",
				new Object[]{tenant.getShopId(), gcode, terminal});

		RemoteResult<Activity> remoteResult = activityService.getActivity(tenant, terminal, gcode);

		return remoteResult;

	}


	@RequestMapping("/test")
	@ResponseBody
	public String getActivity(){
		log.info("test");
		return "hello";
	}


}
