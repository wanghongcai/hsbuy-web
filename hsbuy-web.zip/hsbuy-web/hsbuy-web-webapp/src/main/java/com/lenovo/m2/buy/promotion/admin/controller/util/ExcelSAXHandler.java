package com.lenovo.m2.buy.promotion.admin.controller.util;


import com.lenovo.fileclient.PrivateSpcaceManager;
import com.lenovo.fileclient.UploadImageClient;
import com.lenovo.fileclient.common.UploadResponse;
import com.lenovo.m2.arch.tool.util.DateFormatUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
import com.lenovo.m2.buy.promotion.admin.common.utils.PropertiesUtil;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class ExcelSAXHandler extends DefaultHandler {
    private static final Logger LOGGER = Logger.getLogger(ExcelSAXHandler.class);
    protected SharedStringsTable sst;
    protected String fileName;

    protected boolean canStop = false;
    private static final String appId = PropertiesUtil.getProperty("imageServer.order.appId");
    private static final String appKey = PropertiesUtil.getProperty("imageServer.order.appKey");
    private static final String domain = PropertiesUtil.getProperty("imageServer.order.domain");
    private static final String imageServerURL = PropertiesUtil.getProperty("imageServer.order.imageServerURL");

    private static String targetCouponFilePath = "/orderCenter/";
    /**
     * 解析节点时临时存值的便利
     */
    private boolean nextIsString;// 判断单元格内容是否为文本格式
    private String cellType;
    private String cellStyle;

    protected String lastContents;
    protected String cellIndex;
    protected int rowIndex = 0;

    /**
     * 常量
     */
    private static final String ELEMENT_CELL = "c";
    private static final String ELEMENT_ROW = "row";
    private static final String ELEMENT_VALUE = "v";
    private static final String ATTRIBUTE_REFERENCE = "r";
    private static final String CELL_TYPE = "t";
    private static final String CELL_TYPE_STRING = "s";
    private static final String CELL_STYLE = "s";
    private static final String EXCEL_DOWNPATH_LINUX = PropertiesUtil.getProperty("downloadexcel");
    public  static final int PAGESIZE = 1000;//pageSize 分页条数
    public static final int WORKSIZE = 1000;//超过1000条数据使用缓存
    /**
     * 单元格索引
     */
    protected static final String CELL_INDEX_A = "A";
    protected static final String CELL_INDEX_B = "B";
    protected static final String CELL_INDEX_C = "C";
    protected static final String CELL_INDEX_D = "D";
    protected static final String CELL_INDEX_E = "E";
    protected static final String CELL_INDEX_F = "F";
    protected static final String CELL_INDEX_G = "G";
    protected static final String CELL_INDEX_H = "H";
    protected static final String CELL_INDEX_I = "I";
    protected static final String CELL_INDEX_J = "J";
    protected static final String CELL_INDEX_K = "K";

    private OPCPackage pkg = null;
    private InputStream sheetIS = null;
    private XSSFReader xssfReader = null;
    private XMLReader sheetReader = null;
    private static Logger logger = Logger.getLogger(ExcelSAXHandler.class);
    public ExcelSAXHandler(String fileName) {
        this.fileName = fileName;
        try {
            this.pkg = OPCPackage.open(this.fileName);
            this.xssfReader = new XSSFReader(pkg);
            this.sst = xssfReader.getSharedStringsTable();
            this.sheetReader = XMLReaderFactory
                    .createXMLReader("org.apache.xerces.parsers.SAXParser");
            // 设置解析器对象
            sheetReader.setContentHandler(this);
        } catch (Exception e) {
            e.printStackTrace();
            errorResolver();
        }
    }

    @Override
    public void startElement(String uri, String localName, String name,
                             Attributes attributes) throws SAXException {
        if (isRow(name)) {
            rowIndex = getRowIndex(attributes);
        } else if (isCell(name)) {
            // Print the cell reference
            cellIndex = getCellInex(attributes);

            // Figure out if the value is an index in the SST
            cellType = attributes.getValue(CELL_TYPE);
            cellStyle = attributes.getValue(CELL_STYLE);
            // 如果下一个元素是 SST 的索引，则将nextIsString标记为true
            if (CELL_TYPE_STRING.equals(cellType)) {
                nextIsString = true;
            } else {
                nextIsString = false;
            }
        } else if (isValue(name)) {
            lastContents = "";
        }
    }


    @Override
    public void characters(char[] ch, int start, int length)
            throws SAXException {
        lastContents += new String(ch, start, length);
    }

    private boolean hasValue(String s) {
        if (s == null || "".equals(s.trim())) {
            return false;
        }
        return true;
    }

    protected boolean isDateType(String cellStyle) {
        return "7".equals(cellStyle) || "12".equals(cellStyle)
                || "8".equals(cellStyle) || "13".equals(cellStyle)
                || "9".equals(cellStyle) || "5".equals(cellStyle)
                || "3".equals(cellStyle) || "4".equals(cellStyle);
    }

    protected void analyze(String sheetName) {
        try {
            sheetIS = xssfReader.getSheet(sheetName);
            sheetReader.parse(new InputSource(sheetIS));
        } catch (StopParsingException e) {
        } catch (Exception e) {
            e.printStackTrace();
            errorResolver();
        }
    }

    public void close() {
        if (sheetIS != null) {
            try {
                sheetIS.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (pkg != null) {
            pkg.flush();
            try {
                pkg.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    protected void stop() throws StopParsingException {
        canStop = true;
        throw new StopParsingException();
    }

    protected void errorResolver() {
    }

    protected void resolverContents() {
        if (nextIsString) {
            int idx = Integer.parseInt(lastContents);
            lastContents = new XSSFRichTextString(sst.getEntryAt(idx))
                    .toString().trim();
            nextIsString = false;
        }
    }

    protected boolean isValue(String name) {
        return name.equals(ELEMENT_VALUE);
    }

    protected boolean isRow(String name) {
        return name.equals(ELEMENT_ROW);
    }

    protected boolean isCell(String name) {
        return name.equals(ELEMENT_CELL);
    }

    protected int getRowIndex(Attributes attributes) {
        return Integer.valueOf(attributes.getValue(ATTRIBUTE_REFERENCE));
    }

    protected String getCellInex(Attributes attributes) {
        return attributes.getValue(ATTRIBUTE_REFERENCE).substring(0, 1);
    }

    private class StopParsingException extends RuntimeException {

    }


    public  static String getFileName(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-ddhh-mm-ss");
        //取三位随机数
        String random= String.valueOf(Math.random()).substring(2,5);
        String excelName = sdf.format(new Date()) +random+ ".xlsx";
        excelName = excelName.replace("-", "");
        return excelName;
    }


    public  static  void  saveAndDonwnExcel(SXSSFWorkbook workbook,String path ,HttpServletResponse response, OutputStream out) {
        //存储服务器
        FileOutputStream fout = null;
        FileInputStream in = null;
        try {
            fout = new FileOutputStream(path);
            workbook.write(fout);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                fout.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        //下载
        try {
            in = new FileInputStream(path);
            out = response.getOutputStream();
            byte[] buf = new byte[1024 * 8];
            while (true) {
                int read = 0;
                if (in != null) {
                    read = in.read(buf);
                }
                if (read == -1) {
                    break;
                }
                out.write(buf, 0, read);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                out.close();
                out.flush();
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }


    public static String toUtf8String(String s) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 0 && c <= 255) {
                sb.append(c);
            } else {
                byte[] b;
                try {
                    b = Character.toString(c).getBytes("utf-8");
                } catch (Exception ex) {
                    LOGGER.error(ex);
                    b = new byte[0];
                }
                for (int j = 0; j < b.length; j++) {
                    int k = b[j];
                    if (k < 0) k += 256;
                    sb.append("%" + Integer.toHexString(k).toUpperCase());
                }
            }
        }
        return sb.toString();
    }


    public static void setCellValue(int num, Row row, Object obj) {
        Cell cell = row.createCell(num);//创建一列
        cell.setCellType(CellType.STRING);
        if (obj != null && (obj instanceof Double || obj instanceof Integer)) {
            cell.setCellType(CellType.NUMERIC);
            cell.setCellValue(Double.parseDouble(obj.toString()));
        } else {
            cell.setCellValue(obj == null ? "" : obj.toString());
        }
    }

    public static Object getCellFormatValue(XSSFCell cell) {
        if (cell != null) {
            switch (cell.getCellType()) {
                case XSSFCell.CELL_TYPE_NUMERIC:
                    if (HSSFDateUtil.isCellDateFormatted(cell)) {
                        Date date = cell.getDateCellValue();
                        return DateFormatUtils.format(date);
                    }
                    DecimalFormat df = new DecimalFormat("#.#########");
                    return df.format(Double.valueOf(cell.getNumericCellValue()));
                case XSSFCell.CELL_TYPE_STRING:
                    return cell.getStringCellValue();
                case XSSFCell.CELL_TYPE_BOOLEAN:
                    return cell.getBooleanCellValue();
                case XSSFCell.CELL_TYPE_FORMULA:
                    return cell.getCellFormula();
                case XSSFCell.CELL_TYPE_ERROR:
                    return cell.getErrorCellValue();
                case XSSFCell.CELL_TYPE_BLANK:
                    return "";
            }
            return "";
        } else {
            return "";
        }
    }

    public static Sheet createSheet(SXSSFWorkbook workbook, String sheetName, String[] excelHeaders) {
        Sheet sheet = workbook.createSheet(sheetName);
        Row row = sheet.createRow(0);
        CellStyle style = workbook.createCellStyle();
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);    //设置颜色为红色
        style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        for (int i = 0; i < excelHeaders.length; i++) {
            Cell cell = row.createCell(i);
            cell.setCellValue(excelHeaders[i]);
            cell.setCellStyle(style);
            sheet.setColumnWidth(i, 3000);
        }
        return sheet;
    }

    /**
     * 报表上传到图片服务器
     *
     * @param workbook
     * @return
     */
    public static String uploadImage(SXSSFWorkbook workbook) {
        long timeStamp = new Date().getTime();
        String fileName = "Order_" + UUID.randomUUID().toString().replace("-", "") + ".xlsx";
        String readURL = "";
        try {
            String token = UploadImageClient.getToken(appId, appKey, timeStamp, targetCouponFilePath + fileName, "1");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            workbook.write(bos);
            LOGGER.info("fileName==[" + fileName + "], appId=[" + appId + "], appKey=[" + appKey + "], domain=[" + domain + "]");
            UploadResponse uploadResponse = UploadImageClient.upload(appId, token, timeStamp, imageServerURL + targetCouponFilePath + fileName, bos.toByteArray(), fileName, "1");
            if (uploadResponse == null || !StringUtils.equalsIgnoreCase(uploadResponse.getStatus(), "001")) {
                LOGGER.info("image upload failure：" + uploadResponse.getStatus() + "filepath=" + uploadResponse.getFid());

            } else {
                LOGGER.info("status=：" + uploadResponse.getStatus() + "___filepath=" + uploadResponse.getFilename());
            }

            readURL = PrivateSpcaceManager.getReadURL(appId, appKey, domain, targetCouponFilePath + fileName);
            LOGGER.info("readURL======" + readURL);
        } catch (Exception e) {
            LOGGER.error("报表上传服务器异常", e);
        }

        return readURL;
    }
}
