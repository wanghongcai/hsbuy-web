package com.lenovo.m2.buy.promotion.admin.controller.util;

import com.lenovo.m2.buy.promotion.admin.domain.common.ShopIds;
import com.lenovo.m2.buy.promotion.admin.soa.api.domain.SessionUser;
import com.lenovo.m2.buy.promotion.admin.soa.enums.ShopIdEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dulijie on 2016/7/6.
 */
public class AddShopName {
    private static Logger log = LoggerFactory.getLogger(AddShopName.class);
    //商城类型转换
    public static List<ShopIds> getShopIds(){
        SessionUser user = ThreadLocalObjs.getUser();
        List<String> shopIdsList = user.getShopIds();
        List<ShopIds> newShopIds = new ArrayList<>();
        for(int i=0;i<shopIdsList.size();i++){
            ShopIds shopIds = new ShopIds();
            String eCode = shopIdsList.get(i);
            ShopIdEnum eName =ShopIdEnum.getValueByType(Integer.parseInt(eCode));
            log.info("eCode={}", eCode);
            if (null !=eName){
                log.info("eCode={},shopname={}", eCode,String.valueOf(eName.getDescr()));
                shopIds.setShopType(Integer.parseInt(eCode));
                shopIds.setShopName(eName.getDescr());
                newShopIds.add(shopIds);
            }
        }
        return newShopIds;
    }
    //商城类型转换 过滤掉EPP
    public static List<ShopIds> getShopIdsExceptEpp() {
        SessionUser user = ThreadLocalObjs.getUser();
        List<String> shopIdsList = user.getShopIds();
        List<ShopIds> newShopIds = new ArrayList<>();
        for (int i = 0; i < shopIdsList.size(); i++) {
            ShopIds shopIds = new ShopIds();
            String eCode = shopIdsList.get(i);
            ShopIdEnum eName = ShopIdEnum.getValueByType(Integer.parseInt(eCode));
            log.info("eCode={}", eCode);

            if (null != eName && !"EPP".equals(eName.name())) {
                log.info("eCode={},shopname={}", eCode,String.valueOf(eName.getDescr()));
                shopIds.setShopType(Integer.parseInt(eCode));
                shopIds.setShopName(eName.getDescr());
                newShopIds.add(shopIds);
            }
        }
        return newShopIds;
    }

    //商城类型转换 过滤掉EPP、17积分商城、17商城、MOTO商城
    public static List<ShopIds> getShopIdsExceptEppAndScore() {
        SessionUser user = ThreadLocalObjs.getUser();
        List<String> shopIdsList = user.getShopIds();
        List<ShopIds> newShopIds = new ArrayList<>();
        for (int i = 0; i < shopIdsList.size(); i++) {
            ShopIds shopIds = new ShopIds();
            String eCode = shopIdsList.get(i);
            ShopIdEnum eName = ShopIdEnum.getValueByType(Integer.parseInt(eCode));
            log.info("eCode={}", eCode);
            if ((null != eName && !"EPP".equals(eName.name())) && (null != eName && !"SMBJF".equals(eName.name())) && (null != eName && !"SMB".equals(eName.name())) && (null != eName && !"MOTO".equals(eName.name())))  {
                log.info("eCode={},shopname={}", eCode,String.valueOf(eName.getDescr()));
                shopIds.setShopType(Integer.parseInt(eCode));
                shopIds.setShopName(eName.getDescr());
                newShopIds.add(shopIds);
            }
        }
        return newShopIds;
    }

}
