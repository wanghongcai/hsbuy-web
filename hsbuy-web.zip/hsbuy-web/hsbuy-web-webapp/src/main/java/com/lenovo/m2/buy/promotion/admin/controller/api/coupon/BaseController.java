package com.lenovo.m2.buy.promotion.admin.controller.api.coupon;

import com.lenovo.admin.extra.client.AdminClientUtils;
import com.lenovo.admin.extra.client.vo.DataTypeVo;
import com.lenovo.admin.extra.client.vo.DataVo;
import com.lenovo.admin.extra.client.vo.SystemDataVo;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.CollectionUtils;
import com.lenovo.m2.arch.tool.util.StringUtils;
import com.lenovo.m2.buy.promotion.admin.common.utils.ThreadLocalReqAndResp;
import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;


public class BaseController {
    protected static Logger logger = Logger.getLogger(BaseController.class);
    private String shopIdUrl;
    protected HttpServletRequest request(){
        return ThreadLocalReqAndResp.getRequest();
    }
    protected HttpServletResponse response(){
        return ThreadLocalReqAndResp.getResponse();
    }
    protected HttpSession session(){
        return ThreadLocalReqAndResp.getSession();
    }

    //获取用户itcode
    protected String getItCode(){
        String itCode = AdminClientUtils.getInstance().getCurrItcode(request());
        logger.info("The itCode from AdminClient is: "+itCode);
        return itCode;
//        return "admin";
    }
    //获取当前用户数据权限
    protected List<SystemDataVo> getData4Req (){
        return AdminClientUtils.getInstance().getData4Req(request());
    }

    //获取指定用户数据权限
    protected List<SystemDataVo> getData4Itcode (String itCode){
        return AdminClientUtils.getInstance().getData4Itcode(itCode);
    }
    //获取页码
    public int getPage(HttpServletRequest request) {
        String page = request.getParameter("page");
        if(page==null){
            return 1;
        }
        return Integer.parseInt(page);
    }

    public List<String> getShopIds(HttpServletRequest request) {
        List<DataVo> dataVos = getDataVos(request, "ShopId");
        List<String> shopids = new ArrayList<String>();

        if (CollectionUtils.isNotEmpty(dataVos)) {
            for (DataVo dataVo : dataVos) {
                shopids.add(dataVo.getCode());
            }
        }
        logger.info("当前用户拥有的shopid：" + shopids.toString());
//        List<String> shopids = new ArrayList<String>();
//        shopids.add("1");
//        shopids.add("2");
//        shopids.add("3");
//        shopids.add("5");
//        shopids.add("8");
//        shopids.add("9");
//        shopids.add("10");
//        shopids.add("12");
//        shopids.add("13");
//        shopids.add("14");
//        shopids.add("15");

        return shopids;
    }

    //根据具体的数据权限类型获取数据权限list
    public List<DataVo> getDataVos(HttpServletRequest request, String dataType) {
        List<DataTypeVo> DataTypeVos = AdminClientUtils.getInstance().getSystemDataReq(request);
        if (CollectionUtils.isNotEmpty(DataTypeVos)) {
            for (DataTypeVo dataTypeVo : DataTypeVos) {
                if (dataType.equals(dataTypeVo.getTypeName())) {
                    return dataTypeVo.getDataVo();
                }
            }
        }
        return null;
    }

    public List<DataVo> getDataVosForName(HttpServletRequest request, String dataType, String Name) {
        List<DataTypeVo> DataTypeVos = AdminClientUtils.getInstance().getSystemDataReq(request);
        if (CollectionUtils.isNotEmpty(DataTypeVos)) {
            for (DataTypeVo dataTypeVo : DataTypeVos) {
                if (dataType.equals(dataTypeVo.getTypeName())) {
                    return dataTypeVo.getDataVo();
                }
            }
        }
        return null;
    }

    public Tenant getTenant(HttpServletRequest request) {
        String shopId = null;
        shopId = request.getParameter("shopid");
        if(StringUtils.isEmpty(shopId)){
            shopId = request.getParameter("shopId");
        }
        if(StringUtils.isNotEmpty(shopId)){
            return Tenant.getTenant(Integer.parseInt(shopId));
        }
        return Tenant.getTenant(1);
    }

}
