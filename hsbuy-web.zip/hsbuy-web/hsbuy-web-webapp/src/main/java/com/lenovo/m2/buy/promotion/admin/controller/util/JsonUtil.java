package com.lenovo.m2.buy.promotion.admin.controller.util;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.web.util.PaginatedUtils;
import com.lenovo.m2.couponV2.common.exception.ExceptionUtil;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.Version;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.module.SimpleModule;
import org.codehaus.jackson.type.JavaType;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

public class JsonUtil {

	private static Logger logger = Logger.getLogger(JsonUtil.class);
	private static final ObjectMapper mapper = new ObjectMapper();
	static {
		mapper.disable(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES);
		mapper.configure(SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);
		mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		SimpleModule module = new SimpleModule("money", Version.unknownVersion());
		module.addSerializer(Money.class, new MoneySerializer());
		mapper.registerModule(module);
		mapper.setSerializationInclusion(JsonSerialize.Inclusion.NON_NULL);
	}
	 public static JavaType assignList(Class<? extends Collection> collection, Class<? extends Object> object) {
	        return mapper.getTypeFactory().constructParametricType(collection, object);
	  }
	 
	 public static <T> ArrayList<T> readValuesAsArrayList(String key, Class<T> object) {
	        ArrayList<T> list = null;
	        try {
	            list = mapper.readValue(key, assignList(ArrayList.class, object));
	        } catch (JsonParseException e) {
	            logger.error(e.getMessage(), e);
	        } catch (JsonMappingException e) {
	            logger.error(e.getMessage(), e);
	        } catch (IOException e) {
	            logger.error(e.getMessage(), e);
	        }
	        return list;
	    }

	public static String toJson(Object obj) {
		String json = null;
		if (obj == null) {
			return null;
		}
		try {
			json = mapper.writeValueAsString(obj);
		} catch (Exception e) {
			logger.error(ExceptionUtil.getStackTrace(e));
		}
		return json;
	}

	public static Object toObject(String json, Class ObjectClass) {
		Object object = null;
		if (ObjectClass == null) {
			ObjectClass = HashMap.class;
		}
		if (json == null) {
			return null;
		}
		if (json != null) {
			json = json.replaceAll("\'", "\"");
		}
		try {
			object = mapper.readValue(json, ObjectClass);
		} catch (Exception e) {
			logger.error(ExceptionUtil.getStackTrace(e));
		}
		return object;
	}

    /**
     * 将list转换为json数据
     * @param totalRecord 总记录数
     * @param list 数据list
     * @return
     */
    public static String list2json(Integer totalRecord,List list){
		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.setDateFormat("yyyy-MM-dd HH:mm:ss");
		gsonBuilder.registerTypeAdapter(Money.class, new MoneyAdapter());
        Gson gjson = gsonBuilder.create();
        String aaData=gjson.toJson(list);
        String json = "{\"total\":"+totalRecord+",\"rows\":"+aaData+"}";
        return json;
    }

    /**
     * 返回结构没有total,只有rows
     * @param list
     * @return
     */
    public static String list2json(List list){
		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.setDateFormat("yyyy-MM-dd HH:mm:ss");
		gsonBuilder.registerTypeAdapter(Money.class, new MoneyAdapter());
		Gson gjson = gsonBuilder.create();
        return gjson.toJson(list);
    }

    /**
     *将paginatedUtils转换为json数据
     * @param paginatedUtils
     * @return
     */
    public static String list2json(PaginatedUtils paginatedUtils){
        Gson gjson=new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();
        String aaData=gjson.toJson(paginatedUtils.getDatas());
        String json = "{\"total\":"+paginatedUtils.getTotalPage()+",\"page\":"+paginatedUtils.getIndex()+",\"records\":"+paginatedUtils.getTotalItem()+",\"rows\":"+aaData+"}";
        return json;
    }


    /**
     * 返回页面提示json
     * @param info
     * @param status
     * @return
     */
    public static String backInfo(String info,String status){
        String msg = "{\"info\":\""+info+"\",\"status\":\""+status+"\"}";
        return msg;
    }

}
