/**
 * Project Name:couponV2-admin-webapp
 * File Name:ZipUtils.java
 * Package Name:com.lenovo.m2.couponV2.admin.webapp.util
 * Date:2017年5月9日下午3:15:10
 * Copyright (c) 2017, yuzj7@lenovo.com All Rights Reserved.
 *
*/

package com.lenovo.m2.buy.promotion.admin.controller.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * ClassName:ZipUtils <br/>
 * Function: TODO ADD FUNCTION. <br/>
 * Date: 2017年5月9日 下午3:15:10 <br/>
 * 
 * @author yuzj7
 * @version
 * @since JDK 1.7
 * @see
 */
public class ZipUtils {
	/**
	 * 
	 * 使用gzip进行压缩
	 */
	public static byte[] gzip(String primStr) {
		if (primStr == null || primStr.length() == 0) {
			return null;
		}

		ByteArrayOutputStream out = new ByteArrayOutputStream();

		GZIPOutputStream gzip = null;
		try {
			gzip = new GZIPOutputStream(out);
			gzip.write(primStr.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (gzip != null) {
				try {
					gzip.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return out.toByteArray();
	}

	/**
	 * 使用zip进行压缩
	 * 
	 * @param str
	 *            压缩前的文本
	 * @return 返回压缩后的文本
	 */
	public static final byte[] zip(String str,String name) {
		if (str == null)
			return null;
		byte[] compressed;
		ByteArrayOutputStream out = null;
		ZipOutputStream zout = null;
		InputStream is = null;
		try {
			is = new ByteArrayInputStream(str.getBytes());
			out = new ByteArrayOutputStream();
			zout = new ZipOutputStream(out);
			zout.putNextEntry(new ZipEntry(name));
			//zout.write(str.getBytes());
			byte[] buffer = new byte[512];
			int nNumber = 0;
            while ((nNumber = is.read(buffer)) != -1){
            	zout.write(buffer, 0, nNumber);
            }
            is.close();
            zout.close();
			//zout.closeEntry();
			compressed = out.toByteArray();
			return compressed;
		} catch (IOException e) {
			compressed = null;
		} finally {
			if (zout != null) {
				try {
					zout.close();
				} catch (IOException e) {
				}
			}
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
				}
			}
		}
		return null;
	}
	
	// 压缩   
	 /*public static byte[] compress(String str) throws IOException {   
	    if (str == null || str.length() == 0) {   
	     return null;   
	   }   
	    ByteArrayOutputStream out = new ByteArrayOutputStream();   
	   GZIPOutputStream gzip = new GZIPOutputStream(out);   
	   gzip.
	    gzip.write(str.getBytes());   
	    gzip.close();   
	   return out.toByteArray();   
	  }   */
}
