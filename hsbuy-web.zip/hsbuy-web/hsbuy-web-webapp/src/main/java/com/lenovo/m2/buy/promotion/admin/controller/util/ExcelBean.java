package com.lenovo.m2.buy.promotion.admin.controller.util;

import java.util.HashMap;
import java.util.Map;

/**
 * excel 规则实体类  
 * Created by wangyu46 on 2017/6/9.
 */
public class ExcelBean implements Comparable<ExcelBean>{

	
	private String name;	   		//列名
	
	private String isDefault = "";  //默认
	
	private int order;				//顺序

	private int isMapper;   		//是否需要映射处理   默认0 不需要  1 需要       映射处理设置mapper
	
	private Map<String,Object> mapper = new HashMap<>();
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(String isDefault) {
		this.isDefault = isDefault;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}
	

	

	public int getIsMapper() {
		return isMapper;
	}

	public void setIsMapper(int isMapper) {
		this.isMapper = isMapper;
	}

	public int compareTo(ExcelBean o) {
		return  -(o.getOrder() - this.getOrder());
	}

	public Map<String, Object> getMapper() {
		return mapper;
	}

	public void setMapper(Map<String, Object> mapper) {
		this.mapper = mapper;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((isDefault == null) ? 0 : isDefault.hashCode());
		result = prime * result + isMapper;
		result = prime * result + ((mapper == null) ? 0 : mapper.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + order;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExcelBean other = (ExcelBean) obj;
		if (isDefault == null) {
			if (other.isDefault != null)
				return false;
		} else if (!isDefault.equals(other.isDefault))
			return false;
		if (isMapper != other.isMapper)
			return false;
		if (mapper == null) {
			if (other.mapper != null)
				return false;
		} else if (!mapper.equals(other.mapper))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (order != other.order)
			return false;
		return true;
	}

	
}
