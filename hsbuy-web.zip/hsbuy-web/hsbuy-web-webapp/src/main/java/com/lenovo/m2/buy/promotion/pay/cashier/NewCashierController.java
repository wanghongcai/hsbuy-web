package com.lenovo.m2.buy.promotion.pay.cashier;

import com.lenovo.m2.arch.framework.domain.Money;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.CommonMethod;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.JacksonUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PaySignUtils;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.BaseInfo;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.DateUtil;
import com.lenovo.m2.buy.promotion.admin.domain.pay.cashier.MongoOrderJson;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.baseinfo.CommonPayManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.CashierManager;
import com.lenovo.m2.buy.promotion.admin.manager.pay.cashier.PayPortalOrderManager;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.OrderSupportPayType;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.ucenter.sso.client.util.SSOUserInfoUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.*;

/**
 * 收银台
 * Created by MengQiang on 2016年9月8日14:15:35.
 */
@Controller
public class NewCashierController {
    private Logger LOGGER = Logger.getLogger(this.getClass());
    @Autowired
    private CashierManager cashierManager;
    @Autowired
    private PayPortalOrderManager payPortalOrderManager;
    @Autowired
    private CommonManager commonManager;
    @Autowired
    private CommonPayManager commonPayManager;


    @RequestMapping("/order/toCashier")
    public String toNewCashier(HttpServletRequest request, HttpServletResponse response, Map<String, Object> paraMap) {
        try{
        String service = request.getParameter("service");
        String signType = request.getParameter("sign_type");
        String sign = request.getParameter("sign");
        String notifyUrl = request.getParameter("notify_url");
        String returnUrl = request.getParameter("return_url");
        String inputCharset = request.getParameter("input_charset");
        String paymentType = request.getParameter("payment_type");
        String shopId = request.getParameter("shop_id");
        String terminal = request.getParameter("terminal");
        String currencyCode = request.getParameter("currency_code");
        String tradeInfo = request.getParameter("trade_info");
        String lenovoId = SSOUserInfoUtil.getLenovoId(request);
        String memberCode = SSOUserInfoUtil.getLoginname(request);
        LOGGER.info("Https Invoke ToNewCashier, service[" + service + "],signType[" + signType + "],sign[" + sign + "],notifyUrl[" + notifyUrl + "],returnUrl[" + returnUrl + "],inputCharset[" + inputCharset + "],paymentType[" + paymentType + "],shopId[" + shopId + "],terminal[" + terminal + "],tradeInfo[" + tradeInfo + "],lenovoId[" + lenovoId + "]");
        //测试RequestHeader
        String requestShopId = request.getHeader("X-Request-ShopId");
        LOGGER.info("***Get ShopID From Request-->" + requestShopId + "***");
        String plat = CommonMethod.getPlatFromShopIdTerminal(shopId, terminal);
        paraMap.put("plat", plat);
        paraMap.put("shopId", shopId);
        paraMap.put("terminal", terminal);
        paraMap.put("lenovoId", lenovoId);
        paraMap.put("merchantCode", "");
        paraMap.put("isHb", "0");
        if (StringUtils.isEmpty(tradeInfo)) {
            LOGGER.info("TradeInfo IS NULL");
            paraMap.put("resultReason", "订单异常，请重新发起");
            return getFailRedirect(shopId, terminal);
        }
        Map<String, Object> commonParam = PropertiesHelper.loadToMap("common.properties");
        String signKey = "nlzdsb0x50byzdw8975lm6nqadcuxu17";
        Map<String, String> signMap = new HashMap<String, String>();
        signMap.put("service", service);
        signMap.put("notify_url", notifyUrl);
        signMap.put("return_url", returnUrl);
        signMap.put("payment_type", paymentType);
        signMap.put("shop_id", shopId);
        signMap.put("terminal", terminal);
        signMap.put("currency_code", currencyCode);
        signMap.put("input_charset", inputCharset);
        signMap.put("trade_info", tradeInfo);
        if (StringUtils.isEmpty(sign) || StringUtils.isEmpty(signType)) {
            LOGGER.info("Sign Or SignType IS NULL");
            paraMap.put("resultReason", "订单异常，请重新发起");
            return getFailRedirect(shopId, terminal);
        }
        String checkSign = PaySignUtils.checkSign(signMap, signKey);
        if (StringUtils.isEmpty(checkSign) || !checkSign.equals(sign)) {
            LOGGER.info("Check Signature FAIL");
            paraMap.put("resultReason", "非法请求，签名错误");
            return getFailRedirect(shopId, terminal);
        } else {
            LOGGER.info("Check Signature SUCCESS");
        }
        Tenant tenant = CommonMethod.buildTenant(shopId, currencyCode, null, null, null, null, null);
        //解析请求
        List<PayPortalOrder> payPortalOrderList = new ArrayList<PayPortalOrder>();
        List<String> outTradeNoList = new ArrayList<String>();
        // 切分订单信息每条记录存数组
        try {
            tradeInfo = URLDecoder.decode(tradeInfo, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            LOGGER.info("URLDecode TradeInfo Fail", e);
            paraMap.put("resultReason", "订单异常，请重新发起");
            return getFailRedirect(shopId, terminal);
        }
        LOGGER.info("URLDECODER tradeInfo[" + tradeInfo + "]");
        String[] payPortalOrderArray = tradeInfo.split("&\\-&");
        if (payPortalOrderArray.length == 0) {
            LOGGER.info("Analysis PayPortalOrderArray FAIL, PayPortalOrderArray Length[" + payPortalOrderArray.length + "]");
            paraMap.put("resultReason", "订单异常，请重新发起");
            return getFailRedirect(shopId, terminal);
        }
        // 循环处理每条订单信息
        for (String payPortalOrderInfo : payPortalOrderArray) {
            try {
                // 切割每单参数
                String[] payPortalOrderParamArray = payPortalOrderInfo.split("&\\+&");
                if (payPortalOrderParamArray.length == 0) {
                    LOGGER.info("Analysis payPortalOrderParamArray FAIL, payPortalOrderParamArray Length[" + payPortalOrderArray.length + "]");
                    continue;
                }
                Map<String, String> requestParam = new HashMap<String, String>();
                for (String payPortalOrderParam : payPortalOrderParamArray) {
                    if (StringUtils.isNotEmpty(payPortalOrderParam)) {
                        String[] kvs = payPortalOrderParam.split("=");
                        if (kvs != null && kvs.length == 2) {
                            if ("null".equals(kvs[1])) {
                                LOGGER.info("Illegal Value, Key is[" + kvs[0] + "],Value is [" + kvs[1] + "]");
                            } else {
                                LOGGER.info("Key is[" + kvs[0] + "],Value is [" + kvs[1] + "]");
                                requestParam.put(kvs[0], kvs[1]);
                            }
                        } else {
                            LOGGER.info("KVS is NULL Or Kvs Length Illegal");
                        }
                    } else {
                        LOGGER.info("Analysis PayPortalOrderParam IS NULL");
                    }
                }
                PayPortalOrder payPortalOrder = this.buildPayPortalOrderFromRequestParam(requestParam, memberCode, paymentType, shopId, terminal, lenovoId, currencyCode);
                if ("2".equals(requestParam.get("order_type")) && StringUtils.isNotEmpty(requestParam.get("payment"))) {
                    LOGGER.info("Go Presell Final Payment, orderType[" + requestParam.get("order_type") + "],payment[" + requestParam.get("payment") + "], TradeInfo[" + tradeInfo + "]");
                    if ("16".equals(requestParam.get("payment")) && (PeakConstant.TERMINAL_WAP.equals(terminal) || PeakConstant.TERMINAL_APP.equals(terminal))) {
                        LOGGER.info("Go WeChat Browser PrePay");
                        paraMap.put("resultReason", "此平台无微信支付，请到PC端完成尾款支付！");
                        return getFailRedirect(shopId, terminal);
                    } else if ("0".equals(requestParam.get("payment")) || "1".equals(requestParam.get("payment")) || "17".equals(requestParam.get("payment")) || "7".equals(requestParam.get("payment"))) {
                        payPortalOrder.setShowMsg("请您尽快支付尾款！");
                    } else if("16".equals(requestParam.get("payment")) && PeakConstant.TERMINAL_PC.equals(terminal)){
                        payPortalOrder.setShowMsg("请您尽快支付尾款！");
                    }else {
                        LOGGER.info("Go Presell Final Payment Illegal");
                        paraMap.put("resultReason", "订单异常，请重新发起");
                        return getFailRedirect(shopId, terminal);
                    }
                }
                if (payPortalOrder != null) {
                    payPortalOrderList.add(payPortalOrder);
                    outTradeNoList.add(payPortalOrder.getOutTradeNo());
                }
            } catch (Exception e) {
                LOGGER.info("处理单条PayPortalOrder信息异常,PayPortalOrderInfo[" + payPortalOrderInfo + "]", e);
            }
        }
        try {
            if (payPortalOrderList != null && payPortalOrderList.size() > 0) {
                RemoteResult<List<PayPortalOrder>> existPayPortalOrderList = payPortalOrderManager.queryPayPortalOrderListByOutTradeNoList(outTradeNoList, null, tenant);
                List<PayPortalOrder> savePayPortalOrderList = new ArrayList<PayPortalOrder>();
                List<PayPortalOrder> updatePayPortalOrderList = new ArrayList<PayPortalOrder>();
                Map<String, PayPortalOrder> existPayPortalOrderMap = new HashMap<String, PayPortalOrder>();
                if (existPayPortalOrderList.isSuccess()) {
                    LOGGER.info("PayPortalOrder Exist[" + existPayPortalOrderList + "]");
                    for (PayPortalOrder existPayPortalOrder : existPayPortalOrderList.getT()) {
                        if (StringUtils.isNotEmpty(lenovoId) && !lenovoId.equals(existPayPortalOrder.getLenovoId())) {
                            LOGGER.info("Illegal Request LenovoID NOT METCH");
                            paraMap.put("resultReason", "非法请求！");
                            return getFailRedirect(shopId, terminal);
                        }
                        existPayPortalOrderMap.put(existPayPortalOrder.getOutTradeNo(), existPayPortalOrder);
                        if (PeakConstant.ORDER_STATUS_INVALID.equals(String.valueOf(existPayPortalOrder.getOrderStatus()))) {
                            LOGGER.info("Illegal Status,PayPortalOrder[" + existPayPortalOrder + "],OrderStatus[" + existPayPortalOrder.getOrderStatus() + "]");
                            paraMap.put("resultReason", "订单状态异常，请重新发起！");
                            return getFailRedirect(shopId, terminal);
                        }
                        if (PeakConstant.PAY_STATUS_ALREADY_PAID.equals(String.valueOf(existPayPortalOrder.getPayStatus()))) {
                            LOGGER.info("Illegal Status,PayPortalOrder[" + existPayPortalOrder + "],PayStatus[" + existPayPortalOrder.getPayStatus() + "]");
                            paraMap.put("resultReason", "订单已支付，请到订单列表查看详情！");
                            return getFailRedirect(shopId, terminal);
                        }
                    }
                } else {
                    LOGGER.info("PayPortalOrder Not Exist");
                }
                for (PayPortalOrder payPortalOrder : payPortalOrderList) {
//                    this.buildOrderInvalidTime(payPortalOrder, commonParam);
                    this.buildPayPortalOrderFaName(payPortalOrder, commonParam);
                    if (existPayPortalOrderMap.containsKey(payPortalOrder.getOutTradeNo())) {
                        payPortalOrder.setId(existPayPortalOrderMap.get(payPortalOrder.getOutTradeNo()).getId());
                        updatePayPortalOrderList.add(payPortalOrder);
                        this.buildOrderInvalidTime(payPortalOrder, commonParam,existPayPortalOrderMap.get(payPortalOrder.getOutTradeNo()).getCreateTime());
                    } else {
                        savePayPortalOrderList.add(payPortalOrder);
                        this.buildOrderInvalidTime(payPortalOrder, commonParam,null);
                    }
                }
                if (savePayPortalOrderList.size() == 0 && updatePayPortalOrderList.size() == 0) {
                    LOGGER.info("SavePayPortalOrderList And UpdatePayPortalOrderList ARE BOTH NULL");
                    paraMap.put("resultReason", "订单异常，请重新发起");
                    return getFailRedirect(shopId, terminal);
                }
                RemoteResult<Boolean> saveUpdatePayPortalOrderRemoteResult = payPortalOrderManager.saveOrUpdatePayPortalOrderList(savePayPortalOrderList, updatePayPortalOrderList);
                if (saveUpdatePayPortalOrderRemoteResult.isSuccess()) {
                    LOGGER.info("SaveOrUpdate payPortalOrderList SUCCESS");
                } else {
                    LOGGER.info("SaveOrUpdate payPortalOrderList FAIL");
                    paraMap.put("resultReason", "订单异常，请重新发起");
                    return getFailRedirect(shopId, terminal);
                }
            } else {
                LOGGER.info("Build SaveOrUpate PayPortalOrderList FAIL, PayPortalOrderList IS NULL");
                paraMap.put("resultReason", "订单异常，请重新发起");
                return getFailRedirect(shopId, terminal);
            }
        } catch (Exception saveOrUpdateException) {
            LOGGER.info("Save Or Update PayPortalOrder Excepion", saveOrUpdateException);
            paraMap.put("resultReason", "订单异常，请重新发起");
            return getFailRedirect(shopId, terminal);
        }
        paraMap.put("payPortalOrderList", payPortalOrderList);
        if (payPortalOrderList.size() > 1) {
            paraMap.put("isHb", "1");
        }
        if (StringUtils.isNotEmpty(paymentType) && "2".equals(paymentType)) {
            try {
                LOGGER.info("Invoke Get Offline PayInfo");
                RemoteResult<MerchantPayPlatView> merchantPayPlatViewRemoteResult = commonPayManager.getMerchantPayPlat(payPortalOrderList.get(0).getFaId(), PeakConstant.PAY_TYPE_SMB_OFFLINE);
                if (merchantPayPlatViewRemoteResult.isSuccess()) {
                    LOGGER.info("Get Offline PayInfo SUCCESS");
                    paraMap.put("bankDept", merchantPayPlatViewRemoteResult.getT().getAppId());
                    paraMap.put("bankAcct", merchantPayPlatViewRemoteResult.getT().getMechId());
                } else {
                    LOGGER.info("Get Offline PayInfo FAIL");
                    paraMap.put("bankDept", "联想(北京)有限公司 招商银行北京大屯路支行");
                    paraMap.put("bankAcct", "866180558810001800800");
                }
            } catch (Exception offLineException) {
                LOGGER.info("Get Offline PayInfo EXCEPTION", offLineException);
                paraMap.put("bankDept", "联想(北京)有限公司 招商银行北京大屯路支行");
                paraMap.put("bankAcct", "866180558810001800800");
            }
        }
        return getCashierRedirect(shopId, terminal, paymentType);
    }catch(Exception testException){

            LOGGER.info("Cashier Exception", testException);
            return "403";
        }
    }

    private void buildPayPortalOrderFaName(PayPortalOrder payPortalOrder, Map<String, Object> commonParam) {
        if (commonParam != null) {
            String faName = "SMB商城总代商品";
            LOGGER.info("FAID[" + payPortalOrder.getFaId() + "],FANAME[" + faName + "]");
            if (StringUtils.isNotEmpty(faName) && !("null".equals(faName))) {
                payPortalOrder.setFaName( faName );
            }
        }
    }

    private PayPortalOrder buildPayPortalOrderFromRequestParam(Map<String, String> requestParam, String memberCode, String paymentType, String shopId, String terminal, String lenovoId, String currencyCode) {
        try {
            if (requestParam == null || requestParam.size() == 0) {
                LOGGER.info("Build PayPortalOrder From RequestParam FAIL, RequestParam IS NULL");
                return null;
            }
            PayPortalOrder payPortalOrder = new PayPortalOrder();
            payPortalOrder.setOutTradeNo(requestParam.get("out_trade_no"));
            payPortalOrder.setShowTradeNo(requestParam.get("show_trade_no"));
            payPortalOrder.setFaId(requestParam.get("fa_id"));
            payPortalOrder.setMemberCode(memberCode);
            StringBuffer receiverInfo = new StringBuffer();
            String receiveBuyer = requestParam.get("receive_buyer");
            if (StringUtils.isNotEmpty(receiveBuyer)) {
                receiverInfo.append(receiveBuyer + " ");
            }
            String receivePhone = requestParam.get("receive_phone");
            if (StringUtils.isNotEmpty(receivePhone)) {
                receivePhone = receivePhone.substring(0, 3) + "****" + receivePhone.substring(7);
                receiverInfo.append(receivePhone + " ");
            }
            String receiveAddress = requestParam.get("receive_address");
            if (StringUtils.isNotEmpty(receiveAddress)) {
                receiverInfo.append(receiveAddress);
            }
            if (StringUtils.isNotEmpty(receiverInfo.toString())) {
                payPortalOrder.setDeliveryInfo(receiverInfo.toString());
            }
            payPortalOrder.setTaxType(requestParam.get("tax_type"));
            payPortalOrder.setTaxInfo(requestParam.get("tax_info"));
            StringBuffer taxReceiverInfo = new StringBuffer();
            String taxReceiveBuyer = requestParam.get("tax_receive_buyer");
            if (StringUtils.isNotEmpty(taxReceiveBuyer)) {
                taxReceiverInfo.append(taxReceiveBuyer + " ");
            }
            String taxReceivePhone = requestParam.get("tax_receive_phone");
            if (StringUtils.isNotEmpty(taxReceivePhone)) {
                taxReceivePhone = taxReceivePhone.substring(0, 3) + "****" + taxReceivePhone.substring(7);
                taxReceiverInfo.append(taxReceivePhone + " ");
            }
            String taxReceiveAddress = requestParam.get("tax_receive_address");
            if (StringUtils.isNotEmpty(taxReceiveAddress)) {
                taxReceiverInfo.append(taxReceiveAddress);
            }
            if (StringUtils.isNotEmpty(taxReceiverInfo.toString())) {
                payPortalOrder.setTaxDeliveryInfo(taxReceiverInfo.toString());
            }
            if(StringUtils.isEmpty(requestParam.get("subject"))|| "null".equals(requestParam.get("subject"))||requestParam.get("subject").length() > 80){
                payPortalOrder.setSubject("LenovoProduct");
            }else{
                payPortalOrder.setSubject(requestParam.get("subject"));
            }
            payPortalOrder.setBody(requestParam.get("body"));
            payPortalOrder.setPaymentWay(requestParam.get("payment_way"));
            if (StringUtils.isNotEmpty(requestParam.get("payment"))) {
                LOGGER.info("Build PayPortalOrder From RequestParam, payment[" + requestParam.get("payment") + "]");
                payPortalOrder.setPayment(Integer.parseInt(requestParam.get("payment")));
            } else {
                payPortalOrder.setPayment(100);
            }
            payPortalOrder.setOrderType(requestParam.get("order_type"));
            if (StringUtils.isEmpty(requestParam.get("reward_ledou")) || "null".equals(requestParam.get("reward_ledou"))) {
                payPortalOrder.setRewardLedou("0");
            } else {
                payPortalOrder.setRewardLedou(requestParam.get("reward_ledou"));
            }
            if(StringUtils.isEmpty(currencyCode)){
                currencyCode = "CNY";
            }
            payPortalOrder.setCurrencyCode(currencyCode);
            Money totalFeeMoney = new Money(requestParam.get("total_fee"), currencyCode);
            payPortalOrder.setTotalFee(totalFeeMoney);
            payPortalOrder.setItBPay(requestParam.get("it_b_pay"));
            payPortalOrder.setExtendParam(requestParam.get("extend_param"));
            if (StringUtils.isNotEmpty(paymentType)) {
                payPortalOrder.setPaymentTypeId(Integer.parseInt(paymentType));
            } else {
                payPortalOrder.setPaymentTypeId(0);
            }
            payPortalOrder.setShopId(shopId);
            payPortalOrder.setTerminal(terminal);
            Money refundMoney = new Money("0", currencyCode);
            payPortalOrder.setRefundMoney(refundMoney);
            payPortalOrder.setOrderStatus(0);
            payPortalOrder.setPayStatus(0);
            payPortalOrder.setLenovoId(lenovoId);
            payPortalOrder.setOrderTime(new Date());
//            payPortalOrder.setOrderTime(new Date());  // should be order time
            payPortalOrder.setCreateTime(new Date());
            LOGGER.info("buildPayPortalOrderFromRequestParam PayPortalOrder[" + payPortalOrder + "]");
            return payPortalOrder;
        } catch (Exception e) {
            LOGGER.info("Build PayPortalOrder From RequestParam Exception", e);
            return null;
        }
    }


    private void buildOrderInvalidTime(PayPortalOrder payPortalOrder, Map<String, Object> commonParam, Date createTime) {
        Date expirationTime =  null;
        if (null == createTime){
            expirationTime = payPortalOrder.getCreateTime();
        }else {
            expirationTime = createTime;
        }
        if (expirationTime == null) {
            expirationTime = new Date();
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(expirationTime);
        try {
            if (commonParam == null) {
                LOGGER.info("Invoke buildOrderInvalidTime commonParam Is NULL");
                if (PeakConstant.SHOPID_SMB.equals(payPortalOrder.getShopId())) {
                    calendar.add(Calendar.DATE, 15);
                    payPortalOrder.setExpirationHour("15天");
                } else {
                    calendar.add(Calendar.HOUR, 24);
                    payPortalOrder.setExpirationHour("24小时");
                }
                payPortalOrder.setExpirationTime(DateUtil.formatDate(calendar.getTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
            } else {
                String queryStr = "ORDER_INVALID_TIME_" + payPortalOrder.getShopId() + "_" + payPortalOrder.getOrderType();
                String invalidTimeStr = (String) commonParam.get(queryStr);
                LOGGER.info("Invoke buildOrderInvalidTime Query[" + queryStr + "],invalidTime[" + invalidTimeStr + "]");
                if (StringUtils.isNotEmpty(invalidTimeStr) && !("null".equals(invalidTimeStr))) {
                    int invalidTimeInt = Integer.parseInt(invalidTimeStr);
                    calendar.add(Calendar.MINUTE, invalidTimeInt);
                    payPortalOrder.setExpirationTime(DateUtil.formatDate(calendar.getTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
                    if (invalidTimeInt > 1440) {
                        invalidTimeInt = invalidTimeInt / 1440;
                        payPortalOrder.setExpirationHour(invalidTimeInt + "天");
                    } else if (invalidTimeInt <= 60) {
                        payPortalOrder.setExpirationHour(invalidTimeInt + "分钟");
                    } else {
                        invalidTimeInt = invalidTimeInt / 60;
                        payPortalOrder.setExpirationHour(invalidTimeInt + "小时");
                    }
                } else {
                    LOGGER.info("Invoke buildOrderInvalidTime invalidTimeStr Is NULL");
                    if (PeakConstant.SHOPID_SMB.equals(payPortalOrder.getShopId())) {
                        calendar.add(Calendar.DATE, 15);
                        payPortalOrder.setExpirationHour("15天");
                    } else {
                        calendar.add(Calendar.HOUR, 24);
                        payPortalOrder.setExpirationHour("24小时");
                    }
                    payPortalOrder.setExpirationTime(DateUtil.formatDate(calendar.getTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
                }
            }
        } catch (Exception e) {
            if (PeakConstant.SHOPID_SMB.equals(payPortalOrder.getShopId())) {
                calendar.add(Calendar.DATE, 15);
                payPortalOrder.setExpirationHour("15天");
            } else {
                calendar.add(Calendar.HOUR, 24);
                payPortalOrder.setExpirationHour("24小时");
            }
            payPortalOrder.setExpirationTime(DateUtil.formatDate(calendar.getTime(), PeakConstant.CHANNEL_ORDER_DATE_FORMAT));
        }
    }

    /**
     * 基于SHOPID Terminal 跳转失败页
     *
     * @param shopId   shopId
     * @param terminal terminal
     * @return String
     */
    private String getFailRedirect(String shopId, String terminal) {
        String url = null;
        if (PeakConstant.SHOPID_LENOVO.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                url = "syncback/b2c_pc_fail";
            } else {
                url = "syncback/b2c_wap_error";
            }
        } else if (PeakConstant.SHOPID_THINK.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                url = "syncback/tk_pc_fail";
            } else {
                url = "syncback/tk_wap_error";
            }
        } else if (PeakConstant.SHOPID_EPP.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                url = "syncback/epp_pc_fail";
            } else {
                url = "syncback/epp_wap_error";
            }
        } else if (PeakConstant.SHOPID_DONGDE.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                url = "syncback/dongde_pc_fail";
            } else {
                url = "syncback/dongde_wap_error";
            }
        } else if (PeakConstant.SHOPID_THINKCENTER.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                url = "syncback/thinkcenter_pc_fail";
            } else {
                url = "syncback/thinkcenter_wap_error";
            }
        } else if (PeakConstant.SHOPID_SMB.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                url = "syncback/smb_pc_fail";
            } else {
                url = "syncback/b2c_wap_error";
            }
        }
        return url;
    }

    /**
     * Go Cashier
     */
    private String getCashierRedirect(String shopId, String terminal, String paymentType) {
        LOGGER.info(" getCashierRedirect  terminal---"+terminal+"shopId---"+shopId+"paymentType"+paymentType);
        String url = null;
        if (PeakConstant.SHOPID_LENOVO.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                LOGGER.info("terminal---"+terminal);
                url = "pay/b2c_pc";
            } else {
                url = "pay/b2c_wap";
            }
        } else if (PeakConstant.SHOPID_THINK.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                url = "pay/tk_pc";
            } else {
                url = "pay/tk_wap";
            }
        } else if (PeakConstant.SHOPID_EPP.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                url = "pay/epp_pc";
            } else {
                url = "pay/epp_wap";
            }
        } else if (PeakConstant.SHOPID_DONGDE.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                url = "pay/dongde_pc";
            } else {
                url = "pay/dongde_wap";
            }
        } else if (PeakConstant.SHOPID_THINKCENTER.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                url = "pay/thinkcenter_pc";
            } else {
                url = "pay/thinkcenter_wap";
            }
        } else if (PeakConstant.SHOPID_SMB.equals(shopId)) {
            if (StringUtils.isNotEmpty(paymentType) && "2".equals(paymentType)) {
                url = "pay/offline_pc";
            } else {
                url = "pay/smb_pc";
            }
        }
        return url;
    }


    /**
     * Ajax获取订单明细及订单支持支付类型
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/getOrderSupportPayType", produces = "text/html;charset=UTF-8")
    @ResponseBody
    public String getNewOrderSupportPayType(HttpServletRequest request, HttpServletResponse response) {
        String outTradeNo = request.getParameter("orderMainCode");
        String lenovoId = SSOUserInfoUtil.getLenovoId(request);
        String shopId = request.getParameter("shopId");
        String terminal = request.getParameter("terminal");
        if (StringUtils.isEmpty(lenovoId)) {
            LOGGER.info("SSO Get LenovoID IS NULL，outTradeNo :" + outTradeNo);
            return JacksonUtil.toJson(new BaseInfo(400, "非法请求"));
        }
        LOGGER.info("Https getOrderSupportPayType Ready To GO! out_trade_no[" + outTradeNo + "],lenovo_id[" + lenovoId + "],shop_id[" + shopId + "],terminal[" + terminal + "]");
        List<String> outTradeNoList = new ArrayList<String>();
        outTradeNoList.add(outTradeNo);
        RemoteResult<PayPortalOrder> payPortalOrderRemoteResult;
        PayPortalOrder payPortalOrder;
        MongoOrderJson mongoOrderJson = new MongoOrderJson();
        try {
            Tenant tenant = CommonMethod.buildTenant(shopId, null, null, null, null, null, null);
            payPortalOrderRemoteResult = payPortalOrderManager.queryPayPortalOrderByOutTradeNo(outTradeNo, lenovoId, tenant);
            if (payPortalOrderRemoteResult.isSuccess()) {
                payPortalOrder = payPortalOrderRemoteResult.getT();
                mongoOrderJson.setPayPortalOrder(payPortalOrder);
            } else {
                LOGGER.info("查询订单支持支付类型，获取PayPortalOrder失败，out_trade_no[" + outTradeNo + "]");
                return JacksonUtil.toJson(new BaseInfo(400, "未查到支付订单"));
            }
        } catch (Exception e) {
            LOGGER.error("查询订单支持支付类型失败" + e);
            return JacksonUtil.toJson(new BaseInfo(400, "查询订单失败"));
        }
        String faid = null;
        if ("1".equals(payPortalOrder.getPaymentWay())) {
            faid = commonManager.getLedgerFAID(payPortalOrder);
        } else {
            faid = payPortalOrder.getFaId();
        }
        Money amountMoneyDec = payPortalOrder.getTotalFee();
        LOGGER.info("out_trade_no[" + outTradeNo + "total_fee[" + amountMoneyDec + "]");
        RemoteResult<List<OrderSupportPayType>> orderSupportPayTypeResult = new RemoteResult<List<OrderSupportPayType>>();
        try {
            int payment = payPortalOrder.getPayment();
            String orderType = payPortalOrder.getOrderType();
            LOGGER.info("Get OrderSupportPayTypeList START, payment[" + payment + "],orderType[" + orderType + "]");
            if ("2".equals(orderType) && payment != 100) {
                orderSupportPayTypeResult = cashierManager.getOrderSupportPayTypeListByFaIDPayment(faid, payment);
            } else {
                orderSupportPayTypeResult = cashierManager.getOrderSupportPayTypeList(faid);
            }
            LOGGER.info("Get OrderSupportPayTypeList END, Result[" + orderSupportPayTypeResult + "]");
        } catch (Exception e) {
            LOGGER.error("Ajax查询订单支持支付类型失败" + e);
            return JacksonUtil.toJson(new BaseInfo(400, "查询订单支持支付类型失败"));
        }
        if (orderSupportPayTypeResult.isSuccess()) {
            mongoOrderJson.setRc(0);
            mongoOrderJson.setMsg("Get Pay Rules SUCCESS");
            Map<String, Object> paraMap = new HashMap<String, Object>();
            List<String> showOrderNoList = new ArrayList<String>();
            showOrderNoList.add(payPortalOrder.getShowTradeNo());
            paraMap.put("orderIds", showOrderNoList);
            paraMap.put("lenovoId", payPortalOrder.getLenovoId());
            paraMap.put("shopId", payPortalOrder.getShopId());
            paraMap.put("faId", payPortalOrder.getFaId());
            RemoteResult<Map<String, Object>> rulsMapRemoteResult = new RemoteResult<Map<String, Object>>();
            List<OrderSupportPayType> orderSupportPayTypeList = new ArrayList<OrderSupportPayType>();
            for (OrderSupportPayType orderSupportPayType : orderSupportPayTypeResult.getT()) {
                if (PeakConstant.PAY_TYPE_WECHAT.equals(orderSupportPayType.getPayType())){
                    if(shopId.equals(orderSupportPayType.getShop_id())){
                        orderSupportPayTypeList.add(orderSupportPayType);
                    }else{
                        LOGGER.info("移除非此平台微信NATIVE支付");
                    }
                }else if (PeakConstant.PAY_TYPE_WECHAT_APP.equals(orderSupportPayType.getPayType())){
                    if(shopId.equals(orderSupportPayType.getShop_id())){
                        orderSupportPayTypeList.add(orderSupportPayType);
                    }else{
                        LOGGER.info("移除非此平台微信app支付");
                    }
                }else if (PeakConstant.PAY_TYPE_WECHAT_JSAPI.equals(orderSupportPayType.getPayType())){
                    if(shopId.equals(orderSupportPayType.getShop_id())){
                        orderSupportPayTypeList.add(orderSupportPayType);
                    }else{
                        LOGGER.info("移除非此平台微信JSAPI支付");
                    }
                }else if (PeakConstant.PAY_TYPE_WECHAT_H5.equals(orderSupportPayType.getPayType())){
                    if(shopId.equals(orderSupportPayType.getShop_id())){
                        orderSupportPayTypeList.add(orderSupportPayType);
                    }else{
                        LOGGER.info("移除非此平台微信H5支付");
                    }
                }else {
                    orderSupportPayTypeList.add(orderSupportPayType);
                }
            }
            mongoOrderJson.setOrderSupportPayTypeList(orderSupportPayTypeList);
        } else {
            LOGGER.info("Ajax未查到订单支持支付类型，orderCode：" + outTradeNo);
            return JacksonUtil.toJson(new BaseInfo(400, "查询订单支持支付类型失败"));
        }
        LOGGER.info("Ajax查询订单返回结果：" + JacksonUtil.toJson(mongoOrderJson));
        return JacksonUtil.toJson(mongoOrderJson);
    }


    public CashierManager getCashierManager() {
        return cashierManager;
    }

    public void setCashierManager(CashierManager cashierManager) {
        this.cashierManager = cashierManager;
    }

    public PayPortalOrderManager getPayPortalOrderManager() {
        return payPortalOrderManager;
    }

    public void setPayPortalOrderManager(PayPortalOrderManager payPortalOrderManager) {
        this.payPortalOrderManager = payPortalOrderManager;
    }

    public CommonManager getCommonManager() {
        return commonManager;
    }

    public void setCommonManager(CommonManager commonManager) {
        this.commonManager = commonManager;
    }

    public CommonPayManager getCommonPayManager() {
        return commonPayManager;
    }

    public void setCommonPayManager(CommonPayManager commonPayManager) {
        this.commonPayManager = commonPayManager;
    }

}
