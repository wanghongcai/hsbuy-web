package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * 联动优势WAP一键快捷支付证码请求模型
 * Created by tianchuyang on 2016/11/22.
 */
public class UmpayCaptchaReqModel extends BaseModel implements Serializable {

    private static final long serialVersionUID = 5051702155222926348L;

    private String service;
    private String mer_id;
    private String sign_type;
    private String sign;
    private String version;
    // 业务参数
    private String trade_no;
    private String mer_cust_id;
    private String usr_busi_agreement_id;
    private String usr_pay_agreement_id;

    public UmpayCaptchaReqModel() {
    }

    public UmpayCaptchaReqModel(HttpServletRequest request) {
        super(request);
        this.service = request.getParameter("service");
        this.mer_id = request.getParameter("mer_id");
        this.sign_type = request.getParameter("sign_type");
        this.sign = request.getParameter("sign");
        this.version = request.getParameter("version");
        this.trade_no = request.getParameter("trade_no");
        this.mer_cust_id = request.getParameter("mer_cust_id");
        this.usr_busi_agreement_id = request.getParameter("usr_busi_agreement_id");
        this.usr_pay_agreement_id = request.getParameter("usr_pay_agreement_id");
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getMer_id() {
        return mer_id;
    }

    public void setMer_id(String mer_id) {
        this.mer_id = mer_id;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getTrade_no() {
        return trade_no;
    }

    public void setTrade_no(String trade_no) {
        this.trade_no = trade_no;
    }

    public String getMer_cust_id() {
        return mer_cust_id;
    }

    public void setMer_cust_id(String mer_cust_id) {
        this.mer_cust_id = mer_cust_id;
    }

    public String getUsr_busi_agreement_id() {
        return usr_busi_agreement_id;
    }

    public void setUsr_busi_agreement_id(String usr_busi_agreement_id) {
        this.usr_busi_agreement_id = usr_busi_agreement_id;
    }

    public String getUsr_pay_agreement_id() {
        return usr_pay_agreement_id;
    }

    public void setUsr_pay_agreement_id(String usr_pay_agreement_id) {
        this.usr_pay_agreement_id = usr_pay_agreement_id;
    }
}
