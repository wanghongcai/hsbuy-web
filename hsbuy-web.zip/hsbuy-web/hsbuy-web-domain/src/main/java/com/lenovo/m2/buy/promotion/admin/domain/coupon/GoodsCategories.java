package com.lenovo.m2.buy.promotion.admin.domain.coupon;

/**
 * Created by zhaocl1 on 2015/8/21.
 */
public class GoodsCategories {

    private String id;
    private String categorycode;
    private String categoryname;
    private Integer disabled;
    private String parentid;
    private Integer isDisplayOnMobile;
    private Integer isDisplayOnFrontSite;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategorycode() {
        return categorycode;
    }

    public void setCategorycode(String categorycode) {
        this.categorycode = categorycode;
    }

    public String getCategoryname() {
        return categoryname;
    }

    public void setCategoryname(String categoryname) {
        this.categoryname = categoryname;
    }

    public Integer getDisabled() {
        return disabled;
    }

    public void setDisabled(Integer disabled) {
        this.disabled = disabled;
    }

    public String getParentid() {
        return parentid;
    }

    public void setParentid(String parentid) {
        this.parentid = parentid;
    }


    public Integer getIsDisplayOnMobile() {
        return isDisplayOnMobile;
    }

    public void setIsDisplayOnMobile(Integer isDisplayOnMobile) {
        this.isDisplayOnMobile = isDisplayOnMobile;
    }

    public Integer getIsDisplayOnFrontSite() {
        return isDisplayOnFrontSite;
    }

    public void setIsDisplayOnFrontSite(Integer isDisplayOnFrontSite) {
        this.isDisplayOnFrontSite = isDisplayOnFrontSite;
    }


    @Override
    public String toString() {
        return "GoodsCategories{" +
                "id='" + id + '\'' +
                ", categorycode='" + categorycode + '\'' +
                ", categoryname='" + categoryname + '\'' +
                ", disabled=" + disabled +
                ", parentid='" + parentid + '\'' +
                ", isDisplayOnMobile=" + isDisplayOnMobile +
                ", isDisplayOnFrontSite=" + isDisplayOnFrontSite +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        GoodsCategories that = (GoodsCategories) o;

        if (!categorycode.equals(that.categorycode)) return false;
        if (!categoryname.equals(that.categoryname)) return false;
        if (!disabled.equals(that.disabled)) return false;
        if (!id.equals(that.id)) return false;
        if (!isDisplayOnFrontSite.equals(that.isDisplayOnFrontSite)) return false;
        if (!isDisplayOnMobile.equals(that.isDisplayOnMobile)) return false;
        if (!parentid.equals(that.parentid)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id.hashCode();
        result = 31 * result + categorycode.hashCode();
        result = 31 * result + categoryname.hashCode();
        result = 31 * result + disabled.hashCode();
        result = 31 * result + parentid.hashCode();
        result = 31 * result + isDisplayOnMobile.hashCode();
        result = 31 * result + isDisplayOnFrontSite.hashCode();
        return result;
    }
}
