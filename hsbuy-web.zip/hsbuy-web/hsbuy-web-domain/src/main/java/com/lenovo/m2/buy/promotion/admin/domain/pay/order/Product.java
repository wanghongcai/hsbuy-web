package com.lenovo.m2.buy.promotion.admin.domain.pay.order;

/**
 *
 * @author kangjie
 *
 */
public class Product{ // 产品表
	private String productCode;// 商品编号
	private String productID = "";// 产品ID
	private String productName;// 商品名称
	private String productNumber;// 商品数量
	private String volumePay = "0";// 优惠券金额
	private String productPay = "0";// 商品单价
	private String favourablePay = "0";// 折扣总金额
	private String paySubtotal = "0";// 商品价钱小计
	private String discountRate = "0";// 折扣比例
	private String productCredit = "0";// 商品积分 暂时不用，固定传0
	private String groupingID;//购物车一行（主件/选件/赠品）生产同一字符串标识
	private String isGift;//0主件1选件2赠品
	private String productPhoto;//商品图片
	private String productDesc;//商品描述
	private String specification;//商品规格
	private String stockstatus;//库存状态名称
	
	//物料信息
	private String goodsMaterialID = "";//物料id
	private String lenovoProductCode = "";//联想物料编码
	private String unit = "";//单位
	private String deatLike = "";//产品组
	private String factoryCode = "";//交货工厂
	private String warehouseCode = "";//库存地
	private String storageCode = "";//仓库
	private String salesChannel;
	private String faid;
	private String faname;
	private String fatype;
	private String voucherTotalAmount;//代金券总金额
	private String note;//大礼包金额对应的code，代金券id,多个使用逗号隔开，
	
	
	
	public String getVoucherTotalAmount() {
		return voucherTotalAmount;
	}
	public void setVoucherTotalAmount(String voucherTotalAmount) {
		this.voucherTotalAmount = voucherTotalAmount;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	//产品表信息
	private String salesType;
	


	/**
	 * 二期新增
	 */
	// 区分实物非实物 0 非实物；1 实物
	private int isPhysical;

    // 是否服务 1 服务产品;2 非服务产品
    private int isServiceProd;

    // 购买服务时，绑定的SN号。
    private String machineSN;
    
    private String lsProductCode;
    
    public String getLsProductCode() {
		return lsProductCode;
	}
	public void setLsProductCode(String lsProductCode) {
		this.lsProductCode = lsProductCode;
	}
	/**
     * think 新增
     * @return
     */
    private String thinkRemark="";
    
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductID() {
		return productID;
	}
	public void setProductID(String productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductNumber() {
		return productNumber;
	}
	public void setProductNumber(String productNumber) {
		this.productNumber = productNumber;
	}
	public String getProductPay() {
		return productPay;
	}
	public void setProductPay(String productPay) {
		this.productPay = productPay;
	}
	public String getFavourablePay() {
		return favourablePay;
	}
	public void setFavourablePay(String favourablePay) {
		this.favourablePay = favourablePay;
	}
	public String getPaySubtotal() {
		return paySubtotal;
	}
	public void setPaySubtotal(String paySubtotal) {
		this.paySubtotal = paySubtotal;
	}
	public String getDiscountRate() {
		return discountRate;
	}
	public void setDiscountRate(String discountRate) {
		this.discountRate = discountRate;
	}
	public String getProductCredit() {
		return productCredit;
	}
	public void setProductCredit(String productCredit) {
		this.productCredit = productCredit;
	}
	public String getGroupingID() {
		return groupingID;
	}
	public void setGroupingID(String groupingID) {
		this.groupingID = groupingID;
	}
	public String getIsGift() {
		return isGift;
	}
	public void setIsGift(String isGift) {
		this.isGift = isGift;
	}
	public String getProductPhoto() {
		return productPhoto;
	}
	public void setProductPhoto(String productPhoto) {
		this.productPhoto = productPhoto;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	
	public String getVolumePay() {
		return volumePay;
	}
	public void setVolumePay(String volumePay) {
		this.volumePay = volumePay;
	}
	public String getSpecification() {
		return specification;
	}
	public void setSpecification(String specification) {
		this.specification = specification;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getFaname() {
		return faname;
	}
	public void setFaname(String faname) {
		this.faname = faname;
	}
	public String getFatype() {
		return fatype;
	}
	public void setFatype(String fatype) {
		this.fatype = fatype;
	}
	public String getStockstatus() {
		return stockstatus;
	}
	public void setStockstatus(String stockstatus) {
		this.stockstatus = stockstatus;
	}
	public String getGoodsMaterialID() {
		return goodsMaterialID;
	}
	public void setGoodsMaterialID(String goodsMaterialID) {
		this.goodsMaterialID = goodsMaterialID;
	}
	public String getLenovoProductCode() {
		return lenovoProductCode;
	}
	public void setLenovoProductCode(String lenovoProductCode) {
		this.lenovoProductCode = lenovoProductCode;
	}
	public String getDeatLike() {
		return deatLike;
	}
	public void setDeatLike(String deatLike) {
		this.deatLike = deatLike;
	}
	
	public String getFactoryCode() {
		return factoryCode;
	}
	public void setFactoryCode(String factoryCode) {
		this.factoryCode = factoryCode;
	}
	public String getWarehouseCode() {
		return warehouseCode;
	}
	public void setWarehouseCode(String warehouseCode) {
		this.warehouseCode = warehouseCode;
	}
	public String getStorageCode() {
		return storageCode;
	}
	public void setStorageCode(String storageCode) {
		this.storageCode = storageCode;
	}
	public String getSalesChannel() {
		return salesChannel;
	}
	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}
	public String getFaid() {
		return faid;
	}
	public void setFaid(String faid) {
		this.faid = faid;
	}
	public String getSalesType() {
		return salesType;
	}
	public void setSalesType(String salesType) {
		this.salesType = salesType;
	}
	public int getIsPhysical() {
		return isPhysical;
	}
	public void setIsPhysical(int isPhysical) {
		this.isPhysical = isPhysical;
	}
	public int getIsServiceProd() {
		return isServiceProd;
	}
	public void setIsServiceProd(int isServiceProd) {
		this.isServiceProd = isServiceProd;
	}
	public String getMachineSN() {
		return machineSN;
	}
	public void setMachineSN(String machineSN) {
		this.machineSN = machineSN;
	}
	public String getThinkRemark() {
		return thinkRemark;
	}
	public void setThinkRemark(String thinkRemark) {
		this.thinkRemark = thinkRemark;
	}
	
}