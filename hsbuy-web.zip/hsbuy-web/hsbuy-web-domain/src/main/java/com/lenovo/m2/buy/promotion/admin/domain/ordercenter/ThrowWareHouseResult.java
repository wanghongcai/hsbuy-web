package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;


import com.lenovo.m2.hsbuy.domain.order.mongo.MongoOrderDetail;

import java.util.List;

/**
 * 待抛单列表
 *
 * @Author licy13
 * @Date 2017/3/2
 */

public class ThrowWareHouseResult extends BaseResult {

    private MongoOrderDetail order;

    private List<ItemOfShotInfo> itemOfShotInfo;

    public MongoOrderDetail getOrder() {
        return order;
    }

    public void setOrder(MongoOrderDetail order) {
        this.order = order;
    }

    public List<ItemOfShotInfo> getItemOfShotInfo() {
        return itemOfShotInfo;
    }

    public void setItemOfShotInfo(List<ItemOfShotInfo> itemOfShotInfo) {
        this.itemOfShotInfo = itemOfShotInfo;
    }
}
