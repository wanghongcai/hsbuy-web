package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

/**
 * Created by Administrator on 2016/11/10.
 */
public class CMBFQReq {

    public String mchMchNbr;		/**商户号			 (merchantCode)			商户号（6位数字），商户开通分期支付业务时由银行分配                                                                                     */
    public String mchBllNbr;		/**商户订单号  		 (out_trade_no)			商户定单号（6位或10位数字），由商户产生，商户应确保$MchBllDat$ + $MchBllNbr$永不重复。                                                  */
    public String mchBllDat;		/**商户订单时间		 (order_time)			商户定单日期（格式YYYYMMDD），由商户产生，商户应确保$MchBllDat$ + $MchBllNbr$永不重复。                                                 */
    public String mchBllTim;		/**商户订单日期		 (order_time)			商户定单时间（格式HHMMSS），由商户产生。保留。                                                                                          */
    public String trxTrxCcy;		/**币种				 (curType)				币(固定为156)                                                                                                                           */
    public String trxBllAmt;		/**定单总金额		     (total_fee)			定单总金额                                                                                                                              */
    public String trxPedCnt;		/**分期数			 (fqNo)					分期数                                                                                                                                  */
    public String uiHidePed;		/**					 (uiHidePed)		   	付款页面是否隐藏分期相关文字。该字段为Y且分期数$TrxPedCnt$为1时才隐藏分期相关文字，否则不隐藏。			                                */
    public String mchUsrIdn;		/**商户用户识别号	     (lenovo_id)			商户用户识别号，长度在40个字节以内（1个汉字占2个字节）。                                                                                */
    public String mchNtfUrl;		/**商户提供的通知地址  (informUrl)			商户提供的通知URL。 支付完后银行将支付结果信息发送到该URL                                                                               */
    public String mchNtfPam;		/**商户提供的通知参数  (informPar)			商户提供的通知参数。支付完银行通知商户时将该参数原封不动的传递给商户提供的通知URL                                                       */
    public String mchRetUrl;		/**商户提供的返回地址  (returnUrl)			商户提供的返回地址：支付完成后，支付成功页面会通过该地址返回商户网站。如果商户未提供返回地址，则使用商户通知地址和通知参数返回商户网站。*/
    public String mchRetPam;		/**商户提供的返回参数  (returnPar)			商户提供的返回参数。支付完银行返回商户网站时将该参数原封不动的传递给商户提供的返回URL。如果商户未提供返回地址，则该参数无效             */
    public String trxGdsGrp;		/**商品组号			 (goodsGrup)			商品组号，长度在8个字节以内                                                                                                             */
    public String trxGdsNam;		/**商品名称			 (subject)				商品名称，长度在40个字节以内（1个汉字占2字节）                                                                                          */
    public String trxPstAdr;		/**送货地址			 (tax_delivery_info)	送货地址，长度在50字节以内（1个汉字占2字节）                                                                                            */
    public String trxPstTel;		/**联系电话			 (tel)					联系电话，长度在20字节以内                                                                                                              */


    public String getMchMchNbr() {
        return mchMchNbr;
    }

    public void setMchMchNbr(String mchMchNbr) {
        this.mchMchNbr = mchMchNbr;
    }

    public String getMchBllNbr() {
        return mchBllNbr;
    }

    public void setMchBllNbr(String mchBllNbr) {
        this.mchBllNbr = mchBllNbr;
    }

    public String getMchBllDat() {
        return mchBllDat;
    }

    public void setMchBllDat(String mchBllDat) {
        this.mchBllDat = mchBllDat;
    }

    public String getMchBllTim() {
        return mchBllTim;
    }

    public void setMchBllTim(String mchBllTim) {
        this.mchBllTim = mchBllTim;
    }

    public String getTrxTrxCcy() {
        return trxTrxCcy;
    }

    public void setTrxTrxCcy(String trxTrxCcy) {
        this.trxTrxCcy = trxTrxCcy;
    }

    public String getTrxBllAmt() {
        return trxBllAmt;
    }

    public void setTrxBllAmt(String trxBllAmt) {
        this.trxBllAmt = trxBllAmt;
    }

    public String getTrxPedCnt() {
        return trxPedCnt;
    }

    public void setTrxPedCnt(String trxPedCnt) {
        this.trxPedCnt = trxPedCnt;
    }

    public String getUiHidePed() {
        return uiHidePed;
    }

    public void setUiHidePed(String uiHidePed) {
        this.uiHidePed = uiHidePed;
    }

    public String getMchUsrIdn() {
        return mchUsrIdn;
    }

    public void setMchUsrIdn(String mchUsrIdn) {
        this.mchUsrIdn = mchUsrIdn;
    }

    public String getMchNtfUrl() {
        return mchNtfUrl;
    }

    public void setMchNtfUrl(String mchNtfUrl) {
        this.mchNtfUrl = mchNtfUrl;
    }

    public String getMchNtfPam() {
        return mchNtfPam;
    }

    public void setMchNtfPam(String mchNtfPam) {
        this.mchNtfPam = mchNtfPam;
    }

    public String getMchRetUrl() {
        return mchRetUrl;
    }

    public void setMchRetUrl(String mchRetUrl) {
        this.mchRetUrl = mchRetUrl;
    }

    public String getMchRetPam() {
        return mchRetPam;
    }

    public void setMchRetPam(String mchRetPam) {
        this.mchRetPam = mchRetPam;
    }

    public String getTrxGdsGrp() {
        return trxGdsGrp;
    }

    public void setTrxGdsGrp(String trxGdsGrp) {
        this.trxGdsGrp = trxGdsGrp;
    }

    public String getTrxGdsNam() {
        return trxGdsNam;
    }

    public void setTrxGdsNam(String trxGdsNam) {
        this.trxGdsNam = trxGdsNam;
    }

    public String getTrxPstAdr() {
        return trxPstAdr;
    }

    public void setTrxPstAdr(String trxPstAdr) {
        this.trxPstAdr = trxPstAdr;
    }

    public String getTrxPstTel() {
        return trxPstTel;
    }

    public void setTrxPstTel(String trxPstTel) {
        this.trxPstTel = trxPstTel;
    }
}
