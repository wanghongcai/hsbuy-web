package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;

/**
 * 招商银行支付实体类
 * Created by MengQiang on 2015/5/24.
 */
public class CMBPayModel extends BaseModel {
    public CMBPayModel() {
        super();
    }

    public CMBPayModel(HttpServletRequest request) {
        super(request);
        this.userName = request.getParameter("userName");
    }
    //购买商品用户名
    private String userName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
