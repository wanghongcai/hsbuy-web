package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;

public class AliPayModel extends BaseModel {

	public AliPayModel() {
		super();
	}

	public AliPayModel(HttpServletRequest request) {
		super(request);
        this.os = request.getParameter("os");
	}
    //客户端系统 1:ios,2:android,3:js,4:native，5，pc
    private String os;
    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }
}
