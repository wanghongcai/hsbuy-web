package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

/**
 * Created by zhanglijun on 2015/5/19.
 *
 * 支付宝交易状态的实体
 */


public enum  AlipayTradeStatus {

    WAITBUYERPAY("WAIT_BUYER_PAY","交易创建，等待买家付款"),
    TRADECLOSED("TRADE_CLOSED","在指定时间段内未支付时关闭的交易\n在交易完成全额退款成功时关闭的交易"),
    TRADESUCCESS("TRADE_SUCCESS","交易成功，且可对该交易做操作，如：多级分润、退款等"),
    TRADEPENDING("TRADE_PENDING","且可对该交易做操作，如：多级分润、退款等"),
    TRADE_FINISHED("TRADE_FINISHED","交易成功且结束，即不可再做任何操作");

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @Override
    public String toString() {
        return "AlipayTradeStatus{" +
                "name='" + name + '\'' +
                ", comments='" + comments + '\'' +
                '}';
    }

    // 成员变量
    private String name;
    private String comments ;


    // 构造方法
    private AlipayTradeStatus(String name, String comments) {
        this.name = name;
        this.comments = comments;
    }
    // 根据名称显示中文意思
    /*public static String getName(int index) {
      *//*  for (Color c : Color.values()) {
            if (c.getIndex() == index) {
                return c.name;
            }
        }
        return null;*//*
    }*/





}
