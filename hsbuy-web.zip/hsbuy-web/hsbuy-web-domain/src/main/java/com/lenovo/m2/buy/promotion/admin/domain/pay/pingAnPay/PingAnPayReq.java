package com.lenovo.m2.buy.promotion.admin.domain.pay.pingAnPay;

/**
 * 平安银行支付请求实体
 *
 */
public class PingAnPayReq {
	
	private boolean success;

	/**商户号*/
	private String masterId;

    /**订单号*/
    private String orderId;

    //币种，目前只支持RMB
    private String currency;

    /**金额 12.43*/
    private String amount;

    //商品描述
    private String objectName;

    /**下单时间，YYYYMMDDHHMMSS*/
    private String paydate;

    //订单有效期(毫秒)，0 不生效
    private String validtime;

    //备注字段 平安回传参数
    private String remark;

	/**前台通知*/
	private String notifyUrl;

	/**后台通知*/
	private String returnUrl;

	/*直连网银标识*/
	private String plantId;
	/*银行代码*/
	private String plantBankId;


    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMasterId() {
        return masterId;
    }

    public void setMasterId(String masterId) {
        this.masterId = masterId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public String getPaydate() {
        return paydate;
    }

    public void setPaydate(String paydate) {
        this.paydate = paydate;
    }

    public String getValidtime() {
        return validtime;
    }

    public void setValidtime(String validtime) {
        this.validtime = validtime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getNotifyUrl() {
        return notifyUrl;
    }

    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }

    public String getReturnUrl() {
        return returnUrl;
    }

    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }

    public String getPlantId() {
        return plantId;
    }

    public void setPlantId(String plantId) {
        this.plantId = plantId;
    }

    public String getPlantBankId() {
        return plantBankId;
    }

    public void setPlantBankId(String plantBankId) {
        this.plantBankId = plantBankId;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("{");
        sb.append("\"success\":")
                .append(success);
        sb.append(",\"masterId\":\"")
                .append(masterId).append('\"');
        sb.append(",\"orderId\":\"")
                .append(orderId).append('\"');
        sb.append(",\"currency\":\"")
                .append(currency).append('\"');
        sb.append(",\"amount\":\"")
                .append(amount).append('\"');
        sb.append(",\"objectName\":\"")
                .append(objectName).append('\"');
        sb.append(",\"paydate\":\"")
                .append(paydate).append('\"');
        sb.append(",\"validtime\":\"")
                .append(validtime).append('\"');
        sb.append(",\"remark\":\"")
                .append(remark).append('\"');
        sb.append(",\"notifyUrl\":\"")
                .append(notifyUrl).append('\"');
        sb.append(",\"returnUrl\":\"")
                .append(returnUrl).append('\"');
        sb.append(",\"plantId\":\"")
                .append(plantId).append('\"');
        sb.append(",\"plantBankId\":\"")
                .append(plantBankId).append('\"');
        sb.append('}');
        return sb.toString();
    }
}
