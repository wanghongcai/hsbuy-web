package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.lenovo.m2.hsbuy.domain.order.logistics.NoticeRequest;

import java.io.Serializable;

public class OpenPlatRequestForMsg implements Serializable {
    private String app_key;
    private String format;
    private String method;
    private String shopid;
    private String sign;
    private String source;
    private Number terminal;
    private String timestamp;
    private String unique;
    private String v;


    //物流公司编号
    private String logiCode;
    //快递单号
    private String logiNo;
    //操作类型编码
    private String opCode;
    //物流轨迹明细
    private String remark;
    //推送时间
    private String time;

    public boolean isNull() {
        if (StringUtils.isEmpty(this.time) || StringUtils.isEmpty(this.remark) || StringUtils.isEmpty(this.logiCode) || StringUtils.isEmpty(this.logiNo) || StringUtils.isEmpty(this.opCode)) {
            return true;
        }
        return false;
    }

    public OpenPlatRequestForMsg() {
    }


    public String getLogiCode() {
        return logiCode;
    }

    public void setLogiCode(String logiCode) {
        this.logiCode = logiCode;
    }

    public String getLogiNo() {
        return logiNo;
    }

    public void setLogiNo(String logiNo) {
        this.logiNo = logiNo;
    }

    public String getOpCode() {
        return opCode;
    }

    public void setOpCode(String opCode) {
        this.opCode = opCode;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getMethod() {
        return this.method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getApp_key() {
        return this.app_key;
    }

    public void setApp_key(String app_key) {
        this.app_key = app_key;
    }

    public String getSign() {
        return this.sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getTimestamp() {
        return this.timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getFormat() {
        return this.format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getV() {
        return this.v;
    }

    public void setV(String v) {
        this.v = v;
    }

    public Number getTerminal() {
        return this.terminal;
    }

    public void setTerminal(Number terminal) {
        this.terminal = terminal;
    }

    public String getSource() {
        return this.source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getUnique() {
        return this.unique;
    }

    public void setUnique(String unique) {
        this.unique = unique;
    }

    public String getShopid() {
        return this.shopid;
    }

    public void setShopid(String shopid) {
        this.shopid = shopid;
    }

}