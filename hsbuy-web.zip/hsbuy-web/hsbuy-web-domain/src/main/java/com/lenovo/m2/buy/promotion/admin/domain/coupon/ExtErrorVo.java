package com.lenovo.m2.buy.promotion.admin.domain.coupon;

import java.io.Serializable;

/**
 * Created by admin on 2016/6/21.
 */
public class ExtErrorVo implements Serializable {

    private int rowNumber;
    private int colnNumber;
    private String errorMsg;

    public int getRowNumber() {
        return rowNumber;
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public int getColnNumber() {
        return colnNumber;
    }

    public void setColnNumber(int colnNumber) {
        this.colnNumber = colnNumber;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ExtErrorVo)) return false;

        ExtErrorVo that = (ExtErrorVo) o;

        if (getRowNumber() != that.getRowNumber()) return false;
        if (getColnNumber() != that.getColnNumber()) return false;
        if (getErrorMsg() != null ? !getErrorMsg().equals(that.getErrorMsg()) : that.getErrorMsg() != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = getRowNumber();
        result = 31 * result + getRowNumber();
        result = 31 * result + getColnNumber();
        result = 31 * result + (getErrorMsg() != null ? getErrorMsg().hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ExtErrorVo{" +
                "rowNumber=" + rowNumber +
                ", colnNumber=" + colnNumber +
                ", errorMsg='" + errorMsg + '\'' +
                '}';
    }
}
