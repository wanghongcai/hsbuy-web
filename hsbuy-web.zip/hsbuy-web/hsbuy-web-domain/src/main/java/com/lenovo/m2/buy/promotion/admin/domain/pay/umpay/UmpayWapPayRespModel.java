package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * 联动优势商户确认支付响应Model
 * Created by tianchuyang on 2016/11/22.
 */
public class UmpayWapPayRespModel extends BaseModel implements Serializable {

    private static final long serialVersionUID = 4063521020116253544L;

    private String sign_type;
    private String sign;
    private String mer_id;
    private String version;
    //业务参数
    private String order_id;
    private String mer_date;
    private String pay_date;
    private String amount;
    private String amt_type;
    private String settle_date;
    private String mer_priv;
    private String trade_state;
    private String ret_code;
    private String ret_msg;

    public UmpayWapPayRespModel() {
    }

    public UmpayWapPayRespModel(HttpServletRequest request) {
        super(request);
        this.sign_type = request.getParameter("sign_type");
        this.sign = request.getParameter("sign");
        this.mer_id = request.getParameter("mer_id");
        this.version = request.getParameter("version");
        this.order_id = request.getParameter("order_id");
        this.mer_date = request.getParameter("mer_date");
        this.pay_date = request.getParameter("pay_date");
        this.amount = request.getParameter("amount");
        this.amt_type = request.getParameter("amt_type");
        this.settle_date = request.getParameter("settle_date");
        this.mer_priv = request.getParameter("mer_priv");
        this.trade_state = request.getParameter("trade_state");
        this.ret_code = request.getParameter("ret_code");
        this.ret_msg = request.getParameter("ret_msg");
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getMer_id() {
        return mer_id;
    }

    public void setMer_id(String mer_id) {
        this.mer_id = mer_id;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getMer_date() {
        return mer_date;
    }

    public void setMer_date(String mer_date) {
        this.mer_date = mer_date;
    }

    public String getPay_date() {
        return pay_date;
    }

    public void setPay_date(String pay_date) {
        this.pay_date = pay_date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getAmt_type() {
        return amt_type;
    }

    public void setAmt_type(String amt_type) {
        this.amt_type = amt_type;
    }

    public String getSettle_date() {
        return settle_date;
    }

    public void setSettle_date(String settle_date) {
        this.settle_date = settle_date;
    }

    public String getMer_priv() {
        return mer_priv;
    }

    public void setMer_priv(String mer_priv) {
        this.mer_priv = mer_priv;
    }

    public String getTrade_state() {
        return trade_state;
    }

    public void setTrade_state(String trade_state) {
        this.trade_state = trade_state;
    }

    public String getRet_code() {
        return ret_code;
    }

    public void setRet_code(String ret_code) {
        this.ret_code = ret_code;
    }

    public String getRet_msg() {
        return ret_msg;
    }

    public void setRet_msg(String ret_msg) {
        this.ret_msg = ret_msg;
    }
}
