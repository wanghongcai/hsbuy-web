package com.lenovo.m2.buy.promotion.admin.domain.coupon;

import java.io.Serializable;

/**
 * Created by zhaocl1 on 2016/2/22.
 */
public class GoodsInfo implements Serializable {

    String id ;
    String materialNumber;//物料编号
    int goodscode;//商品编码
    String goodsname;//商品名称
    String name;//产品名称，即平台商品名称
    String platformcode;//平台编号
    String platformname;//支持的平台名称，多个平台以逗号隔开
    int marketable;//上架  1：上架 ；0：下架
    String marketablename;//上下架 1：上架 ；0：下架
    int status;//审核状态  2 审核通过
    String price;//价格，主要用在查询c2c商品时指定的优惠的价格

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMaterialNumber() {
        return materialNumber;
    }

    public void setMaterialNumber(String materialNumber) {
        this.materialNumber = materialNumber;
    }

    public int getGoodscode() {
        return goodscode;
    }

    public void setGoodscode(int goodscode) {
        this.goodscode = goodscode;
    }

    public String getGoodsname() {
        return goodsname;
    }

    public void setGoodsname(String goodsname) {
        this.goodsname = goodsname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPlatformcode() {
        return platformcode;
    }

    public void setPlatformcode(String platformcode) {
        this.platformcode = platformcode;
    }

    public String getPlatformname() {
        return platformname;
    }

    public void setPlatformname(String platformname) {
        this.platformname = platformname;
    }

    public int getMarketable() {
        return marketable;
    }

    public void setMarketable(int marketable) {
        this.marketable = marketable;
    }

    public String getMarketablename() {
        return marketablename;
    }

    public void setMarketablename(String marketablename) {
        this.marketablename = marketablename;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "GoodsInfo{" +
                "id='" + id + '\'' +
                ", materialNumber='" + materialNumber + '\'' +
                ", goodscode=" + goodscode +
                ", goodsname='" + goodsname + '\'' +
                ", name='" + name + '\'' +
                ", platformcode='" + platformcode + '\'' +
                ", platformname='" + platformname + '\'' +
                ", marketable=" + marketable +
                ", marketablename='" + marketablename + '\'' +
                ", status=" + status +
                ", price='" + price + '\'' +
                '}';
    }
}
