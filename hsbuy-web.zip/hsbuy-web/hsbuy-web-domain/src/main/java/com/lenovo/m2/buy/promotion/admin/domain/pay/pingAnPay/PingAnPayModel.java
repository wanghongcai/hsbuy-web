package com.lenovo.m2.buy.promotion.admin.domain.pay.pingAnPay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;

/**
 * 平安支付实体
 * Created by qixin on 2016/11/1.
 */
public class PingAnPayModel extends BaseModel {
    //订单有效期(毫秒)，0 不生效
    private String validtime;
    //商品描述
    private String objectName;
    // 对直连网银的支持
    private String accountType;
    private String bankNo;
    private String cardType;
    private String bankCode;
    private String plantId;

    //
    public PingAnPayModel(){super();}

    public PingAnPayModel(HttpServletRequest request){
        super(request);
        this.objectName = request.getParameter("objectName");
        this.validtime = request.getParameter("validtime");
    }
    public String getValidtime() {
        return validtime;
    }

    public void setValidtime(String validtime) {
        this.validtime = validtime;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getBankNo() {
        return bankNo;
    }

    public void setBankNo(String bankNo) {
        this.bankNo = bankNo;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getPlantId() {
        return plantId;
    }

    public void setPlantId(String plantId) {
        this.plantId = plantId;
    }
}
