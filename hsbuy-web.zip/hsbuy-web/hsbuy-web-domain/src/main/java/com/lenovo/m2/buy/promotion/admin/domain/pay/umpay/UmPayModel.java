package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/** 联动优势支付实体
 * Created by tiancy3 on 2016/11/8.
 */
public class UmPayModel extends BaseModel implements Serializable {

    private static final long serialVersionUID = 7412103384613124562L;

    public UmPayModel(){
        super();
    }

    public UmPayModel(HttpServletRequest request) {
        super(request);
        this.service = request.getParameter("service");
        this.charset= request.getParameter("charset");
        this.mer_id= request.getParameter("mer_id");
        this.sign_type= request.getParameter("sign_type");
        this.sign= request.getParameter("sign");
        this.ret_url= request.getParameter("ret_url");
        this.notify_url= request.getParameter("notify_url");
        this.version= request.getParameter("version");
        this.goods_id= request.getParameter("goods_id");
        this.goods_inf= request.getParameter("goods_inf");
        this.order_id= request.getParameter("order_id");
        this.mer_date= request.getParameter("mer_date");
        this.amount= request.getParameter("amount");
        this.amt_type= request.getParameter("amt_type");
        this.pay_type= request.getParameter("pay_type");
        this.gate_id= request.getParameter("gate_id");
        this.mer_priv= request.getParameter("mer_priv");
        this.user_ip= request.getParameter("user_ip");
        this.expand= request.getParameter("expand");
        this.expire_time= request.getParameter("expire_time");
        this.interface_type= request.getParameter("interface_type");
        this.card_id= request.getParameter("card_id");
        this.identity_type= request.getParameter("identity_type");
        this.identity_code= request.getParameter("identity_code");
        this.card_holder= request.getParameter("card_holder");
        this.valid_date= request.getParameter("valid_date");
        this.cvv2= request.getParameter("cvv2");
        this.can_modify_flag= request.getParameter("can_modify_flag");
        this.media_id= request.getParameter("media_id");
        this.media_type= request.getParameter("media_type");
        // 网银直连
        this.accountType = request.getParameter("accountType");
        this.bankNo= request.getParameter("bank_no");
        this.cardType= request.getParameter("card_type");
        this.bankCode= request.getParameter("bank_code");
    }

    //接口名称
    private String service;
    //参数字符编码集
    private String charset;
    private String mer_id;
    private String sign_type;
    private String sign;
    private String ret_url;
    private String notify_url;
    private String version;
    // 业务参数
    private String goods_id;
    private String goods_inf;
    private String order_id;
    private String mer_date;
    private String amount;
    private String amt_type;
    private String pay_type;
    private String gate_id;
    private String mer_priv;
    private String user_ip;
    private String expand;
    private String expire_time;
    private String interface_type;
    private String card_id;
    private String identity_type;
    private String identity_code;
    private String card_holder;
    private String valid_date;
    private String cvv2;
    private String can_modify_flag;
    private String media_id;
    private String media_type;
    // 网银直连
    private String accountType;
    private String bankNo;
    private String cardType;
    private String bankCode;

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public String getMer_id() {
        return mer_id;
    }

    public void setMer_id(String mer_id) {
        this.mer_id = mer_id;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getRet_url() {
        return ret_url;
    }

    public void setRet_url(String ret_url) {
        this.ret_url = ret_url;
    }

    public String getNotify_url() {
        return notify_url;
    }

    public void setNotify_url(String notify_url) {
        this.notify_url = notify_url;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id;
    }

    public String getGoods_inf() {
        return goods_inf;
    }

    public void setGoods_inf(String goods_inf) {
        this.goods_inf = goods_inf;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getMer_date() {
        return mer_date;
    }

    public void setMer_date(String mer_date) {
        this.mer_date = mer_date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getAmt_type() {
        return amt_type;
    }

    public void setAmt_type(String amt_type) {
        this.amt_type = amt_type;
    }

    public String getPay_type() {
        return pay_type;
    }

    public void setPay_type(String pay_type) {
        this.pay_type = pay_type;
    }

    public String getGate_id() {
        return gate_id;
    }

    public void setGate_id(String gate_id) {
        this.gate_id = gate_id;
    }

    public String getMer_priv() {
        return mer_priv;
    }

    public void setMer_priv(String mer_priv) {
        this.mer_priv = mer_priv;
    }

    public String getUser_ip() {
        return user_ip;
    }

    public void setUser_ip(String user_ip) {
        this.user_ip = user_ip;
    }

    public String getExpand() {
        return expand;
    }

    public void setExpand(String expand) {
        this.expand = expand;
    }

    public String getExpire_time() {
        return expire_time;
    }

    public void setExpire_time(String expire_time) {
        this.expire_time = expire_time;
    }

    public String getInterface_type() {
        return interface_type;
    }

    public void setInterface_type(String interface_type) {
        this.interface_type = interface_type;
    }

    public String getCard_id() {
        return card_id;
    }

    public void setCard_id(String card_id) {
        this.card_id = card_id;
    }

    public String getIdentity_type() {
        return identity_type;
    }

    public void setIdentity_type(String identity_type) {
        this.identity_type = identity_type;
    }

    public String getIdentity_code() {
        return identity_code;
    }

    public void setIdentity_code(String identity_code) {
        this.identity_code = identity_code;
    }

    public String getCard_holder() {
        return card_holder;
    }

    public void setCard_holder(String card_holder) {
        this.card_holder = card_holder;
    }

    public String getValid_date() {
        return valid_date;
    }

    public void setValid_date(String valid_date) {
        this.valid_date = valid_date;
    }

    public String getCvv2() {
        return cvv2;
    }

    public void setCvv2(String cvv2) {
        this.cvv2 = cvv2;
    }

    public String getCan_modify_flag() {
        return can_modify_flag;
    }

    public void setCan_modify_flag(String can_modify_flag) {
        this.can_modify_flag = can_modify_flag;
    }

    public String getMedia_id() {
        return media_id;
    }

    public void setMedia_id(String media_id) {
        this.media_id = media_id;
    }

    public String getMedia_type() {
        return media_type;
    }

    public void setMedia_type(String media_type) {
        this.media_type = media_type;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getBankNo() {
        return bankNo;
    }

    public void setBankNo(String bankNo) {
        this.bankNo = bankNo;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }
}
