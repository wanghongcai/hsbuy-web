package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * 联动优势WAP一键快捷支付证码响应模型
 * Created by tianchuyang on 2016/11/22.
 */
public class UmpayCaptchaRespModel extends BaseModel implements Serializable {

    private static final long serialVersionUID = 3466118675130966758L;

    private String sign_type;
    private String sign;
    private String mer_id;
    private String version;
    private String ret_code;
    private String ret_msg;

    public UmpayCaptchaRespModel() {
    }

    public UmpayCaptchaRespModel(HttpServletRequest request) {
        super(request);
        this.sign_type = request.getParameter("sign_type");
        this.sign = request.getParameter("sign");
        this.mer_id = request.getParameter("mer_id");
        this.version = request.getParameter("version");
        this.ret_code = request.getParameter("ret_code");
        this.ret_msg = request.getParameter("ret_msg");
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getMer_id() {
        return mer_id;
    }

    public void setMer_id(String mer_id) {
        this.mer_id = mer_id;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getRet_code() {
        return ret_code;
    }

    public void setRet_code(String ret_code) {
        this.ret_code = ret_code;
    }

    public String getRet_msg() {
        return ret_msg;
    }

    public void setRet_msg(String ret_msg) {
        this.ret_msg = ret_msg;
    }
}
