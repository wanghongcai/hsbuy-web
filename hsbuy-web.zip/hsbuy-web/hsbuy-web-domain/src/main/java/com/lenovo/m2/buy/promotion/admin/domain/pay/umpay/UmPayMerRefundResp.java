package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * 商户退款响应实体
 * Created by tianchuyang on 2016/11/9.
 */
public class UmPayMerRefundResp implements Serializable {

    private static final long serialVersionUID = -7198247849103627160L;

    private String sign_type;
    private String sign;
    private String mer_id;
    private String version;
    // 业务参数
    private String refund_no;
    private String order_id;
    private String mer_date;
    private String amount;
    private String trade_no;
    private String refund_state;
    private String refund_amt;
    private String ret_code;
    private String ret_msg;

    public UmPayMerRefundResp() {
    }

    public UmPayMerRefundResp(HttpServletRequest request) {

        this.sign_type = request.getParameter("sign_type");
        this.sign = request.getParameter("sign");
        this.mer_id = request.getParameter("mer_id");
        this.version = request.getParameter("version");
        this.refund_no = request.getParameter("refund_no");
        this.order_id = request.getParameter("order_id");
        this.mer_date = request.getParameter("mer_date");
        this.amount = request.getParameter("amount");
        this.trade_no = request.getParameter("trade_no");
        this.refund_state = request.getParameter("refund_state");
        this.refund_amt = request.getParameter("refund_amt");
        this.ret_code = request.getParameter("ret_code");
        this.ret_msg = request.getParameter("ret_msg");
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getMer_id() {
        return mer_id;
    }

    public void setMer_id(String mer_id) {
        this.mer_id = mer_id;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getRefund_no() {
        return refund_no;
    }

    public void setRefund_no(String refund_no) {
        this.refund_no = refund_no;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getMer_date() {
        return mer_date;
    }

    public void setMer_date(String mer_date) {
        this.mer_date = mer_date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getTrade_no() {
        return trade_no;
    }

    public void setTrade_no(String trade_no) {
        this.trade_no = trade_no;
    }

    public String getRefund_state() {
        return refund_state;
    }

    public void setRefund_state(String refund_state) {
        this.refund_state = refund_state;
    }

    public String getRefund_amt() {
        return refund_amt;
    }

    public void setRefund_amt(String refund_amt) {
        this.refund_amt = refund_amt;
    }

    public String getRet_code() {
        return ret_code;
    }

    public void setRet_code(String ret_code) {
        this.ret_code = ret_code;
    }

    public String getRet_msg() {
        return ret_msg;
    }

    public void setRet_msg(String ret_msg) {
        this.ret_msg = ret_msg;
    }
}
