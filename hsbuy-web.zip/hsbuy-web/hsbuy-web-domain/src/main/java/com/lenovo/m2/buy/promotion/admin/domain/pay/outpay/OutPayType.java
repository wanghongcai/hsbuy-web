package com.lenovo.m2.buy.promotion.admin.domain.pay.outpay;

import java.io.Serializable;
import java.util.List;

/**
 * Created by MengQiang on 2016/10/21.
 */
public class OutPayType implements Serializable {

    private String fa_id;
    private String pay_type;
    private String account_type;
    private List<DirectBank> bank_list;

    public OutPayType() {
    }

    public OutPayType(String fa_id, String pay_type, String account_type, List<DirectBank> bank_list) {
        this.fa_id = fa_id;
        this.pay_type = pay_type;
        this.account_type = account_type;
        this.bank_list = bank_list;
    }

    public String getFa_id() {
        return fa_id;
    }

    public void setFa_id(String fa_id) {
        this.fa_id = fa_id;
    }

    public String getPay_type() {
        return pay_type;
    }

    public void setPay_type(String pay_type) {
        this.pay_type = pay_type;
    }

    public String getAccount_type() {
        return account_type;
    }

    public void setAccount_type(String account_type) {
        this.account_type = account_type;
    }

    public List<DirectBank> getBank_list() {
        return bank_list;
    }

    public void setBank_list(List<DirectBank> bank_list) {
        this.bank_list = bank_list;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OutPayType that = (OutPayType) o;

        if (!fa_id.equals(that.fa_id)) return false;
        if (!pay_type.equals(that.pay_type)) return false;
        if (!account_type.equals(that.account_type)) return false;
        return bank_list != null ? bank_list.equals(that.bank_list) : that.bank_list == null;
    }

    @Override
    public int hashCode() {
        int result = fa_id.hashCode();
        result = 31 * result + pay_type.hashCode();
        result = 31 * result + account_type.hashCode();
        result = 31 * result + (bank_list != null ? bank_list.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("{");
        sb.append("\"fa_id\":\"")
                .append(fa_id).append('\"');
        sb.append(",\"pay_type\":\"")
                .append(pay_type).append('\"');
        sb.append(",\"account_type\":\"")
                .append(account_type).append('\"');
        sb.append(",\"bank_list\":")
                .append(bank_list);
        sb.append('}');
        return sb.toString();
    }
}
