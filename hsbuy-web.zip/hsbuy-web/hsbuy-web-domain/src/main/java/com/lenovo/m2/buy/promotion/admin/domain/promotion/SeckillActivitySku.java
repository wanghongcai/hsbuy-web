package com.lenovo.m2.buy.promotion.admin.domain.promotion;

import java.math.BigDecimal;

/**
 * Created by lihc5 on 2017/5/11.
 */
public class SeckillActivitySku {

    private String gcode;
    private String name;
    private String thumbnail;
    private String faId;
    private String faName;
    private Integer addDiscountCount;
    private String purchaseceiling;
    private String seckillMoney;


    public String getGcode() {
        return gcode;
    }

    public void setGcode(String gcode) {
        this.gcode = gcode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getFaId() {
        return faId;
    }

    public void setFaId(String faid) {
        this.faId = faid;
    }

    public String getFaName() {
        return faName;
    }

    public void setFaName(String faName) {
        this.faName = faName;
    }

    public Integer getAddDiscountCount() {
        return addDiscountCount;
    }

    public void setAddDiscountCount(Integer addDiscountCount) {
        this.addDiscountCount = addDiscountCount;
    }

    public String getSeckillMoney() {
        return seckillMoney;
    }

    public void setSeckillMoney(String seckillMoney) {
        this.seckillMoney = seckillMoney;
    }

    public String getPurchaseceiling() {
        return purchaseceiling;
    }

    public void setPurchaseceiling(String purchaseceiling) {
        this.purchaseceiling = purchaseceiling;
    }
}
