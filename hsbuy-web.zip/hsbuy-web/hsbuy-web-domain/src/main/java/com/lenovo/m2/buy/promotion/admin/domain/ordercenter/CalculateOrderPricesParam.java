package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

/**
 * @Author licy13
 * @Date 2017/3/25
 */

public class CalculateOrderPricesParam extends BaseParam {
    private String orderId;
    private String creditLine;
//    [{"code":"123123","orderItemId":0,"gPrice":"1223"}]
    private String orderItems;

    public String getCreditLine() {
        return creditLine;
    }

    public void setCreditLine(String creditLine) {
        this.creditLine = creditLine;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(String orderItems) {
        this.orderItems = orderItems;
    }
}