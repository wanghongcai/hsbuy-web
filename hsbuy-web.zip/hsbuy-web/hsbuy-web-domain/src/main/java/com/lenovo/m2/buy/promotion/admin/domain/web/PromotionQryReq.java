package com.lenovo.m2.buy.promotion.admin.domain.web;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class PromotionQryReq implements Serializable{
	
	//促销类型
	private String promotionType;
	//促销名称
	private String promotionName;
	//平台
	private Integer plat;
	//主品物料编号
	private String mainMaterialCode;
	//关联品物料编号
	private String releMaterialCode;
	
	private Integer page;
	private Integer rows;
    private Integer terminal;

    private String shopId;
    private Integer curPage;
    private Integer pageSize;
    private String mainProductMaterial;
    private String relProductMaterial;
    private Integer status;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getTerminal() {
        return terminal;
    }

    public void setTerminal(Integer terminal) {
        this.terminal = terminal;
    }

    public String getPromotionType() {
        return promotionType;
    }

    public void setPromotionType(String promotionType) {
        this.promotionType = promotionType;
    }

    public String getPromotionName() {
		return promotionName;
	}
	public void setPromotionName(String promotionName) {
		this.promotionName = promotionName;
	}
	public Integer getPlat() {
		return plat;
	}
	public void setPlat(Integer plat) {
		this.plat = plat;
	}
	public String getMainMaterialCode() {
		return mainMaterialCode;
	}
	public void setMainMaterialCode(String mainMaterialCode) {
		this.mainMaterialCode = mainMaterialCode;
	}
	public String getReleMaterialCode() {
		return releMaterialCode;
	}
	public void setReleMaterialCode(String releMaterialCode) {
		this.releMaterialCode = releMaterialCode;
	}
	
	
	
	public Integer getPage() {
		if(page ==null || page < 1){
			page = 1;
		}
		return page;
	}
	public void setRows(Integer rows) {
		this.rows = rows;
	}
	public Integer getRows() {
		if(rows == null || rows < 1){
			rows = 20;
		}
		return rows;
	}
	public void setPage(Integer page) {
		this.page = page;
	}
	
	
	public  Map<String,Object> toMap(){
		
		Map<String,Object> ret = new HashMap<>();
		ret.put("promotionType", this.promotionType);
		ret.put("promotionName", this.promotionName);
		ret.put("terminal", this.terminal);
		ret.put("mainProductMaterial", this.mainMaterialCode);
		ret.put("relProductMaterial", this.releMaterialCode);
		ret.put("shopid",this.shopId);
        ret.put("status",this.status);
		return ret;
	}

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }



    public void setCurPage(Integer curPage) {
        this.page = curPage;
    }


    public void setPageSize(Integer pageSize) {
        this.rows = pageSize;
    }

    public void setMainProductMaterial(String mainProductMaterial) {
        this.mainMaterialCode = mainProductMaterial;
    }



    public void setRelProductMaterial(String relProductMaterial) {
        this.releMaterialCode = relProductMaterial;
    }

    @Override
    public String toString() {
        return "PromotionQryReq{" +
                "promotionType='" + promotionType + '\'' +
                ", promotionName='" + promotionName + '\'' +
                ", plat=" + plat +
                ", mainMaterialCode='" + mainMaterialCode + '\'' +
                ", releMaterialCode='" + releMaterialCode + '\'' +
                ", page=" + page +
                ", rows=" + rows +
                ", terminal=" + terminal +
                ", shopId='" + shopId + '\'' +
                ", curPage=" + curPage +
                ", pageSize=" + pageSize +
                ", mainProductMaterial='" + mainProductMaterial + '\'' +
                ", relProductMaterial='" + relProductMaterial + '\'' +
                ", status=" + status +
                '}';
    }
}
