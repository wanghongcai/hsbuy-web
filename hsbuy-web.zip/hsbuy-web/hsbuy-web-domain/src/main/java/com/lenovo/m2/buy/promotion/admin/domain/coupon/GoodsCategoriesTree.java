package com.lenovo.m2.buy.promotion.admin.domain.coupon;

import java.io.Serializable;
import java.util.List;

/**
 * Created by zhaocl1 on 2016/1/22.
 */
public class GoodsCategoriesTree implements Serializable {

    String id;
    String text;
    String state;
    Boolean checked;
    String attributes;
    List<GoodsCategoriesTree> children;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Boolean getChecked() {
        return checked;
    }

    public void setChecked(Boolean checked) {
        this.checked = checked;
    }

    public String getAttributes() {
        return attributes;
    }

    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }

    public List<GoodsCategoriesTree> getChildren() {
        return children;
    }

    public void setChildren(List<GoodsCategoriesTree> children) {
        this.children = children;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        GoodsCategoriesTree that = (GoodsCategoriesTree) o;

        if (attributes != null ? !attributes.equals(that.attributes) : that.attributes != null) return false;
        if (checked != null ? !checked.equals(that.checked) : that.checked != null) return false;
        if (children != null ? !children.equals(that.children) : that.children != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (state != null ? !state.equals(that.state) : that.state != null) return false;
        if (text != null ? !text.equals(that.text) : that.text != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (text != null ? text.hashCode() : 0);
        result = 31 * result + (state != null ? state.hashCode() : 0);
        result = 31 * result + (checked != null ? checked.hashCode() : 0);
        result = 31 * result + (attributes != null ? attributes.hashCode() : 0);
        result = 31 * result + (children != null ? children.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "GoodsCategoriesTree{" +
                "id='" + id + '\'' +
                ", text='" + text + '\'' +
                ", state='" + state + '\'' +
                ", checked=" + checked +
                ", attributes='" + attributes + '\'' +
                ", children=" + children +
                '}';
    }
}
