package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

/**
 * Created by Administrator on 2016/11/11.
 */

/**
 * cmbfq通知model
 */

public class CMBFQInformModel {

    public String resultFlag;		/* 交易成功标志（Y：成功；N：失败；S：待人工处理）		    */
    public String mchMchNbr;		/*商户号（原样返回支付请求中的对应数据）					    */
    public String mchBllNbr;		/*商户定单号（原样返回支付请求中的对应数据）				     */
    public String mchBllDat;		/*商户定单日期（原样返回支付请求中的对应数据）			     */
    public String mchBllTim;		/*商户定单时间（原样返回支付请求中的对应数据）			     */
    public String trxTrxCcy;		/*币种（原样返回支付请求中的对应数据）					     */
    public String trxBllAmt;		/*定单总金额（原样返回支付请求中的对应数据）				     */
    public String trxPedCnt;		/*分期数（原样返回支付请求中的对应数据）					      */
    public String mchNtfPam;		/*商户提供的通知参数（原样返回支付请求中的对应数据）		       */
    public String crdBllNbr;		/*信用卡中心内部定单号（15位）							     */
    public String crdBllRef;		/*信用卡中心内部参考号（12位）							     */
    public String crdAutCod;		/*信用卡中心内部授权号（6位）							     */


    public String getResultFlag() {
        return resultFlag;
    }

    public void setResultFlag(String resultFlag) {
        this.resultFlag = resultFlag;
    }

    public String getMchMchNbr() {
        return mchMchNbr;
    }

    public void setMchMchNbr(String mchMchNbr) {
        this.mchMchNbr = mchMchNbr;
    }

    public String getMchBllNbr() {
        return mchBllNbr;
    }

    public void setMchBllNbr(String mchBllNbr) {
        this.mchBllNbr = mchBllNbr;
    }

    public String getMchBllDat() {
        return mchBllDat;
    }

    public void setMchBllDat(String mchBllDat) {
        this.mchBllDat = mchBllDat;
    }

    public String getMchBllTim() {
        return mchBllTim;
    }

    public void setMchBllTim(String mchBllTim) {
        this.mchBllTim = mchBllTim;
    }

    public String getTrxTrxCcy() {
        return trxTrxCcy;
    }

    public void setTrxTrxCcy(String trxTrxCcy) {
        this.trxTrxCcy = trxTrxCcy;
    }

    public String getTrxBllAmt() {
        return trxBllAmt;
    }

    public void setTrxBllAmt(String trxBllAmt) {
        this.trxBllAmt = trxBllAmt;
    }

    public String getTrxPedCnt() {
        return trxPedCnt;
    }

    public void setTrxPedCnt(String trxPedCnt) {
        this.trxPedCnt = trxPedCnt;
    }

    public String getMchNtfPam() {
        return mchNtfPam;
    }

    public void setMchNtfPam(String mchNtfPam) {
        this.mchNtfPam = mchNtfPam;
    }

    public String getCrdBllNbr() {
        return crdBllNbr;
    }

    public void setCrdBllNbr(String crdBllNbr) {
        this.crdBllNbr = crdBllNbr;
    }

    public String getCrdBllRef() {
        return crdBllRef;
    }

    public void setCrdBllRef(String crdBllRef) {
        this.crdBllRef = crdBllRef;
    }

    public String getCrdAutCod() {
        return crdAutCod;
    }

    public void setCrdAutCod(String crdAutCod) {
        this.crdAutCod = crdAutCod;
    }
}
