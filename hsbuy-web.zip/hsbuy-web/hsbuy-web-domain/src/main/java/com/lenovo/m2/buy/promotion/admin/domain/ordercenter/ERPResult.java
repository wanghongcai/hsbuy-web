package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

import java.io.Serializable;
import java.util.List;

public class ERPResult implements Serializable {

    /**
     * 下单时间
     */
    private String voucherDate;

    /**
     * 订单号
     */
    private String externalCode;

    /**
     * 订单号
     */
    private String code;

    /**
     * 经销商编码
     */
    private String customerCode;

    /**
     * 经销商名称
     */
    private String customerName;

    /**
     * 预计交货日期，空着
     */
    private String deliveryDate;

    /**
     * 运输方式，空着
     */
    private String deliveryMode;

    /**
     * 送货地址
     */
    private String address;

    /**
     * 收货联系人
     */
    private String linkMan;

    /**
     * 收货人联系电话
     */
    private String contactPhone;

    /**
     * 制单人，空着
     */
    private String maker;

    /**
     * V3系统中存在的往来单位
     */
    private String partner;

    /**
     * 订单备注
     */
    private String memo;

    /**
     * 支付时间
     */
    private String paidTime;

    /**
     * 单据明细信息
     */
    private List<SaleOrderDetail> saleOrderDetails;

    /**
     * 支付信息
     */
    private List<ArapMultiSettleDetail> arapMultiSettleDetails;

    public String getVoucherDate() {
        return voucherDate;
    }

    public void setVoucherDate(String voucherDate) {
        this.voucherDate = voucherDate;
    }

    public String getExternalCode() {
        return externalCode;
    }

    public void setExternalCode(String externalCode) {
        this.externalCode = externalCode;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public String getDeliveryMode() {
        return deliveryMode;
    }

    public void setDeliveryMode(String deliveryMode) {
        this.deliveryMode = deliveryMode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLinkMan() {
        return linkMan;
    }

    public void setLinkMan(String linkMan) {
        this.linkMan = linkMan;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getMaker() {
        return maker;
    }

    public void setMaker(String maker) {
        this.maker = maker;
    }

    public String getPartner() {
        return partner;
    }

    public void setPartner(String partner) {
        this.partner = partner;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getPaidTime() {
        return paidTime;
    }

    public void setPaidTime(String paidTime) {
        this.paidTime = paidTime;
    }

    public List<SaleOrderDetail> getSaleOrderDetails() {
        return saleOrderDetails;
    }

    public void setSaleOrderDetails(List<SaleOrderDetail> saleOrderDetails) {
        this.saleOrderDetails = saleOrderDetails;
    }

    public List<ArapMultiSettleDetail> getArapMultiSettleDetails() {
        return arapMultiSettleDetails;
    }

    public void setArapMultiSettleDetails(List<ArapMultiSettleDetail> arapMultiSettleDetails) {
        this.arapMultiSettleDetails = arapMultiSettleDetails;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
}
