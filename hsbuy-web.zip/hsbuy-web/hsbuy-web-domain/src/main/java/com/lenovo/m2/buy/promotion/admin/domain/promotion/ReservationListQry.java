package com.lenovo.m2.buy.promotion.admin.domain.promotion;


import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ReservationListQry implements Serializable{

    private String gcode;

    private String gname;

    private Integer terminal;

    private String membercode;

    private String phone;

    private String reservationStartTime;

    private String reservationEndTime;

    private Integer pageNum;

    private Integer pageSize;


    public String getMembercode() {
        return membercode;
    }

    public void setMembercode(String membercode) {
        this.membercode = membercode == null ? null : membercode.trim();
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname == null ? null : gname.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public Integer getTerminal() {
        return terminal;
    }

    public void setTerminal(Integer terminal) {
        this.terminal = terminal;
    }

    public String getGcode() {
        return gcode;
    }

    public void setGcode(String gcode) {
        this.gcode = gcode;
    }


    public String getReservationStartTime() {
        return reservationStartTime;
    }

    public void setReservationStartTime(String reservationStartTime) {
        this.reservationStartTime = reservationStartTime;
    }

    public String getReservationEndTime() {
        return reservationEndTime;
    }

    public void setReservationEndTime(String reservationEndTime) {
        this.reservationEndTime = reservationEndTime;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Map<String,Object> toMap(){
        Map<String,Object> ret = new HashMap<>();
        ret.put("gcode", this.gcode);
        ret.put("gname", this.gname);
        ret.put("terminal", this.terminal);
        ret.put("membercode", this.membercode);
        ret.put("phone", this.phone);
        ret.put("reservationStartTime",this.reservationStartTime);
        ret.put("reservationEndTime",this.reservationEndTime);
        return ret;
    }
}