package com.lenovo.m2.buy.promotion.admin.domain.pay.outpay;

import java.io.Serializable;

/**
 * Created by jh on 2017/8/8.
 */
public class Points implements Serializable {
    private Integer usedPoints =0 ;    //已使用积分
    private Integer availablePoints;   // 可用积分
    private Integer pointStatus = 0;    //0:不可用 1：可用
    private Integer pointRate;       //积分比例

    public Integer getPointRate() {
        return pointRate;
    }

    public void setPointRate(Integer pointRate) {
        this.pointRate = pointRate;
    }


    public Integer getUsedPoints() {
        return usedPoints;
    }

    public void setUsedPoints(Integer usedPoints) {
        this.usedPoints = usedPoints;
    }

    public Integer getAvailablePoints() {
        return availablePoints;
    }

    public void setAvailablePoints(Integer availablePoints) {
        this.availablePoints = availablePoints;
    }

    public Integer getPointStatus() {
        return pointStatus;
    }

    public void setPointStatus(Integer pointStatus) {
        this.pointStatus = pointStatus;
    }

    @Override
    public String toString() {
        return "Points{" +
                "usedPoints=" + usedPoints +
                ", availablePoints=" + availablePoints +
                ", pointStatus=" + pointStatus +
                ", pointRate='" + pointRate + '\'' +
                '}';
    }
}
