package com.lenovo.m2.buy.promotion.admin.domain.pay.order;

/**
 *
 * @author kangjie
 *
 */
public class MongoOrderDetail extends MongoOrder {

	private String cpaymoney;// 支付订单金额（为客户端自行计算的价格，客户端以此价格与服务器端计算的价格做校验）
	private String couponids;// 使用的优惠卷id集合（多个优惠卷用逗号分隔）
	private String deliverid;// 收货人id
	
	private String discount; //优惠总价（即折扣总价）
	private String coupon = "0.00";   //优惠卷总价
	
	
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	public String getCoupon() {
		return coupon;
	}
	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}
	public String getCpaymoney() {
		return cpaymoney;
	}
	public void setCpaymoney(String cpaymoney) {
		this.cpaymoney = cpaymoney;
	}
	public String getCouponids() {
		return couponids;
	}
	public void setCouponids(String couponids) {
		this.couponids = couponids;
	}
	
	public String getDeliverid() {
		return deliverid;
	}
	public void setDeliverid(String deliverid) {
		this.deliverid = deliverid;
	}
	
}
