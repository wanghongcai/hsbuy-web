package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

/**
 * 招商银行支付请求实体
 *
 */
public class CmbPayReq {
	
	private boolean success;
	private String msg;

	/**地区*/
	private String branchid;

	/**商户号*/
	private String cono;

	/**日期  20140425*/
	private String date;

	/**订单号*/
	private String billno;

	/**金额 12.43*/
	private String amount;

	/**商户参数*/
	private String merchantPara;

	/**商户URL*/
	private String merchantUrl;

	/**校验码*/
	private String merchantCode;

	public String getBranchid() {
		return branchid;
	}

	public void setBranchid(String branchid) {
		this.branchid = branchid;
	}

	public String getCono() {
		return cono;
	}

	public void setCono(String cono) {
		this.cono = cono;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getBillno() {
		return billno;
	}

	public void setBillno(String billno) {
		this.billno = billno;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getMerchantPara() {
		return merchantPara;
	}

	public void setMerchantPara(String merchantPara) {
		this.merchantPara = merchantPara;
	}

	public String getMerchantUrl() {
		return merchantUrl;
	}

	public void setMerchantUrl(String merchantUrl) {
		this.merchantUrl = merchantUrl;
	}

	public String getMerchantCode() {
		return merchantCode;
	}

	public void setMerchantCode(String merchantCode) {
		this.merchantCode = merchantCode;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
}
