package com.lenovo.m2.buy.promotion.admin.domain.pay.wxpay;

/**
 * Created by kenvin on 2014/10/21.
 */
public class BaseResp {
    private String errcode = "0";
    private String errmsg = "";

    public String getErrcode() {
        return errcode;
    }

    public void setErrcode(String errcode) {
        this.errcode = errcode;
    }

    public String getErrmsg() {
        return errmsg;
    }

    public void setErrmsg(String errmsg) {
        this.errmsg = errmsg;
    }
}
