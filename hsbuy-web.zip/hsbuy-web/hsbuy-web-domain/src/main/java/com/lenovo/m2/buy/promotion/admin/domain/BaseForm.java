package com.lenovo.m2.buy.promotion.admin.domain;

import com.lenovo.m2.buy.promotion.admin.soa.utils.JsonUtil;

/**
 * Created by wangrq1 on 2017/2/7.
 */
public class BaseForm {

    private int shopId;
    private String authdata;

    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
    }

    public String getAuthdata() {
        return authdata;
    }

    public void setAuthdata(String authdata) {
        this.authdata = authdata;
    }

    public AuthData parseAuthData(){

    try{
        return JsonUtil.fromJson(authdata, AuthData.class);
        
    }catch (Exception e){
        e.printStackTrace();
        return null;
    }

}




}
