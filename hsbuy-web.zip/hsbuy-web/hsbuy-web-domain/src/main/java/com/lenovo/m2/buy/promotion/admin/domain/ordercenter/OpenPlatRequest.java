package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.lenovo.m2.arch.tool.util.DateFormatUtils;
import com.lenovo.m2.hsbuy.domain.order.logistics.RemoteLogistic;

import java.io.Serializable;
import java.util.Date;

public class OpenPlatRequest implements Serializable {
    private String app_key;
    private String format;
    private String method;
    private String shopid;
    private String sign;
    private String source;
    private Number terminal;
    private String timestamp;
    private String unique;
    private String v;
    //订单号
    private String orderId;
    //快递单号
    private String logiNo;
    //物流公司编号
    private String logisticsCode;

    public boolean isNull() {
        if (StringUtils.isEmpty(logiNo) || StringUtils.isEmpty(this.orderId) || StringUtils.isEmpty(this.logisticsCode)) {
            return true;
        }
        return false;
    }

    /**
     * 对象转换
     *
     * @param orderId
     * @return
     */
    public RemoteLogistic genRemoteLogistic(String orderId) {
        RemoteLogistic remoteLogistic = new RemoteLogistic();
        remoteLogistic.setOrderCode(StringUtils.isEmpty(orderId) ? this.getOrderId() : orderId);
        remoteLogistic.setLogiCode(this.getLogisticsCode());
        remoteLogistic.setLogiNo(this.getLogiNo());
        remoteLogistic.setLogiName(this.getLogisticsCode());
        remoteLogistic.setShipDate(DateFormatUtils.format(new Date()));
        remoteLogistic.setOrderType("ZOR");
        remoteLogistic.setShipStatus("1");
        remoteLogistic.setLogiType("0");
        return remoteLogistic;
    }


    public String getLogiNo() {
        return logiNo;
    }

    public void setLogiNo(String logiNo) {
        this.logiNo = logiNo;
    }

    public String getMethod() {
        return this.method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getApp_key() {
        return this.app_key;
    }

    public void setApp_key(String app_key) {
        this.app_key = app_key;
    }

    public String getSign() {
        return this.sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getTimestamp() {
        return this.timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getFormat() {
        return this.format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getV() {
        return this.v;
    }

    public void setV(String v) {
        this.v = v;
    }

    public Number getTerminal() {
        return this.terminal;
    }

    public void setTerminal(Number terminal) {
        this.terminal = terminal;
    }

    public String getSource() {
        return this.source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getUnique() {
        return this.unique;
    }

    public void setUnique(String unique) {
        this.unique = unique;
    }

    public String getShopid() {
        return this.shopid;
    }

    public void setShopid(String shopid) {
        this.shopid = shopid;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getLogisticsCode() {
        return this.logisticsCode;
    }

    public void setLogisticsCode(String logisticsCode) {
        this.logisticsCode = logisticsCode;
    }
}