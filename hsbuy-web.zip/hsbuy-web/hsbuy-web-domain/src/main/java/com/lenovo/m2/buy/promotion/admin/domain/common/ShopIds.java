package com.lenovo.m2.buy.promotion.admin.domain.common;


public class ShopIds {
    private Integer shopType;
    private String shopName;

    public Integer getShopType() {
        return shopType;
    }

    public void setShopType(Integer shopType) {
        this.shopType = shopType;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }
}