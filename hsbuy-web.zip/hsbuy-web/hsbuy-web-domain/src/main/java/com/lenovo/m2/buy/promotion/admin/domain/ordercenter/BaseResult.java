
package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

/**
 * 对返回结果的公共部分封装
 */
public class BaseResult implements java.io.Serializable {

    private static final long serialVersionUID = 1L;

}

