package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import java.io.Serializable;

/**
 * 对账文件数据模型
 * Created by tianchuyang on 2016/11/9.
 */
public class UmPaySettleFileModel implements Serializable {

    private static final long serialVersionUID = 6176152541847707272L;

    private String mer_id;
    private String goods_id;
    private String mobile_id;
    private String order_id;
    private String mer_date;
    private String pay_date;
    private String amount;
    private String gate_id;
    private String settle_date;
    private String trans_type;
    private String trans_state;
    private String bank_check;
    private String product_id;
    private String refund_no;
    private String trans_time;

    public UmPaySettleFileModel() {
    }

    public String getMer_id() {
        return mer_id;
    }

    public void setMer_id(String mer_id) {
        this.mer_id = mer_id;
    }

    public String getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id;
    }

    public String getMobile_id() {
        return mobile_id;
    }

    public void setMobile_id(String mobile_id) {
        this.mobile_id = mobile_id;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getMer_date() {
        return mer_date;
    }

    public void setMer_date(String mer_date) {
        this.mer_date = mer_date;
    }

    public String getPay_date() {
        return pay_date;
    }

    public void setPay_date(String pay_date) {
        this.pay_date = pay_date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getGate_id() {
        return gate_id;
    }

    public void setGate_id(String gate_id) {
        this.gate_id = gate_id;
    }

    public String getSettle_date() {
        return settle_date;
    }

    public void setSettle_date(String settle_date) {
        this.settle_date = settle_date;
    }

    public String getTrans_type() {
        return trans_type;
    }

    public void setTrans_type(String trans_type) {
        this.trans_type = trans_type;
    }

    public String getTrans_state() {
        return trans_state;
    }

    public void setTrans_state(String trans_state) {
        this.trans_state = trans_state;
    }

    public String getBank_check() {
        return bank_check;
    }

    public void setBank_check(String bank_check) {
        this.bank_check = bank_check;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getRefund_no() {
        return refund_no;
    }

    public void setRefund_no(String refund_no) {
        this.refund_no = refund_no;
    }

    public String getTrans_time() {
        return trans_time;
    }

    public void setTrans_time(String trans_time) {
        this.trans_time = trans_time;
    }
}
