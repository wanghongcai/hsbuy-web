package com.lenovo.m2.buy.promotion.admin.domain.pay.order;

public class OrderDetailDescriptionJSONPlist {
	private String ptime;// 支付时间
	private String pno;// 支付单号
	private String pfrom;// 支付来源
	private String pmoney;// 支付金额

	public String getPfrom() {
		return pfrom;
	}

	public void setPfrom(String pfrom) {
		this.pfrom = pfrom;
	}

	public String getPmoney() {
		return pmoney;
	}

	public void setPmoney(String pmoney) {
		this.pmoney = pmoney;
	}

	public String getPtime() {
		return ptime;
	}

	public void setPtime(String ptime) {
		this.ptime = ptime;
	}

	public String getPno() {
		return pno;
	}

	public void setPno(String pno) {
		this.pno = pno;
	}

}
