package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

import com.lenovo.m2.buy.promotion.admin.common.utils.JsonUtil;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang.StringUtils;

import java.util.Map;

/**
 * 待审核订单列表
 * @Author licy13
 * @Date 2017/3/6
 */

public class ToAuditOrderListParam extends BaseParam {

    private int pageSize;
    private int pageNum;
    /**
     * @Param 分销商编码
     */
    private String faId;

    private String filterJson;

    private Map<String,Object> filterMap;

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public String getFaId() {
        return faId;
    }

    public void setFaId(String faId) {
        this.faId = faId;
    }

    public String getFilterJson() {
        return filterJson;
    }

    public void setFilterJson(String filterJson) {
        this.filterJson = filterJson;
        if(StringUtils.isEmpty(filterJson)){
            filterMap=new HashedMap();
        }else {
            filterMap= JsonUtil.fromJson(filterJson,Map.class);
        }
    }

    public Map<String, Object> getFilterMap() {
        if(filterMap==null) return new HashedMap();
        return filterMap;
    }

}
