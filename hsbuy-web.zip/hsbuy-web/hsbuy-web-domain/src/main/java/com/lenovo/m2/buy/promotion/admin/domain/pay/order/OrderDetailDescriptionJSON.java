package com.lenovo.m2.buy.promotion.admin.domain.pay.order;

import java.util.List;

/**
 *
 * @author kangjie
 * 订单详情
 */
public class OrderDetailDescriptionJSON extends BaseInfo {
	private String orderno;       //订单编号
	private String orderstatus;   //订单状态名称（包含物流状态，是否退货状态）
	private String orderstatuscode;//订单状态代码
	private String ispay;         //是否已支付
    private String faid;          //代理商ID
	private String ordermoney;    //订单商品总金额
	private String discount;      //优惠总价（即折扣总价）
	private String coupon;        //优惠卷总价
	private String tranmoney;        //运费
	private String paymoney;      //支付订单金额
	private String orderremark;   //订单备注
	private String paytype;       //付款方式名称
	private String delivername;   //收货人
	private String deliveraddr;   //收货地址(全地址)
	private String delivertel;    //收货人电话号码
	private String invoicetype;   //发票类型名称
	private String invoicehead;   //发票抬头
	private String iselectroniccoupons;//发票类型是否是电子券：是 1 ,否 0
	private List<OrderDetailDescriptionJSONGlist> glist;   //商品列表
	private List<OrderDetailDescriptionJSONLglist> lglist; //物流快递详情
	private List<OrderDetailDescriptionJSONPlist> plist; //支付列表（目前二期中只有一条记录）
	private List<OrderDetailDescriptionJSONSlist> slist; //订单状态追踪列表
	private String salestype; // 销售类型
	private String statusBar; // 抢购状态

    public String getFaid() {
        return faid;
    }
    public void setFaid(String faid) {
        this.faid = faid;
    }
    public String getStatusBar() {
		return statusBar;
	}
	public void setStatusBar(String statusBar) {
		this.statusBar = statusBar;
	}
	public String getSalestype() {
		return salestype;
	}
	public void setSalestype(String salestype) {
		this.salestype = salestype;
	}
	public String getTranmoney() {
		return tranmoney;
	}
	public void setTranmoney(String tranmoney) {
		this.tranmoney = tranmoney;
	}
	public List<OrderDetailDescriptionJSONPlist> getPlist() {
		return plist;
	}
	public void setPlist(List<OrderDetailDescriptionJSONPlist> plist) {
		this.plist = plist;
	}
	public List<OrderDetailDescriptionJSONSlist> getSlist() {
		return slist;
	}
	public void setSlist(List<OrderDetailDescriptionJSONSlist> slist) {
		this.slist = slist;
	}	
	
	public String getOrderstatuscode() {
		return orderstatuscode;
	}
	public void setOrderstatuscode(String orderstatuscode) {
		this.orderstatuscode = orderstatuscode;
	}
	public String getOrderno() {
		return orderno;
	}
	public void setOrderno(String orderno) {
		this.orderno = orderno;
	}
	public String getOrderstatus() {
		return orderstatus;
	}
	public void setOrderstatus(String orderstatus) {
		this.orderstatus = orderstatus;
	}
	public String getIspay() {
		return ispay;
	}
	public void setIspay(String ispay) {
		this.ispay = ispay;
	}
	public String getOrdermoney() {
		return ordermoney;
	}
	public void setOrdermoney(String ordermoney) {
		this.ordermoney = ordermoney;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	public String getCoupon() {
		return coupon;
	}
	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}
	public String getPaymoney() {
		return paymoney;
	}
	public void setPaymoney(String paymoney) {
		this.paymoney = paymoney;
	}
	public String getOrderremark() {
		return orderremark;
	}
	public void setOrderremark(String orderremark) {
		this.orderremark = orderremark;
	}
	public String getPaytype() {
		return paytype;
	}
	public void setPaytype(String paytype) {
		this.paytype = paytype;
	}
	public String getDelivername() {
		return delivername;
	}
	public void setDelivername(String delivername) {
		this.delivername = delivername;
	}
	public String getDeliveraddr() {
		return deliveraddr;
	}
	public void setDeliveraddr(String deliveraddr) {
		this.deliveraddr = deliveraddr;
	}
	public String getDelivertel() {
		return delivertel;
	}
	public void setDelivertel(String delivertel) {
		this.delivertel = delivertel;
	}
	public String getInvoicetype() {
		return invoicetype;
	}
	public void setInvoicetype(String invoicetype) {
		this.invoicetype = invoicetype;
	}
	public String getInvoicehead() {
		return invoicehead;
	}
	public void setInvoicehead(String invoicehead) {
		this.invoicehead = invoicehead;
	}
	public List<OrderDetailDescriptionJSONGlist> getGlist() {
		return glist;
	}
	public void setGlist(List<OrderDetailDescriptionJSONGlist> glist) {
		this.glist = glist;
	}
	public List<OrderDetailDescriptionJSONLglist> getLglist() {
		return lglist;
	}
	public void setLglist(List<OrderDetailDescriptionJSONLglist> lglist) {
		this.lglist = lglist;
	}
	public String getIselectroniccoupons() {
		return iselectroniccoupons;
	}
	public void setIselectroniccoupons(String iselectroniccoupons) {
		this.iselectroniccoupons = iselectroniccoupons;
	}
}
