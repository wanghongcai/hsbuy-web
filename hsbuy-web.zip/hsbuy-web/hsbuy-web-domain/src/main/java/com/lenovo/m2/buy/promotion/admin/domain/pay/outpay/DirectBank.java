package com.lenovo.m2.buy.promotion.admin.domain.pay.outpay;

import java.io.Serializable;

/**
 * 惠商直连网银
 * Created by tianchuyang on 2017/1/10.
 */
public class DirectBank implements Serializable,Comparable<DirectBank> {

    private Integer bank_type;
    private Integer bank_code;
    private String bank_abbr;
    private Integer card_type;

    public DirectBank() {
    }

    public DirectBank(Integer bank_type, Integer bank_code, String bank_abbr, Integer card_type) {
        this.bank_type = bank_type;
        this.bank_code = bank_code;
        this.bank_abbr = bank_abbr;
        this.card_type = card_type;
    }

    public Integer getBank_type() {
        return bank_type;
    }

    public void setBank_type(Integer bank_type) {
        this.bank_type = bank_type;
    }

    public Integer getBank_code() {
        return bank_code;
    }

    public void setBank_code(Integer bank_code) {
        this.bank_code = bank_code;
    }

    public String getBank_abbr() {
        return bank_abbr;
    }

    public void setBank_abbr(String bank_abbr) {
        this.bank_abbr = bank_abbr;
    }

    public Integer getCard_type() {
        return card_type;
    }

    public void setCard_type(Integer card_type) {
        this.card_type = card_type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DirectBank that = (DirectBank) o;

        if (!bank_type.equals(that.bank_type)) return false;
        if (!bank_code.equals(that.bank_code)) return false;
        if (!bank_abbr.equals(that.bank_abbr)) return false;
        return card_type.equals(that.card_type);
    }

    @Override
    public int hashCode() {
        int result = bank_type.hashCode();
        result = 31 * result + bank_code.hashCode();
        result = 31 * result + bank_abbr.hashCode();
        result = 31 * result + card_type.hashCode();
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("{");
        sb.append("\"bank_type\":")
                .append(bank_type);
        sb.append(",\"bank_code\":")
                .append(bank_code);
        sb.append(",\"bank_abbr\":\"")
                .append(bank_abbr).append('\"');
        sb.append(",\"card_type\":")
                .append(card_type);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int compareTo(DirectBank o) {
        if (this.getBank_type().compareTo(o.getBank_type()) == 0){
            return this.getBank_code().compareTo(o.getBank_code());
        }else {
            return this.getBank_type().compareTo(o.getBank_type());
        }
    }
}
