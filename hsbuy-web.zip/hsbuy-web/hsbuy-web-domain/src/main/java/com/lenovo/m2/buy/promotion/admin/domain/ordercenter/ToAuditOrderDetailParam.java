package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

/**
 * 待审核订单详情
 * @Author licy13
 * @Date 2017/3/6
 */

public class ToAuditOrderDetailParam extends BaseParam {
    private String orderId;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
