package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

/**
 * Created by Administrator on 2017-07-08.
 */
public class PayRecordsSaveParam extends BaseParam {
    private String payRecordsJson;

    public String getPayRecordsJson() {
        return payRecordsJson;
    }

    public void setPayRecordsJson(String payRecordsJson) {
        this.payRecordsJson = payRecordsJson;
    }

    @Override
    public String toString() {
        return "PayRecordsSaveParam{" +
                "payRecordsJson='" + payRecordsJson + '\'' +
                '}';
    }
}
