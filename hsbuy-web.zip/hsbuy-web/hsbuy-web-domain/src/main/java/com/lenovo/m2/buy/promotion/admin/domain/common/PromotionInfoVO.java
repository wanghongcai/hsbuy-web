package com.lenovo.m2.buy.promotion.admin.domain.common;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.lenovo.m2.buy.promotion.admin.common.enums.PromorionDisabled;
import com.lenovo.m2.buy.promotion.admin.common.enums.PromotionCrowd;
import com.lenovo.m2.buy.promotion.admin.common.enums.PromotionEnum;
import com.lenovo.m2.buy.promotion.admin.common.utils.CommonUtils;
import com.lenovo.m2.buy.promotion.admin.common.utils.CustomDateSerializer;
import com.lenovo.m2.buy.promotion.admin.common.utils.DateUtils;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import java.util.Date;

/**
 * Created by luqian on 2015-11-12.
 */
public class PromotionInfoVO {

	private String id;
    private String promotionName;
    private String promotionType;
    private String platformName;
    private String description;
    private String disabled;
    private String promotionURL;
    private String status;
    private String applyTo = "0";//适用人群
    private String mainProductMaterial;
    private String relProductMaterial;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private Date createTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private Date fromtime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private Date totime;

    public String getPromotionName() {
        return promotionName;
    }

    public String getPromotionType() {
    	if(this.promotionType == null){
    		return "";
    	}
        if(CommonUtils.isNumeric(this.promotionType)){
           return  PromotionEnum.getPromotionByType(Integer.valueOf(this.promotionType)).getDescr();
        }else{
        	return String.valueOf(this.promotionType);
        }
    }

    public String getDescription() {
        return description;
    }

    public String getDisabled() {
        if(CommonUtils.isNumeric(this.disabled)){
           return PromorionDisabled.getDisabledByType(Integer.valueOf(this.disabled)).getDescr();
        }
        return "undefined";
    }

    public String getPromotionURL() {
        return promotionURL;
    }

    public String getStatus() {
    	if("0".equals(this.status)){
    		return "新建";
    	}else if("1".equals(this.status)){
    		return "审核驳回";
    	}else if("2".equals(this.status)){
    		return "审核通过";
    	}else if("3".equals(this.status)){
    		return "待审核";
    	}else{
            return "未知";
        }

    }

    public String getApplyTo() {
//        if(CommonUtils.isNumeric(this.applyTo)){
//            return PromotionCrowd.getCrowdByType(Integer.valueOf(this.applyTo)).getDescr();
//        }
        return "";
    }


    public String getMainProductMaterial() {
        return mainProductMaterial;
    }

    public String getRelProductMaterial() {
        return relProductMaterial;
    }


    public void setPromotionName(String promotionName) {
        this.promotionName = promotionName;
    }

    public void setPromotionType(String promotionType) {
        this.promotionType = promotionType;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDisabled(String disabled) {
        this.disabled = disabled;
    }

    public void setPromotionURL(String promotionURL) {
        this.promotionURL = promotionURL;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setApplyTo(String applyTo) {
        this.applyTo = applyTo;
    }

    public void setMainProductMaterial(String mainProductMaterial) {
        this.mainProductMaterial = mainProductMaterial;
    }

    public void setRelProductMaterial(String relProductMaterial) {
        this.relProductMaterial = relProductMaterial;
    }

    @JsonSerialize(using = CustomDateSerializer.class)  
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getPlatformName() {
        return platformName;
    }

    public void setPlatformName(String platformName) {
        this.platformName = platformName;
    }
    
    

    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

    public Date getFromtime() {
        return fromtime;
    }

    public Date getTotime() {
        return totime;
    }

    public void setFromtime(Date fromtime) {
        this.fromtime = fromtime;
    }

    public void setTotime(Date totime) {
        this.totime = totime;
    }

    @Override
    public String toString() {
        return "PromotionInfoVO{" +
                "id='" + id + '\'' +
                ", promotionName='" + promotionName + '\'' +
                ", promotionType='" + promotionType + '\'' +
                ", platformName='" + platformName + '\'' +
                ", description='" + description + '\'' +
                ", disabled='" + disabled + '\'' +
                ", promotionURL='" + promotionURL + '\'' +
                ", status='" + status + '\'' +
                ", applyTo='" + applyTo + '\'' +
                ", mainProductMaterial='" + mainProductMaterial + '\'' +
                ", relProductMaterial='" + relProductMaterial + '\'' +
                ", createTime=" + createTime +
                ", fromtime=" + fromtime +
                ", totime=" + totime +
                '}';
    }
}
