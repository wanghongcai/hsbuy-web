package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/** 支付结果请求实体
 * Created by tianchuyang on 2016/11/9.
 */
public class UmPayResultReq implements Serializable {

    private static final long serialVersionUID = 8287357041298590455L;

    private String service;
    private String charset;
    private String mer_id;
    private String sign_type;
    private String sign;
    private String version;

    // 业务参数
    private String trade_no;
    private String goods_id;
    private String order_id;
    private String mer_date;
    private String pay_date;
    private String amount;
    private String amt_type;
    private String pay_type;
    private String media_id;
    private String media_type;
    private String settle_date;
    private String mer_priv;
    private String trade_state;
    private String pay_seq;
    private String error_code;
    private String gete_id;
    private String last_four_cardid;

    public UmPayResultReq() {

    }

    public UmPayResultReq(HttpServletRequest request) {
        this.service = request.getParameter("service");
        this.charset= request.getParameter("charset");
        this.mer_id= request.getParameter("mer_id");
        this.sign_type= request.getParameter("sign_type");
        this.sign= request.getParameter("sign");
        this.version= request.getParameter("version");
        this.trade_no= request.getParameter("trade_no");
        this.goods_id= request.getParameter("goods_id");
        this.order_id= request.getParameter("order_id");
        this.mer_date= request.getParameter("mer_date");
        this.pay_date= request.getParameter("pay_date");
        this.amount= request.getParameter("amount");
        this.amt_type= request.getParameter("amt_type");
        this.pay_type= request.getParameter("pay_type");
        this.media_id= request.getParameter("media_id");
        this.media_type= request.getParameter("media_type");
        this.settle_date= request.getParameter("settle_date");
        this.mer_priv= request.getParameter("mer_priv");
        this.trade_state= request.getParameter("trade_state");
        this.pay_seq= request.getParameter("pay_seq");
        this.error_code= request.getParameter("error_code");
        this.gete_id= request.getParameter("gete_id");
        this.last_four_cardid= request.getParameter("last_four_cardid");
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public String getMer_id() {
        return mer_id;
    }

    public void setMer_id(String mer_id) {
        this.mer_id = mer_id;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getTrade_no() {
        return trade_no;
    }

    public void setTrade_no(String trade_no) {
        this.trade_no = trade_no;
    }

    public String getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getMer_date() {
        return mer_date;
    }

    public void setMer_date(String mer_date) {
        this.mer_date = mer_date;
    }

    public String getPay_date() {
        return pay_date;
    }

    public void setPay_date(String pay_date) {
        this.pay_date = pay_date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getAmt_type() {
        return amt_type;
    }

    public void setAmt_type(String amt_type) {
        this.amt_type = amt_type;
    }

    public String getPay_type() {
        return pay_type;
    }

    public void setPay_type(String pay_type) {
        this.pay_type = pay_type;
    }

    public String getMedia_id() {
        return media_id;
    }

    public void setMedia_id(String media_id) {
        this.media_id = media_id;
    }

    public String getMedia_type() {
        return media_type;
    }

    public void setMedia_type(String media_type) {
        this.media_type = media_type;
    }

    public String getSettle_date() {
        return settle_date;
    }

    public void setSettle_date(String settle_date) {
        this.settle_date = settle_date;
    }

    public String getMer_priv() {
        return mer_priv;
    }

    public void setMer_priv(String mer_priv) {
        this.mer_priv = mer_priv;
    }

    public String getTrade_state() {
        return trade_state;
    }

    public void setTrade_state(String trade_state) {
        this.trade_state = trade_state;
    }

    public String getPay_seq() {
        return pay_seq;
    }

    public void setPay_seq(String pay_seq) {
        this.pay_seq = pay_seq;
    }

    public String getError_code() {
        return error_code;
    }

    public void setError_code(String error_code) {
        this.error_code = error_code;
    }

    public String getGete_id() {
        return gete_id;
    }

    public void setGete_id(String gete_id) {
        this.gete_id = gete_id;
    }

    public String getLast_four_cardid() {
        return last_four_cardid;
    }

    public void setLast_four_cardid(String last_four_cardid) {
        this.last_four_cardid = last_four_cardid;
    }
}
