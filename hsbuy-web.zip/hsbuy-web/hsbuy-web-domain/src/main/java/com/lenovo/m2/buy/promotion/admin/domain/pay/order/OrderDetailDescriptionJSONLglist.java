package com.lenovo.m2.buy.promotion.admin.domain.pay.order;

/**
 *
 * @author kangjie
 *
 */
public class OrderDetailDescriptionJSONLglist {
	private String lgtime;
	private String lgdesc;
	public String getLgtime() {
		return lgtime;
	}
	public void setLgtime(String lgtime) {
		this.lgtime = lgtime;
	}
	public String getLgdesc() {
		return lgdesc;
	}
	public void setLgdesc(String lgdesc) {
		this.lgdesc = lgdesc;
	}
}
