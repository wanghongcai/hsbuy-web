package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * 退费信息补录请求实体
 * Created by tianchuyang on 2016/11/9.
 */
public class UmPayRefundInfoReplenishReq implements Serializable {

    private static final long serialVersionUID = -4034233069230030250L;

    private String service;
    private String sign_type;
    private String charset;
    private String res_format;
    private String sign;
    private String mer_id;
    private String version;
    // 业务参数
    private String refund_no;
    private String card_holder;
    private String card_id;
    private String gate_id;
    private String card_branch_name;


    public UmPayRefundInfoReplenishReq() {

    }

    public UmPayRefundInfoReplenishReq(HttpServletRequest request) {

        this.service = request.getParameter("service");
        this.sign_type = request.getParameter("sign_type");
        this.charset = request.getParameter("charset");
        this.res_format = request.getParameter("res_format");
        this.sign = request.getParameter("sign");
        this.mer_id = request.getParameter("mer_id");
        this.version = request.getParameter("version");
        // 业务参数
        this.refund_no = request.getParameter("refund_no");
        this.card_holder = request.getParameter("card_holder");
        this.card_id = request.getParameter("card_id");
        this.gate_id = request.getParameter("gate_id");
        this.card_branch_name = request.getParameter("card_branch_name");
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public String getRes_format() {
        return res_format;
    }

    public void setRes_format(String res_format) {
        this.res_format = res_format;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getMer_id() {
        return mer_id;
    }

    public void setMer_id(String mer_id) {
        this.mer_id = mer_id;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getRefund_no() {
        return refund_no;
    }

    public void setRefund_no(String refund_no) {
        this.refund_no = refund_no;
    }

    public String getCard_holder() {
        return card_holder;
    }

    public void setCard_holder(String card_holder) {
        this.card_holder = card_holder;
    }

    public String getCard_id() {
        return card_id;
    }

    public void setCard_id(String card_id) {
        this.card_id = card_id;
    }

    public String getGate_id() {
        return gate_id;
    }

    public void setGate_id(String gate_id) {
        this.gate_id = gate_id;
    }

    public String getCard_branch_name() {
        return card_branch_name;
    }

    public void setCard_branch_name(String card_branch_name) {
        this.card_branch_name = card_branch_name;
    }
}
