package com.lenovo.m2.buy.promotion.admin.domain.pay;

/**
 * Created by caoxd2 on 2015/5/30.
 */
public enum Payment {
    ZhaoShang(0,"招商银行"),AliPay(1,"支付宝"),UnionPay(2,"银联支付"),AliPureGateway(4,"支付宝纯网关支付");

    private int payType;
    private String desc;
    private Payment(int payType,String desc){
        this.payType = payType;
        this.desc = desc;
    }

    public int getPayType() {
        return payType;
    }

    public void setPayType(int payType) {
        this.payType = payType;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
