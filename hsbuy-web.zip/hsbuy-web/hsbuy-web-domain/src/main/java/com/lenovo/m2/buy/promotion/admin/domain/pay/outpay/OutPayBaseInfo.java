package com.lenovo.m2.buy.promotion.admin.domain.pay.outpay;


import java.io.Serializable;

/**
 * MengQiang
 */
public class OutPayBaseInfo implements Serializable {


    public OutPayBaseInfo(Integer rc, String msg, String result) {
        this.rc = rc;
        this.msg = msg;
        this.result = result;
    }

    private int rc;
    private String msg;
    private String result;

    public int getRc() {
        return rc;
    }

    public void setRc(int rc) {
        this.rc = rc;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
