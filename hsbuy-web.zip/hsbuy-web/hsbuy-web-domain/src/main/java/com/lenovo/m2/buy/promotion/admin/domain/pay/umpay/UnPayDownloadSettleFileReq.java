package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * 数据对账请求实体
 * Created by tianchuyang on 2016/11/9.
 */
public class UnPayDownloadSettleFileReq implements Serializable {

    private static final long serialVersionUID = 5149032788166756120L;

    private String service;
    private String sign_type;
    private String sign;
    private String mer_id;
    private String version;
    // 业务参数
    private String settle_date;

    public UnPayDownloadSettleFileReq() {
    }

    public UnPayDownloadSettleFileReq(HttpServletRequest request) {
        this.service = request.getParameter("service");
        this.sign_type = request.getParameter("sign_type");
        this.sign = request.getParameter("sign");
        this.mer_id = request.getParameter("mer_id");
        this.version = request.getParameter("version");
        // 业务参数
        this.settle_date = request.getParameter("settle_date");
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getMer_id() {
        return mer_id;
    }

    public void setMer_id(String mer_id) {
        this.mer_id = mer_id;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getSettle_date() {
        return settle_date;
    }

    public void setSettle_date(String settle_date) {
        this.settle_date = settle_date;
    }
}
