package com.lenovo.m2.buy.promotion.admin.domain.promotion;


import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.soa.enums.GloablErrorMessageEnum;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;

/**
 * Created by lihc5 on 2017/5/11.
 */
public class SeckillActivityForm implements Serializable {

    private Long id;

    //活动名称
    private String activityName;

    //抢购类型 (2:闪购 3：限时抢购)
    private int activityType;

    //是否需要提前预约
    private Integer isReservation;

    //抢购开始时间
    private String seckillStartTime;

    private String seckillEndTime;

    //商品编码
    private String code;

    //商品名称
    private String name;

    //物料编号
    private String materialNumber;

    //FA名称
    private String faName;

    //缩略图地址
    private String thumbnail;

    //折扣金额
    private double seckillMoney;

    //最大购买数量
    private int maxNum;

    //协同人数
    private int addDiscountCount;

    //预约开始时间
    private String reservationStartTime;

    //预约结束时间

    private String reservationEndTime;

    //非预约开始抢购时间
    private  String noReservationSeckillStartTime;

    //平台
    private int terminal;

    //是否启用(0:未启用 1：启用)
    private  Integer markeTable = 0;


    private Integer page;
    private Integer rows;

    private String productsStr;



    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public Integer getIsReservation() {
        return isReservation;
    }

    public void setIsReservation(int isReservation) {
        this.isReservation = isReservation;
    }

    public int getActivityType() {
        return activityType;
    }

    public void setActivityType(int activityType) {
        this.activityType = activityType;
    }


    public double getSeckillMoney() {
        return seckillMoney;
    }

    public void setSeckillMoney(double seckillMoney) {
        this.seckillMoney = seckillMoney;
    }

    public int getMaxNum() {
        return maxNum;
    }

    public void setMaxNum(int maxNum) {
        this.maxNum = maxNum;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMaterialNumber() {
        return materialNumber;
    }

    public void setMaterialNumber(String materialNumber) {
        this.materialNumber = materialNumber;
    }

    public String getFaName() {
        return faName;
    }

    public void setFaName(String faName) {
        this.faName = faName;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getRows() {
        return rows;
    }

    public void setRows(Integer rows) {
        this.rows = rows;
    }

    public int getAddDiscountCount() {
        return addDiscountCount;
    }

    public void setAddDiscountCount(int addDiscountCount) {
        this.addDiscountCount = addDiscountCount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public int getTerminal() {
        return terminal;
    }

    public void setTerminal(int terminal) {
        this.terminal = terminal;
    }

    public String getSeckillStartTime() {
        return seckillStartTime;
    }

    public void setSeckillStartTime(String seckillStartTime) {
        this.seckillStartTime = seckillStartTime;
    }

    public String getSeckillEndTime() {
        return seckillEndTime;
    }

    public void setSeckillEndTime(String seckillEndTime) {
        this.seckillEndTime = seckillEndTime;
    }

    public String getReservationStartTime() {
        return reservationStartTime;
    }

    public void setReservationStartTime(String reservationStartTime) {
        this.reservationStartTime = reservationStartTime;
    }

    public String getReservationEndTime() {
        return reservationEndTime;
    }

    public void setReservationEndTime(String reservationEndTime) {
        this.reservationEndTime = reservationEndTime;
    }

    public String getNoReservationSeckillStartTime() {
        return noReservationSeckillStartTime;
    }

    public void setNoReservationSeckillStartTime(String noReservationSeckillStartTime) {
        this.noReservationSeckillStartTime = noReservationSeckillStartTime;
    }

    public String getProductsStr() {
        return productsStr;
    }

    public void setProductsStr(String productsStr) {
        this.productsStr = productsStr;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getMarkeTable() {
        return markeTable;
    }

    public void setMarkeTable(Integer markeTable) {
        this.markeTable = markeTable;
    }




    public RemoteResult check(){
        RemoteResult remoteResult =new RemoteResult();
        remoteResult.setSuccess(false);
        if (StringUtils.isEmpty(this.activityName)){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("活动名称不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.activityType))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("抢购类型不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.seckillStartTime))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("抢购开始时间不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.seckillEndTime))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("抢购截止时间不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.terminal))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("限时抢购终端不能为空");
            return remoteResult;
        }
        remoteResult.setSuccess(true);
        return remoteResult;
    }

}
