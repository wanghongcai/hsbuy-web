package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

import java.io.Serializable;
import java.math.BigDecimal;

public class ArapMultiSettleDetail implements Serializable {

    /**
     * 惠商订单号
     */
    private String VoucherCode;

    /**
     * code表示结算方式的编码
     */
    private String SettleStyle;

    /**
     * Name表示账号名称
     */
    private String BankAccount;

    /**
     * 收款金额
     */
    private BigDecimal OrigAmount;

    public String getVoucherCode() {
        return VoucherCode;
    }

    public void setVoucherCode(String voucherCode) {
        VoucherCode = voucherCode;
    }

    public String getSettleStyle() {
        return SettleStyle;
    }

    public void setSettleStyle(String settleStyle) {
        SettleStyle = settleStyle;
    }

    public String getBankAccount() {
        return BankAccount;
    }

    public void setBankAccount(String bankAccount) {
        BankAccount = bankAccount;
    }

    public BigDecimal getOrigAmount() {
        return OrigAmount;
    }

    public void setOrigAmount(BigDecimal origAmount) {
        OrigAmount = origAmount;
    }
}
