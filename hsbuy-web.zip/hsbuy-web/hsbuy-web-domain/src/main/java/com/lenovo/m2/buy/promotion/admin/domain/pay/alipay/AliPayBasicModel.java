package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;


/**
 * 支付宝请求基本参数
 *
 */
public class AliPayBasicModel extends BaseModel {

	public AliPayBasicModel() {
		super();
	}

	public AliPayBasicModel(HttpServletRequest request) {
		super(request);

	}































}
