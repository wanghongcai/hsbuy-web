package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;

/**
 * 通联支付实体
 * Created by zhangqy10 on 2016/11/1.
 */
public class AllinpayModel extends BaseModel {

    public AllinpayModel(){super();}

    //同步回调地址
    private String return_url;

    //异步回调地址
    private String notify_url;

    //支付金额
    private String total_fee;

    //异常通知地址
    private String exception_url;

    //支付用户
    private String member_code;

    //下单时间
    private String order_time;

    //商品信息
    private String productName;

    //非代收代付
    private String payment_way = "0";
    //支付类型
    private int payment_type_id = 0;//线上支付

    // 支持网银直连
    private String accountType;
    private String bankNo;
    private String cardType;
    private String bankCode;

    public AllinpayModel(HttpServletRequest request){
        super(request);
        return_url = request.getParameter("return_url");
        notify_url = request.getParameter("notify_url");
        total_fee = request.getParameter("total_fee");
        exception_url = request.getParameter("exception_url");
        member_code = request.getParameter("member_code");
        order_time = request.getParameter("order_time");
        productName = request.getParameter("productName");
    }

    public String getReturn_url() {
        return return_url;
    }

    public void setReturn_url(String return_url) {
        this.return_url = return_url;
    }

    public String getNotify_url() {
        return notify_url;
    }

    public void setNotify_url(String notify_url) {
        this.notify_url = notify_url;
    }

    public String getPayment_way() {
        return payment_way;
    }

    public void setPayment_way(String payment_way) {
        this.payment_way = payment_way;
    }

    public String getTotal_fee() {
        return total_fee;
    }

    public void setTotal_fee(String total_fee) {
        this.total_fee = total_fee;
    }

    public String getException_url() {
        return exception_url;
    }

    public void setException_url(String exception_url) {
        this.exception_url = exception_url;
    }

    public String getMember_code() {
        return member_code;
    }

    public void setMember_code(String member_code) {
        this.member_code = member_code;
    }

    public int getPayment_type_id() {
        return payment_type_id;
    }

    public void setPayment_type_id(int payment_type_id) {
        this.payment_type_id = payment_type_id;
    }

    public String getOrder_time() {
        return order_time;
    }

    public void setOrder_time(String order_time) {
        this.order_time = order_time;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getBankNo() {
        return bankNo;
    }

    public void setBankNo(String bankNo) {
        this.bankNo = bankNo;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }
}
