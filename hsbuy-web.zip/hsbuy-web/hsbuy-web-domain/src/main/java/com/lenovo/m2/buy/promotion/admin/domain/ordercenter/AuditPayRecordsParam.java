package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

/**
 * @Author licy13
 * @Date 2017/7/8
 */

public class AuditPayRecordsParam extends BaseParam {

    //{"payId":"eeb03cf0-dc29-4f62-b759-204d6577a97f","faId":"93558ecf-6d2f-48f8-a703-e0a79e1278d0","payeeBank":"收款银行","payeeVoucher":"收款流水单号","payeePic":"http://admin.lenovouat.com","status":1,"remarks":"审核拒绝填写"}
    private String payRecordsJson;

    public String getPayRecordsJson() {
        return payRecordsJson;
    }

    public void setPayRecordsJson(String payRecordsJson) {
        this.payRecordsJson = payRecordsJson;
    }
}
