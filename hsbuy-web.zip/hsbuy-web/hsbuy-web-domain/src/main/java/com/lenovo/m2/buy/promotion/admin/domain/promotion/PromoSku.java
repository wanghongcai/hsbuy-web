package com.lenovo.m2.buy.promotion.admin.domain.promotion;

import java.math.BigDecimal;

/**
 * Created by wangrq1 on 2017/2/7.
 */
public class PromoSku {

    private String gcode;
    private String name;
    private String materialNumber;
    private String faId;
    private String faName;//分销商信息
    //物料类型
    private String materialType;
    //产品组
    private String productGroup;

    private int quantity;
    private BigDecimal discount;

    private String productid1;  //主品id
    private String productid2;  //关联品id

    public String getGcode() {
        return gcode;
    }

    public void setGcode(String gcode) {
        this.gcode = gcode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMaterialNumber() {
        return materialNumber;
    }

    public void setMaterialNumber(String materialNumber) {
        this.materialNumber = materialNumber;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }

    public String getFaId() {
        return faId;
    }

    public void setFaId(String faId) {
        this.faId = faId;
    }

    public String getFaName() {
		return faName;
	}

	public void setFaName(String faName) {
		this.faName = faName;
	}

	public String getMaterialType() {
        return materialType;

    }

    public void setMaterialType(String materialType) {
        this.materialType = materialType;
    }

    public String getProductGroup() {
        return productGroup;
    }

    public void setProductGroup(String productGroup) {
        this.productGroup = productGroup;
    }

    public String getProductid1() {
        return productid1;
    }

    public void setProductid1(String productid1) {
        this.productid1 = productid1;
    }

    public String getProductid2() {
        return productid2;
    }

    public void setProductid2(String productid2) {
        this.productid2 = productid2;
    }
}
