package com.lenovo.m2.buy.promotion.admin.domain.common;

import com.lenovo.m2.buy.promotion.admin.common.enums.GloablErrorMessageEnum;
import com.lenovo.m2.buy.promotion.admin.common.enums.PromotionEnum;
import com.lenovo.m2.buy.promotion.admin.common.exception.BusinessException;
import com.lenovo.m2.buy.promotion.admin.common.utils.CommonUtils;
import com.lenovo.m2.buy.promotion.admin.common.utils.CustomDateSerializer;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.*;

public class SalesGoodsPromotionRoles {
	
    private String id;
    
    private Integer promotioncode;   //促销编号（自增）

    private Integer promotiontype;  //促销类型

    private String promotionpic;    //促销图片

    private String promotionurl;    //促销url

    private Integer isexclusivechoice = 0;  //是否排它

    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")  
    private Date fromtime;   //起始时间
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date totime;    //截止时间

    private Integer disabled; //是否启用

    private Integer status;   //状态

    private Integer applyto = 0;  //适用人群

    private Integer sortorder = 0; //优先级

    private Integer freeshipping = 0;  //免运费

    private String platformid;   //平台id

    private BigDecimal limitorderamount = BigDecimal.ZERO;  //限制订单金额

    private BigDecimal discountamount = BigDecimal.ZERO;  //优惠金额

    private Integer limitquantity = 0;   //限制数量

    private Integer residuequantity;  //剩余数量

    private Integer isdesign = 0 ;   //是否定制
    
   
    private Date createtime;  //创建时间

    private String createby;  //创建人

    private Date updatetime;  //更新时间

    private String updateby;  //更新人
    
    private String promotionname;

    private String description;



	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public Integer getPromotioncode() {
        return promotioncode;
    }

    public void setPromotioncode(Integer promotioncode) {
        this.promotioncode = promotioncode;
    }

    public Integer getPromotiontype() {
        return promotiontype;
    }

    public void setPromotiontype(Integer promotiontype) {
        this.promotiontype = promotiontype;
    }

    public String getPromotionpic() {
        return promotionpic;
    }

    public void setPromotionpic(String promotionpic) {
        this.promotionpic = promotionpic == null ? null : promotionpic.trim();
    }

    public String getPromotionurl() {
        return promotionurl;
    }

    public void setPromotionurl(String promotionurl) {
        this.promotionurl = promotionurl == null ? null : promotionurl.trim();
    }

    public Integer getIsexclusivechoice() {
        return isexclusivechoice;
    }

    public void setIsexclusivechoice(Integer isexclusivechoice) {
        this.isexclusivechoice = isexclusivechoice;
    }

    public Date getFromtime() {
        return fromtime;
    }

    public void setFromtime(Date fromtime) {
        this.fromtime = fromtime;
    }

    public Date getTotime() {
        return totime;
    }

    public void setTotime(Date totime) {
        this.totime = totime;
    }

    public Integer getDisabled() {
        return disabled;
    }

    public void setDisabled(Integer disabled) {
        this.disabled = disabled;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getApplyto() {
        return applyto;
    }

    public void setApplyto(Integer applyto) {
        this.applyto = applyto;
    }

    public Integer getSortorder() {
        return sortorder;
    }

    public void setSortorder(Integer sortorder) {
        this.sortorder = sortorder;
    }

    public Integer getFreeshipping() {
        return freeshipping;
    }

    public void setFreeshipping(Integer freeshipping) {
        this.freeshipping = freeshipping;
    }

    public String getPlatformid() {
        return platformid;
    }

    public void setPlatformid(String platformid) {
        this.platformid = platformid == null ? null : platformid.trim();
    }

    public BigDecimal getLimitorderamount() {
        return limitorderamount;
    }

    public void setLimitorderamount(BigDecimal limitorderamount) {
        this.limitorderamount = limitorderamount;
    }

    public BigDecimal getDiscountamount() {
        return discountamount;
    }

    public void setDiscountamount(BigDecimal discountamount) {
        this.discountamount = discountamount;
    }

    public Integer getLimitquantity() {
        return limitquantity;
    }

    public void setLimitquantity(Integer limitquantity) {
        this.limitquantity = limitquantity;
    }

    public Integer getResiduequantity() {
        return residuequantity;
    }

    public void setResiduequantity(Integer residuequantity) {
        this.residuequantity = residuequantity;
    }

    public Integer getIsdesign() {
        return isdesign;
    }

    public void setIsdesign(Integer isdesign) {
        this.isdesign = isdesign;
    }

    @JsonSerialize(using = CustomDateSerializer.class)  
    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby == null ? null : createby.trim();
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby == null ? null : updateby.trim();
    }
    
    public String getPromotionname() {
        return promotionname;
    }

    public void setPromotionname(String promotionname) {
        this.promotionname = promotionname;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }
    
    /**
     * 简单校验参数
     * @return
     * @author wangrq1
     */
    public boolean check(){
    	if(StringUtils.isEmpty(this.promotionname)||
    		StringUtils.isEmpty(this.platformid)  ||
    		this.promotiontype == null ||
    		this.disabled == null||
    		this.isexclusivechoice == null){
    		return false;
    	}
    	return true;
    }
    
    /**
     * 是否需要关联品
     * @return
     * @author wangrq1
     */
    public boolean needRel(){
    	PromotionEnum type = PromotionEnum.getPromotionByType(this.promotiontype);
    	if(type == null){
    		throw new BusinessException(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode(), "promotiontype错误"+promotiontype);
    	}
    	switch (type) {
		case OPTION_GOODS:
			return true;
		default:
			return false;
		}
    }

}