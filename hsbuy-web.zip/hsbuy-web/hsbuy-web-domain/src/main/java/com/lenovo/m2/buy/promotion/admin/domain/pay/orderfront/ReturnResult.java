package com.lenovo.m2.buy.promotion.admin.domain.pay.orderfront;

/**
 * @Description:
 * @author: lijie14
 * @Date: 2016/3/18.
 * @Version:1.0
 */
public class ReturnResult<T> extends com.lenovo.m2.arch.framework.domain.BaseObject  {
    private String code;
    private String msg;
    private T data;
    public ReturnResult(String code, String msg){
        this.code=code;
        this.msg=msg;
    }
    public ReturnResult(){
    }
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ReturnResult that = (ReturnResult) o;

        if (code != null ? !code.equals(that.code) : that.code != null) return false;
        if (data != null ? !data.equals(that.data) : that.data != null) return false;
        if (msg != null ? !msg.equals(that.msg) : that.msg != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = code != null ? code.hashCode() : 0;
        result = 31 * result + (msg != null ? msg.hashCode() : 0);
        result = 31 * result + (data != null ? data.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ReturnResult{" +
                "code='" + code + '\'' +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }
}
