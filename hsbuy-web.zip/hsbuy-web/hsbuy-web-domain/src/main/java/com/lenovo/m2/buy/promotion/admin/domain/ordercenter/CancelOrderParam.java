package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

/**
 * @Author licy13
 * @Date 2017/3/23
 */

public class CancelOrderParam extends BaseParam {
    private String orderId;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    @Override
    public String toString() {
        return "CancelOrderParam{" +
                "orderId='" + orderId + '\'' +
                '}';
    }

}
