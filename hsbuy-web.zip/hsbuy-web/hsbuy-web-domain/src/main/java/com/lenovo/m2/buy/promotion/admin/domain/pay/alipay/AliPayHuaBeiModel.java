package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;

/**
 * 支付宝花呗分期实体
 * Created by MengQiang on 2016/1/4.
 */
public class AliPayHuaBeiModel extends BaseModel{

    public AliPayHuaBeiModel(){super();}

    public AliPayHuaBeiModel(HttpServletRequest request){
        super(request);
        this.hbfqNum = request.getParameter("hbfqNum");
        this.browser = request.getParameter("browser");
    }

    private String hbfqNum;

    private String browser;

    public String getBrowser() {
        return browser;
    }

    public void setBrowser(String browser) {
        this.browser = browser;
    }

    public String getHbfqNum() {
        return hbfqNum;
    }

    public void setHbfqNum(String hbfqNum) {
        this.hbfqNum = hbfqNum;
    }
}
