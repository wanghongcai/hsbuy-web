package com.lenovo.m2.buy.promotion.admin.domain.pay.outpay;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 支持的银行列表查询对象
 * Created by tianchuyang on 2017/1/3.
 */
public class BanksQo implements Serializable {

    private static final long serialVersionUID = -6509783327469831565L;

    private BigDecimal bill_amount;
    private String fa_id;
    private Integer account_type;

    public BigDecimal getBill_amount() {
        return bill_amount;
    }

    public void setBill_amount(BigDecimal bill_amount) {
        this.bill_amount = bill_amount;
    }

    public String getFa_id() {
        return fa_id;
    }

    public void setFa_id(String fa_id) {
        this.fa_id = fa_id;
    }

    public Integer getAccount_type() {
        return account_type;
    }

    public void setAccount_type(Integer account_type) {
        this.account_type = account_type;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("{");
        sb.append("            \"bill_amount\"=").append(bill_amount);
        sb.append(",             \"fa_id\"=\"").append(fa_id).append('\"');
        sb.append(",             \"account_type\"=").append(account_type);
        sb.append('}');
        return sb.toString();
    }
}
