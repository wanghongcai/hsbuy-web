package com.lenovo.m2.buy.promotion.admin.domain.pay.order;

public class OrderDetailDescriptionJSONSlist {
	private String scode;//订单状态表示1：提交订单 2付款成功 3商品出库 4等待收货 5完成 ，根据顺序排列返回集合
	private String sname;//订单状态名称
	private String stime;//状态完成时间，如果没有时间返回空
	private String iscomplete;//状态是否完成 1完成 0未完成
	public String getScode() {
		return scode;
	}
	public void setScode(String scode) {
		this.scode = scode;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getStime() {
		return stime;
	}
	public void setStime(String stime) {
		this.stime = stime;
	}
	public String getIscomplete() {
		return iscomplete;
	}
	public void setIscomplete(String iscomplete) {
		this.iscomplete = iscomplete;
	}
	

}
