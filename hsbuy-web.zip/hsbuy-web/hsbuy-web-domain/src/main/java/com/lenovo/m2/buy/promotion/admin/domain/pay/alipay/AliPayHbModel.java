package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by caoxd2 on 2015/6/1.
 */
public class AliPayHbModel extends AliPayModel {
    public AliPayHbModel(HttpServletRequest request){
        super(request);
        this.defaultbank = request.getParameter("directbank");

    }


    //支付宝分期默认银行，银行简码
    private String defaultbank;

    public String getDefaultbank() {
        return defaultbank;
    }

    public void setDefaultbank(String defaultbank) {
        this.defaultbank = defaultbank;
    }
}
