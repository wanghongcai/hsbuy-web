package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.common.middleware.ResultMessageEnum;

import java.io.Serializable;

public class OpenPlatResultMsg implements Serializable {


    private String msg;
    private String rc;

    public String getRc() {
        return this.rc;
    }

    public void setRc(String rc) {
        this.rc = rc;
    }

    public String getMsg() {
        return this.msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public OpenPlatResultMsg() {
    }

    public OpenPlatResultMsg(ResultMessageEnum messageEnum) {
        this.msg = messageEnum.getDesc();
        this.rc = messageEnum.getCode();
    }

    public OpenPlatResultMsg(String rc, String msg) {
        this.msg = msg;
        this.rc = rc;
    }


    public OpenPlatResultMsg(RemoteResult remoteResult) {
        this.rc = remoteResult.getResultCode();
        this.msg = remoteResult.getResultMsg();
    }
}