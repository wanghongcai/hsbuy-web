package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by zhanglijun on 2015/5/23.
 */
public class AliPaySjModel extends BaseModel {


    public AliPaySjModel(HttpServletRequest request){

        super(request);
        this.os = request.getParameter("os");
    }
    public AliPaySjModel(){

        super();

    }


    //客户端系统 1:ios,2:android,3:js,4:native，5，pc
    private String os;
    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

     /*接口名称 */
     private String service;
    /*请求参数格式 */
     private String format;
    /*接口版本号*/
    private String v;
    /*合作者身份 ID*/
     private String partner;
    /*请求号*/
     private String req_id;
    /*签名方式*/
     private String sec_id;
    /*签名*/
     private String sign;
    /*请求业务参数*/
     private String req_data;
    /*商品名称*/
     private String subject;
    /*商户网站唯一订单号*/
     private String out_trade_no;
    /*交易金额*/
     private String total_fee;
    /*卖家账户*/
    private String seller_account_name;
    /*同步通知的url*/
    private String call_back_url;
    /*异步通知的url*/
    private String notify_url;
    /*用户唯一Id*/
    private String out_user;
    /*操作中断返回的url*/
    private String merchant_url;
    /*交易关闭时间*/
    private String pay_expire;


    public String getPay_expire() {
        return pay_expire;
    }

    public void setPay_expire(String pay_expire) {
        this.pay_expire = pay_expire;
    }

    public String getMerchant_url() {
        return merchant_url;
    }

    public void setMerchant_url(String merchant_url) {
        this.merchant_url = merchant_url;
    }

    public String getOut_user() {
        return out_user;
    }

    public void setOut_user(String out_user) {
        this.out_user = out_user;
    }

    public String getNotify_url() {
        return notify_url;
    }

    public void setNotify_url(String notify_url) {
        this.notify_url = notify_url;
    }

    public String getCall_back_url() {
        return call_back_url;
    }

    public void setCall_back_url(String call_back_url) {
        this.call_back_url = call_back_url;
    }

    public String getSeller_account_name() {
        return seller_account_name;
    }

    public void setSeller_account_name(String seller_account_name) {
        this.seller_account_name = seller_account_name;
    }

    public String getTotal_fee() {
        return total_fee;
    }

    public void setTotal_fee(String total_fee) {
        this.total_fee = total_fee;
    }

    public String getOut_trade_no() {
        return out_trade_no;
    }

    public void setOut_trade_no(String out_trade_no) {
        this.out_trade_no = out_trade_no;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getReq_data() {
        return req_data;
    }

    public void setReq_data(String req_data) {
        this.req_data = req_data;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getSec_id() {
        return sec_id;
    }

    public void setSec_id(String sec_id) {
        this.sec_id = sec_id;
    }

    public String getReq_id() {
        return req_id;
    }

    public void setReq_id(String req_id) {
        this.req_id = req_id;
    }

    public String getPartner() {
        return partner;
    }

    public void setPartner(String partner) {
        this.partner = partner;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AliPaySjModel)) return false;

        AliPaySjModel that = (AliPaySjModel) o;

        if (!call_back_url.equals(that.call_back_url)) return false;
        if (!format.equals(that.format)) return false;
        if (!merchant_url.equals(that.merchant_url)) return false;
        if (!notify_url.equals(that.notify_url)) return false;
        if (!out_trade_no.equals(that.out_trade_no)) return false;
        if (!out_user.equals(that.out_user)) return false;
        if (!partner.equals(that.partner)) return false;
        if (!pay_expire.equals(that.pay_expire)) return false;
        if (!req_data.equals(that.req_data)) return false;
        if (!req_id.equals(that.req_id)) return false;
        if (!sec_id.equals(that.sec_id)) return false;
        if (!seller_account_name.equals(that.seller_account_name)) return false;
        if (!service.equals(that.service)) return false;
        if (!sign.equals(that.sign)) return false;
        if (!subject.equals(that.subject)) return false;
        if (!total_fee.equals(that.total_fee)) return false;
        if (!v.equals(that.v)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = service.hashCode();
        result = 31 * result + format.hashCode();
        result = 31 * result + v.hashCode();
        result = 31 * result + partner.hashCode();
        result = 31 * result + req_id.hashCode();
        result = 31 * result + sec_id.hashCode();
        result = 31 * result + sign.hashCode();
        result = 31 * result + req_data.hashCode();
        result = 31 * result + subject.hashCode();
        result = 31 * result + out_trade_no.hashCode();
        result = 31 * result + total_fee.hashCode();
        result = 31 * result + seller_account_name.hashCode();
        result = 31 * result + call_back_url.hashCode();
        result = 31 * result + notify_url.hashCode();
        result = 31 * result + out_user.hashCode();
        result = 31 * result + merchant_url.hashCode();
        result = 31 * result + pay_expire.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "AliPaySjModel{" +
                "service='" + service + '\'' +
                ", format='" + format + '\'' +
                ", v='" + v + '\'' +
                ", partner='" + partner + '\'' +
                ", req_id='" + req_id + '\'' +
                ", sec_id='" + sec_id + '\'' +
                ", sign='" + sign + '\'' +
                ", req_data='" + req_data + '\'' +
                ", subject='" + subject + '\'' +
                ", out_trade_no='" + out_trade_no + '\'' +
                ", total_fee='" + total_fee + '\'' +
                ", seller_account_name='" + seller_account_name + '\'' +
                ", call_back_url='" + call_back_url + '\'' +
                ", notify_url='" + notify_url + '\'' +
                ", out_user='" + out_user + '\'' +
                ", merchant_url='" + merchant_url + '\'' +
                ", pay_expire='" + pay_expire + '\'' +
                '}';
    }
}
