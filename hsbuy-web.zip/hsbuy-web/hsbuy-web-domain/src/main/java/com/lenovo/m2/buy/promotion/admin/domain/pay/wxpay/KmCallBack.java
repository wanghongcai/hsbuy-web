package com.lenovo.m2.buy.promotion.admin.domain.pay.wxpay;

/**
 * Created by kenvin on 2014/11/4.
 */
public class KmCallBack {
    /** 返回参数 必填**/
    private String sign;
//    private Integer trade_mode;
    private Integer trade_state;
    private String partner;
    private String bank_type;
    private Integer total_fee;
    private Integer fee_type;
    private String notify_id;
    private String transaction_id;
    private String out_trade_no;
    private String time_end;

    /** 返回参数 选填**/
//    private String sign_type;
//    private String input_charset;
    private String bank_billno;
//    private String attach;
    private Integer transport_fee;
    private Integer product_fee;
    private Integer discount;
}
