package com.lenovo.m2.buy.promotion.admin.domain.promotion;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class PromotionListQry implements Serializable{
	
	//促销类型
	private String promotionType;
	//促销名称
	private String promotionName;
	//主品物料编号
	private String mainMaterialNumber;
	//关联品物料编号
	private String relMaterialNumber;

    private Integer terminal;

    private Integer pageNum;
    private Integer pageSize;
    private Integer status;
	private String disabled; //启用状态

	private String faName; //促销分销商信息
	

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	private Date fromTime;
	
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
	private Date toTime;

	
	public Date getFromTime() {
		return fromTime;
	}

	public void setFromTime(Date fromTime) {
		this.fromTime = fromTime;
	}

	public Date getToTime() {
		return toTime;
	}

	public void setToTime(Date toTime) {
		this.toTime = toTime;
	}

	public String getFaName() {
		return faName;
	}

	public void setFaName(String faName) {
		this.faName = faName;
	}

	public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getTerminal() {
        return terminal;
    }

    public void setTerminal(Integer terminal) {
        this.terminal = terminal;
    }

    public String getPromotionType() {
        return promotionType;
    }

    public void setPromotionType(String promotionType) {
        this.promotionType = promotionType;
    }

    public String getPromotionName() {
		return promotionName;
	}
	public void setPromotionName(String promotionName) {
		this.promotionName = promotionName;
	}


	public String getDisabled() {
		return disabled;
	}

	public void setDisabled(String disabled) {
		this.disabled = disabled;
	}

	
	public  Map<String,Object> toMap(){
		Map<String,Object> ret = new HashMap<>();
		ret.put("promotionType", this.promotionType);
		ret.put("promotionName", this.promotionName);
		ret.put("terminal", this.terminal);
		ret.put("mainProductMaterial", this.mainMaterialNumber);
		ret.put("relProductMaterial", this.relMaterialNumber);
		ret.put("status",this.status);
		ret.put("disabled",this.disabled);
		ret.put("faName", this.faName);
		ret.put("fromtime", this.fromTime);
		ret.put("totime", this.toTime);
		return ret;
	}


	public String getMainMaterialNumber() {
		return mainMaterialNumber;
	}

	public void setMainMaterialNumber(String mainMaterialNumber) {
		this.mainMaterialNumber = mainMaterialNumber;
	}

	public String getRelMaterialNumber() {
		return relMaterialNumber;
	}

	public void setRelMaterialNumber(String relMaterialNumber) {
		this.relMaterialNumber = relMaterialNumber;
	}

	public Integer getPageNum() {
		return pageNum;
	}

	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	@Override
    public String toString() {
        return "PromotionQryReq{" +
                "promotionType='" + promotionType + '\'' +
                ", promotionName='" + promotionName + '\'' +
                ", terminal=" + terminal +
                ", pageSize=" + pageSize +
                ", status=" + status +
				", disabled=" + disabled +
                '}';
    }

}
