package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;


/**
 * 获取未抛单的列表入参
 *
 * @Author licy13
 * @Date 2017/3/2
 */

public class ThrowWareHouseListParam extends BaseParam {
    private String orderId;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
