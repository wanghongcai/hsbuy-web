package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.hsbuy.common.middleware.ResultMessageEnum;

import java.io.Serializable;

/**
 * 物流返回对象
 * <p>
 * Created by yyduff on 2016/4/26.
 */
public class ResultLogistics implements Serializable {

    private String code;

    private String message;

    public String getCode() {
        return code;
    }

    public ResultLogistics(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public ResultLogistics() {
    }

    public ResultLogistics(ResultMessageEnum resultMessageEnum) {
        this.code = resultMessageEnum.getCode();
        this.message = resultMessageEnum.getDesc();
    }


    public ResultLogistics(RemoteResult remoteResult) {
        this.code = remoteResult.getResultCode();
        this.message = remoteResult.getResultMsg();
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
