package com.lenovo.m2.buy.promotion.admin.domain.pay;

/**
 * Created by caoxd2 on 2015/6/7.
 */
public enum Plat {
    Wap(1,"WAP"),WeiXin(2,"Weixin"),App(3,"App"),Pc(4,"Pc");

    private Plat(int type,String desc){
        this.type = type;
        this.desc = desc;
    }

    private int type;

    private String desc;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
