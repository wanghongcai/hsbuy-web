package com.lenovo.m2.buy.promotion.admin.domain.pay.wxpay;

/**
 * Created by kenvin on 2014/11/10.
 */
public class RefundWx extends RefundBaseResp {
    private String out_trade_no;
    private String transaction_id;
    private String out_refund_no ;
    private int refund_fee;
    private int refund_channel;
    private int refund_status;
    private String refund_id;
    private String recv_user_id;
    private String recv_user_name;

    public String getOut_trade_no() {
        return out_trade_no;
    }

    public void setOut_trade_no(String out_trade_no) {
        this.out_trade_no = out_trade_no;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public String getOut_refund_no() {
        return out_refund_no;
    }

    public void setOut_refund_no(String out_refund_no) {
        this.out_refund_no = out_refund_no;
    }

    public int getRefund_fee() {
        return refund_fee;
    }

    public void setRefund_fee(int refund_fee) {
        this.refund_fee = refund_fee;
    }

    public int getRefund_channel() {
        return refund_channel;
    }

    public void setRefund_channel(int refund_channel) {
        this.refund_channel = refund_channel;
    }

    public int getRefund_status() {
        return refund_status;
    }

    public void setRefund_status(int refund_status) {
        this.refund_status = refund_status;
    }

    public String getRefund_id() {
        return refund_id;
    }

    public void setRefund_id(String refund_id) {
        this.refund_id = refund_id;
    }

    public String getRecv_user_id() {
        return recv_user_id;
    }

    public void setRecv_user_id(String recv_user_id) {
        this.recv_user_id = recv_user_id;
    }

    public String getRecv_user_name() {
        return recv_user_name;
    }

    public void setRecv_user_name(String recv_user_name) {
        this.recv_user_name = recv_user_name;
    }
}
