package com.lenovo.m2.buy.promotion.admin.domain.web;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.soa.enums.GloablErrorMessageEnum;
import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by dulijie on 2016/3/2.
 */
public class ProductsPageQueryVO implements Serializable {

    private Long seckillId;

    //活动名称
    private String name;

    //商品编码
    private Long code;

    //活动名称
    private String activityName;

    //商城
    private String shopType;

    //销售平台
    private Integer salesType;

    //物料编号
    private String materialNumber;

    //FA名称
    private String faName;

    //抢购折扣金额
    private double seckillMoney;

    //最大购买数量
    private int maxNum;

    //抢购类型
   // private int panicBuyType;

    //抢购结束是否正常销售
    private int isNormalSaleAfterActivity;

    //是否需要提前预约
    private int isReservation;

    //活动状态 1:无效 0:在活动时间结束之前为有效 在活动结束后 为结束
    private int status;

    //抢购类型
    private int activityType;

    //协同人数
    private int addDiscountCount;

    //图片地址
    private String thumbnail;

    //faid
    private String faid;

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public int getAddDiscountCount() {
        return addDiscountCount;
    }

    public void setAddDiscountCount(int addDiscountCount) {
        this.addDiscountCount = addDiscountCount;
    }

    //抢购开始时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private java.util.Date seckillStartTime;

    //抢购结束时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private java.util.Date seckillEndTime;

    //预约开始时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private java.util.Date reservationStartTime;

    //预约结束时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private java.util.Date reservationEndTime;

    //非预约开始抢购时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private  java.util.Date noReservationSeckillStartTime;

    //支持平台
    private int Terminal;

    //是否启用(0:未启用 1：启用)
    private  int markeTable;

    private Integer page;
    private Integer rows;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getIsNormalSaleAfterActivity() {
        return isNormalSaleAfterActivity;
    }

    public void setIsNormalSaleAfterActivity(int isNormalSaleAfterActivity) {
        this.isNormalSaleAfterActivity = isNormalSaleAfterActivity;
    }

    public int getMarkeTable() {
        return markeTable;
    }

    public void setMarkeTable(int markeTable) {
        this.markeTable = markeTable;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public int getIsReservation() {
        return isReservation;
    }

    public void setIsReservation(int isReservation) {
        this.isReservation = isReservation;
    }

    public int getActivityType() {
        return activityType;
    }

    public void setActivityType(int activityType) {
        this.activityType = activityType;
    }

    public Date getSeckillStartTime() {
        return seckillStartTime;
    }

    public void setSeckillStartTime(Date seckillStartTime) {
        this.seckillStartTime = seckillStartTime;
    }

    public Date getSeckillEndTime() {
        return seckillEndTime;
    }

    public void setSeckillEndTime(Date seckillEndTime) {
        this.seckillEndTime = seckillEndTime;
    }

    public Date getReservationStartTime() {
        return reservationStartTime;
    }

    public void setReservationStartTime(Date reservationStartTime) {
        this.reservationStartTime = reservationStartTime;
    }

    public Date getReservationEndTime() {
        return reservationEndTime;
    }

    public void setReservationEndTime(Date reservationEndTime) {
        this.reservationEndTime = reservationEndTime;
    }

    public Date getNoReservationSeckillStartTime() {
        return noReservationSeckillStartTime;
    }

    public void setNoReservationSeckillStartTime(Date noReservationSeckillStartTime) {
        this.noReservationSeckillStartTime = noReservationSeckillStartTime;
    }

    public int getTerminal() {
        return Terminal;
    }

    public void setTerminal(int terminal) {
        Terminal = terminal;
    }

    public double getSeckillMoney() {
        return seckillMoney;
    }

    public void setSeckillMoney(double seckillMoney) {
        this.seckillMoney = seckillMoney;
    }

    public int getMaxNum() {
        return maxNum;
    }

    public void setMaxNum(int maxNum) {
        this.maxNum = maxNum;
    }

    public ProductsPageQueryVO() {
    }

    public Long getCode() {
        return code;
    }

    public void setCode(Long code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShopType() {
        return shopType;
    }

    public void setShopType(String shopType) {
        this.shopType = shopType;
    }

    public Integer getSalesType() {
        return salesType;
    }

    public void setSalesType(Integer salesType) {
        this.salesType = salesType;
    }

    public String getMaterialNumber() {
        return materialNumber;
    }

    public void setMaterialNumber(String materialNumber) {
        this.materialNumber = materialNumber;
    }

    public String getFaName() {
        return faName;
    }

    public void setFaName(String faName) {
        this.faName = faName;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getRows() {
        return rows;
    }

    public void setRows(Integer rows) {
        this.rows = rows;
    }

    public String getFaid() {
        return faid;
    }

    public void setFaid(String faid) {
        this.faid = faid;
    }

    /**
     * seckillActivity add 校验参数非空
     * @return
     * @author lihc5
     */
    public RemoteResult check(){
        RemoteResult remoteResult =new RemoteResult();
        remoteResult.setSuccess(false);
        if (StringUtils.isEmpty(this.activityName)){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("活动名称不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.activityType))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("抢购类型不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.isReservation))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("是否预约不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.seckillStartTime))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("抢购开始时间不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.seckillEndTime))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("抢购截止时间不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.Terminal))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("限时抢购终端不能为空");
            return remoteResult;
        }
        remoteResult.setSuccess(true);
        return remoteResult;
    }

    /**
     * seckillActivity edit 校验参数非空
     * @return
     * @author lihc5
     */
    public RemoteResult editCheck(){
        RemoteResult remoteResult =new RemoteResult();
        remoteResult.setSuccess(false);
        if (StringUtils.isEmpty(this.activityName)){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("活动名称不能为空");
            return remoteResult;
        } else if(StringUtils.isEmpty(String.valueOf(this.seckillId))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("id不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.activityType))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("抢购类型不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.isReservation))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("是否预约不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.seckillStartTime))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("抢购开始时间不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.seckillEndTime))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("抢购截止时间不能为空");
            return remoteResult;
        }else if(StringUtils.isEmpty(String.valueOf(this.Terminal))){
            remoteResult.setResultCode(GloablErrorMessageEnum.ERROR_PARAM_ILLEGAL.getCode());
            remoteResult.setResultMsg("限时抢购终端不能为空");
            return remoteResult;
        }
        remoteResult.setSuccess(true);
        return remoteResult;
    }

    public Map<String,Object> toMap(String faid){ //设置参数
        Map<String,Object> ret = new HashMap<>();
        ret.put("id", this.seckillId);
        ret.put("seckillId", this.seckillId);
        ret.put("activityName", this.activityName);
        ret.put("activityType", this.activityType);
        ret.put("isReservation", this.isReservation);
        ret.put("seckillStartTime", this.seckillStartTime);
        ret.put("seckillEndTime", this.seckillEndTime);
        ret.put("reservationStartTime", this.reservationStartTime);
        ret.put("reservationEndTime", this.reservationEndTime);
        ret.put("noReservationSeckillStartTime", this.noReservationSeckillStartTime);
        ret.put("terminal", this.Terminal);
        ret.put("markeTable", this.markeTable);
        ret.put("faId", faid);
        return ret;
    }

    public Long getSeckillId() {
        return seckillId;
    }

    public void setSeckillId(Long seckillId) {
        this.seckillId = seckillId;
    }
}
