package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**支付结果响应实体
 * Created by tianchuyang on 2016/11/9.
 */
public class UmPayResultResp implements Serializable {

    private static final long serialVersionUID = -6154207001607804023L;

    public UmPayResultResp() {

    }

    public UmPayResultResp(HttpServletRequest request) {
        this.mer_id= request.getParameter("mer_id");
        this.sign_type= request.getParameter("sign_type");
        this.sign= request.getParameter("sign");
        this.version= request.getParameter("version");
        this.order_id= request.getParameter("order_id");
        this.mer_date= request.getParameter("mer_date");
        this.ret_code= request.getParameter("ret_code");
        this.ret_msg= request.getParameter("ret_msg");
    }

    private String mer_id;
    private String sign_type;
    private String sign;
    private String version;
    // 业务参数
    private String order_id;
    private String mer_date;
    private String ret_code;
    private String ret_msg;

    public String getMer_id() {
        return mer_id;
    }

    public void setMer_id(String mer_id) {
        this.mer_id = mer_id;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getMer_date() {
        return mer_date;
    }

    public void setMer_date(String mer_date) {
        this.mer_date = mer_date;
    }

    public String getRet_code() {
        return ret_code;
    }

    public void setRet_code(String ret_code) {
        this.ret_code = ret_code;
    }

    public String getRet_msg() {
        return ret_msg;
    }

    public void setRet_msg(String ret_msg) {
        this.ret_msg = ret_msg;
    }
}
