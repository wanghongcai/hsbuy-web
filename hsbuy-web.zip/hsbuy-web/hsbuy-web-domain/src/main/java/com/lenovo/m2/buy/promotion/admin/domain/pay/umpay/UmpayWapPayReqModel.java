package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * 联动优势WAP支付请求实体
 * Created by tianchuyang on 2016/11/22.
 */
public class UmpayWapPayReqModel extends BaseModel implements Serializable {

    private static final long serialVersionUID = -8654061169175767458L;

    private String tradeNo;
    // 业务参数
    private String cardId;
    private String identityType;
    private String identityCode;
    private String cardHolder;
    private String merCustId;
    private String payType;
    private String gateId;
    private String canModifyFlag;
    private String mobileId;

    public UmpayWapPayReqModel() {
    }

    public UmpayWapPayReqModel(HttpServletRequest request) {
        super(request);
        this.tradeNo= request.getParameter("tradeNo");
        this.cardId= request.getParameter("cardId");
        this.identityType= request.getParameter("identityType");
        this.identityCode= request.getParameter("identityCode");
        this.cardHolder= request.getParameter("cardHolder");
        this.merCustId= request.getParameter("merCustId");
        this.payType= request.getParameter("payType");
        this.gateId= request.getParameter("gateId");
        this.canModifyFlag= request.getParameter("canModifyFlag");
        this.mobileId= request.getParameter("mobileId");
    }

    public String getTradeNo() {
        return tradeNo;
    }

    public void setTradeNo(String tradeNo) {
        this.tradeNo = tradeNo;
    }

    public String getCardId() {
        return cardId;
    }

    public void setCardId(String cardId) {
        this.cardId = cardId;
    }

    public String getIdentityType() {
        return identityType;
    }

    public void setIdentityType(String identityType) {
        this.identityType = identityType;
    }

    public String getIdentityCode() {
        return identityCode;
    }

    public void setIdentityCode(String identityCode) {
        this.identityCode = identityCode;
    }

    public String getCardHolder() {
        return cardHolder;
    }

    public void setCardHolder(String cardHolder) {
        this.cardHolder = cardHolder;
    }

    public String getMerCustId() {
        return merCustId;
    }

    public void setMerCustId(String merCustId) {
        this.merCustId = merCustId;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getGateId() {
        return gateId;
    }

    public void setGateId(String gateId) {
        this.gateId = gateId;
    }

    public String getCanModifyFlag() {
        return canModifyFlag;
    }

    public void setCanModifyFlag(String canModifyFlag) {
        this.canModifyFlag = canModifyFlag;
    }

    public String getMobileId() {
        return mobileId;
    }

    public void setMobileId(String mobileId) {
        this.mobileId = mobileId;
    }
}
