package com.lenovo.m2.buy.promotion.admin.domain.pay.order;

/**
 *
 * @author kangjie
 *
 */
public class OrderDetailDescriptionJSONGlist {
	private String gcode;       //商品编码
	private String servicesn;       //SN（如果gcode是服务商品，则此处是与此服务商品关联的SN）
	private String gname;       //商品名称
	private String canchange = "0";   //canchange
	private String gexchange = "";   //换货状态名称（如果为空表示不是在换货）
	private String isgift;      //是否赠品
	private String gphoto;      //商品图片url
	private String grealprice;  //成交价格
	private String gcount;      //商品数量
	private String gstockstatus;//库存状态名称（未支付的返回此字段信息）
	private String evalstatus;//评价状态（为空是未评价，不为空是已评价）
	
	public String getCanchange() {
		return canchange;
	}
	public void setCanchange(String canchange) {
		this.canchange = canchange;
	}
	public String getEvalstatus() {
		return evalstatus;
	}
	public void setEvalstatus(String evalstatus) {
		this.evalstatus = evalstatus;
	}
	public String getServicesn() {
		return servicesn;
	}
	public void setServicesn(String servicesn) {
		this.servicesn = servicesn;
	}
	
	public String getGcode() {
		return gcode;
	}
	public void setGcode(String gcode) {
		this.gcode = gcode;
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public String getGexchange() {
		return gexchange;
	}
	public void setGexchange(String gexchange) {
		this.gexchange = gexchange;
	}
	public String getIsgift() {
		return isgift;
	}
	public void setIsgift(String isgift) {
		this.isgift = isgift;
	}
	public String getGphoto() {
		return gphoto;
	}
	public void setGphoto(String gphoto) {
		this.gphoto = gphoto;
	}
	public String getGrealprice() {
		return grealprice;
	}
	public void setGrealprice(String grealprice) {
		this.grealprice = grealprice;
	}
	public String getGcount() {
		return gcount;
	}
	public void setGcount(String gcount) {
		this.gcount = gcount;
	}
	public String getGstockstatus() {
		return gstockstatus;
	}
	public void setGstockstatus(String gstockstatus) {
		this.gstockstatus = gstockstatus;
	}
}
