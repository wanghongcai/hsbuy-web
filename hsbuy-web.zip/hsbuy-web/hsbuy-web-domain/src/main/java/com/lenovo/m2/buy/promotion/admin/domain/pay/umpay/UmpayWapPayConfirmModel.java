package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * 联动优势商户确认支付请求Model
 * Created by tianchuyang on 2016/11/22.
 */
public class UmpayWapPayConfirmModel extends BaseModel implements Serializable {

    private static final long serialVersionUID = -3196720747529639409L;

    private String service;
    private String mer_id;
    private String charset;
    private String res_format;
    private String sign_type;
    private String sign;
    private String version;
    // 业务参数
    private String trade_no;
    private String verify_code;
    private String mer_cust_id;
    private String usr_busi_agreement_id;
    private String usr_pay_agreement_id;
    private String birthday;
    private String valid_date;
    private String cvv2;

    public UmpayWapPayConfirmModel() {
    }

    public UmpayWapPayConfirmModel(HttpServletRequest request) {
        super(request);
        this.service = request.getParameter("service");
        this.mer_id = request.getParameter("mer_id");
        this.charset = request.getParameter("charset");
        this.res_format = request.getParameter("res_format");
        this.sign_type = request.getParameter("sign_type");
        this.sign = request.getParameter("sign");
        this.version = request.getParameter("version");
        // 业务参数
        this.trade_no = request.getParameter("trade_no");
        this.verify_code = request.getParameter("verify_code");
        this.mer_cust_id = request.getParameter("mer_cust_id");
        this.usr_busi_agreement_id = request.getParameter("usr_busi_agreement_id");
        this.usr_pay_agreement_id = request.getParameter("usr_pay_agreement_id");
        this.birthday = request.getParameter("birthday");
        this.valid_date = request.getParameter("valid_date");
        this.cvv2 = request.getParameter("cvv2");
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getMer_id() {
        return mer_id;
    }

    public void setMer_id(String mer_id) {
        this.mer_id = mer_id;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public String getRes_format() {
        return res_format;
    }

    public void setRes_format(String res_format) {
        this.res_format = res_format;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getTrade_no() {
        return trade_no;
    }

    public void setTrade_no(String trade_no) {
        this.trade_no = trade_no;
    }

    public String getVerify_code() {
        return verify_code;
    }

    public void setVerify_code(String verify_code) {
        this.verify_code = verify_code;
    }

    public String getMer_cust_id() {
        return mer_cust_id;
    }

    public void setMer_cust_id(String mer_cust_id) {
        this.mer_cust_id = mer_cust_id;
    }

    public String getUsr_busi_agreement_id() {
        return usr_busi_agreement_id;
    }

    public void setUsr_busi_agreement_id(String usr_busi_agreement_id) {
        this.usr_busi_agreement_id = usr_busi_agreement_id;
    }

    public String getUsr_pay_agreement_id() {
        return usr_pay_agreement_id;
    }

    public void setUsr_pay_agreement_id(String usr_pay_agreement_id) {
        this.usr_pay_agreement_id = usr_pay_agreement_id;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getValid_date() {
        return valid_date;
    }

    public void setValid_date(String valid_date) {
        this.valid_date = valid_date;
    }

    public String getCvv2() {
        return cvv2;
    }

    public void setCvv2(String cvv2) {
        this.cvv2 = cvv2;
    }
}
