package com.lenovo.m2.buy.promotion.admin.domain.common;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class Seckillreservation {
    private Integer id;

    private String seckillRoleid;

    private String lenovoid;

    private String membercode;

    private Byte platformcode;

    private Long gcode;

    private String gname;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private Date reservationTime;

    private Boolean status;

    private String phone;

    private String platformName;

    private Date ReservationStartTime;

    private Date ReservationEndTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSeckillRoleid() {
        return seckillRoleid;
    }

    public void setSeckillRoleid(String seckillRoleid) {
        this.seckillRoleid = seckillRoleid == null ? null : seckillRoleid.trim();
    }

    public String getLenovoid() {
        return lenovoid;
    }

    public void setLenovoid(String lenovoid) {
        this.lenovoid = lenovoid == null ? null : lenovoid.trim();
    }

    public String getMembercode() {
        return membercode;
    }

    public void setMembercode(String membercode) {
        this.membercode = membercode == null ? null : membercode.trim();
    }

    public Byte getPlatformcode() {
        return platformcode;
    }

    public void setPlatformcode(Byte platformcode) {
        this.platformcode = platformcode;
    }

    public Long getGcode() {
        return gcode;
    }

    public void setGcode(Long gcode) {
        this.gcode = gcode;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname == null ? null : gname.trim();
    }

    public Date getReservationTime() {
        return reservationTime;
    }

    public void setReservationTime(Date reservationTime) {
        this.reservationTime = reservationTime;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getPlatformName() {
        return platformName;
    }

    public void setPlatformName(String platformName) {
        this.platformName = platformName;
    }

    public Date getReservationStartTime() {
        return ReservationStartTime;
    }

    public void setReservationStartTime(Date reservationStartTime) {
        ReservationStartTime = reservationStartTime;
    }

    public Date getReservationEndTime() {
        return ReservationEndTime;
    }

    public void setReservationEndTime(Date reservationEndTime) {
        ReservationEndTime = reservationEndTime;
    }
}