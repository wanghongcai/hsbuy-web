package com.lenovo.m2.buy.promotion.admin.domain;

import java.util.List;

/**
 * Created by wangrq1 on 2017/2/7.
 */
public class AuthData {

    private List<String> faIds;

    private List<String> storeIds;

    private String userid;

    private List<String> shopIds;


    public List<String> getFaIds() {
        return faIds;
    }

    public void setFaIds(List<String> faIds) {
        this.faIds = faIds;
    }

    public List<String> getStoreIds() {
        return storeIds;
    }

    public void setStoreIds(List<String> storeIds) {
        this.storeIds = storeIds;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public List<String> getShopIds() {
        return shopIds;
    }

    public void setShopIds(List<String> shopIds) {
        this.shopIds = shopIds;
    }
}
