package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

/**
 * @Author licy13
 * @Date 2017/7/8
 */

public class PayRecordsDetailParam extends BaseParam {

    /**
     * @Param payId 付款记录ID
     */
    private String payId;
    /**
     * @Param faId 分销商faid
     */
    private String faId;


    public String getPayId() {
        return payId;
    }

    public void setPayId(String payId) {
        this.payId = payId;
    }

    public String getFaId() {
        return faId;
    }

    public void setFaId(String faId) {
        this.faId = faId;
    }
}
