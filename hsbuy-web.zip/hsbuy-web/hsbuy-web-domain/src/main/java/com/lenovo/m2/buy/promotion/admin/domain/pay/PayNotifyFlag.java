package com.lenovo.m2.buy.promotion.admin.domain.pay;

/**
 * Created by caoxd2 on 2015/5/30.
 */
public enum PayNotifyFlag {
    NotifyFail(2,"Fail"),NotifySuccess(1,"Success"),NeedNotifyAgain(3,"NeedNotifyAgain");

    private PayNotifyFlag(int tradeStatus, String desc){
        this.tradeStatus = tradeStatus;
        this.desc = desc;
    }

    private int tradeStatus;
    private String desc;

    public int getTradeStatus() {
        return tradeStatus;
    }

    public void setTradeStatus(int tradeStatus) {
        this.tradeStatus = tradeStatus;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
