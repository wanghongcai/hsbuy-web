package com.lenovo.m2.buy.promotion.admin.domain.pay.wxpay;

/**
 * Created by caoxd2 on 2015/9/9.
 */
public class WxTicket {
    private int errCode;
    private String errmsg;
    private String ticket;
    private int expires_id;

    public String getErrmsg() {
        return errmsg;
    }

    public void setErrmsg(String errmsg) {
        this.errmsg = errmsg;
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    public int getExpires_id() {
        return expires_id;
    }

    public void setExpires_id(int expires_id) {
        this.expires_id = expires_id;
    }

    public int getErrCode() {
        return errCode;
    }

    public void setErrCode(int errCode) {
        this.errCode = errCode;
    }
}
