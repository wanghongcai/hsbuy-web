package com.lenovo.m2.buy.promotion.admin.domain.pay.outpay;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Created by tianchuyang on 2017/1/10.
 */
@JsonIgnoreProperties(value={"plat_rank","rateType","rate"})
public class BankOfPayPlat implements Serializable,Comparable<BankOfPayPlat> {

    private static final long serialVersionUID = -3775220488150279764L;

    private Integer plat_rank;
    private Integer plat_code;
    private Integer rateType;
    private BigDecimal rate;

    public Integer getPlat_rank() {
        return plat_rank;
    }

    public void setPlat_rank(Integer plat_rank) {
        this.plat_rank = plat_rank;
    }

    public Integer getPlat_code() {
        return plat_code;
    }

    public void setPlat_code(Integer plat_code) {
        this.plat_code = plat_code;
    }

    public Integer getRateType() {
        return rateType;
    }

    public void setRateType(Integer rateType) {
        this.rateType = rateType;
    }

    public BigDecimal getRate() {
        return rate;
    }

    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("{");
        sb.append("\"plat_rank\":").append(plat_rank);
        sb.append(",\"plat_code\":").append(plat_code);
        sb.append(",\"rateType\":").append(rateType);
        sb.append(",\"rate\":").append(rate);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        BankOfPayPlat that = (BankOfPayPlat) o;

        if (!plat_rank.equals(that.plat_rank)) return false;
        if (!plat_code.equals(that.plat_code)) return false;
        if (!rateType.equals(that.rateType)) return false;
        return rate.equals(that.rate);
    }

    @Override
    public int hashCode() {
        int result = plat_rank.hashCode();
        result = 31 * result + plat_code.hashCode();
        result = 31 * result + rateType.hashCode();
        result = 31 * result + rate.hashCode();
        return result;
    }

    @Override
    public int compareTo(BankOfPayPlat o) {
        return this.getRate().compareTo(o.getRate());
    }
}
