package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * 退款状态变更通知请求实体
 * Created by tianchuyang on 2016/11/9.
 */
public class UmPayRefundStatusReq implements Serializable {

    private static final long serialVersionUID = -5256040698747103757L;

    private String mer_id;
    private String sign_type;
    private String sign;
    private String version;
    // 业务参数
    private String refund_no;
    private String order_id;
    private String mer_date;
    private String refund_state;
    private String refund_amt;
    private String error_code;

    public UmPayRefundStatusReq() {
    }

    public UmPayRefundStatusReq(HttpServletRequest request) {
        this.mer_id = request.getParameter("mer_id");
        this.sign_type = request.getParameter("sign_type");
        this.sign = request.getParameter("sign");
        this.version = request.getParameter("version");
        // 业务参数
        this.refund_no = request.getParameter("refund_no");
        this.order_id = request.getParameter("order_id");
        this.mer_date = request.getParameter("mer_date");
        this.refund_state = request.getParameter("refund_state");
        this.refund_amt = request.getParameter("refund_amt");
        this.error_code = request.getParameter("error_code");
    }

    public String getMer_id() {
        return mer_id;
    }

    public void setMer_id(String mer_id) {
        this.mer_id = mer_id;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getRefund_no() {
        return refund_no;
    }

    public void setRefund_no(String refund_no) {
        this.refund_no = refund_no;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getMer_date() {
        return mer_date;
    }

    public void setMer_date(String mer_date) {
        this.mer_date = mer_date;
    }

    public String getRefund_state() {
        return refund_state;
    }

    public void setRefund_state(String refund_state) {
        this.refund_state = refund_state;
    }

    public String getRefund_amt() {
        return refund_amt;
    }

    public void setRefund_amt(String refund_amt) {
        this.refund_amt = refund_amt;
    }

    public String getError_code() {
        return error_code;
    }

    public void setError_code(String error_code) {
        this.error_code = error_code;
    }
}
