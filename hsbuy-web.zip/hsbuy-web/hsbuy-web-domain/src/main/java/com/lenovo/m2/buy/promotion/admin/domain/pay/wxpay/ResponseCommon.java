package com.lenovo.m2.buy.promotion.admin.domain.pay.wxpay;

/**
 * Created by kenvin on 2014/10/30.
 */
public class ResponseCommon extends BaseResp {
    private Object data;

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
