package com.lenovo.m2.buy.promotion.admin.domain.pay.ppcloud;

/**
 * @Description:
 * @author: lijie14
 * @Date: 2016/3/14.
 * @Version:1.0
 */
public class SupportPayType {
    /**
     * 支付id
     */
    private String payId;
    /**
     * 支付类型
     */
    private String payType;
    /**
     * 支付请求Url
     */
    private String url;

    public String getPayId() {
        return payId;
    }

    public void setPayId(String payId) {
        this.payId = payId;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SupportPayType that = (SupportPayType) o;

        if (payId != null ? !payId.equals(that.payId) : that.payId != null) return false;
        if (payType != null ? !payType.equals(that.payType) : that.payType != null) return false;
        if (url != null ? !url.equals(that.url) : that.url != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = payId != null ? payId.hashCode() : 0;
        result = 31 * result + (payType != null ? payType.hashCode() : 0);
        result = 31 * result + (url != null ? url.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SupportPayType{" +
                "payId='" + payId + '\'' +
                ", payType='" + payType + '\'' +
                ", url='" + url + '\'' +
                '}';
    }
}
