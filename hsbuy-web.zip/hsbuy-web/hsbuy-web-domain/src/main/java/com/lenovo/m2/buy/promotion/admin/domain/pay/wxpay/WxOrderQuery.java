package com.lenovo.m2.buy.promotion.admin.domain.pay.wxpay;

/**
 * 订单查询
 * Created by kenvin on 2014/10/21.
 */
public class WxOrderQuery {
    private String errcode = "-1";
    private String errmsg ="";
    private WxOrderQueryInfo order_info;

    public String getErrcode() {
        return errcode;
    }

    public void setErrcode(String errcode) {
        this.errcode = errcode;
    }

    public String getErrmsg() {
        return errmsg;
    }

    public void setErrmsg(String errmsg) {
        this.errmsg = errmsg;
    }

    public WxOrderQueryInfo getOrder_info() {
        return order_info;
    }

    public void setOrder_info(WxOrderQueryInfo order_info) {
        this.order_info = order_info;
    }
}
