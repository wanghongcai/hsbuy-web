package com.lenovo.m2.buy.promotion.admin.domain.pay.order;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kangjie
 * @Modified shejc 2014-11-19
 */
public class MongoOrder implements Cloneable {
	
	// 订单
	private String payOrderNo;// 用户支付订单号
	private String orderMainCode;// 主订单号
	private String orderCode;// 订单号
	private String vkorg;// 销售组织
	private String salesChannel = "";// 销售渠道
	private String memberID;// 会员ID
	private String memberCode;//会员编码
	private String costItem = "0";// 订单总价
	private String amountMoney = "0";// 支付订单总金额
	private String giveawayCost = "0";// 赠品优惠金额
	private String giveawayTotal = "0";// 优惠金额总计
	private String creditTotal = "0";// 可得积分
	private String paymentType;// 支付方式  0:招商，1支付宝
	private String payStatus;// 支付状态 0表示正在支付，1表示支付中，2表示完成
	private String orderStatus;//订单状态 活动订单0 作废订单1 已完成2
	private String augru = "";//订单原因
	private String payDatetime;// 支付时间
	private String isTax;
	private String taxContent = "";// 发票内容
	private String taxType = "";// 发票类型
	private String taxCompanyType = "";//发票抬头类型
	private String taxCompany = "";// 发票抬头
	private String isRevoked;// 是否撤单
	private String markText = "";// 订单备注
	private String memberDesc = "";// 会员备注
	private String addonstr = "";// 订单附言
	private String orderRefer;// 订单来源
	private String faType;// 是否FA订单
	private String faid;// faid
	private String faname;// fa名称
	private String customerManagerCode;// 客户经理
	private String createTime;//下单时间
	private String source;
	private String isAbnormal; //异常订单 0为正常订单，1为异常订单
	private String productPhoto;//商品图片
	private String productDesc;//商品描述
    private String hasComment = "0";//是否已评论
    
    private String orderAddType;//订单类型
    private String voucherTotalAmount;//代金券金额，多个用逗号隔开
    private String note;//大礼包金额对应的code，代金券id,多个使用逗号隔开，
    
    private String C1lenovoid;
    
    public String getC1lenovoid() {
		return C1lenovoid;
	}
	public void setC1lenovoid(String c1lenovoid) {
		C1lenovoid = c1lenovoid;
	}
	public String getOrderAddType() {
		return orderAddType;
	}
	public void setOrderAddType(String orderAddType) {
		this.orderAddType = orderAddType;
	}
	public String getVoucherTotalAmount() {
		return voucherTotalAmount;
	}
	public void setVoucherTotalAmount(String voucherTotalAmount) {
		this.voucherTotalAmount = voucherTotalAmount;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}

	//二期新增
    //是否被mq作业取消  orderstatus为1 为取消 可能为作业取消或者被用户撤单
    private String iscancel;
    //更新时间 作业取消的时候更新此时间
    private String updatetime;
    //订单内商品销售类型 0普通商品 1闪购 2预售 3先试后买
    private String salesOrderType;
	
	public String getHasComment() {
		return hasComment;
	}
	public void setHasComment(String hasComment) {
		this.hasComment = hasComment;
	}

	// 产品表
	private List<Product> products;
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	public List<Product> addProduct(Product product) {
		if (products == null) {
			products = new ArrayList<Product>();
		}
		products.add(product);
		return products;
	}
	public List<Product> removeProduct(Product product) {
		if (products == null) {
			products = new ArrayList<Product>();
		}
		else {
			products.remove(product);
		}
		return products;
	}
	
	//支付表
	//private List<PayCount> pay = new ArrayList<PayCount>();
	
	/**
	 * 取代原来的get方法
	 * @return
	 */
//	public PayCount takePay() {
//		if(pay.size()==0){
//			return null;
//		}else {
//			return pay.get(0);
//		}
//	}
//	/**
//	 * 取代原来的 set 方法
//	 * @param receiver
//	 */
//	public void placePay(PayCount payCount) {
//		if(pay.size()==0){
//			pay.add(payCount);
//		}else{
//			pay.set(0, payCount);
//		}
//	}
//	@Deprecated
//	public List<PayCount> getPay() {
//		return pay;
//	}
//	@Deprecated
//	public void setPay(List<PayCount> pay) {
//		this.pay = pay;
//	}
//
//	// 子表(Receiver)
//	private List<Receiver> deliveries = new ArrayList<Receiver>();
//	/**
//	 * 取代原来的get方法
//	 * @return
//	 */
//	public Receiver takeReceiver() {
//		if(deliveries.size()==0){
//			return null;
//		}else {
//			return deliveries.get(0);
//		}
//	}
//	/**
//	 * 取代原来的 set 方法
//	 * @param receiver
//	 */
//	public void placeReceiver(Receiver receiver) {
//		if(deliveries.size()==0){
//			deliveries.add(receiver);
//		}else{
//			deliveries.set(0, receiver);
//		}
//	}
//	/**使用takeReceiver代替get方法*/
//	@Deprecated
//	public List<Receiver> getDeliveries() {
//		return deliveries;
//	}
//	/**使用placeReceiver代替get方法*/
//	@Deprecated
//	public void setDeliveries(List<Receiver> deliveries) {
//		this.deliveries = deliveries;
//	}
	public String getPayOrderNo() {
		return payOrderNo;
	}
	public void setPayOrderNo(String payOrderNo) {
		this.payOrderNo = payOrderNo;
	}
	public String getOrderMainCode() {
		return orderMainCode;
	}
	public void setOrderMainCode(String orderMainCode) {
		this.orderMainCode = orderMainCode;
	}
	public String getOrderCode() {
		return orderCode;
	}
	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}
	public String getVkorg() {
		return vkorg;
	}
	public void setVkorg(String vkorg) {
		this.vkorg = vkorg;
	}
	public String getSalesChannel() {
		return salesChannel;
	}
	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}
	public String getMemberID() {
		return memberID;
	}
	public void setMemberID(String memberID) {
		this.memberID = memberID;
	}
	public String getMemberCode() {
		return memberCode;
	}
	public void setMemberCode(String memberCode) {
		this.memberCode = memberCode;
	}
	public String getCostItem() {
		return costItem;
	}
	public void setCostItem(String costItem) {
		this.costItem = costItem;
	}
	public String getAmountMoney() {
		return amountMoney;
	}
	public void setAmountMoney(String amountMoney) {
		this.amountMoney = amountMoney;
	}
	public String getGiveawayCost() {
		return giveawayCost;
	}
	public void setGiveawayCost(String giveawayCost) {
		this.giveawayCost = giveawayCost;
	}
	public String getGiveawayTotal() {
		return giveawayTotal;
	}
	public void setGiveawayTotal(String giveawayTotal) {
		this.giveawayTotal = giveawayTotal;
	}
	public String getCreditTotal() {
		return creditTotal;
	}
	public void setCreditTotal(String creditTotal) {
		this.creditTotal = creditTotal;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getPayStatus() {
		return payStatus;
	}
	public void setPayStatus(String payStatus) {
		this.payStatus = payStatus;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getAugru() {
		return augru;
	}
	public void setAugru(String augru) {
		this.augru = augru;
	}
	public String getPayDatetime() {
		return payDatetime;
	}
	public void setPayDatetime(String payDatetime) {
		this.payDatetime = payDatetime;
	}
	public String getIsTax() {
		return isTax;
	}
	public void setIsTax(String isTax) {
		this.isTax = isTax;
	}
	public String getTaxContent() {
		return taxContent;
	}
	public void setTaxContent(String taxContent) {
		this.taxContent = taxContent;
	}
	public String getTaxType() {
		return taxType;
	}
	public void setTaxType(String taxType) {
		this.taxType = taxType;
	}
	public String getTaxCompanyType() {
		return taxCompanyType;
	}
	public void setTaxCompanyType(String taxCompanyType) {
		this.taxCompanyType = taxCompanyType;
	}
	public String getTaxCompany() {
		return taxCompany;
	}
	public void setTaxCompany(String taxCompany) {
		this.taxCompany = taxCompany;
	}
	public String getIsRevoked() {
		return isRevoked;
	}
	public void setIsRevoked(String isRevoked) {
		this.isRevoked = isRevoked;
	}
	public String getMarkText() {
		return markText;
	}
	public void setMarkText(String markText) {
		this.markText = markText;
	}
	public String getMemberDesc() {
		return memberDesc;
	}
	public void setMemberDesc(String memberDesc) {
		this.memberDesc = memberDesc;
	}
	public String getAddonstr() {
		return addonstr;
	}
	public void setAddonstr(String addonstr) {
		this.addonstr = addonstr;
	}
	public String getOrderRefer() {
		return orderRefer;
	}
	public void setOrderRefer(String orderRefer) {
		this.orderRefer = orderRefer;
	}
	
	
	public String getFaType() {
		return faType;
	}
	public void setFaType(String faType) {
		this.faType = faType;
	}
	public String getFaid() {
		return faid;
	}
	public void setFaid(String faid) {
		this.faid = faid;
	}
	public String getFaname() {
		return faname;
	}
	public void setFaname(String faname) {
		this.faname = faname;
	}
	public String getCustomerManagerCode() {
		return customerManagerCode;
	}
	public void setCustomerManagerCode(String customerManagerCode) {
		this.customerManagerCode = customerManagerCode;
	}

	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}


	public String getIscancel() {
		return iscancel;
	}
	public void setIscancel(String iscancel) {
		this.iscancel = iscancel;
	}
	public String getUpdatetime() {
		return updatetime;
	}
	public void setUpdatetime(String updatetime) {
		this.updatetime = updatetime;
	}
	public String getIsAbnormal() {
		return isAbnormal;
	}
	public void setIsAbnormal(String isAbnormal) {
		this.isAbnormal = isAbnormal;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getProductPhoto() {
		return productPhoto;
	}
	public void setProductPhoto(String productPhoto) {
		this.productPhoto = productPhoto;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	/**
	 * <br> json后的格式
	 * {
		    "payOrderNo": null,
		    "orderMainCode": null,
		    "orderCode": null,
		    "vkorg": null,
		    "salesChannel": null,
		    "memberID": null,
		    "costItem": null,
		    "amountMoney": null,
		    "giveawayCost": null,
		    "giveawayTotal": null,
		    "creditTotal": null,
		    "paymentType": null,
		    "payStatus": null,
		    "payDatetime": null,
		    "taxContent": null,
		    "taxType": null,
		    "taxCompany": null,
		    "isRevoked": null,
		    "markText": null,
		    "memberDesc": null,
		    "addonstr": null,
		    "orderRefer": null,
		    "isFAOrder": null,
		    "customerManagerCode": null,
		    "products": [
		        {
		            "productCode": null,
		            "productID": null,
		            "productName": null,
		            "productNumber": null,
		            "realityPay": null,
		            "productPay": null,
		            "favourablePay": null,
		            "paySubtotal": null,
		            "discountRate": null,
		            "productCredit": null
		        }
		    ],
		    "paycount": {
		        "gatheringBank": null,
		        "gatheringCode": null,
		        "gatheringNum": null,
		        "gatheringName": null,
		        "paymentLX": null,
		        "payment": null,
		        "paymentUser": null,
		        "gatheringDesc": null
		    },
		    "receiver": {
		        "shipCode": null,
		        "shipName": null,
		        "shipAddr": null,
		        "shipZip": null,
		        "shipEmail": null,
		        "shipCity": null,
		        "deliverCounty": null,
		        "shipArea": null,
		        "deliverArea": null,
		        "deliverAreaName": null,
		        "shipMobile": null,
		        "shipTel": null,
		        "descriptionQuestion": null
		    },
		    "faid": null,
		    "faname": null
		}
	 * @param args
	 */
	public static void main(String[] args) {
//		MongoOrder order = new MongoOrder();
//		
//		Receiver receiver = order.new Receiver();
//		order.setReceiver(receiver);
//		
////		Product product = order.new Product();
////		order.addProduct(product);
//		
//		PayCount payCount = order.new PayCount();
//		order.setPaycount(payCount);
//		
//		String res = JacksonUtil.toJson(order);
//		System.out.println(res);
	}
	
	public MongoOrder clone() throws CloneNotSupportedException {
		MongoOrder cloned = (MongoOrder)super.clone();  
		return cloned;  
    }
	public String getSalesOrderType() {
		return salesOrderType;
	}
	public void setSalesOrderType(String salesOrderType) {
		this.salesOrderType = salesOrderType;
	}  
	
}

