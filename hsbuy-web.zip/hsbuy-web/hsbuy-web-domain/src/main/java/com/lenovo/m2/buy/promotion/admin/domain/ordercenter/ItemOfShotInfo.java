package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;


import com.lenovo.m2.hsbuy.domain.inventory.HsStock;
import com.lenovo.m2.hsbuy.domain.order.OrderItem;

import java.util.List;

/**
 * Created by lzg on 2017/6/7.
 */
public class ItemOfShotInfo extends OrderItem {
    private  List<HsStock> hsStocks;

    public List<HsStock> getHsStocks() {
        return hsStocks;
    }

    public void setHsStocks(List<HsStock> hsStocks) {
        this.hsStocks = hsStocks;
    }
}
