package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;

/**
 * 支付宝纯网关支付实体
 * Created by MengQiang on 2015/5/23.
 */
public class AliPayCwgModel extends BaseModel {
    public AliPayCwgModel() {
        super();
    }

    public AliPayCwgModel(HttpServletRequest request) {
        super(request);
        this.defaultbank = request.getParameter("directbank");
    }
    //支付宝分期默认银行，银行简码
    private String defaultbank;

    public String getDefaultbank() {
        return defaultbank;
    }

    public void setDefaultbank(String defaultbank) {
        this.defaultbank = defaultbank;
    }
}
