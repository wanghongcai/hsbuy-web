package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

/**
 * 更新库存地入参
 *
 * @Author licy13
 * @Date 2017/3/2
 */

public class WareHouseUpdateParam extends BaseParam {
//    [{"orderId":"10284161","orderItemId":"0","wareHouse":"CF","type":1}]
    private String orderItemsJson;

    public String getOrderItemsJson() {
        return orderItemsJson;
    }

    public void setOrderItemsJson(String orderItemsJson) {
        this.orderItemsJson = orderItemsJson;
    }

    @Override
    public String toString() {
        return "WareHouseUpdateParam{" +
                "orderItemsJson='" + orderItemsJson + '\'' +
                '}';
    }
}
