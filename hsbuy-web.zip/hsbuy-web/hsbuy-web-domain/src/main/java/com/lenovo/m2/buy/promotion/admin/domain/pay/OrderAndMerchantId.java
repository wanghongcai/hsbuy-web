package com.lenovo.m2.buy.promotion.admin.domain.pay;

/**
 * Created by caoxd2 on 2015/5/27.
 */
public class OrderAndMerchantId {
    private String orderId;
    private String merchantId;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }
}
