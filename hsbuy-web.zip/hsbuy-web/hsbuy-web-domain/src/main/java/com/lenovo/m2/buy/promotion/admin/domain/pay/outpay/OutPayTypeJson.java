package com.lenovo.m2.buy.promotion.admin.domain.pay.outpay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.order.BaseInfo;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;

import java.util.List;


/**
 * Create For Cashier
 * 收银台切换订单支持支付类型返回Json
 * Created by mengqiang1 on 2015/8/24.
 */
public class OutPayTypeJson extends BaseInfo {
    private PayPortalOrder pay_portal_order;
    private List<OutPayType> pay_type_info;
    public OutPayTypeJson(int rc, String msg, PayPortalOrder pay_portal_order, List<OutPayType> pay_type_info) {
        super(rc, msg);
        this.pay_portal_order = pay_portal_order;//delete
        this.pay_type_info = pay_type_info;
    }
    public OutPayTypeJson() {
        super(0, "");
    }

    public PayPortalOrder getPay_portal_order() {
        return pay_portal_order;
    }

    public void setPay_portal_order(PayPortalOrder pay_portal_order) {
        this.pay_portal_order = pay_portal_order;
    }

    public List<OutPayType> getPay_type_info() {
        return pay_type_info;
    }

    public void setPay_type_info(List<OutPayType> pay_type_info) {
        this.pay_type_info = pay_type_info;
    }
}
