package com.lenovo.m2.buy.promotion.admin.domain.promotion;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class SeckillActivityListQry implements Serializable {
	private Integer id;

	private Integer checkstatus;  //审核状态(0新建；1待审核；2审核通过；3审核未通过)

	private Integer activityType ;  //预约类型 1:团购 2:闪购 3：限时抢购 4：预售

	private String activityname;  //活动名称

	private Integer goodscode;  //商品编码

	private Integer marketable;  //是否上架(0:未启用 1：启用)

	private Integer pageNum;
	private Integer pageSize;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}


    public String getActivityname() {
		return activityname;
	}

	public void setActivityname(String activityname) {
		this.activityname = activityname == null ? null : activityname.trim();
	}

	public Integer getCheckstatus() {
		return checkstatus;
	}

	public void setCheckstatus(Integer checkstatus) {
		this.checkstatus = checkstatus;
	}

    public Integer getActivityType() {
        return activityType;
    }

    public void setActivityType(Integer activityType) {
        this.activityType = activityType;
    }

	public Integer getPageNum() {
		return pageNum;
	}

	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getGoodscode() {
		return goodscode;
	}

	public void setGoodscode(Integer goodscode) {
		this.goodscode = goodscode;
	}

	public Integer getMarketable() {
		return marketable;
	}

	public void setMarketable(Integer marketable) {
		this.marketable = marketable;
	}

	public Map<String,Object> toMap(){
		Map<String,Object> ret = new HashMap<>();
		ret.put("checkstatus", this.checkstatus);
		ret.put("activityType", this.activityType);
		ret.put("activityname", this.activityname);
		ret.put("gcode", this.goodscode);
		ret.put("marketable", this.marketable);
		return ret;
	}

	@Override
	public String toString() {
		return "SeckillActivityListQry [id=" + id + ", checkstatus=" + checkstatus + ", activityType=" + activityType
				+ ", activityname=" + activityname + ", goodscode=" + goodscode + ", marketable=" + marketable
				+ ", pageNum=" + pageNum + ", pageSize=" + pageSize + "]";
	}
	
}