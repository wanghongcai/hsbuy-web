package com.lenovo.m2.buy.promotion.admin.domain.pay.wxpay;

import org.apache.commons.lang.StringUtils;

import java.util.TreeMap;

/**
 * 支付package 通过订单号 从科马获取
 * Created by kenvin on 2014/10/23.
 */
public class PayPackage {
    private String errcode = "-1";
    private String errmsg;
    private String body;
    private String attach;//附加数据
    private String out_trade_no;//商户订单号
    private String partner;//商户号
    private String total_fee;//支付金额 订单总金额 单位：分
    private String fee_type;// 1 默认人民币
    private String spbill_create_ip;//用户下单机器ip
    private String time_start;
    private String time_expire;
    private String transport_fee;//物流费用
    private String product_fee;//物品费用
    private String goods_tag;//商品标记
    private String input_charset;
    private String bank_type;
    private String notify_url;//回调ｕｒｌ
    private String sign;//签名

    public String getErrcode() {
        return errcode;
    }

    public void setErrcode(String errcode) {
        this.errcode = errcode;
    }

    public String getErrmsg() {
        return errmsg;
    }

    public void setErrmsg(String errmsg) {
        this.errmsg = errmsg;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getAttach() {
        return attach;
    }

    public void setAttach(String attach) {
        this.attach = attach;
    }

    public String getOut_trade_no() {
        return out_trade_no;
    }

    public void setOut_trade_no(String out_trade_no) {
        this.out_trade_no = out_trade_no;
    }

    public String getTotal_fee() {
        return total_fee;
    }

    public void setTotal_fee(String total_fee) {
        this.total_fee = total_fee;
    }

    public String getSpbill_create_ip() {
        return spbill_create_ip;
    }

    public void setSpbill_create_ip(String spbill_create_ip) {
        this.spbill_create_ip = spbill_create_ip;
    }

    public String getTime_start() {
        return time_start;
    }

    public void setTime_start(String time_start) {
        this.time_start = time_start;
    }

    public String getTime_expire() {
        return time_expire;
    }

    public void setTime_expire(String time_expire) {
        this.time_expire = time_expire;
    }

    public String getTransport_fee() {
        return transport_fee;
    }

    public void setTransport_fee(String transport_fee) {
        this.transport_fee = transport_fee;
    }

    public String getProduct_fee() {
        return product_fee;
    }

    public void setProduct_fee(String product_fee) {
        this.product_fee = product_fee;
    }

    public String getGoods_tag() {
        return goods_tag;
    }

    public void setGoods_tag(String goods_tag) {
        this.goods_tag = goods_tag;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getInput_charset() {
        return input_charset;
    }

    public void setInput_charset(String input_charset) {
        this.input_charset = input_charset;
    }

    public String getBank_type() {
        return bank_type;
    }

    public void setBank_type(String bank_type) {
        this.bank_type = bank_type;
    }

    public String getNotify_url() {
        return notify_url;
    }

    public void setNotify_url(String notify_url) {
        this.notify_url = notify_url;
    }

    public String getPartner() {
        return partner;
    }

    public void setPartner(String partner) {
        this.partner = partner;
    }

    public String getFee_type() {
        return fee_type;
    }

    public void setFee_type(String fee_type) {
        this.fee_type = fee_type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PayPackage that = (PayPackage) o;

        if (attach != null ? !attach.equals(that.attach) : that.attach != null) return false;
        if (bank_type != null ? !bank_type.equals(that.bank_type) : that.bank_type != null) return false;
        if (body != null ? !body.equals(that.body) : that.body != null) return false;
        if (fee_type != null ? !fee_type.equals(that.fee_type) : that.fee_type != null) return false;
        if (goods_tag != null ? !goods_tag.equals(that.goods_tag) : that.goods_tag != null) return false;
        if (input_charset != null ? !input_charset.equals(that.input_charset) : that.input_charset != null)
            return false;
        if (notify_url != null ? !notify_url.equals(that.notify_url) : that.notify_url != null) return false;
        if (out_trade_no != null ? !out_trade_no.equals(that.out_trade_no) : that.out_trade_no != null) return false;
        if (partner != null ? !partner.equals(that.partner) : that.partner != null) return false;
        if (product_fee != null ? !product_fee.equals(that.product_fee) : that.product_fee != null) return false;
        if (sign != null ? !sign.equals(that.sign) : that.sign != null) return false;
        if (spbill_create_ip != null ? !spbill_create_ip.equals(that.spbill_create_ip) : that.spbill_create_ip != null)
            return false;
        if (time_expire != null ? !time_expire.equals(that.time_expire) : that.time_expire != null) return false;
        if (time_start != null ? !time_start.equals(that.time_start) : that.time_start != null) return false;
        if (total_fee != null ? !total_fee.equals(that.total_fee) : that.total_fee != null) return false;
        if (transport_fee != null ? !transport_fee.equals(that.transport_fee) : that.transport_fee != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = body != null ? body.hashCode() : 0;
        result = 31 * result + (attach != null ? attach.hashCode() : 0);
        result = 31 * result + (out_trade_no != null ? out_trade_no.hashCode() : 0);
        result = 31 * result + (partner != null ? partner.hashCode() : 0);
        result = 31 * result + (total_fee != null ? total_fee.hashCode() : 0);
        result = 31 * result + (fee_type != null ? fee_type.hashCode() : 0);
        result = 31 * result + (spbill_create_ip != null ? spbill_create_ip.hashCode() : 0);
        result = 31 * result + (time_start != null ? time_start.hashCode() : 0);
        result = 31 * result + (time_expire != null ? time_expire.hashCode() : 0);
        result = 31 * result + (transport_fee != null ? transport_fee.hashCode() : 0);
        result = 31 * result + (product_fee != null ? product_fee.hashCode() : 0);
        result = 31 * result + (goods_tag != null ? goods_tag.hashCode() : 0);
        result = 31 * result + (input_charset != null ? input_charset.hashCode() : 0);
        result = 31 * result + (bank_type != null ? bank_type.hashCode() : 0);
        result = 31 * result + (notify_url != null ? notify_url.hashCode() : 0);
        result = 31 * result + (sign != null ? sign.hashCode() : 0);
        return result;
    }

    public TreeMap<String,String> getMap(){
        TreeMap<String,String> map = new TreeMap<String, String>();

        map.put("out_trade_no",out_trade_no);
        map.put("total_fee",total_fee);

        if(StringUtils.isNotEmpty(body)) map.put("body",body);

        if(StringUtils.isNotEmpty(attach)) map.put("attach",attach);

        if(StringUtils.isNotEmpty(spbill_create_ip)) map.put("spbill_create_ip",spbill_create_ip);

        if(StringUtils.isNotEmpty(time_start)) map.put("time_start",time_start);

        if(StringUtils.isNotEmpty(time_expire)) map.put("time_expire",time_expire);

        if(StringUtils.isNotEmpty(transport_fee)) map.put("transport_fee",transport_fee);

        if(StringUtils.isNotEmpty(product_fee)) map.put("product_fee",product_fee);

        if(StringUtils.isNotEmpty(goods_tag)) map.put("goods_tag",goods_tag);

        if(StringUtils.isNotEmpty(input_charset)) map.put("input_charset",input_charset);

        if(StringUtils.isNotEmpty(bank_type)) map.put("bank_type",bank_type);

        if(StringUtils.isNotEmpty(notify_url)) map.put("notify_url",notify_url);

        if(StringUtils.isNotEmpty(partner)) map.put("partner",partner);

        if(StringUtils.isNotEmpty(fee_type)) map.put("fee_type",fee_type);

        return map;
    }

}
