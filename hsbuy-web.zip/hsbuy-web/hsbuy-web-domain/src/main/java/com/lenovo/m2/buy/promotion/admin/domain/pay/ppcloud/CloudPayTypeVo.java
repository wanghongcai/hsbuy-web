package com.lenovo.m2.buy.promotion.admin.domain.pay.ppcloud;

import java.util.List;

/**
 * @Description:
 * @author: lijie14
 * @Date: 2016/3/14.
 * @Version:1.0
 */
public class CloudPayTypeVo {
    /**
     * 返回码
     */
    private String code;
    /**
     * 返回信息
     */
    private String msg;
    /**
     * 主单号
     */
    private String orderMainCode;

    private List<SupportPayType> orderSupportPayTypeList;

    private List<FqPayType> orderFqList;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getOrderMainCode() {
        return orderMainCode;
    }

    public void setOrderMainCode(String orderMainCode) {
        this.orderMainCode = orderMainCode;
    }

    public List<SupportPayType> getOrderSupportPayTypeList() {
        return orderSupportPayTypeList;
    }

    public void setOrderSupportPayTypeList(List<SupportPayType> orderSupportPayTypeList) {
        this.orderSupportPayTypeList = orderSupportPayTypeList;
    }

    public List<FqPayType> getOrderFqList() {
        return orderFqList;
    }

    public void setOrderFqList(List<FqPayType> orderFqList) {
        this.orderFqList = orderFqList;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CloudPayTypeVo that = (CloudPayTypeVo) o;

        if (msg != null ? !msg.equals(that.msg) : that.msg != null) return false;
        if (orderFqList != null ? !orderFqList.equals(that.orderFqList) : that.orderFqList != null) return false;
        if (orderMainCode != null ? !orderMainCode.equals(that.orderMainCode) : that.orderMainCode != null)
            return false;
        if (orderSupportPayTypeList != null ? !orderSupportPayTypeList.equals(that.orderSupportPayTypeList) : that.orderSupportPayTypeList != null)
            return false;
        if (code != null ? !code.equals(that.code) : that.code != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = code != null ? code.hashCode() : 0;
        result = 31 * result + (msg != null ? msg.hashCode() : 0);
        result = 31 * result + (orderMainCode != null ? orderMainCode.hashCode() : 0);
        result = 31 * result + (orderSupportPayTypeList != null ? orderSupportPayTypeList.hashCode() : 0);
        result = 31 * result + (orderFqList != null ? orderFqList.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "CloudPayTypeVo{" +
                "code='" + code + '\'' +
                ", msg='" + msg + '\'' +
                ", orderMainCode='" + orderMainCode + '\'' +
                ", orderSupportPayTypeList=" + orderSupportPayTypeList +
                ", orderFqList=" + orderFqList +
                '}';
    }
}
