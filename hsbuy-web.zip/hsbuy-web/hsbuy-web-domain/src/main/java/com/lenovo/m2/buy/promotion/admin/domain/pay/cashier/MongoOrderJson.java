package com.lenovo.m2.buy.promotion.admin.domain.pay.cashier;

import com.lenovo.m2.buy.promotion.admin.domain.pay.order.BaseInfo;
import com.lenovo.m2.hsbuy.domain.pay.soa.ChannelOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.OrderSupportPayType;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;

import java.util.List;


/**
 * Create For Cashier
 * 收银台切换订单支持支付类型返回Json
 * Created by mengqiang1 on 2015/8/24.
 */
public class MongoOrderJson extends BaseInfo {
    private PayPortalOrder payPortalOrder;//delete
    private ChannelOrder channelOrder;
    private List<OrderSupportPayType> orderSupportPayTypeList;
    public MongoOrderJson(int rc, String msg, PayPortalOrder payPortalOrder, ChannelOrder channelOrder, List<OrderSupportPayType> orderSupportPayTypeList) {
        super(rc, msg);
        this.payPortalOrder = payPortalOrder;//delete
        this.channelOrder = channelOrder;
        this.orderSupportPayTypeList = orderSupportPayTypeList;
    }
    public MongoOrderJson() {
        super(0, "");
    }

    public PayPortalOrder getPayPortalOrder() {
        return payPortalOrder;
    }

    public void setPayPortalOrder(PayPortalOrder payPortalOrder) {
        this.payPortalOrder = payPortalOrder;
    }

    public ChannelOrder getChannelOrder() {
        return channelOrder;
    }

    public void setChannelOrder(ChannelOrder channelOrder) {
        this.channelOrder = channelOrder;
    }

    public List<OrderSupportPayType> getOrderSupportPayTypeList() {
        return orderSupportPayTypeList;
    }

    public void setOrderSupportPayTypeList(List<OrderSupportPayType> orderSupportPayTypeList) {
        this.orderSupportPayTypeList = orderSupportPayTypeList;
    }
}
