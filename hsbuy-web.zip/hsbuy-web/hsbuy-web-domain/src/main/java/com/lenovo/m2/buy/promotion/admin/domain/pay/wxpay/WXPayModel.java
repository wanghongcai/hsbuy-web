package com.lenovo.m2.buy.promotion.admin.domain.pay.wxpay;



import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;

public class WXPayModel extends BaseModel {

	public WXPayModel() {
		super();
	}

	public WXPayModel(HttpServletRequest request) {
		super(request);
	}
	
}
