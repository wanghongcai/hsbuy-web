package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by Administrator on 2016/11/10.
 */
public class CMBFQModel extends BaseModel {

    public CMBFQModel() {
        super();
    }

    public CMBFQModel(HttpServletRequest request) {
        super(request);
    }
}
