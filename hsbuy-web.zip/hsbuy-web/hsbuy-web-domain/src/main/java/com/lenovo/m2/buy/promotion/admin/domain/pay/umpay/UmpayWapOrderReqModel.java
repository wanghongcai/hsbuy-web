package com.lenovo.m2.buy.promotion.admin.domain.pay.umpay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * 联动优势WAP下订单请求模型
 * Created by tianchuyang on 2016/11/22.
 */
public class UmpayWapOrderReqModel extends BaseModel implements Serializable {

    private static final long serialVersionUID = 5571987516809443435L;

    private String service;
    private String charset;
    private String mer_id;
    private String sign_type;
    private String sign;
    private String ret_url;
    private String notify_url;
    private String res_format;
    private String version;
    // 业务参数
    private String goods_id;
    private String goods_inf;
    private String order_id;
    private String mer_date;
    private String amount;
    private String amt_type;
    private String mer_priv;
    private String expand;
    private String expire_time;
    private String risk_expand;

    public UmpayWapOrderReqModel() {
    }

    public UmpayWapOrderReqModel(HttpServletRequest request) {
        super(request);
        this.service = request.getParameter("service");
        this.charset = request.getParameter("charset");
        this.mer_id = request.getParameter("mer_id");
        this.sign_type = request.getParameter("sign_type");
        this.sign = request.getParameter("sign");
        this.ret_url = request.getParameter("ret_url");
        this.notify_url = request.getParameter("notify_url");
        this.res_format = request.getParameter("res_format");
        this.version = request.getParameter("version");
        this.goods_id = request.getParameter("goods_id");
        this.goods_inf = request.getParameter("goods_inf");
        this.order_id = request.getParameter("order_id");
        this.mer_date = request.getParameter("mer_date");
        this.amount = request.getParameter("amount");
        this.amt_type = request.getParameter("amt_type");
        this.mer_priv = request.getParameter("mer_priv");
        this.expand = request.getParameter("expand");
        this.expire_time = request.getParameter("expire_time");
        this.risk_expand = request.getParameter("risk_expand");
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public String getMer_id() {
        return mer_id;
    }

    public void setMer_id(String mer_id) {
        this.mer_id = mer_id;
    }

    public String getSign_type() {
        return sign_type;
    }

    public void setSign_type(String sign_type) {
        this.sign_type = sign_type;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getRet_url() {
        return ret_url;
    }

    public void setRet_url(String ret_url) {
        this.ret_url = ret_url;
    }

    public String getNotify_url() {
        return notify_url;
    }

    public void setNotify_url(String notify_url) {
        this.notify_url = notify_url;
    }

    public String getRes_format() {
        return res_format;
    }

    public void setRes_format(String res_format) {
        this.res_format = res_format;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getGoods_id() {
        return goods_id;
    }

    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id;
    }

    public String getGoods_inf() {
        return goods_inf;
    }

    public void setGoods_inf(String goods_inf) {
        this.goods_inf = goods_inf;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getMer_date() {
        return mer_date;
    }

    public void setMer_date(String mer_date) {
        this.mer_date = mer_date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getAmt_type() {
        return amt_type;
    }

    public void setAmt_type(String amt_type) {
        this.amt_type = amt_type;
    }

    public String getMer_priv() {
        return mer_priv;
    }

    public void setMer_priv(String mer_priv) {
        this.mer_priv = mer_priv;
    }

    public String getExpand() {
        return expand;
    }

    public void setExpand(String expand) {
        this.expand = expand;
    }

    public String getExpire_time() {
        return expire_time;
    }

    public void setExpire_time(String expire_time) {
        this.expire_time = expire_time;
    }

    public String getRisk_expand() {
        return risk_expand;
    }

    public void setRisk_expand(String risk_expand) {
        this.risk_expand = risk_expand;
    }
}
