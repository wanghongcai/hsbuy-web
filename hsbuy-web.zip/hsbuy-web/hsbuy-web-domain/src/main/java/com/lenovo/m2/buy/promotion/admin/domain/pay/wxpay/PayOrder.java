package com.lenovo.m2.buy.promotion.admin.domain.pay.wxpay;

import java.util.Date;

/**
 * Created by kenvin on 2014/10/30.
 */
public class PayOrder {

    private Long id;
    private String body;
    private String u_id;
    private Integer pay_type;
    private Integer os;
    private String openid;
    private String attach;
    private String out_trade_no;
    private Integer total_fee;
    private Integer fee_type;
    private String spbill_create_ip;
    private Date time_start;
    private Date time_expire;
    private Integer transport_fee;
    private Integer product_fee;
    private String goods_tag;
    private Integer wx_flag;
    private Integer km_flag;
    private Integer trade_state;
    private String notify_id;
    private String transation_id;
    private Integer is_refund;
    private String header_data;
    private Date time_end;
    private Date create_time;
    private Date update_time;
    private Integer version;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getU_id() {
        return u_id;
    }

    public void setU_id(String u_id) {
        this.u_id = u_id;
    }

    public Integer getOs() {
        return os;
    }

    public void setOs(Integer os) {
        this.os = os;
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getAttach() {
        return attach;
    }

    public void setAttach(String attach) {
        this.attach = attach;
    }

    public String getOut_trade_no() {
        return out_trade_no;
    }

    public void setOut_trade_no(String out_trade_no) {
        this.out_trade_no = out_trade_no;
    }

    public Integer getTotal_fee() {
        return total_fee;
    }

    public void setTotal_fee(Integer total_fee) {
        this.total_fee = total_fee;
    }

    public Integer getFee_type() {
        return fee_type;
    }

    public void setFee_type(Integer fee_type) {
        this.fee_type = fee_type;
    }

    public String getSpbill_create_ip() {
        return spbill_create_ip;
    }

    public void setSpbill_create_ip(String spbill_create_ip) {
        this.spbill_create_ip = spbill_create_ip;
    }

    public Date getTime_start() {
        return time_start;
    }

    public void setTime_start(Date time_start) {
        this.time_start = time_start;
    }

    public Date getTime_expire() {
        return time_expire;
    }

    public void setTime_expire(Date time_expire) {
        this.time_expire = time_expire;
    }

    public Integer getTransport_fee() {
        return transport_fee;
    }

    public void setTransport_fee(Integer transport_fee) {
        this.transport_fee = transport_fee;
    }

    public Integer getProduct_fee() {
        return product_fee;
    }

    public void setProduct_fee(Integer product_fee) {
        this.product_fee = product_fee;
    }

    public String getGoods_tag() {
        return goods_tag;
    }

    public void setGoods_tag(String goods_tag) {
        this.goods_tag = goods_tag;
    }

    public Integer getWx_flag() {
        return wx_flag;
    }

    public void setWx_flag(Integer wx_flag) {
        this.wx_flag = wx_flag;
    }

    public Integer getKm_flag() {
        return km_flag;
    }

    public void setKm_flag(Integer km_flag) {
        this.km_flag = km_flag;
    }

    public Integer getTrade_state() {
        return trade_state;
    }

    public void setTrade_state(Integer trade_state) {
        this.trade_state = trade_state;
    }

    public String getNotify_id() {
        return notify_id;
    }

    public void setNotify_id(String notify_id) {
        this.notify_id = notify_id;
    }

    public String getTransation_id() {
        return transation_id;
    }

    public void setTransation_id(String transation_id) {
        this.transation_id = transation_id;
    }

    public Date getTime_end() {
        return time_end;
    }

    public void setTime_end(Date time_end) {
        this.time_end = time_end;
    }

    public Date getCreate_time() {
        return create_time;
    }

    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Integer getPay_type() {
        return pay_type;
    }

    public void setPay_type(Integer pay_type) {
        this.pay_type = pay_type;
    }

    public Integer getIs_refund() {
        return is_refund;
    }

    public void setIs_refund(Integer is_refund) {
        this.is_refund = is_refund;
    }

    public String getHeader_data() {
        return header_data;
    }

    public void setHeader_data(String header_data) {
        this.header_data = header_data;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PayOrder payOrder = (PayOrder) o;

        if (attach != null ? !attach.equals(payOrder.attach) : payOrder.attach != null) return false;
        if (body != null ? !body.equals(payOrder.body) : payOrder.body != null) return false;
        if (create_time != null ? !create_time.equals(payOrder.create_time) : payOrder.create_time != null)
            return false;
        if (fee_type != null ? !fee_type.equals(payOrder.fee_type) : payOrder.fee_type != null) return false;
        if (goods_tag != null ? !goods_tag.equals(payOrder.goods_tag) : payOrder.goods_tag != null) return false;
        if (header_data != null ? !header_data.equals(payOrder.header_data) : payOrder.header_data != null)
            return false;
        if (id != null ? !id.equals(payOrder.id) : payOrder.id != null) return false;
        if (is_refund != null ? !is_refund.equals(payOrder.is_refund) : payOrder.is_refund != null) return false;
        if (km_flag != null ? !km_flag.equals(payOrder.km_flag) : payOrder.km_flag != null) return false;
        if (notify_id != null ? !notify_id.equals(payOrder.notify_id) : payOrder.notify_id != null) return false;
        if (openid != null ? !openid.equals(payOrder.openid) : payOrder.openid != null) return false;
        if (os != null ? !os.equals(payOrder.os) : payOrder.os != null) return false;
        if (out_trade_no != null ? !out_trade_no.equals(payOrder.out_trade_no) : payOrder.out_trade_no != null)
            return false;
        if (pay_type != null ? !pay_type.equals(payOrder.pay_type) : payOrder.pay_type != null) return false;
        if (product_fee != null ? !product_fee.equals(payOrder.product_fee) : payOrder.product_fee != null)
            return false;
        if (spbill_create_ip != null ? !spbill_create_ip.equals(payOrder.spbill_create_ip) : payOrder.spbill_create_ip != null)
            return false;
        if (time_end != null ? !time_end.equals(payOrder.time_end) : payOrder.time_end != null) return false;
        if (time_expire != null ? !time_expire.equals(payOrder.time_expire) : payOrder.time_expire != null)
            return false;
        if (time_start != null ? !time_start.equals(payOrder.time_start) : payOrder.time_start != null) return false;
        if (total_fee != null ? !total_fee.equals(payOrder.total_fee) : payOrder.total_fee != null) return false;
        if (trade_state != null ? !trade_state.equals(payOrder.trade_state) : payOrder.trade_state != null)
            return false;
        if (transation_id != null ? !transation_id.equals(payOrder.transation_id) : payOrder.transation_id != null)
            return false;
        if (transport_fee != null ? !transport_fee.equals(payOrder.transport_fee) : payOrder.transport_fee != null)
            return false;
        if (u_id != null ? !u_id.equals(payOrder.u_id) : payOrder.u_id != null) return false;
        if (update_time != null ? !update_time.equals(payOrder.update_time) : payOrder.update_time != null)
            return false;
        if (version != null ? !version.equals(payOrder.version) : payOrder.version != null) return false;

        if (wx_flag != null ? !wx_flag.equals(payOrder.wx_flag) : payOrder.wx_flag != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (body != null ? body.hashCode() : 0);
        result = 31 * result + (u_id != null ? u_id.hashCode() : 0);
        result = 31 * result + (pay_type != null ? pay_type.hashCode() : 0);

        result = 31 * result + (os != null ? os.hashCode() : 0);
        result = 31 * result + (openid != null ? openid.hashCode() : 0);
        result = 31 * result + (attach != null ? attach.hashCode() : 0);
        result = 31 * result + (out_trade_no != null ? out_trade_no.hashCode() : 0);
        result = 31 * result + (total_fee != null ? total_fee.hashCode() : 0);
        result = 31 * result + (fee_type != null ? fee_type.hashCode() : 0);
        result = 31 * result + (spbill_create_ip != null ? spbill_create_ip.hashCode() : 0);
        result = 31 * result + (time_start != null ? time_start.hashCode() : 0);
        result = 31 * result + (time_expire != null ? time_expire.hashCode() : 0);
        result = 31 * result + (transport_fee != null ? transport_fee.hashCode() : 0);
        result = 31 * result + (product_fee != null ? product_fee.hashCode() : 0);
        result = 31 * result + (goods_tag != null ? goods_tag.hashCode() : 0);
        result = 31 * result + (wx_flag != null ? wx_flag.hashCode() : 0);
        result = 31 * result + (km_flag != null ? km_flag.hashCode() : 0);
        result = 31 * result + (trade_state != null ? trade_state.hashCode() : 0);
        result = 31 * result + (notify_id != null ? notify_id.hashCode() : 0);
        result = 31 * result + (transation_id != null ? transation_id.hashCode() : 0);
        result = 31 * result + (is_refund != null ? is_refund.hashCode() : 0);
        result = 31 * result + (header_data != null ? header_data.hashCode() : 0);
        result = 31 * result + (time_end != null ? time_end.hashCode() : 0);
        result = 31 * result + (create_time != null ? create_time.hashCode() : 0);
        result = 31 * result + (update_time != null ? update_time.hashCode() : 0);
        result = 31 * result + (version != null ? version.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "PayOrder{" +
                "id=" + id +
                ", body='" + body + '\'' +
                ", u_id='" + u_id + '\'' +
                ", pay_type=" + pay_type +
                ", os=" + os +
                ", openid='" + openid + '\'' +
                ", attach='" + attach + '\'' +
                ", out_trade_no='" + out_trade_no + '\'' +
                ", total_fee=" + total_fee +
                ", fee_type=" + fee_type +
                ", spbill_create_ip='" + spbill_create_ip + '\'' +
                ", time_start=" + time_start +
                ", time_expire=" + time_expire +
                ", transport_fee=" + transport_fee +
                ", product_fee=" + product_fee +
                ", goods_tag='" + goods_tag + '\'' +
                ", wx_flag=" + wx_flag +
                ", km_flag=" + km_flag +
                ", trade_state=" + trade_state +
                ", notify_id='" + notify_id + '\'' +
                ", transation_id='" + transation_id + '\'' +
                ", is_refund=" + is_refund +
                ", header_data='" + header_data + '\'' +
                ", time_end=" + time_end +
                ", create_time=" + create_time +
                ", update_time=" + update_time +
                ", version=" + version +
                '}';
    }
}
