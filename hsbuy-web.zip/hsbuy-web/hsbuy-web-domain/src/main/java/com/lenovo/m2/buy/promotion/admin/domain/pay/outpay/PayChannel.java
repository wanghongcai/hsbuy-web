package com.lenovo.m2.buy.promotion.admin.domain.pay.outpay;

import java.util.List;

/**
 * 支付渠道
 * Created by tianchuyang on 2017/1/10.
 */
public class PayChannel {

    private boolean success;
    private String resultMessage;
    private List<OutPayType> pay_type_list;
    private Points points;

    public PayChannel() {
    }

    public PayChannel(boolean success, String resultMessage, List<OutPayType> pay_type_list, Points points) {
        this.success = success;
        this.resultMessage = resultMessage;
        this.pay_type_list = pay_type_list;
        this.points = points;
    }

    public Points getPoints() {
        return points;
    }

    public void setPoints(Points points) {
        this.points = points;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getResultMessage() {
        return resultMessage;
    }

    public void setResultMessage(String resultMessage) {
        this.resultMessage = resultMessage;
    }

    public List<OutPayType> getPay_type_list() {
        return pay_type_list;
    }

    public void setPay_type_list(List<OutPayType> pay_type_list) {
        this.pay_type_list = pay_type_list;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PayChannel that = (PayChannel) o;

        if (success != that.success) return false;
        if (resultMessage != null ? !resultMessage.equals(that.resultMessage) : that.resultMessage != null)
            return false;
        if (pay_type_list != null ? !pay_type_list.equals(that.pay_type_list) : that.pay_type_list != null)
            return false;
        return points != null ? points.equals(that.points) : that.points == null;
    }

    @Override
    public int hashCode() {
        int result = (success ? 1 : 0);
        result = 31 * result + (resultMessage != null ? resultMessage.hashCode() : 0);
        result = 31 * result + (pay_type_list != null ? pay_type_list.hashCode() : 0);
        result = 31 * result + (points != null ? points.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("{");
        sb.append("\"success\":")
                .append(success);
        sb.append(",\"resultMessage\":\"")
                .append(resultMessage).append('\"');
        sb.append(",\"pay_type_list\":")
                .append(pay_type_list);
        sb.append(",\"points\":")
                .append(points);
        sb.append('}');
        return sb.toString();
    }
}
