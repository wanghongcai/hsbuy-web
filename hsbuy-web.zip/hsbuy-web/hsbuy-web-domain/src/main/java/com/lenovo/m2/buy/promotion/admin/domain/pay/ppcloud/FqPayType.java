package com.lenovo.m2.buy.promotion.admin.domain.pay.ppcloud;

/**
 * @Description:
 * @author: lijie14
 * @Date: 2016/3/14.
 * @Version:1.0
 */
public class FqPayType {
    /**
     * 分期类型：10农行分期，11花呗分期
     */
    private String fqType;
    /**
     *分期期数
     */
    private String fqNum;
    /**
     *分期费率
     */
    private String fqRate;
    /**
     *费用承担比例
     */
    private String fqRatePer;
    /**
     *分期代码
     */
    private String installmentCode;
    /**
     * 支付请求Url
     */
    private String url;

    public String getFqType() {
        return fqType;
    }

    public void setFqType(String fqType) {
        this.fqType = fqType;
    }

    public String getFqNum() {
        return fqNum;
    }

    public void setFqNum(String fqNum) {
        this.fqNum = fqNum;
    }

    public String getFqRate() {
        return fqRate;
    }

    public void setFqRate(String fqRate) {
        this.fqRate = fqRate;
    }

    public String getFqRatePer() {
        return fqRatePer;
    }

    public void setFqRatePer(String fqRatePer) {
        this.fqRatePer = fqRatePer;
    }

    public String getInstallmentCode() {
        return installmentCode;
    }

    public void setInstallmentCode(String installmentCode) {
        this.installmentCode = installmentCode;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FqPayType fqPayType = (FqPayType) o;

        if (fqNum != null ? !fqNum.equals(fqPayType.fqNum) : fqPayType.fqNum != null) return false;
        if (fqRate != null ? !fqRate.equals(fqPayType.fqRate) : fqPayType.fqRate != null) return false;
        if (fqRatePer != null ? !fqRatePer.equals(fqPayType.fqRatePer) : fqPayType.fqRatePer != null) return false;
        if (fqType != null ? !fqType.equals(fqPayType.fqType) : fqPayType.fqType != null) return false;
        if (installmentCode != null ? !installmentCode.equals(fqPayType.installmentCode) : fqPayType.installmentCode != null)
            return false;
        if (url != null ? !url.equals(fqPayType.url) : fqPayType.url != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = fqType != null ? fqType.hashCode() : 0;
        result = 31 * result + (fqNum != null ? fqNum.hashCode() : 0);
        result = 31 * result + (fqRate != null ? fqRate.hashCode() : 0);
        result = 31 * result + (fqRatePer != null ? fqRatePer.hashCode() : 0);
        result = 31 * result + (installmentCode != null ? installmentCode.hashCode() : 0);
        result = 31 * result + (url != null ? url.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "FqPayType{" +
                "fqType='" + fqType + '\'' +
                ", fqNum='" + fqNum + '\'' +
                ", fqRate='" + fqRate + '\'' +
                ", fqRatePer='" + fqRatePer + '\'' +
                ", installmentCode='" + installmentCode + '\'' +
                ", url='" + url + '\'' +
                '}';
    }
}
