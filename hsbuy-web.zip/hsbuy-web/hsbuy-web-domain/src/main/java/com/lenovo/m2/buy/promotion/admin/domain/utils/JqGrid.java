package com.lenovo.m2.buy.promotion.admin.domain.utils;

import com.lenovo.m2.arch.framework.domain.PageModel;
import com.lenovo.m2.arch.framework.domain.PageModel2;
import com.lenovo.m2.arch.framework.domain.PageQuery;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author luqian
 * @ClassName:JqGrid
 * @Description:jqgrid表格实体类，用来封装jqgrid属性及json字符串的返回
 */
public class JqGrid<T> implements Serializable {
    /**
     * 第几页
     */
    private int page = 1;

    private int total = 0;
    /**
     * 每页最大行数
     */
    private int rows = 20;
    /**
     * 总数据数，非查询结果数
     */
    private long records = 0;
    /**
     * 排序字段
     */
    private String sidx;

    /**
     * 排序方式
     */
    private String sord = "desc";
    /**
     * 查询结果
     */
    private List<T> dateList = new ArrayList<T>();

    private Map<String, Object> filter = new HashMap<String, Object>();

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public long getRecords() {
        return records;
    }

    public void setRecords(long records) {
        this.records = records;
    }

    /**
     * page的get方法.
     *
     * @return this.page
     */
    public int getPage() {
        return page;
    }

    /**
     * page的set方法.
     *
     * @param page set到 this.page
     */
    public void setPage(int page) {
        this.page = page;
    }

    public int getRows() {
        return rows;
    }

    public void setRows(int rows) {
        this.rows = rows;
    }

    public List<T> getDateList() {
        return dateList;
    }

    public void setDateList(List<T> dateList) {
        this.dateList = dateList;
    }

    /**
     * filter的get方法.
     *
     * @return this.filter
     */
    public Map<String, Object> getFilter() {
        return filter;
    }

    public Object getFilter(String key) {
        return filter.get(key);
    }

    /**
     * filter的set方法.
     *
     * @param filter set到 this.filter
     */
    public void setFilter(Map<String, Object> filter) {
        this.filter = filter;
    }

    public void setFilter(String key, Object value) {
        this.filter.put(key, value);
    }

    public String getSidx() {
        return sidx;
    }

    public void setSidx(String sidx) {
        this.sidx = sidx;
    }

    public String getSord() {
        return sord;
    }

    public void setSord(String sord) {
        this.sord = sord;
    }

    public PageQuery genPageQuery() {
        return new PageQuery(page, rows);
    }

    public void setPageModel2(PageModel2 pageModel) {
        this.dateList = pageModel.getDatas();
        this.total = pageModel.getTotalPageNum();
        this.records = pageModel.getTotalCount();
    }

    public void setPageModel(PageModel<T> pageModel) {
        this.dateList = pageModel.getDatas();
        this.total = pageModel.getTotalPageNum();
        this.records = pageModel.getTotalCount();
    }
}
