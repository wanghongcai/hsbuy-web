
package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.buy.promotion.admin.common.utils.JsonUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.annotate.JsonIgnore;

import java.util.List;
import java.util.Map;

/**
 * 对接受参数的公共部分封装
 */
public class BaseParam implements java.io.Serializable {
    private static final Logger LOGGER = Logger.getLogger(BaseParam.class);


    private static final long serialVersionUID = 1L;

    private int shopId;
    private int terminal;
    private String userId;
    private Tenant tenant;
    @JsonIgnore
    private String authdata;
    private List<String> faIds;

    public String getAuthdata() {
        return authdata;
    }

    public void setAuthdata(String authdata) {
        this.authdata = authdata;
        if(StringUtils.isEmpty(authdata)){
            this.userId="";
        }else {
            Map map = JsonUtil.fromJson(authdata, Map.class);
            this.userId =(String) map.get("userid");
            this.faIds=(List)map.get("faIds");
        }
    }

    //获取租户信息
    public Tenant getTenant() {
        return this.tenant;
    }

    public int getShopId() {
        return shopId;
    }

    public void setShopId(int shopId) {
        this.shopId = shopId;
        this.tenant = Tenant.getTenant(shopId);
    }

    public int getTerminal() {
        return terminal;
    }

    public void setTerminal(int terminal) {
        this.terminal = terminal;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public List<String> getFaIds() {
        return faIds;
    }

    @Override
    public String toString() {
        return "BaseParam{" +
                "shopId=" + shopId +
                ", terminal=" + terminal +
                ", userId='" + userId + '\'' +
                ", tenant=" + tenant +
                ", faIds=" + faIds +
                '}';
    }
}
