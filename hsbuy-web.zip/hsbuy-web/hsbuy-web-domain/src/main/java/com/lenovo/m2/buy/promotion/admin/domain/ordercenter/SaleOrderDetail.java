package com.lenovo.m2.buy.promotion.admin.domain.ordercenter;

import java.io.Serializable;
import java.math.BigDecimal;

public class SaleOrderDetail implements Serializable {
    private BigDecimal quantity;
    private BigDecimal origDiscountPrice;
    private BigDecimal taxRate;
    private BigDecimal origTaxPrice;
    private BigDecimal origDiscountAmount;
    private BigDecimal origTax;
    private BigDecimal origTaxAmount;
    private String deliveryDate;
    private String inventoryCode;
    private String ProductName;

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getOrigDiscountPrice() {
        return origDiscountPrice;
    }

    public void setOrigDiscountPrice(BigDecimal origDiscountPrice) {
        this.origDiscountPrice = origDiscountPrice;
    }

    public BigDecimal getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(BigDecimal taxRate) {
        this.taxRate = taxRate;
    }

    public BigDecimal getOrigTaxPrice() {
        return origTaxPrice;
    }

    public void setOrigTaxPrice(BigDecimal origTaxPrice) {
        this.origTaxPrice = origTaxPrice;
    }

    public BigDecimal getOrigDiscountAmount() {
        return origDiscountAmount;
    }

    public void setOrigDiscountAmount(BigDecimal origDiscountAmount) {
        this.origDiscountAmount = origDiscountAmount;
    }

    public BigDecimal getOrigTax() {
        return origTax;
    }

    public void setOrigTax(BigDecimal origTax) {
        this.origTax = origTax;
    }

    public BigDecimal getOrigTaxAmount() {
        return origTaxAmount;
    }

    public void setOrigTaxAmount(BigDecimal origTaxAmount) {
        this.origTaxAmount = origTaxAmount;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public String getInventoryCode() {
        return inventoryCode;
    }

    public void setInventoryCode(String inventoryCode) {
        this.inventoryCode = inventoryCode;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String productName) {
        ProductName = productName;
    }
}
