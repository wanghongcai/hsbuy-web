package com.lenovo.m2.buy.promotion.admin.domain.pay.alipay;

import com.lenovo.m2.buy.promotion.admin.domain.pay.BaseModel;

import javax.servlet.http.HttpServletRequest;

/**
 * 支付宝WAP直连实体
 * Created by MengQiang on 2016/9/1.
 */
public class AliPayDirectWapModel extends BaseModel {

    public AliPayDirectWapModel(){super();}

    public AliPayDirectWapModel(HttpServletRequest request){
        super(request);
        this.browser = request.getParameter("browser");
    }
    private String browser;

    public String getBrowser() {
        return browser;
    }

    public void setBrowser(String browser) {
        this.browser = browser;
    }
}
