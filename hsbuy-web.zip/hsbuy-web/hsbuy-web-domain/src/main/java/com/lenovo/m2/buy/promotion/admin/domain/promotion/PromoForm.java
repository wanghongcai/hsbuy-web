package com.lenovo.m2.buy.promotion.admin.domain.promotion;

import com.lenovo.m2.buy.promotion.admin.domain.BaseForm;

/**
 * Created by wangrq1 on 2017/2/7.
 */
public class PromoForm extends BaseForm{

    private String id;
    private String name;
    private String beginTime;
    private String endTime;
    private String terminal;     // 逗号分隔
    private String terminalName; // 逗号分隔
    private int enable;
    private String description;
    private int promotionType;
    private String mainProducts;
    private String relProducts;
    private Integer status;
    private String group; //用户组code 多个用逗号分隔
    private String groupName; //用户组name 多个用逗号分隔
    private String fullset; //满减
    private Integer showInList; //是否在app列表展示

    private String productid1;  //主品id
    private String productid2;  //关联品id


	public Integer getShowInList() {
        return showInList;
    }

    public void setShowInList(Integer showInList) {
        this.showInList = showInList;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public int getEnable() {
        return enable;
    }

    public void setEnable(int enable) {
        this.enable = enable;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPromotionType() {
        return promotionType;
    }

    public void setPromotionType(int promotionType) {
        this.promotionType = promotionType;
    }

    public String getMainProducts() {
        return mainProducts;
    }

    public void setMainProducts(String mainProducts) {
        this.mainProducts = mainProducts;
    }

    public String getRelProducts() {
        return relProducts;
    }

    public void setRelProducts(String relProducts) {
        this.relProducts = relProducts;
    }


    public boolean check(){


        return false;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getFullset() {
        return fullset;
    }

    public void setFullset(String fullset) {
        this.fullset = fullset;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getProductid1() {
        return productid1;
    }

    public void setProductid1(String productid1) {
        this.productid1 = productid1;
    }

    public String getProductid2() {
        return productid2;
    }

    public void setProductid2(String productid2) {
        this.productid2 = productid2;
    }

    public String getTerminalName() {
        return terminalName;
    }

    public void setTerminalName(String terminalName) {
        this.terminalName = terminalName;
    }
}
