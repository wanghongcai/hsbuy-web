package com.lenovo.m2.buy.promotion.admin.domain.pay;

/**
 * Created by caoxd2 on 2015/5/23.
 */
public enum PayType {
    Weixin(1,"微信支付"),AliInstant(2,"支付宝即时到账支付"),AliPureGateway(3,"支付宝纯网关支付"),AliMerge(4,"支付宝合并支付"),AliMobile(5,"支付宝移动端"),AliInstalments(6,"支付宝分期支付"),ZhaoShang(7,"招商银行");

    private int payType;
    private String desc;
    private PayType(int payType,String desc){
        this.payType = payType;
        this.desc = desc;
    }

    public static PayType getPayType(int payType){
        switch (payType){
            case 1:
                return Weixin;
            case 2:
                return AliInstant;
            case 3:
                return AliPureGateway;
            case 4:
                return AliMerge;
            case 5:
                return AliMobile;
            case 6:
                return AliInstalments;
            case 7:
                return ZhaoShang;
            default:
                return null;
        }
    }

    public int getPayType() {
        return payType;
    }

    public void setPayType(int payType) {
        this.payType = payType;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
