package com.lenovo.m2.buy.promotion.admin.common.pay.common;

import java.util.ArrayList;
import java.util.HashMap;

public class Constant {
    //是否加密
    public static String ENCRYPT = "encrypt";

    public static String SYS_ERROR = "系统错误！请重试！";

    public static String INPUT_CHARSET = "UTF-8";
    public static String WX_MD5_CHARSET = "GBK";

    public static int TOKEN_EXPIRES = 7000;
    public static String MPAPPID = "wx7b37229179b64bf3";

    public static final int HTTP_TYPE_GET   = 1;

    public static final int HTTP_TYPE_POST  = 2;

    public static final String GET_PAY_PACKAGE_ERROR  = "获取订单支付信息失败";
    public static final String PARMS_ERROR  = "参数错误";
    public static final String SIGN_ERROR  = "签名失败";
    public static final String FEE_ERROR  = "金额费用有误";
    public static final String WX_SERVER_ERROR = "微信服务器异常";
    public static final String WOMAI_SERVER_ERROR = "服务器异常";
    public static final String ORDER_PAYED_ERROR = "该订单已经发起支付";
    public static final String ORDER_NOPAYED_ERROR = "该订单未发起支付无法退款";

    public static final String WX_SERVICE_ERROR_CODE = "-2";
    public static final String WOMAI_SERVICE_ERROR_CODE = "-1";
    public static final String SIGN_ERROR_CODE = "100001";
    public static final String FEE_ERROR_CODE = "100003";
    public static final String PARMS_ERROR_CODE = "100004";
    public static final String GET_PAY_PACKAGE_ERROR_CODE = "100002";
    public static final String ORDER_PAYED_CODE = "100005";
    public static final String ORDER_NOPAYED_CODE = "100006";

    public static HashMap<String,String> errMap = new HashMap<String, String>();

    static {
        errMap.put(WX_SERVICE_ERROR_CODE,WX_SERVER_ERROR);
        errMap.put(WOMAI_SERVICE_ERROR_CODE,WOMAI_SERVER_ERROR);
        errMap.put(SIGN_ERROR_CODE,SIGN_ERROR);
        errMap.put(FEE_ERROR_CODE,FEE_ERROR);
        errMap.put(PARMS_ERROR_CODE,PARMS_ERROR);
        errMap.put(GET_PAY_PACKAGE_ERROR_CODE,GET_PAY_PACKAGE_ERROR);
        errMap.put(ORDER_PAYED_CODE,ORDER_PAYED_ERROR);
        errMap.put(ORDER_NOPAYED_CODE,ORDER_NOPAYED_ERROR);
    }


    public static ArrayList<String> ignorePackList = new ArrayList<String>();

    //不需要转换的字段
    static {
        ignorePackList.add("total_fee");
        ignorePackList.add("product_fee");
        ignorePackList.add("transport_fee");
        ignorePackList.add("fee_type");
        ignorePackList.add("time_start");
        ignorePackList.add("time_expire");
        ignorePackList.add("fee_type");
        ignorePackList.add("input_charset");
        ignorePackList.add("bank_type");
        ignorePackList.add("partner");
        ignorePackList.add("notify_url");
        ignorePackList.add("sign");
        ignorePackList.add("errcode");
        ignorePackList.add("errmsg");
    }

}
