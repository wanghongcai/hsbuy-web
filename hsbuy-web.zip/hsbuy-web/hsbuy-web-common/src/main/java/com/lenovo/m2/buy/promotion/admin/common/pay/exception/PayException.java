package com.lenovo.m2.buy.promotion.admin.common.pay.exception;

/**
 * Created by kenvin on 2014/10/28.
 */
public class PayException extends Exception {
    private String message;

    public PayException(String message) {

        super(message);    //To change body of overridden methods use File | Settings | File Templates.
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
