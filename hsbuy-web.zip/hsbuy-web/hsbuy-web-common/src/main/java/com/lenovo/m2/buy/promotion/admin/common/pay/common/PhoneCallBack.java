package com.lenovo.m2.buy.promotion.admin.common.pay.common;

/**
 * Created by zhanglijun on 2015/5/29.
 */
public enum PhoneCallBack {
    wap("1", "wap"), weixin("2", "weixin"), app("3", "app"), pc("4", "pc");

    PhoneCallBack() {
    }

    ;

    PhoneCallBack(String name, String type) {
        this.name = name;
        this.type = type;
    }

    private String name;
    private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
