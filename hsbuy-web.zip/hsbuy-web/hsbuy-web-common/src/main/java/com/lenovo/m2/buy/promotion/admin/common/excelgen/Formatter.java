package com.lenovo.m2.buy.promotion.admin.common.excelgen;

/**
 * @author wangrq1
 * @create 2017-09-28 下午1:51
 **/
public interface Formatter {


    String format(ExcelGenConfig config, Object obj);



}
