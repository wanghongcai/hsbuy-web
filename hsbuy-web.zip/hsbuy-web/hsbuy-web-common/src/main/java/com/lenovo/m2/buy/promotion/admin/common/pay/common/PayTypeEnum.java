package com.lenovo.m2.buy.promotion.admin.common.pay.common;

/**
 * Created by kenvin on 2014/11/24.
 */
public enum PayTypeEnum {
    IOS("ios",1),ANDROID("android",2),MPJS("mp-js",3),MPNATIVE("mp-native",4);

    PayTypeEnum(String name, int type) {
        this.name = name;
        this.type = type;
    }

    private String name;
    private int type;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
