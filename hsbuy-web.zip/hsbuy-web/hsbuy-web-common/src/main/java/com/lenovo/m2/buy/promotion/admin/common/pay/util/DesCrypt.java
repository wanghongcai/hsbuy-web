package com.lenovo.m2.buy.promotion.admin.common.pay.util;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.IvParameterSpec;
import java.io.UnsupportedEncodingException;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DesCrypt {
    private static final byte[] KEY_IV = { 18, 52, 86, 120, -112, -85, -51, -17 };

    public static byte[] decrypt(byte[] data, String key)
            throws Exception
    {
        byte[] byteKey = new BASE64Decoder().decodeBuffer(key);
        Key deskey = null;
        DESedeKeySpec spec = new DESedeKeySpec(byteKey);
        SecretKeyFactory keyfactory = SecretKeyFactory.getInstance("desede");
        deskey = keyfactory.generateSecret(spec);
        Cipher cipher = Cipher.getInstance("desede/CBC/PKCS5Padding");
        IvParameterSpec ips = new IvParameterSpec(KEY_IV);
        cipher.init(2, deskey, ips);
        byte[] bOut = cipher.doFinal(decryptBASE64(new String(data)));
        return bOut;
    }

    public static byte[] encrypt(byte[] data, String key) throws Exception {
        byte[] byteKey = new BASE64Decoder().decodeBuffer(key);
        Key deskey = null;
        DESedeKeySpec spec = new DESedeKeySpec(byteKey);
        SecretKeyFactory keyfactory = SecretKeyFactory.getInstance("desede");
        deskey = keyfactory.generateSecret(spec);
        Cipher cipher = Cipher.getInstance("desede/CBC/PKCS5Padding");
        IvParameterSpec ips = new IvParameterSpec(KEY_IV);
        cipher.init(1, deskey, ips);
        byte[] bOut = cipher.doFinal(data);
        return encryptBASE64(bOut).getBytes();
    }

    public static String calcDigest(String source, String key) {
        String s = source + key;
        MessageDigest md5 = null;
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        BASE64Encoder baseEncoder = new BASE64Encoder();
        String value = null;
        try {
            value = baseEncoder.encode(md5.digest(s.getBytes("utf-8")));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return value;
    }

    private static String encryptBASE64(byte[] key) {
        return new BASE64Encoder().encodeBuffer(key);
    }

    private static byte[] decryptBASE64(String key) throws Exception {
        return new BASE64Decoder().decodeBuffer(key);
    }
}

