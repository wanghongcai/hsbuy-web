package com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 支付宝Util
 * @author MengQiang
 */
public class AlipayUtil {
     /**
      * <br>解析支付宝异步回调请求数据</br>
      * @author MengQiang@2015年5月19日17:56:13
      */
     public static Map<String, String> parseRequestParams(Map<?, ?> requestParams){
          Map<String, String> params = new HashMap<String, String>();
          for (Iterator<?> iter = requestParams.keySet().iterator(); iter.hasNext();) {
               String name = (String) iter.next();
               String[] values = (String[]) requestParams.get(name);
               String valueStr = "";
               for (int i = 0; i < values.length; i++) {
                    valueStr = (i == values.length - 1) ? valueStr + values[i]
                            : valueStr + values[i] + ",";
               }
               // 乱码解决，这段代码在出现乱码时使用。如果mysign和sign不相等也可以使用这段代码转化
               // valueStr = new String(valueStr.getBytes("ISO-8859-1")/, "utf-8");
               params.put(name, valueStr);
          }
          return params;
     }
    /**
     * 解析支付上送需要支付宝反馈数据
     * @param extra_common_param
     * @return
     */
    public static Map<String, String> parseCommonParam(String extra_common_param) throws UnsupportedEncodingException {
        String decodeStr = URLDecoder.decode(extra_common_param, "UTF-8");
        Map<String, String> sParaMap = new HashMap<String, String>();
        String[] split = decodeStr.split(",");
        for(String str : split){
            String[] tempStr = str.split("=");
            sParaMap.put(tempStr[0],tempStr[1]);
        }
        return sParaMap;
    }

    /**
     * <br>解析支付宝异步回调数据</br>
     * @author MengQiang@2015年5月19日17:56:13
     */
    public static Map<String, String> parseParams(String requestParams){
        Map<String, String> params = new HashMap<String, String>();
        String[] strs=requestParams.split("&");
        if(null !=strs && strs.length > 0){
            for(String item:strs){
                String[] str=item.split("=");
                params.put(str[0],str[1]);
            }
        }else{
            return null;
        }
        return params;
    }

}
