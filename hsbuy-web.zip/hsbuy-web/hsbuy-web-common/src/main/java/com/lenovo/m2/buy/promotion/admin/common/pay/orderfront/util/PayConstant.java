package com.lenovo.m2.buy.promotion.admin.common.pay.orderfront.util;


import com.lenovo.m2.hsbuy.domain.pay.ordersoa.ChannelOrder;

import java.util.Map;

/**支付参数
 * @Description:
 * @author: lijie14
 * @Date: 2016/8/26.
 * @Version:1.0
 */
public class PayConstant {
    /**
     * 支付接口名称
     */
    public final static String PAY_SERVICE_NAME="lenovo_direct_pay";
    /**
     * 支付接口名称
     */
    public final static String SIGN_TYPE="MD5";
    /**
     * 支付接口名称
     */
    public final static String SIGN_KEY="nlzdsb0x50byzdw8975lm6nqadcuxu17";
    /**
     * 支付接口名称
     */
    public final static String INPUT_CHARSET="UTF-8";

    public final static String SHOPID_SMB="8";

}
