package com.lenovo.m2.buy.promotion.admin.common.pay.util;

import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.MD5;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.Signature;
import org.apache.log4j.Logger;

import java.util.*;

/**
 * 支付签名工具类
 * Created by MengQiang on 2016/3/3.
 */
public class PaySignUtils {
    private static final Logger logger = Logger.getLogger(PaySignUtils.class);

    /**
     * 生成查询订单信息SingKey
     * @param orderCode
     * @param lenovoId
     * @param shopId
     * @return
     */
    public static String getPayOrderInfoSign(String orderCode, String lenovoId, String shopId){
        Map<String, Object> paraMap = new HashMap<String, Object>();
        logger.info("查询订单信息签名入参orderCode" + orderCode + " lenovoId==>" + lenovoId + " shopId==>" + shopId);
        paraMap.put("orderCode", orderCode);
        paraMap.put("lenovoId", lenovoId);
        paraMap.put("shopId", shopId);
        Map proMap = PropertiesHelper.loadToMap();
        String signKey = Signature.getSign(paraMap, (String) proMap.get("b2cKey"));
        logger.info("查询订单信息签名==>" + signKey);
        return signKey;
    }
    /**
     * 生成SingKey
     * @param paraMap
     * @return
     */
    public static String getLenovoPaySign(Map<String, Object> paraMap ){
        logger.info("查询订单信息签名入参=" + paraMap.toString());
        Map proMap = PropertiesHelper.loadToMap();
        String signKey = Signature.getSign(paraMap, (String) proMap.get("b2cKey"));
        logger.info("信息签名==>" + signKey);
        return signKey;
    }


    public static String checkSign(Map<String, String> signMap, String signKey){
        logger.info("Invoke PaySignUtils CheckSign");
        String key = getSign(signMap, signKey);
        logger.info("key[" + key + "]");
        return key;
    }

    /**
     * 生成签名密文
     * @param signMap   待签名参数
     * @param signType  签名类型，目前支持支MD5
     * @param signKey   签名KEY
     * @return  密文串
     */
    public static String buildSignKey(Map<String, String> signMap, String signType, String signKey){
        if("MD5".equals(signType)){
            String key =  getSign(signMap, signKey);
            logger.info("SignKey[" + key + "]");
            return key;
        }else{
            logger.info("目前只支持MD5加密");
            return null;
        }
    }

    /**
     * 验证签名
     * @param sign  密文串
     * @param signMap   待签名参数
     * @param signType  签名类型，目前支持支MD5
     * @param signKey   签名KEY
     * @return 验签结果
     */
    public static boolean checkSignKey(String sign, Map<String, String> signMap, String signType, String signKey){
        if("MD5".equals(signType)){
            String tempSign = getSign(signMap, signKey);
            return sign.equals(tempSign);
        }else{
            logger.info("目前只支持MD5加密");
            return false;
        }
    }
    private static String getSign(Map<String, String> map, String signKey) {
        ArrayList<String> list = new ArrayList<String>();
        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (entry.getValue() != null && !"".equals(entry.getValue())) {
                list.add(entry.getKey() + "=" + entry.getValue() + "&");
            }
        }
        logger.info("signList[" + list + "]");
        int size = list.size();
        String[] arrayToSort = list.toArray(new String[size]);
        Arrays.sort(arrayToSort, String.CASE_INSENSITIVE_ORDER);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(arrayToSort[i]);
        }
        String result = sb.toString();
        result += "key=" + signKey;
        result = MD5.MD5Encode(result).toUpperCase();
        return result;
    }
    /**
     * 建立请求，以表单HTML形式构造（默认）
     * @param postMap	请求参数数组
     * @param getWay 	支付网关地址
     * @param method	提交方式：post
     * @return	提交表单HTML文本
     */
    public static String buildRequest(Map<String, String> postMap, String getWay, String method) {
        List<String> keys = new ArrayList<String>(postMap.keySet());
        StringBuffer sbHtml = new StringBuffer();
        sbHtml.append("<form id=\"paydirsubmit\" name=\"outpaysubmit\" action=\"" + getWay
                + "?_input_charset=UTF-8" + "\" method=\"" + method
                + "\" target=\"_self\">");
        for (int i = 0; i < keys.size(); i++) {
            String name =  keys.get(i);
            String value = postMap.get(name);
            if(value != null && !"".equals(value)){
                sbHtml.append("<input type=\"hidden\" name=\"" + name + "\" value=\"" + value + "\"/>");
            }
        }
        sbHtml.append("<input type=\"submit\" value=\"" + "outpaysubmit" + "\" style=\"display:none;\"></form>");
        sbHtml.append("<script>document.forms['paydirsubmit'].submit();</script>");
        return sbHtml.toString();
    }
}
