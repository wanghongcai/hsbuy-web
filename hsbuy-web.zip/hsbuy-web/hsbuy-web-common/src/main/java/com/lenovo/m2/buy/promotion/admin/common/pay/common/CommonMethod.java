package com.lenovo.m2.buy.promotion.admin.common.pay.common;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.arch.framework.domain.Tenant;
import com.lenovo.m2.arch.tool.util.IntUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PayConfig;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PaySignUtils;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.ChannelOrder;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.Product;
import com.lenovo.m2.hsbuy.domain.pay.ordersoa.wxpay.ChannelOrderProduct;
import com.lenovo.m2.hsbuy.domain.pay.soa.MerchantPayPlatView;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by caoxd2 on 2015/5/24.
 */
public class CommonMethod {
    private static final Logger logger = Logger.getLogger(CommonMethod.class);

    public static String digitalConversion(Double d) {
        BigDecimal db = BigDecimal.valueOf(d * 100.00);
        int value = db.intValue();
        return String.valueOf(value);
    }


    public static <T> void getRemoteResult(RemoteResult<T> remoteResult, T t, boolean status, String resultCode, String resultMsg) {
        remoteResult.setT(t);
        remoteResult.setResultCode(resultCode);
        remoteResult.setResultMsg(resultMsg);
        remoteResult.setSuccess(status);
    }

    public static String getProductName(String subject) {
        Pattern p = Pattern.compile("^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$");
        Matcher m = p.matcher(subject);
        if (!m.matches() || subject.length() > 50 || StringUtils.isEmpty(subject)) {
            subject = "联想商品";
        }
        return subject;
    }

    public static String getBodyHtml(String formHtml) {
        return "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>支付宝订单请求</title></head><body>"
                + formHtml + "</body></html>";
    }


    /**
     * 获取10进制数据
     *
     * @param keyId
     * @return
     */
    public static String get32To10(String keyId) {
        String str = "";
        str = keyId.substring(3, keyId.length());
        Long id = IntUtil.c32to10(str);
        return id.toString();
    }


    /**
     * **********************************--------新增方法--------------------*************
     */
    public static String getProductName(ChannelOrder channelOrder) {
        StringBuilder goodsName = new StringBuilder();

        List<Product> goodsList = channelOrder.getProduct();
        if (goodsList != null && goodsList.size() > 0) {
            int listSize = goodsList.size();
            int count = 0;
            for (Product product : goodsList) {
                goodsName.append(product.getProductName());
                count++;
                if (count < listSize - 1) {
                    goodsName.append(",");
                }
            }
        }

        String goodsNameStr = goodsName.toString();
        Pattern p = Pattern.compile("^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$");
        Matcher m = p.matcher(goodsNameStr);
        if (!m.matches() || goodsNameStr.length() > 50) {
            //处理签名异常
            goodsNameStr = "联想商品";
        }

        return goodsNameStr;
    }

    public static String getPlatFromShopIdTerminal(String shopId, String terminal) {
        String plat = "";
        if (PeakConstant.SHOPID_LENOVO.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                plat = PeakConstant.PLAT_PC;
            } else if (PeakConstant.TERMINAL_WAP.equals(terminal)) {
                plat = PeakConstant.PLAT_WAP;
            } else if (PeakConstant.TERMINAL_APP.equals(terminal)) {
                plat = PeakConstant.PLAT_APP;
            } else if (PeakConstant.TERMINAL_WECHAT.equals(terminal) || PeakConstant.TERMINAL_WECHAT_APPLET.equals(terminal)) {
                plat = PeakConstant.PLAT_WX;
            }
        } else if (PeakConstant.SHOPID_THINK.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                plat = PeakConstant.PLAT_THINK_PC;
            } else if (PeakConstant.TERMINAL_WAP.equals(terminal)) {
                plat = PeakConstant.PLAT_THINK_WAP;
            } else if (PeakConstant.TERMINAL_APP.equals(terminal)) {
                plat = PeakConstant.PLAT_THINK_APP;
            } else if (PeakConstant.TERMINAL_WECHAT.equals(terminal) || PeakConstant.TERMINAL_WECHAT_APPLET.equals(terminal)) {
                plat = PeakConstant.PLAT_THINK_WX;
            }
        } else if (PeakConstant.SHOPID_EPP.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                plat = PeakConstant.PLAT_EPP_PC;
            } else if (PeakConstant.TERMINAL_WAP.equals(terminal)) {
                plat = PeakConstant.PLAT_EPP_WAP;
            } else if (PeakConstant.TERMINAL_APP.equals(terminal)) {
                logger.info("商城及平台错误");
            } else if (PeakConstant.TERMINAL_WECHAT.equals(terminal) || PeakConstant.TERMINAL_WECHAT_APPLET.equals(terminal)) {
                logger.info("商城及平台错误");
            }
        } else if (PeakConstant.SHOPID_ROAMING.equals(shopId)) {
            plat = PeakConstant.PLAT_ROAMING;
        } else if (PeakConstant.SHOPID_MOTO.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                plat = PeakConstant.PLAT_MOTO_PC;
            } else if (PeakConstant.TERMINAL_WAP.equals(terminal)) {
                plat = PeakConstant.PLAT_MOTO_WAP;
            } else if (PeakConstant.TERMINAL_APP.equals(terminal)) {
                plat = PeakConstant.PLAT_MOTO_APP;
            } else if (PeakConstant.TERMINAL_WECHAT.equals(terminal) || PeakConstant.TERMINAL_WECHAT_APPLET.equals(terminal)) {
                plat = PeakConstant.PLAT_MOTO_WX;
            }
        } else if (PeakConstant.SHOPID_DONGDE.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                plat = PeakConstant.PLAT_DONGDE_PC;
            } else if (PeakConstant.TERMINAL_WAP.equals(terminal)) {
                plat = PeakConstant.PLAT_DONGDE_WAP;
            } else if (PeakConstant.TERMINAL_APP.equals(terminal)) {
                plat = PeakConstant.PLAT_DONGDE_APP;
            } else if (PeakConstant.TERMINAL_WECHAT.equals(terminal) || PeakConstant.TERMINAL_WECHAT_APPLET.equals(terminal)) {
                plat = PeakConstant.PLAT_DONGDE_WX;
            }
        } else if (PeakConstant.SHOPID_HUISHANG.equals(shopId)) {
            if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                plat = PeakConstant.PLAT_ALLINPAY_PC;
            } else if (PeakConstant.TERMINAL_WAP.equals(terminal)) {
                plat = PeakConstant.PLAT_ALLINPAY_WAP;
            } else{
                plat = shopId;
            }
        } else {
            plat = shopId;
        }
        return plat;
    }

    public static String getShopIdFromPlat(String plat) {
        String shopId = "";
        if (PeakConstant.PLAT_PC.equals(plat) || PeakConstant.PLAT_WAP.equals(plat) || PeakConstant.PLAT_APP.equals(plat) || PeakConstant.PLAT_WX.equals(plat)) {
            shopId = PeakConstant.SHOPID_LENOVO;
        } else if (PeakConstant.PLAT_THINK_PC.equals(plat) || PeakConstant.PLAT_THINK_WAP.equals(plat) || PeakConstant.PLAT_THINK_APP.equals(plat) || PeakConstant.PLAT_THINK_WX.equals(plat)) {
            shopId = PeakConstant.SHOPID_THINK;
        } else if (PeakConstant.PLAT_EPP_PC.equals(plat) || PeakConstant.PLAT_EPP_WAP.equals(plat)) {
            shopId = PeakConstant.SHOPID_EPP;
        } else if (PeakConstant.PLAT_ROAMING.equals(plat)) {
            shopId = PeakConstant.SHOPID_ROAMING;
        } else if (PeakConstant.PLAT_MOTO_PC.equals(plat) || PeakConstant.PLAT_MOTO_WAP.equals(plat) || PeakConstant.PLAT_MOTO_APP.equals(plat) || PeakConstant.PLAT_MOTO_WX.equals(plat)) {
            shopId = PeakConstant.SHOPID_MOTO;
        } else {
            shopId = plat;
        }
        return shopId;
    }

    public static String getTerminalFromPlat(String plat) {
        String terminal = "";
        if (PeakConstant.PLAT_PC.equals(plat) || PeakConstant.PLAT_THINK_PC.equals(plat) || PeakConstant.PLAT_EPP_PC.equals(plat) || PeakConstant.PLAT_MOTO_PC.equals(plat)) {
            terminal = PeakConstant.TERMINAL_PC;
        } else if (PeakConstant.PLAT_WAP.equals(plat) || PeakConstant.PLAT_THINK_WAP.equals(plat) || PeakConstant.PLAT_EPP_WAP.equals(plat) || PeakConstant.PLAT_MOTO_WAP.equals(plat)) {
            terminal = PeakConstant.TERMINAL_WAP;
        } else if (PeakConstant.PLAT_APP.equals(plat) || PeakConstant.PLAT_THINK_APP.equals(plat) || PeakConstant.PLAT_MOTO_APP.equals(plat) || PeakConstant.PLAT_ROAMING.equals(plat)) {
            terminal = PeakConstant.TERMINAL_APP;
        } else if (PeakConstant.PLAT_WX.equals(plat) || PeakConstant.PLAT_THINK_WX.equals(plat) || PeakConstant.PLAT_MOTO_WX.equals(plat)) {
            terminal = PeakConstant.TERMINAL_WECHAT;
        }
        return terminal;
    }

    public static String bigDecimalToString(BigDecimal d) {
        return String.valueOf(d);
    }

    public static String getHlwzqUrl(String outNotifyUrl) {
        Map<String, Object> resouceMap = PayConfig.loadToMap();
        String payEnvironment = (String) resouceMap.get("PAY_ENVIRONMENT");
        logger.info("运行环境==>" + payEnvironment);
        if ("domain".equals(payEnvironment)) {
            outNotifyUrl = outNotifyUrl.replace("https://cashier.lenovo.com.cn", "https://cashier.lenovo.com.cn/hlwzq");
            logger.info("修改话联网专区通知地址==>" + outNotifyUrl);
        }
        return outNotifyUrl;
    }

    public static String getBody(ChannelOrder channelOrder) {
        String aliPayBody = "";
        try {
            StringBuilder aliPayBodyBuilder = new StringBuilder();
            List<Product> goodsList = channelOrder.getProduct();
            if (goodsList != null && goodsList.size() > 0) {
                int listSize = goodsList.size();
                int count = 0;
                for (Product product : goodsList) {
                    aliPayBodyBuilder.append(product.getProductName());
                    count++;
                    if (count < listSize - 1) {
                        aliPayBodyBuilder.append(",");
                    }
                }
            }
//            aliPayBody = URLEncoder.encode(aliPayBodyBuilder.toString(), "UTF-8");
            aliPayBody = aliPayBodyBuilder.toString();
        } catch (Exception e) {
            logger.info("构建支付宝支付商品描述失败");
        }
        return aliPayBody;
    }

    public static List<ChannelOrderProduct> convertProductToChannelOrderProduct(List<Product> products) {
        List<ChannelOrderProduct> channelOrderProductList = new ArrayList<ChannelOrderProduct>();
        if (products != null || products.size() > 0) {
            for (Product product : products) {
                ChannelOrderProduct channelOrderProduct = new ChannelOrderProduct();
                channelOrderProduct.setFaId(product.getFaId());
                channelOrderProduct.setFaName(product.getFaName());
                channelOrderProduct.setFavourablePay(product.getFavourablePay());
                channelOrderProduct.setProductCode(product.getProductCode());
                channelOrderProduct.setProductName(product.getProductName());
                channelOrderProduct.setProductId(product.getProductId());
                channelOrderProduct.setProductNumber(product.getProductNumber());
                channelOrderProduct.setProductPay(product.getProductPay());
                channelOrderProduct.setTotalMoney(product.getTotalMoney());
                channelOrderProductList.add(channelOrderProduct);
            }
            return channelOrderProductList;
        } else {
            logger.info("构建查询分期规则产品为空");
            return null;
        }

    }

    public static boolean checkHuabeiActivity() {
        Date checkDate = new Date();
        Date huaBeiDateStart = null;
        Date huaBeiDateEnd = null;
        try {
            Map<String, Object> paySwitchMap = PropertiesHelper.loadToMap("pay_switch.properties");
            String huabeiActivityStart = (String) paySwitchMap.get("HUABEI_ACTIVITY_START");
            String huabeiActivityEnd = (String) paySwitchMap.get("HUABEI_ACTIVITY_END");
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            huaBeiDateStart = format.parse(huabeiActivityStart);
            huaBeiDateEnd = format.parse(huabeiActivityEnd);
            if (checkDate.after(huaBeiDateStart) && checkDate.before(huaBeiDateEnd)) {
                return true;
            } else {
                return false;
            }
        } catch (Exception formatException) {
            logger.error("格式化花呗分期活动时间异常", formatException);
            return false;
        }
    }

    public static boolean checkDaChuActivity() {
        Date checkDate = new Date();
        Date daChuDateStart = null;
        Date daChuDateEnd = null;
        try {
            Map<String, Object> paySwitchMap = PropertiesHelper.loadToMap("pay_switch.properties");
            String daChuActivityStart = (String) paySwitchMap.get("DACHU_ACTIVITY_START");
            String daChuActivityEnd = (String) paySwitchMap.get("DACHU_ACTIVITY_END");
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            daChuDateStart = format.parse(daChuActivityStart);
            daChuDateEnd = format.parse(daChuActivityEnd);
            if (checkDate.after(daChuDateStart) && checkDate.before(daChuDateEnd)) {
                return true;
            } else {
                return false;
            }
        } catch (Exception formatException) {
            logger.error("格式化打出活动时间异常", formatException);
            return false;
        }
    }

    public static String getSuccessSyncReturnURLByShopIdTerminal(String shopId, String terminal) {
        String returnURL = null;
        if(PeakConstant.SHOPID_LENOVO.equals(shopId)){
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = "syncback/b2c_pc_succ";
            }else {
                returnURL = "syncback/b2c_wap_success";
            }
        }else if(PeakConstant.SHOPID_THINK.equals(shopId)){
            Map<String, Object> urlMap = PropertiesHelper.loadToMap("ali_pay.properties");
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = (String) urlMap.get("THINK_PC_SUCC");
            }else {
                returnURL = (String) urlMap.get("THINK_WAP_SUCC");
            }
        }else if(PeakConstant.SHOPID_EPP.equals(shopId)){
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = "syncback/epp_pc_succ";
            }else {
                returnURL=  "syncback/epp_wap_success";
            }
        }else if(PeakConstant.SHOPID_SMB.equals(shopId)){
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = "syncback/smb_pc_succ";
            }else {
                returnURL = "syncback/b2c_wap_success";
            }
        }
        return returnURL;
    }

    public static String getFailSyncReturnURLByShopIdTerminal(String shopId, String terminal) {
        String returnURL = null;
        if(PeakConstant.SHOPID_LENOVO.equals(shopId)){
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = "syncback/b2c_pc_fail";
            }else {
                returnURL = "syncback/b2c_wap_error";
            }
        }else if(PeakConstant.SHOPID_THINK.equals(shopId)){
            Map<String, Object> urlMap = PropertiesHelper.loadToMap("ali_pay.properties");
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = (String) urlMap.get("THINK_PC_ERROR");
            }else {
                returnURL = (String) urlMap.get("THINK_WAP_ERROR");
            }
        }else if(PeakConstant.SHOPID_EPP.equals(shopId)){
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = "syncback/epp_pc_fail";
            }else {
                returnURL=  "syncback/epp_wap_error";
            }
        }else if(PeakConstant.SHOPID_SMB.equals(shopId)){
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                returnURL = "syncback/smb_pc_fail";
            }else {
                returnURL = "syncback/b2c_wap_error";
            }
        }
        return returnURL;
    }

    public static String getPCFailSyncReturnURLByShopId(String shopId) {
        String returnURL = null;
        if(PeakConstant.SHOPID_LENOVO.equals(shopId)){
            returnURL = "syncback/b2c_pc_fail";
        }else if(PeakConstant.SHOPID_THINK.equals(shopId)){
            Map<String, Object> urlMap = PropertiesHelper.loadToMap("ali_pay.properties");
            returnURL = (String) urlMap.get("THINK_PC_ERROR");
        }else if(PeakConstant.SHOPID_EPP.equals(shopId)){
            returnURL = "syncback/epp_pc_fail";
        }else if(PeakConstant.SHOPID_SMB.equals(shopId)){
            returnURL = "syncback/smb_pc_fail";
        }else{
            returnURL = "outpay/outpay_pc_fail";
        }
        logger.info("getPCFailSyncReturnURLByShopId, URL[" + returnURL + "]");
        return returnURL;
    }
    public static String getPCSuccSyncReturnURLByShopId(String shopId) {
        String returnURL = null;
        if(PeakConstant.SHOPID_LENOVO.equals(shopId)){
            returnURL = "syncback/b2c_pc_succ";
        }else if(PeakConstant.SHOPID_THINK.equals(shopId)){
            Map<String, Object> urlMap = PropertiesHelper.loadToMap("ali_pay.properties");
            returnURL = (String) urlMap.get("THINK_PC_SUCC");
        }else if(PeakConstant.SHOPID_EPP.equals(shopId)){
            returnURL = "syncback/epp_pc_succ";
        }else if(PeakConstant.SHOPID_SMB.equals(shopId)){
            returnURL = "syncback/smb_pc_succ";
        }else{
            returnURL = "outpay/outpay_pc_succ";
        }
        logger.info("getPCSuccSyncReturnURLByShopId, URL[" + returnURL + "]");
        return returnURL;
    }
    public static void buildReturnParaMap(Map<String, Object> paraMap, PayOrder payOrder, MerchantPayPlatView merchantPayPlatView, PayPortalOrder payPortalOrder) {
        try {
            BigDecimal decimal = new BigDecimal(payOrder.getTotal_fee());
            decimal = decimal.movePointLeft(2);
            paraMap.put("totalFee", decimal);
            paraMap.put("pay_type", payOrder.getPay_type());
            paraMap.put("lenovoId", payOrder.getU_id());
            paraMap.put("shopId", payOrder.getShop_id());
            paraMap.put("terminal", payOrder.getTerminal());
            paraMap.put("outTradeNo", payOrder.getOut_trade_no());
            paraMap.put("totalFee", decimal);
            paraMap.put("plat", payOrder.getOs());
            paraMap.put("payPortalOrder", payPortalOrder);
            if (!PeakConstant.ORDER_TYPE_DONGDE_CZ.equals(payPortalOrder.getOrderType())) {
                int leBean = Integer.parseInt(payPortalOrder.getRewardLedou());
                if (leBean != 0) {
                    paraMap.put("leBean", "恭喜您获得了" + String.valueOf(leBean) + "个乐豆，");
                } else {
                    paraMap.put("leBean", " ");
                }
                String delivery = payPortalOrder.getDeliveryInfo();
                if (StringUtils.isNotEmpty(delivery)) {
                    paraMap.put("delivery", delivery);
                } else {
                    paraMap.put("delivery", " ");
                }
            }
        } catch (Exception ex) {
            logger.info("处理同步回调信息异常", ex);
        }
    }

    public static PayPortalOrder buildUpdatePayPortalOrder(String payTransactionId, String outTradeNo, String lenovoId, int payment, String payStatus, String shopId, Date payTime) {
        PayPortalOrder updatePayPortalOrder = new PayPortalOrder();
        updatePayPortalOrder.setTransationId(payTransactionId);
        updatePayPortalOrder.setOutTradeNo(outTradeNo);
        updatePayPortalOrder.setLenovoId(lenovoId);
        updatePayPortalOrder.setPayment(payment);
        updatePayPortalOrder.setPayStatus(Integer.valueOf(payStatus));
        updatePayPortalOrder.setShopId(shopId);
        updatePayPortalOrder.setPayTime(payTime);
        return updatePayPortalOrder;
    }


    public static String getOutSyncReturnForm(PayOrder payOrder, MerchantPayPlatView merchantPayPlatView, PayPortalOrder payPortalOrder, Map<String, Object> paraMap, Map<String, Object> commonParam, String tradeStatus, String tradeNo) {
        logger.info("DirectPay Go getOutSyncReturnForm");
        Map<String, String> postMap = new HashMap<String, String>();
        try{
            postMap.put("is_success","T");
            postMap.put("notify_type", "trade_status_sync");
            postMap.put("out_trade_no", payPortalOrder.getOutTradeNo());
            postMap.put("shop_id", payPortalOrder.getShopId());
            if(!PeakConstant.SHOPID_PCSD.equals(payPortalOrder.getShopId())){
                postMap.put("terminal", payPortalOrder.getTerminal());
            }
            postMap.put("fa_id", payPortalOrder.getFaId());
            postMap.put("payment", String.valueOf(payOrder.getPay_type()));
            postMap.put("total_fee", String.valueOf(payPortalOrder.getTotalFee()));
            postMap.put("trade_no", String.valueOf(payOrder.getId()));
            postMap.put("transaction_no", tradeNo);
            postMap.put("trade_status", tradeStatus);
            if(PeakConstant.SHOPID_HUISHANG.equals(payPortalOrder.getShopId())
                    && payPortalOrder.getPoint()>0){
                postMap.put("reward_point", payPortalOrder.getPoint()+"");
            }
            String signKey = (String) commonParam.get(payPortalOrder.getShopId());
            String sign = PaySignUtils.buildSignKey(postMap, "MD5", signKey);
            postMap.put("sign", sign);
            postMap.put("sign_type", "MD5");
        }catch(Exception e){
            logger.info("DirectPay Go getOutSyncReturnForm Exception", e);
            paraMap.put("error_msg", "服务器异常，请到订单列表查询交易状态！");
            return getPCFailSyncReturnURLByShopId(payPortalOrder.getShopId());
        }
        String bodyHtml = PaySignUtils.buildRequest(postMap, payPortalOrder.getReturnUrl(),"post");
        bodyHtml = "<html>" + "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>outPay</title></head>" + "<body>"
                + bodyHtml + "</body></html>";
        logger.info("DirectPay Go OutSyncReturn,HTML[" + bodyHtml + "]");
        paraMap.put("postForm", bodyHtml);
        return "outpay/outpay_gotobank";
    }

    /**
     * 惠商错误页
     * @param terminal
     * @return
     */
    public static String getOutPayFailPage(String terminal){
        String page = null;
        if(PeakConstant.TERMINAL_PC.equals(terminal)){
            return "outpay/outpay_pc_fail";
        }else{
            return "outpay/outpay_wap_fail";
        }
    }

    public static boolean checkInShopId(String shopId) {
        return (PeakConstant.SHOPID_LENOVO.equals(shopId) || PeakConstant.SHOPID_THINK.equals(shopId) || PeakConstant.SHOPID_EPP.equals(shopId) || PeakConstant.SHOPID_ROAMING.equals(shopId)
        || PeakConstant.SHOPID_MOTO.equals(shopId) || PeakConstant.SHOPID_DONGDE.equals(shopId) || PeakConstant.SHOPID_THINKCENTER.equals(shopId) || PeakConstant.SHOPID_SMB.equals(shopId)
        || PeakConstant.SHOPID_PCSD.equals(shopId) || PeakConstant.SHOPID_HUISHANG.equals(shopId) || PeakConstant.SHOPID_MOTO_INDIA.equals(shopId));
    }

    public static boolean checkMoneyPattern(String refundFee) {
        Pattern pattern = Pattern.compile("^(([1-9]{1}\\d*)|([0]{1}))(\\.(\\d){1,2})?$");
        Matcher matcher = pattern.matcher(refundFee);
        return matcher.matches();
    }

    public static RemoteResult<String> checkRequestParam(Map<String, String> requestParam) {
        RemoteResult<String> remoteResult = new RemoteResult<String>();
        remoteResult.setSuccess(true);
        try{
            String itBPay = requestParam.get("it_b_pay");
            if(StringUtils.isNotEmpty(itBPay) && !"null".equals(itBPay)){
                logger.info("Invoke checkRequestParam Check:itBPay[" + itBPay + "]");
                if(itBPay.endsWith("m")||itBPay.endsWith("h")||itBPay.endsWith("d")){
                    try {
                        String itBPayStr = itBPay.substring(0, itBPay.length() - 1);
                        Integer itBPayInt = Integer.parseInt(itBPayStr);
                    }catch(NumberFormatException numberException){
                        logger.info("Illegal RequestParam, it_b_pay[" + itBPay + "]");
                        remoteResult.setSuccess(false);
                        remoteResult.setResultCode("it_b_pay");
                        return remoteResult;
                    }
                }else{
                    logger.info("Illegal RequestParam, it_b_pay[" + itBPay + "]");
                    remoteResult.setSuccess(false);
                    remoteResult.setResultCode("it_b_pay");
                    return remoteResult;
                }
            }
            String subject = requestParam.get("subject");
            if(StringUtils.isEmpty(subject)){
                logger.info("Illegal RequestParam, subject[" + subject + "]");
                remoteResult.setSuccess(false);
                remoteResult.setResultCode("subject");
                return remoteResult;
            }
//            String payment = requestParam.get("payment");
//            if(StringUtils.isEmpty(payment)){
//                logger.info("Illegal RequestParam, payment[" + payment + "]");
//                remoteResult.setSuccess(false);
//                remoteResult.setResultCode("payment");
//            }
            return remoteResult;
        }catch(Exception e){
            logger.info("Invoke checkRequestParam Exception", e);
            remoteResult.setSuccess(false);
            remoteResult.setResultCode("trade_info");
            return remoteResult;
        }
    }

    /**
     * Build Tenant
     * @param shopId Tenant Id
     * @param currencyCode 货币编码
     * @param language 语言编码
     * @param timeZone 租户时区
     * @param nationalCode 国家编码
     * @param nationalName 国家名称
     * @param currencySign 币种符号
     * @return
     */
    public static Tenant buildTenant(String shopId, String currencyCode, String language, String timeZone, String nationalCode, String nationalName, String currencySign){
        Tenant tenant = new Tenant();
        tenant.setShopId(Integer.parseInt(shopId));
        tenant.setCurrencyCode(currencyCode);
        tenant.setLanguage(language);
        tenant.setTimeZone(timeZone);
        tenant.setNationalCode(nationalCode);
        tenant.setNationalName(nationalName);
        tenant.setCurrencySign(currencySign);
        return tenant;
    }

    /**
     * 同步跳转到外部错误页面
     * @param service
     * @param payment
     * @param failTradeInfo
     * @param shopId
     * @param terminal
     * @param exceptionUrl
     * @param paraMap
     * @param commonParam
     * @return
     */
    public static String getFailRedirect(String service, String payment, String failTradeInfo, String shopId, String terminal, String exceptionUrl, Map<String, Object> paraMap, Map<String, Object> commonParam) {
        if(StringUtils.isNotEmpty(exceptionUrl)){
            logger.info("DirectPay Go FailRedirect, ExceptionUrl[" + exceptionUrl + "],service[" + service + "],tradeInfo[" + failTradeInfo + "],shopId[" + shopId + "],terminal[" + terminal + "]");
            Map<String, String> postMap = new HashMap<String, String>();
            postMap.put("service",service);
            postMap.put("payment", payment);
            postMap.put("shop_id", shopId);
            postMap.put("terminal", terminal);
            postMap.put("input_charset", "UTF-8");
            postMap.put("trade_info", failTradeInfo);
            postMap.put("error_code", (String) paraMap.get("error_code"));
            String signKey = (String) commonParam.get(shopId);
            String sign = PaySignUtils.buildSignKey(postMap, "MD5", signKey);
            postMap.put("sign", sign);
            postMap.put("sign_type", "MD5");
            String bodyHtml = PaySignUtils.buildRequest(postMap, exceptionUrl,"post");
            bodyHtml = "<html>" + "<head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>outPay</title></head>" + "<body>"
                    + bodyHtml + "</body></html>";
            logger.info("DirectPay Go FailRedirect,HTML[" + bodyHtml + "]");
            paraMap.put("postForm", bodyHtml);
            return "outpay/outpay_gotobank";
        }else{
            if(PeakConstant.TERMINAL_PC.equals(terminal)){
                logger.info("DirectPay Go FailRedirect, URL[outpay/outpay_pc_fail]");
                return "outpay/outpay_pc_fail";
            }else{
                logger.info("DirectPay Go FailRedirect, URL[outpay/outpay_wap_fail]");
                return "outpay/outpay_wap_fail";
            }
        }
    }

}
