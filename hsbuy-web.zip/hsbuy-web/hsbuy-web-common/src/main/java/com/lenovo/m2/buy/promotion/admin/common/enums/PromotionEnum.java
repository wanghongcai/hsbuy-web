package com.lenovo.m2.buy.promotion.admin.common.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * 促销类型枚举
* @ClassName: PromotionEnum
* @Description: (这里用一句话描述这个类的作用)
* @author zhanghs
* @date 2015年7月27日 下午10:17:59
*
 */
public enum PromotionEnum {


    COMMON_GOODS(-1, "普通商品"),
    OPTION_GOODS(0, "选件搭售");



    public final static String PROMOTION_KEY="promotionType";//调用商品服务时，查询返回的map促销信息中的key减前缀
    private final int type;
    private final String descr;



    public int getType() {
        return type;
    }

    public String getDescr() {
        return descr;
    }

    PromotionEnum(int type, String descr) {
		this.type = type;
		this.descr = descr;
	}

	final  static  Map<Integer, String> map = new HashMap<Integer, String>();
    final  static  Map<Integer, PromotionEnum> enumMap = new HashMap<Integer, PromotionEnum>();
	/**
	 * 获取枚举类型的所有<值,名称>对
	 * 
	 * @return
	 */
	public static Map<Integer, String> toMap() {
		if(map.size() > 0){
			return map;
		}
		for (int i = 0; i < PromotionEnum.values().length; i++) {
			map.put(PromotionEnum.values()[i].getType(), PromotionEnum.values()[i].getDescr());
		}
		return map;
	}

    /**根据促销类型得到对应的枚举项
     *
     * @param type
     * @return
     */
    public static PromotionEnum getPromotionByType(int type ){
        if(enumMap.size() > 0){
            return enumMap.get(type);
        }

        PromotionEnum[] promotionEnums =  PromotionEnum.values();
        for (PromotionEnum promotionEnum:promotionEnums){
            enumMap.put(promotionEnum.getType(),promotionEnum);
        }
        return enumMap.get(type);
    }

}
