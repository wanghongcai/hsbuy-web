package com.lenovo.m2.buy.promotion.admin.common.utils;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by luqian on 2016-04-22.
 * @Desc 防止表单重复提交
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public  @interface Token {

    boolean save() default false;

    boolean remove() default false;
}
