package com.lenovo.m2.buy.promotion.admin.common.pay.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * Created by zhanglijun on 2015/5/27.
 */
public class AliPayConfigUtil {

    public AliPayConfigUtil(){}
    private static Properties props = new Properties();
    static{
        try {
            props.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("wx_pay.properties"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static String getValue(String key){
        return props.getProperty(key);
    }

    public static void updateProperties(String key, String value) {
        props.setProperty(key, value);
    }

}
