package com.lenovo.m2.buy.promotion.admin.common.pay.util.util2;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by luqian on 2015-05-05.
 */
public class BaseInfo {
    private static final Map<Integer, BaseInfo> map = new HashMap<Integer, BaseInfo>();

    public static BaseInfo errInfo(Integer key){
        return map.get(key);
    }

    public BaseInfo() {
    }

    public BaseInfo(Integer rc, String msg) {
        this.rc = rc;
        this.msg = msg;
    }
    public BaseInfo(String msg) {
        this.msg = msg;
    }
    public BaseInfo(Integer rc) {
        this.rc = rc;
    }

    private int rc;
    private String msg = "";

    public int getRc() {
        return rc;
    }
    public void setRc(int rc) {
        this.rc = rc;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
}
