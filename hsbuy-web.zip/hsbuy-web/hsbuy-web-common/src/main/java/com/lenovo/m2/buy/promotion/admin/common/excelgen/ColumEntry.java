package com.lenovo.m2.buy.promotion.admin.common.excelgen;

/**
 * @author wangrq1
 * @create 2017-09-28 下午1:50
 **/
public class ColumEntry {

    private String header;
    private String field;
    private Formatter formater;

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public Formatter getFormater() {
        return formater;
    }

    public void setFormater(Formatter formater) {
        this.formater = formater;
    }


}
