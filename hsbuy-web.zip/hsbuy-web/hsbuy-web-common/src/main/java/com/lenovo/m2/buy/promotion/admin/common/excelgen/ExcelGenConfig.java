package com.lenovo.m2.buy.promotion.admin.common.excelgen;

import com.lenovo.m2.buy.promotion.admin.common.excelgen.formatter.DateFormater;

import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.ss.usermodel.CellStyle;

/**
 * @author wangrq1
 * @create 2017-09-28 下午1:51
 **/
public class ExcelGenConfig {


    public static ExcelGenConfig instance = new ExcelGenConfig();

    private ExcelGenConfig(){}

    private Map<String, Formatter> formatters = new HashMap<String, Formatter>();
    private Map<String, Object> props = new HashMap<String, Object>();
    private Map<String, HSSFCellStyle> cellStyles = new HashMap<String,HSSFCellStyle>();

    public static String SHEET_NAME = "sheet_name";
    public static String DATE_TIME_CELL_STYLE = "date_time";


    //注册formatter
    public void registerFormatter(String key, Formatter val){
        formatters.put(key, val);
    }

    public Formatter getFormatter(String key){
        return formatters.get(key);
    }


    public void addProp(String key, Object value){
        props.put(key, value);
    }

    public Object getProp(String key){
        return props.get(key);
    }
    
    //注册cellStyle
    public void registerCellStyle(String key, HSSFCellStyle val){
    	cellStyles.put(key, val);
    }

    public CellStyle getCellStyle(String key){
        return cellStyles.get(key);
    }

    public void reset(){

        formatters.clear();
        props.clear();

        defaultConfig();
    }


    public void defaultConfig(){


        registerFormatter("date", DateFormater.getInstance());


    }


}
