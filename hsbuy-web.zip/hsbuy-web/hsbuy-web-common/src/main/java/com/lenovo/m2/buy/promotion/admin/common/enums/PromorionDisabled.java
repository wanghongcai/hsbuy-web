package com.lenovo.m2.buy.promotion.admin.common.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by luqian on 2015-11-16.
 */
public enum  PromorionDisabled {

    DISABLED_NO(0,"否"),
    DISABLED_YES(1,"是");
    private final int type;
    private final String descr;
    PromorionDisabled(int type,String descr){
        this.type = type;
        this.descr = descr;
    }

    public int getType() {
        return type;
    }

    public String getDescr() {
        return descr;
    }

    final  static Map<Integer, String> map = new HashMap<Integer, String>();
    final  static  Map<Integer,PromorionDisabled> enumMap = new HashMap<Integer, PromorionDisabled>();
    public static PromorionDisabled getDisabledByType(int type ){
        if(enumMap.size() > 0){
            return enumMap.get(type);
        }
        PromorionDisabled[]disabledEnums =  PromorionDisabled.values();
        for (PromorionDisabled disabledEnum:disabledEnums){
            enumMap.put(disabledEnum.getType(),disabledEnum);
        }
        return enumMap.get(type);
    }
}
