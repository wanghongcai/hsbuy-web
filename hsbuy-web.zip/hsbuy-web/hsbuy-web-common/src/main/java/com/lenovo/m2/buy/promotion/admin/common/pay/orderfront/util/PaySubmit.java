package com.lenovo.m2.buy.promotion.admin.common.pay.orderfront.util;

import org.apache.log4j.Logger;

import java.util.Map;

/* *
 *类名：PaySubmit
 *功能：支付接口请求提交类
 *详细：构造支付各接口表单HTML文本，获取远程HTTP数据
 *版本：3.3
 *日期：2012-08-13
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */

public class PaySubmit {
	
	private static Logger logger = Logger.getLogger(PaySubmit.class);
    
    /**
     * 建立请求，以表单HTML形式构造（默认）
     * @param sParaTemp 请求参数数组
     * @param strMethod 提交方式。两个值可选：post、get
     * @param strButtonName 确认按钮显示文字
     * @return 提交表单HTML文本
     */
    public static String buildRequest(Map<String, String> sParaTemp,String url, String strMethod, String strButtonName) {
        //待请求参数数组

        StringBuffer sbHtml = new StringBuffer();

        sbHtml.append("<form id=\"paysubmit\" name=\"paysubmit\" action=\"" + url
                      + "\" method=\"" + strMethod
                      + "\" target=\"_self\">");
        for (Map.Entry<String,String> item:sParaTemp.entrySet()) {
            String name = item.getKey();
            String value = item.getValue();
            sbHtml.append("<input type=\"hidden\" name=\"" + name + "\" value=\"" + value + "\"/>");
        }

        //submit按钮控件请不要含有name属性
        sbHtml.append("<input type=\"submit\" value=\"" + strButtonName + "\" style=\"display:none;\"></form>");
        sbHtml.append("<script>document.forms['paysubmit'].submit();</script>");
        return sbHtml.toString();
    }
    

}
