package com.lenovo.m2.buy.promotion.admin.common.pay.util.util2;

/**
 * Created by luqian on 2015-04-27.
 */
public class WxPayDto {

    private String orderId;//订单号
    private String totalFee;//金额
    private String spbillCreateIp;//订单生成的机器 IP
    private String notifyUrl;//这里notify_url是 支付完成后微信发给该链接信息，可以判断会员是否支付成功，改变订单状态等
    private String body;// 商品描述根据情况修改
    private String openId;//微信用户对一个公众号唯一
    private String merchantCode;
    private String os;
    private String payType;
    private String lenovoId;
    /**
     * @return the orderId
     */
    public String getOrderId() {
        return orderId;
    }
    /**
     * @param orderId the orderId to set
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    /**
     * @return the totalFee
     */
    public String getTotalFee() {
        return totalFee;
    }
    /**
     * @param totalFee the totalFee to set
     */
    public void setTotalFee(String totalFee) {
        this.totalFee = totalFee;
    }
    /**
     * @return the spbillCreateIp
     */
    public String getSpbillCreateIp() {
        return spbillCreateIp;
    }
    /**
     * @param spbillCreateIp the spbillCreateIp to set
     */
    public void setSpbillCreateIp(String spbillCreateIp) {
        this.spbillCreateIp = spbillCreateIp;
    }
    /**
     * @return the notifyUrl
     */
    public String getNotifyUrl() {
        return notifyUrl;
    }
    /**
     * @param notifyUrl the notifyUrl to set
     */
    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }
    /**
     * @return the body
     */
    public String getBody() {
        return body;
    }
    /**
     * @param body the body to set
     */
    public void setBody(String body) {
        this.body = body;
    }
    /**
     * @return the openId
     */
    public String getOpenId() {
        return openId;
    }
    /**
     * @param openId the openId to set
     */
    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getMerchantCode() {
        return merchantCode;
    }

    public void setMerchantCode(String merchantCode) {
        this.merchantCode = merchantCode;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getLenovoId() {
        return lenovoId;
    }

    public void setLenovoId(String lenovoId) {
        this.lenovoId = lenovoId;
    }
}
