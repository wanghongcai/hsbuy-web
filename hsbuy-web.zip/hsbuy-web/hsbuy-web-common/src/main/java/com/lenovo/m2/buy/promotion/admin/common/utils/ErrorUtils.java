package com.lenovo.m2.buy.promotion.admin.common.utils;

/**
 * Created by mayan3 on 2016/4/9.
 */
public class ErrorUtils {
    public static final String ERR_NOT_ALLOWED="2000";
    public static final String ERR_SYSTEM_EXCEPTION="1000";
    public static final String ERR_NONEXIST_FA="2001";

    // 手机号格式错误
    public static final String ERR_CODE_SMS_PHONEERROR = "20203";
    // 两分钟内只能发一条短信
    public static final String ERR_CODE_SMS_MINUTELIMIT = "20204";
    // 订发送验证码失败
    public static final String ERR_CODE_SMS_ERROR = "20205";
}
