
package com.lenovo.m2.buy.promotion.admin.common.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

/**
 * @Description:
 * @author:
 */
public class HttpUtil {

	private static Log log = LogFactory.getLog(HttpUtil.class);

	private static int conTimeOutMs = 10000;
	private static int soTimeOutMs = 30000;




	/**
	 * @description 发送httpClient post 请求，json 格式返回
	 * @author qinhc
	 * @2015下午6:03:09
	 * @param url
	 * @param body
	 * @return
	 * @throws Exception
	 */
	public static String executeHttpPost(String url, String body) throws Exception {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		StringEntity entity = new StringEntity(body, "utf-8");// 解决中文乱码问题
		entity.setContentEncoding("UTF-8");
		entity.setContentType("application/json");

		String resData = "";
		RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(soTimeOutMs)
				.setConnectTimeout(conTimeOutMs).build();

		HttpPost method = new HttpPost(url);
		method.setEntity(entity);
		method.setConfig(requestConfig);
		try {
			HttpResponse result = httpclient.execute(method);
			// 请求结束，返回结果
			resData = EntityUtils.toString(result.getEntity());
			log.info("executeHttpPost返回：" + resData);
		} catch (Exception e) {
			log.error("executeHttpPost请求出错：" + e.getMessage());
		} finally {
			httpclient.close();
		}
		return resData;
	}

	/**
	 * 
	 * @Description: post 提交
	 * @author yuzj7@lenovo.com
	 * @date 2015年5月15日 上午10:41:49
	 * @param url
	 * @param params
	 * @return
	 */
	public static String postStr(String url, Map<String, String> params) throws UnsupportedEncodingException {
		return PostStr(url, params, null, null, false, "utf-8");
	}

	/**
	 * post 方法
	 * 
	 * @param url
	 * @return
	 * @author mamj
	 * @throws UnsupportedEncodingException
	 * @date 2013-11-19 下午03:46:58
	 */
	public static String PostStr(String url, Map<String, String> params, String referer, String cookie, boolean isproxy,
			String charset) throws UnsupportedEncodingException {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(url);
		// 请求超时 读取超时//设置请求和传输超时时间
		RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(soTimeOutMs)
				.setConnectTimeout(conTimeOutMs).build();
		httpPost.setConfig(requestConfig);
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		if (params != null && !params.isEmpty()) {
			for (Entry<String, String> entry : params.entrySet()) {
				nvps.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
			}
		}
		if (!StringUtils.isEmpty(cookie)) {
			httpPost.setHeader("Cookie", cookie);
		}
		if (!StringUtils.isEmpty(referer)) {
			httpPost.addHeader("Referer", referer);
		}

		if (StringUtils.isEmpty(charset)) {
			charset = "utf-8";
		}
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, charset));
		String line = null;
		StringBuffer str = new StringBuffer();
		InputStreamReader inreader = null;
		BufferedReader reader = null;
		try {
			HttpResponse response = httpclient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			inreader = new InputStreamReader(entity.getContent(), charset);
			reader = new BufferedReader(inreader);
			while ((line = reader.readLine()) != null) {
				str.append(line);
			}
		} catch (Exception e) {
            log.error(e.getMessage(),e);
		} finally {
			try {
				if(reader != null){
					reader.close();   // 最后要关闭BufferedReader
					inreader.close();  //最先创建的最后关，最后创建的最先关
				}
				httpclient.close();
			} catch (IOException e) {
                log.error(e.getMessage(),e);
			}
		}
		return str.toString();
	}

	/**
	 * 
	 * @Description: http get 请求
	 * @author yuzj7@lenovo.com
	 * @date 2015年6月11日 下午5:53:28
	 * @param url
	 * @return
	 */
	public static String getStr(String url) {

		BufferedReader in = null;
		// 定义HttpClient
		CloseableHttpClient client = HttpClients.createDefault();
		// 实例化HTTP方法
		HttpGet request = new HttpGet();
		RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(soTimeOutMs)
				.setConnectTimeout(conTimeOutMs).build();// 设置请求和传输超时时间
		request.setConfig(requestConfig);
		String line = "";
		String tmp = "";
		try {
			request.setURI(new URI(url));
			request.setHeader("Content-Type", "text/html;charset=UTF-8");
			HttpResponse response = client.execute(request);
			in = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
			while ((tmp = in.readLine()) != null) {
				line += tmp;
			}
		} catch (Exception e) {
            log.error(e.getMessage(),e);
        } finally {
			if (in != null) {
				try {
					in.close();// 最后要关闭BufferedReader
					client.close();
				} catch (IOException e) {
                    log.error(e.getMessage(),e);
				}
			}
		}
		return line;

	}

	public static void main(String[] args) {
	
	}
}
