package com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils;

import org.apache.commons.codec.digest.DigestUtils;

import java.io.UnsupportedEncodingException;
import java.security.SignatureException;

/**
 * MD5签名验签类
 * @author 3y
 *@version $Id: MD5Signature.java, v 0.1 2011-8-21 上午10:47:41 3y Exp $
 */
public class MD5Signature{
    /**
     * 对字符串使用MD5签名,待签名字符串+key值签名
     * @param content 待签名的字符串
     * @param key MD5校验码
     * @return 返回签名字符串
     * @throws Exception
     */
    public static String sign(String content, String key) throws Exception {
        String tosign = (content == null ? "" : content) + key;
        System.out.println("signdata:"+tosign);
        try {
            return DigestUtils.md5Hex(getContentBytes(tosign, "utf-8"));
        } catch (UnsupportedEncodingException e) {
            throw new SignatureException("MD5签名[content = " + content + "; charset = utf-8"
                    + "]发生异常!", e);
        }

    }

    /**
     * 对字符串使用MD5验签,验签内容为签名字符串+key值
     * @param content 签名字符串
     * @param sign 签名值
     * @param key MD5校验码
     * @return 如果验签成功返回true 验签失败返回false
     * @throws Exception
     */
    public static boolean verify(String content, String sign, String key)
            throws Exception {
        String tosign = (content == null ? "" : content) + key;

        try {
            String mySign = DigestUtils.md5Hex(getContentBytes(tosign, "utf-8"));

            return StringUtil.equalsStr(mySign, sign) ? true : false;
        } catch (UnsupportedEncodingException e) {
            throw new SignatureException("MD5验证签名[content = " + content + "; charset =utf-8 "
                    + "; signature = " + sign + "]发生异常!", e);
        }
    }

    /**
     * 根据编码字符集对字符串使用MD5验签,验签内容为签名字符串+key值
     * @param content 签名字符串
     * @param sign 签名值
     * @param key MD5校验码
     * @param charset 编码字符集
     * @return 如果验签成功返回true 验签失败返回false
     * @throws Exception
     */
    public static boolean verify(String content, String sign, String key, String charset)
            throws Exception {
        String tosign = (content == null ? "" : content) + key;
        try {
            String mySign = DigestUtils.md5Hex(getContentBytes(tosign, charset));

            return StringUtil.equalsStr(mySign, sign) ? true : false;
        } catch (UnsupportedEncodingException e) {
            throw new SignatureException("MD5验证签名[content = " + content + "; charset ="+ charset
                    + "; signature = " + sign + "]发生异常!", e);
        }
    }

    /**
     * 获取指定编码字符集字符串的byte数组
     * @param content 字符串
     * @param charset 编码字符集
     * @return 返回字符串的byte数组
     * @throws SignatureException
     * @throws UnsupportedEncodingException
     */
    protected static byte[] getContentBytes(String content, String charset)
            throws UnsupportedEncodingException {
        if (StringUtil.isEmpty(charset)) {
            return content.getBytes();
        }

        return content.getBytes(charset);
    }
}
