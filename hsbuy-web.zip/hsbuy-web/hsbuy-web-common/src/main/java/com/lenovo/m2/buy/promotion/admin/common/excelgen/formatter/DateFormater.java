package com.lenovo.m2.buy.promotion.admin.common.excelgen.formatter;

import com.lenovo.m2.buy.promotion.admin.common.excelgen.ExcelGenConfig;
import com.lenovo.m2.buy.promotion.admin.common.excelgen.Formatter;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author wangrq1
 * @create 2017-09-28 下午1:52
 **/
public class DateFormater implements Formatter{

    public static String FORMATTER_PATTEN = "date_patten";

    private static DateFormater instance;


    @Override
    public String format(ExcelGenConfig context, Object obj) {
        String patten = (String)context.getProp(FORMATTER_PATTEN);
        SimpleDateFormat sdf = new SimpleDateFormat(patten);
        return sdf.format((Date)obj);
    }

    public static DateFormater getInstance(){
        if(instance == null){
            synchronized (FORMATTER_PATTEN){
                if(instance != null){
                    return instance;
                }else {
                    instance = new DateFormater();
                }
            }
        }
        return instance;
    }


}
