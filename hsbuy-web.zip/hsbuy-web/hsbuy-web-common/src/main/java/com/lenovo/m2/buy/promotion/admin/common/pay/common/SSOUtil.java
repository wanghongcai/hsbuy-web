package com.lenovo.m2.buy.promotion.admin.common.pay.common;

import com.lenovo.m2.buy.promotion.admin.common.pay.util.JacksonUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.PropertiesHelper;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils.StringUtil;
import com.lenovo.m2.buy.promotion.admin.common.pay.util.util2.BaseInfo;
import com.lenovo.ucenter.sso.client.util.SSOUserInfoUtil;
import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;


/** 单点登录工具类
 * Created by zhanglijun on 2015/8/21.
 */
public class SSOUtil {

    private static final Logger logger = Logger.getLogger(SSOUtil.class);

    /**
     *  单点登录开关
     *
     */
    public static  boolean isSsoSwitch(){
        String isSsoSwitch = PropertiesHelper.loadToMap("pay_switch.properties").get("ssoSwitch").toString();
        if(isSsoSwitch.equals("0")){
            logger.info("单点登录已开启");
            return true;
        }
        logger.info("单点登录已关闭");
        return false;
    }

    /**
     *  判断是否已经登录
     *
     */
    public static  boolean  islogin(HttpServletRequest request){
        String lenovoId= SSOUserInfoUtil.getLenovoId(request);
        logger.info("lenovoId==单点登录获取======"+lenovoId);
        String lenovoid = request.getParameter("lenovoId");
        logger.info("lenovoid==前台页面获取======"+lenovoid);
        if(StringUtil.isNotEmpty(lenovoId)&& StringUtil.isNotEmpty(lenovoid)&&lenovoid.equals(lenovoId)){
            logger.info("单点登录校验正确。。。");
            return  true;
        }else{
            logger.info("单点登录校验失败。。。");
            return false;
        }
    }





    //单点登录的url拼接
    public static String ssoLoginUrl(String orderid, String payType, String callback, String directbank){
        String loginUrl="";
        try {
            logger.info("用户未登录，跳转到登录页面....");
            String url = PropertiesHelper.loadToMap("ali_pay.properties").get("pcGoToBank").toString();
            String alipayUrl = url+"?ordercode=" + orderid + "&paymentTypeCode=" + payType;
            logger.info("用户登录成功后跳转的url==="+alipayUrl);
            String ssourl= PropertiesHelper.loadToMap("ali_pay.properties").get("ssoRegtUrl").toString();
            if(StringUtil.isNotEmpty(directbank)){
                alipayUrl+="&directbank=" + directbank ;
            }
            loginUrl = ssourl+"?ru=" + java.net.URLEncoder.encode(alipayUrl,"UTF-8");
            logger.info("用户登录的url==="+loginUrl);
        } catch (Exception e) {
            logger.error("单点登录失败跳转异常", e);
        }
        return callback+"("+ JacksonUtil.toJson(new BaseInfo(10,loginUrl ))+")";
    }

}
