package com.lenovo.m2.buy.promotion.admin.common.enums;


public enum Terminal {
	
	
	PC(1, "PC"),
	WAP(2, "WAP"),
	APP(3, "APP"),
	WECHAT(4, "微信");
	
	private final int type;
	private final String descr;
	
	private Terminal(int type, String descr){
		this.type = type;
		this.descr = descr;
		
	}

	public int getType() {
		return type;
	}

	public String getDescr() {
		return descr;
	} 

	public static void main(String[] args) {
	}


}
