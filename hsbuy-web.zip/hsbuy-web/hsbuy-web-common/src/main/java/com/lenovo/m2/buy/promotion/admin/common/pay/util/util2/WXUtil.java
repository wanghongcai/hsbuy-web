package com.lenovo.m2.buy.promotion.admin.common.pay.util.util2;

import java.util.Random;


/**
 * @ClassName: WXUtil 
 * @Description: TODO(这里用一句话描述这个类的作用) 
 * @author ywx
 * @date 2015-4-15 下午11:13:48 
 *  
 */
public class WXUtil {
	/**
	 * 获取所及字符串
	 * @return
	 */
	public static String getNonceStr() {
		Random random = new Random();
		return MD5.MD5Encode(String.valueOf(random.nextInt(10000)), "UTF-8");
	}
	/**
	 * 获取时间戳
	 * @return
	 */
	public static String getTimeStamp() {
		return String.valueOf(System.currentTimeMillis() / 1000);
	}

}
