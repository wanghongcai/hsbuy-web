package com.lenovo.m2.buy.promotion.admin.common.pay.common;

/**
 * Created by yangjj7 on 2015/5/3.
 */
public class ReturnUrl {

    //跳转到微信调起页面
    public static final String TO_WX_PAY = "weixin/pay";



    //跳转到微信调起页面
    public static final String TO_WX_ERROR = "weixin/error";

}
