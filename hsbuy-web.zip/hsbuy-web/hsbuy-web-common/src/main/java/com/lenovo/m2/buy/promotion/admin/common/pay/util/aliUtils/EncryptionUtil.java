package com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils;
/**
 * Created by zhanglijun on 2015/5/23.
 */
/**
 * @Description: 加密解密工具类
 * @version:v1.0.0
 * @Created:2014年5月22日上午10:27:48
 * @Modified:
 */
public class EncryptionUtil {

    /**
     * @param source 加密前的原串
     * @return String 加密后的加密串
     * @Description: 加密
     * @Created:lining 2014年5月22日上午10:29:01
     * @Modified:
     */
    public static String encryption(String source) {
        byte[] a = source.getBytes();
        for (int i = 0; i < a.length; i++) {
            a[i] = (byte) (a[i] ^ 't');
        }
        return Base64.encode(a);
    }

    /**
     * @param target 需解密的加密串
     * @return String 解密后的原串
     * @Description: 解密
     * @Created:lining 2014年5月22日上午10:31:34
     * @Modified:
     */
    public static String deEncryption(String target) {
        byte[] a = Base64.decode(target);
        for (int i = 0; i < a.length; i++) {
            a[i] = (byte) (a[i] ^ 't');
        }
        String k = new String(a);

        return k;
    }


}