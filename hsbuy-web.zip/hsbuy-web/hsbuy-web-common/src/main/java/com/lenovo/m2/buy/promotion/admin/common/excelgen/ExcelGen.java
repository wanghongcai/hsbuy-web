package com.lenovo.m2.buy.promotion.admin.common.excelgen;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.*;

import com.esotericsoftware.reflectasm.MethodAccess;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author wangrq1
 * @create 2017-09-28 下午2:09
 **/
public class ExcelGen {


    /**
     * header 格式: 名称-name, 年龄-age, 生日-birth
     * @param config
     * @param header
     * @param datas
     * @param <T>
     * @return
     */
    public static <T> HSSFWorkbook gen(ExcelGenConfig config, String header, List<T> datas) {
        //解析列名 列和属性映射

        Map<String, ColumEntry> configMap = parseColumMeta(header);

        // 产生工作簿对象
        HSSFWorkbook workbook = new HSSFWorkbook();

        HSSFSheet sheet = workbook.createSheet((String)config.getProp(ExcelGenConfig.SHEET_NAME));

        HSSFCellStyle style = workbook.createCellStyle();
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);

        genHeader(configMap, workbook, sheet, style);

        genDataRows(config, datas, configMap, sheet, style);

        return workbook;
    }

    private static <T> void genDataRows(ExcelGenConfig config, List<T> datas, Map<String, ColumEntry> configMap, HSSFSheet sheet, HSSFCellStyle style) {
    	Class<? extends Object> dataType = datas.get((int) 0).getClass();
    	MethodAccess access = MethodAccess.get(dataType);
    	int j = 0;
        for(T data: datas){
            HSSFRow row1 = sheet.createRow(++j);
            genRow(config, configMap, row1, style, data, access);
        }
    }


    private static Map<String, ColumEntry> parseColumMeta(String header) {
        Map<String, ColumEntry> configMap = new LinkedHashMap<>();
        for(String entry: StringUtils.split(header, ",")){
            String[] arr = StringUtils.split(entry, "-");
            ColumEntry columEntry = new ColumEntry();
            columEntry.setField(StringUtils.trim(arr[1]));
            columEntry.setHeader(StringUtils.trim(arr[0]));
            configMap.put(StringUtils.trim(arr[0]), columEntry);
        }
        return configMap;
    }

    private static void genHeader(Map<String, ColumEntry> configMap, HSSFWorkbook workbook, HSSFSheet sheet, HSSFCellStyle style) {
        HSSFRow head = sheet.createRow((int) 0);
        //header
        int i = 0;
        for(String tital: configMap.keySet()){
            HSSFCell cell = head.createCell(i++);
            cell.setCellValue(tital);
            cell.setCellStyle(style);
            sheet.setColumnWidth(i, 6000);
        }
    }

    private static <T> void genRow(ExcelGenConfig config, Map<String, ColumEntry> configMap, HSSFRow row, HSSFCellStyle style, T data, MethodAccess access) {

        int j = 0;
        for(ColumEntry entry: configMap.values()){
            HSSFCell cell = row.createCell(j++);
            cell.setCellStyle(style);

            Object val = null;
            //ColumEntry entry;
			try {
				val = access.invoke(data, "get"+StringUtils.capitalize(entry.getField()));
			} catch (Exception e) {
				try {
					val = access.invoke(data, "is"+StringUtils.capitalize(entry.getField()));
				} catch (Exception e1) {
					
				}
				
			}
			
            if(val == null){
                continue;
            }

            String value = null;
            Formatter formater = config.getFormatter(entry.getField());
            if(formater != null){
                value = formater.format(config, val);
            }else {
                value = String.valueOf(val);
            }

            cell.setCellValue(value);
        }
    }


}
