package com.lenovo.m2.buy.promotion.admin.common.pay.util.aliUtils;

/* *
 *类名：AliSimplePaltPayConfig
 *功能：基础配置类
 *详细：设置帐户有关信息及返回路径
 *版本：1.0
 *日期：2015-09-14
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
	
 *提示：如何获取安全校验码和合作身份者ID
 *1.用您的签约支付宝账号登录支付宝网站(www.alipay.com)
 *2.点击“商家服务”(https://b.alipay.com/order/myOrder.htm)
 *3.点击“查询合作者身份(PID)”、“查询安全校验码(Key)”

 *安全校验码查看时，输入支付密码后，页面呈灰色的现象，怎么办？
 *解决方法：
 *1、检查浏览器配置，不让浏览器做弹框屏蔽设置
 *2、更换浏览器或电脑，重新登录查询。
 */

public class AliSimplePaltPayConfig {
	
	//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
	// 合作身份者ID，以2088开头由16位纯数字组成的字符串
	public static String partner = "2088311865032391";
	// 商户的私钥,使用支付宝自带的openssl工具生成。
	public static String private_key = "MIICXAIBAAKBgQCmR5xDTnvDSGmx6SWW6HKcX4eynxumIXT6ivl7nTS3ngAlR8VcZWr/RW0I0ZawQC3V/Y1rg2nrlcslL/Y7FaGUn4O+5Gy8/tNdVd6WL5NeXPZx2gHKlsXOPdsbsJXSWuIOjRnZlNQsbvC4VR/LNCWjwJ/LNcdUEbSlJA9Jyba6rwIDAQABAoGAU8+acs53UUoJhFQ4zySgyDLaiezqmcUZWkN8VpM5hCeOeTwAvX6c/Mf4mk5R/sqKj+a6Rmu5krYw67COEt/nTdr8YEwOz74/7C8x3LxOX6he1z24cngh3dMzUdtqfCCV97YssUdUwayIgxtpamxx+OerUcf4ydbWrdi4feDSf5ECQQDaO0bZukd9N3efvCnFvgTJPKnld963laDgntyDgoxhOPGIRV9oSP9LfbquvOyCTc+0EVNvgDbNWorT1O5y31DZAkEAww6dQMpApO1yA25NdZTPRJSjoKBFOQt5b5vq/eRGMRI02TX5aw+s0IpELoP+cmJqbfBoHCA+HxQ7mIYBhiiyxwJBAIJs6us1aYRsohHVYyHLbxDWMLPz8CfIRV35k9EFNODmJ3RKAbtR5UI44lmMj81Qs9HqiPMaraYNdusjV19QGAECQEyJCHTqpzDPpmPoPOZ9DFLZi9az7FV0xiJf6HXUwyHwBeKQxhwXG3T8O8KQsh9JtH8MzJz0nctuEfBH7IMqpvMCQGmdhpjivFu//4GXEWbunq4UrvOoIxxArOz3t47/Y0Tiumds/2rOYiwu4CtyGl5SrVr3kRsAkcEFKncW6lNP5Bs=";

    public static String private_key_pkcs8="MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKZHnENOe8NIabHpJZbocpxfh7KfG6YhdPqK+XudNLeeACVHxVxlav9FbQjRlrBALdX9jWuDaeuVyyUv9jsVoZSfg77kbLz+011V3pYvk15c9nHaAcqWxc492xuwldJa4g6NGdmU1Cxu8LhVH8s0JaPAn8s1x1QRtKUkD0nJtrqvAgMBAAECgYBTz5pyzndRSgmEVDjPJKDIMtqJ7OqZxRlaQ3xWkzmEJ455PAC9fpz8x/iaTlH+yoqP5rpGa7mStjDrsI4S3+dN2vxgTA7Pvj/sLzHcvE5fqF7XPbhyeCHd0zNR22p8IJX3tiyxR1TBrIiDG2lqbHH456tRx/jJ1tat2Lh94NJ/kQJBANo7Rtm6R303d5+8KcW+BMk8qeV33reVoOCe3IOCjGE48YhFX2hI/0t9uq687IJNz7QRU2+ANs1aitPU7nLfUNkCQQDDDp1AykCk7XIDbk11lM9ElKOgoEU5C3lvm+r95EYxEjTZNflrD6zQikQug/5yYmpt8GgcID4fFDuYhgGGKLLHAkEAgmzq6zVphGyiEdVjIctvENYws/PwJ8hFXfmT0QU04OYndEoBu1HlQjjiWYyPzVCz0eqI8xqtpg126yNXX1AYAQJATIkIdOqnMM+mY+g85n0MUtmL1rPsVXTGIl/oddTDIfAF4pDGHBcbdPw7wpCyH0m0fwzMnPSdy24R8Efsgyqm8wJAaZ2GmOK8W7//gZcRZu6erhSu86gjHECs7Pe3jv9jROK6Z2z/as5iLC7gK3IaXlKtWveRGwCRwQUqdxbqU0/kGw==";
	// 支付宝的公钥，无需修改该值
	public static String ali_public_key  = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCnxj/9qwVfgoUh/y2W89L6BkRAFljhNhgPdyPuBV64bfQNN1PjbCzkIM6qRdKBoLPXmKKMiFYnkd6rAoprih3/PrQEB/VsW8OoM8fxn67UDYuyBTqA23MML9q1+ilIZwBC2AQ2UBVOrFXfFl75p6/B5KsiNG9zpgmLCUYuLkxpLQIDAQAB";


	//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
	public static final String SIGN_ALGORITHMS = "SHA1WithRSA";
	//商户收款账号
	public static String seller = "lenovogw@lenovo.com";

	// 字符编码格式 目前支持 gbk 或 utf-8
	public static String input_charset = "UTF-8";
	
	// 签名方式 不需修改
	public static String sign_type = "RSA";
}
