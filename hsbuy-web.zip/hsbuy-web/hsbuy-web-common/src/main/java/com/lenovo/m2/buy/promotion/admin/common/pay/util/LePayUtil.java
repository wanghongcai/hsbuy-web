package com.lenovo.m2.buy.promotion.admin.common.pay.util;

import com.lenovo.m2.arch.framework.domain.RemoteResult;
import com.lenovo.m2.buy.promotion.admin.common.pay.common.PeakConstant;
import com.lenovo.m2.hsbuy.domain.pay.soa.cashier.PayPortalOrder;
import com.lenovo.m2.hsbuy.domain.pay.soa.wxpay.PayOrder;
import com.lenovo.points.client.MemPointsClient;
import com.lenovo.points.vo.MemPointsWriteResult;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileInputStream;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 乐支付公共工具类
 * Created by tianchuyang on 2017/3/1.
 */
public class LePayUtil {

    private static Logger logger = Logger.getLogger(LePayUtil.class);

    // 接口版本号
    public static final String VERSION = "1.0.0.0";
    // 人民币代码
    public static final String TrxTrxCcy = "156";
    // 24小时秒数
    public static final String ORDER_INDATE_SEC = "864399";
    // PC URL
    public static final String PAY_URL_PC = "https://netpay.cmbchina.com/cdpay/cdpay.dll?cdpay";
    // WAP URL
    public static final String PAY_URL_WAP = "https://netpay.cmbchina.com/cdpay/cdpay.dll?MB_Prepay";
    // 掌上生活扫码支结果
    public static final String CMBLIFE_PAY_PS = "2";  // 支付成功
    public static final String CMBLIFE_PAY_PF = "3";  // 支付失败
    public static final String CMBLIFE_PAY_PSNF = "200"; // 支付成功通知失败
    public static final String CMBLIFE_PAY_PFNF = "300";  // 支付失败通知失败
    // 掌上生活支付状态返回
    public static final String CMBLIFE_DISPOSE_SUCC = "{\"respCode\":\"1000\"}";  // 支付成功处理成功
    public static final String CMBLIFE_DISPOSE_FAIL = "{\"respCode\":\"1001\"}";  // 处理失败
    // 掌上生活扫码支付协议
    public static final String CMBLIFE_RELEASE_TAG_FUNC_NAME = "releaseTagForQRPay.json";  // 处理失败
    public static final String CMBLIFE_PROTOCOL_HEADER = "pay";  // 处理失败
    // 发码消息状态
    public static final String CMBLIFE_REQ_SUCC = "1000";  // 请求成功
    public static final String CMBLIFE_REQ_FAIL = "1001";  // 请求失败
    public static final String AGENT_BUSINESS = "1";  // 代收代付

    // 招行扫码分期发码接口
    public static final String RELEASE_TAG_URL = "https://sandbox.ccc.cmbchina.com/AccessGateway/transIn/releaseTagForQRPay.json";
    // 招行扫码轮询接口
    public static final String POLLING_QUERY_URL = "https://open.cmbchina.com/AccessGateway/transIn/queryTagForPay.json";
    // 招行掌上生活扫码支付商户私钥
    public static final String CMBLIFE_MER_PRI_KEY = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCcfAstxxYNBRqmUp52R5qWObX1qVx9kjQrQUj246aPSFLdAjj5YdtkTg/oCXGvHAEa0umR2nY/BB0t5DQ1KT9ZTcY5Ka4ilmbIdYx4CrPcjQ7OhZDnRS7ot0TgEg09iUHVbFNidQRiYxn4e/2or7mU4vIQvcXGwd9lRPG11iEZknKpRsXn2AZoga13SUcAG0H3YNGot0FFwTH902euG3AUrEngax2Vn3bBnnfP0GSjAQTS7qaP7HUKiQI6xQMcXBhQd4Gw4SJshKumXIvK0xkpf6fHOkS0OSxKRrNXcdmrj9Xt0FV2mC6EtfoTa9MaWpKjpThHH/0kAZshjnVfksO7AgMBAAECggEBAJX03PWSahQyBvbKB6aLOZ2qUi/Hi6Wd/LZSyqwlPhDimt3F6nk5CHgXwnB21GWdLYXaBhBKTLRYqem3XTxweY+H02QmCASHIpoI44KJpxC8cCsCnfiyOKC0N6GOSvfkV51BQKsCPiBWnaWclFkZhHsj/BqE8UllskGmjwbU20VXrTlkO3WqoPCFQ6KmH1bsn+WblswtI8dQY7bWpiUUv9TSEqSdImyHBFh+5FQisscgSyA0L5ZfD8oZ6oXiA0NdySdrK1KTiW2tkrek4C/a/zj3XDkTOOstTG9keTncu7Rlap1YZt2uT7y6CkaIEYg9jq008cPANp1oEipfRh+qX4ECgYEAyyPy+d0PPd4wHhugBDFo2JX3f/yEKQZPDmGA/5HFAsu3x3GBfhkFsXdyuXotowSVqFNC+V93v7HOC1r7e8i9sXYPKxudGAQ8EgPyKdpLAjiJhj9mwaMe7gUaDy6483ss9pk7+xqNpQrLL1jaNBm6rZwVEnVrSl/pqYJYw0hjAkECgYEAxTQlrdiECglk/aQa5fy4zMIdNb5EBxCMTN+bXP7yx48hzHeYi+TEY2SH65GD/klEN1d+corLf75Pt0osw5iqfFaSkrurKUvU2YMk8c2onAnq+kVCagqI6R5tEEzg8BCxZqy5WRmCESIfwSSp7GJt8ublzDqQJ0ETjB0WFiRgDvsCgYBwq+nSyNfxWtGZgX0JllYu+08hv++VyZgDw/UGy9VYLaIrjzths4NC4ZvSYH/7kUlo6XWWV2tV+crs5XPjPn5odbEIGfLSJVckLugcaqV7/9vXiEb4U/+NyWqgzStscP+Jb4ijSCEUT55PDptIlpTCQnY1nMb7o6M4j8Gn3vh7gQKBgALPeXH+0fLqq1vKCPAaJ/ATHCN18LZBEB7QWQB8Sa16ZrrpQW1M91eLSTycOEtZc/Vt88liHQBXD//GuNiYxmU7Pp+EuS2/fOsUqWQg0DRZF9Y1QnsMZ2MbIebHkbUaJ80UzRdt+6KO3/D6usk5peN+UuwUMZW9oa+vgm8SWaQdAoGBAI57ypdh7XmyRdpVxkrVfmCl2xEVB+qfZz0sc+sfU8UsOGJ3FZ78kAUZsJh7tAjIqQwV9RtoN7jUWbnYpTkQg6KkZMe5ClA7IUCAQWFyisfVd8gYS/ZHiFnXLH8nmPZYCMlIno8BVHcI/EJPeZUYQPsPIHrnB5hdMuN5D7BFZa04";

    public static final String CMBLIFE_PUB_KEY_UAT = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqoUJLtUCJSNe/XjBWci5JD9muP1e8Jbwe5c6H6oRcsD8CvY7EqZVD2GLW/UWumgtM652LQF2U3DX5Zi57XPFEjvOdRpVROaurvYVyvpudMBF3Yu33PV7k7OB+bR5cGfuUu0QOFUSJSLVTA7SPAGVP1XoIPZ48utX1jBcW9y7atVba7Mwmjhn+chDplJXQhbA3htpfRRL6ZyGQltyym6UN3dIddYxXfaL05zwbEOVwDU1H5u0QOO2chaFFyoUFEkMSRWcVUz20pbEQ0HEYUy4bPvxuLWTGauuMRAF4Ltta2uELveWHZL7USfwqFZ2Lo61x78BheicZT/fC6oZTxpfhQIDAQAB";

    public static final String CMBLIFE_PUB_KEY_PRO = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1z9Z6Y4Ecv27AIJd0LY8YsJQg+cuyHQm2oBOWBm/xE1T+4iGyV+YFm//bbFtqGGIjbnTSD8RSHyYFcAW9bQ8g6nvGfCDIsdtv62JUKQkQRRw/TNZ0CrVO0rZvboF5GDgKyxLaZkAqOLWdbblyduKBVkvjmsf0F7ViegAx5tEOP0rE2OaryLIOlTu0qmoT6fG71dwoUFcJJWidxFyD5gjEexIgTKOSJ0k0SNixxuT34Czd7mzArp8oE1jdWiTDKKE4VSpxTu0+gZwcfEPByOf5t+rysrQB1tcpCrv+AxIT1c7J3WVhYNx7CT9brsEGZ452btSMeoSvpvWfdsladMB3wIDAQAB";

    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String DEFUALT_TIME_ZONE_ID = "Asia/Shanghai";
    public static final String INDIA_TIME_ZONE_ID = "IST";

    public static final String DEFAULT_TIMEZONE = "GMT+8";

    private static RequestConfig requestConfig = RequestConfig.custom()
            .setSocketTimeout(15000)
            .setConnectTimeout(15000)
            .setConnectionRequestTimeout(15000)
            .build();

    /**
     * xml解析成Map
     *
     * @param retXml
     * @return
     * @throws Exception
     */
    public static Map<String, String> parseXml(String retXml) throws Exception {
        // 替换掉$符
        String s = retXml.replaceAll("\\u0024", "");
        System.out.println(s);
        Map<String, String> map = new HashMap<String, String>();
        getElementList(getRootElement(s), map);
        return map;
    }

    /**
     * 获取根元素
     *
     * @return
     * @throws DocumentException
     */
    public static Element getRootElement(String xml) throws DocumentException {
        Document srcdoc = DocumentHelper.parseText(xml);
        Element elem = srcdoc.getRootElement();
        return elem;
    }

    /**
     * 递归遍历方法
     *
     * @param element
     */
    public static void getElementList(Element element, Map<String, String> map) {
        List elements = element.elements();
        if (elements.size() == 0) {
            //没有子元素
            String name = element.getName();
            String value = element.getTextTrim();
            map.put(name, value);
        } else {
            //有子元素
            for (Iterator it = elements.iterator(); it.hasNext(); ) {
                Element elem = (Element) it.next();
                //递归遍历
                getElementList(elem, map);
            }
        }
    }

    /**
     * 签名
     *
     * @param cleartext head+body
     * @param key       商户密钥
     * @return 签名结果
     */
    public static String sign(String cleartext, String key) {
        MessageDigest messageDigest = null;
        StringBuffer signature = new StringBuffer();
        try {
            signature.append(key).append(cleartext);
            messageDigest = MessageDigest.getInstance("SHA-1");
            messageDigest.update(signature.toString().getBytes("GB2312"));
        } catch (Exception e) {
            logger.info("招行网关分期签名发生错误：Error Cause By :" + e);
        }
        String sign = byte2hex(messageDigest.digest()).toLowerCase();
        return sign;
    }

    /**
     * 验签
     *
     * @param text
     * @param sign
     * @return
     */
    public static boolean verifySign(String text, String sign, String path) {
        boolean flag = false;
        byte[] baKey = new byte[0];
        try {
            baKey = LoadFile(path + File.separator + "cmbfq.key");
            RSAPublicKey public_key = byteToKey(baKey);
            //上面两行完成公钥的加载。商户可以把加载后的公钥放在变量中反复使用，避免每次重新加载
            Signature signCheck = Signature.getInstance("SHA1withRSA");
            signCheck.initVerify(public_key);
            signCheck.update(text.getBytes("GB2312"));
            flag = signCheck.verify(fromHex(sign));
        } catch (Exception e) {
            logger.info("招行网关分期验签发生错误：Error Cause By :" + e);
        }
        return flag;
    }

    public static String byte2hex(byte[] b) {//二行制转字符串
        String hs = "";
        String stmp = "";
        for (int n = 0; n < b.length; n++) {
            stmp = (Integer.toHexString(b[n] & 0XFF));
            if (stmp.length() == 1)
                hs = hs + "0" + stmp;
            else
                hs = hs + stmp;
        }
        return hs;
    }

    //读取文件内容，返回byte[]数组
    public static byte[] LoadFile(String filePath) throws Exception {
        File f = new File(filePath);
        byte[] baPublicKey = new byte[(int) f.length()];

        FileInputStream fisFile = new FileInputStream(filePath);
        fisFile.read(baPublicKey);
        fisFile.close();
        return baPublicKey;
    }

    //从公钥文件原始数据，获取公钥
    public static RSAPublicKey byteToKey(byte[] baPublicKey) throws Exception {
        X509EncodedKeySpec spec = new X509EncodedKeySpec(baPublicKey);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return (RSAPublicKey) keyFactory.generatePublic(spec);
    }

    //二进制字符串，转换成byte[]数组。每两位为一个字节
    public static byte[] fromHex(String hex) throws Exception {
        byte[] ba = new byte[hex.length() / 2];
        for (int i = 0; i < hex.length(); i += 2) {
            String digit2 = hex.substring(i, i + 2);
            ba[i / 2] = (byte) Integer.parseInt(digit2, 16);
        }
        return ba;
    }

    /**
     * date格式任意转换
     *
     * @param dateStr 要转换的date
     * @param srcFmt  原格式
     * @param dstFmt  目标格式
     * @return
     */
    public static String dateFormatConvert(String dateStr, String srcFmt, String dstFmt) {
        SimpleDateFormat srcSdf = new SimpleDateFormat(srcFmt);
        SimpleDateFormat dstSdf = new SimpleDateFormat(dstFmt);
        String dst = "";
        try {
            Date date = srcSdf.parse(dateStr);
            dst = dstSdf.format(date);
        } catch (ParseException e) {
            logger.info("日期格式转换异常：Error Cause By :" + e);
        }
        return dst;
    }

    /**
     * 判断多字符串参数全不为空
     *
     * @param args
     * @return
     */
    public static boolean isParamsEmpty(String... args) {
        for (String arg : args) {
            if (null == arg || "".equals(arg.trim())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 判断Map是否有空值
     * @param map
     * @return
     */
    public static boolean hasEmptyFromMap(Map<String,Object> map){
        if (null == map || map.isEmpty()){
            return false;
        }
        for (Map.Entry<String,Object> entry : map.entrySet()){
            if (entry.getValue() instanceof String){
                if (null == entry.getValue() || "".equals(((String) entry.getValue()).trim())){
                    logger.info("hasEmptyFromMap :" +entry.getKey() +" is empty!");
                    return true;
                }
            } else {
                if (null == entry.getValue()){
                    logger.info("hasEmptyFromMap :" +entry.getKey() +" is null!");
                    return true;
                }
            }
        }
        return false;
    }
    /**
     * 将request转成Map
     *
     * @param request
     * @return
     */
    public static Map getParametersToMap(HttpServletRequest request) {
        // 参数Map
        Map properties = request.getParameterMap();
        // 返回值Map
        Map returnMap = new HashMap();
        Iterator entries = properties.entrySet().iterator();
        Map.Entry entry;
        String name = "";
        String value = "";
        while (entries.hasNext()) {
            entry = (Map.Entry) entries.next();
            name = (String) entry.getKey();
            Object valueObj = entry.getValue();
            if (null == valueObj) {
                value = "";
            } else if (valueObj instanceof String[]) {
                String[] values = (String[]) valueObj;
                for (int i = 0; i < values.length; i++) {
                    value = values[i] + ",";
                }
                value = value.substring(0, value.length() - 1);
            } else {
                value = valueObj.toString();
            }
            returnMap.put(name, value);
        }
        return returnMap;
    }

    /**
     * 将request转换成map
     *
     * @param request
     * @return
     */
    public static Map<String, String> getParameterMap(HttpServletRequest request) {
        Map<String, String> map = new HashMap<String, String>();
        String name = "", value = "";
        StringBuffer log = new StringBuffer();
        log.append("LePayUtil getParameterMap with Map data is ");
        for (Enumeration names = request.getParameterNames(); names.hasMoreElements(); map.put(name, value)) {
            name = (String) names.nextElement();
            value = request.getParameter(name);
            map.put(name, value);
            log.append(name = value + ",");
        }
        logger.info(log.toString());
        return map;
    }

    /**
     * 产生32位随机数
     *
     * @return
     */
    public static String genRandom() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }

    /**
     * 生成时间戳
     *
     * @return
     */
    public static String getDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = new Date();
        return sdf.format(date);
    }

    public static String buildRequestFrom(Map<String, String> postMap, String url, String method) {
        StringBuffer sb = new StringBuffer();
        sb.append("<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>PAY</title></head>");
        sb.append("<body>" + buildRequest(postMap, url, method) + "</body>" +
                "</html>");
        return sb.toString();
    }

    /**
     * 建立请求，以表单HTML形式构造（默认）
     *
     * @param postMap 请求参数数组
     * @param url     支付网关地址
     * @param method  提交方式：post
     * @return 提交表单HTML文本
     */
    public static String buildRequest(Map<String, String> postMap, String url, String method) {
        StringBuffer sbHtml = new StringBuffer();
        sbHtml.append("<form name=\"paydirsubmit\" action=\"" + url + "\" method=\"" + method + "\">");
        //待请求参数数组
        ListIterator<Map.Entry<String, String>> keys = new ArrayList<Map.Entry<String, String>>(postMap.entrySet()).listIterator(postMap.size());
        while (keys.hasPrevious()) {
            Map.Entry<String, String> entry = keys.previous();
            sbHtml.append("<input type=\"hidden\" name=\"" + entry.getKey() + "\" value=\"" + entry.getValue() + "\"/>");
        }
        //submit按钮控件请不要含有name属性
        sbHtml.append("<input type=\"submit\" value=\"提交\" style=\"display:none;\"></form>");
        sbHtml.append("<script>document.forms['paydirsubmit'].submit();</script>");
        return sbHtml.toString();
    }

    /**
     * 生成RSA 私钥
     *
     * @param size
     * @return
     * @throws GeneralSecurityException
     */
    public static Map<String, Object> genRSAKey(int size) throws GeneralSecurityException {
        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
        keyPairGen.initialize(size);
        KeyPair keyPair = keyPairGen.generateKeyPair();
        RSAPublicKey publicKey = (RSAPublicKey) keyPair.getPublic();
        RSAPrivateKey privateKey = (RSAPrivateKey) keyPair.getPrivate();
        Map<String, Object> keyMap = new HashMap<String, Object>();
        keyMap.put("RSAPublicKey", publicKey);
        keyMap.put("RSAPrivateKey", privateKey);
        keyMap.put("RSAPublicKeyString", Base64.encodeBase64String(publicKey.getEncoded()));
        keyMap.put("RSAPrivateKeyString", Base64.encodeBase64String(privateKey.getEncoded()));
        keyMap.put("RSAModulesHex", publicKey.getModulus().toString(16));
        keyMap.put("RSAExponentHex", "0" + publicKey.getPublicExponent().toString(16));
        return keyMap;
    }

    /**
     * 将json转化为实体POJO
     *
     * @param jsonStr
     * @param obj
     * @return
     */
    public static <T> Object jsonToObj(String jsonStr, Class<T> obj) {
        T t = null;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            t = objectMapper.readValue(jsonStr, obj);
        } catch (Exception e) {
            logger.info("Json to Object Error:Error Cause By :" + e);
        }
        return t;
    }

    /**
     * 发送HTTP POST请求,支持带多个String参数
     *
     * @param url      链接
     * @param paramMap 参数
     */
    public static String sendHttpPost(String url, Map<String, String> paramMap) throws Exception {
        CloseableHttpClient httpclient = getHttpClient();
        return sendHttpPost(url, paramMap, httpclient);
    }

    /**
     * 获取HttpClient
     */
    private static CloseableHttpClient getHttpClient() {
        return HttpClients.createDefault();
    }

    /**
     * 发送HTTP POST请求
     */
    private static String sendHttpPost(String url, Map<String, String> paramMap, CloseableHttpClient httpclient) throws Exception {
        try {
            HttpPost httpPost = new HttpPost(url);
            // 处理发送中文问题
            httpPost.getParams().setParameter("http.protocol.content-charset", HTTP.UTF_8);
            httpPost.getParams().setParameter(HTTP.CONTENT_ENCODING, HTTP.UTF_8);
            httpPost.getParams().setParameter(HTTP.CHARSET_PARAM, HTTP.UTF_8);
            httpPost.getParams().setParameter(HTTP.DEFAULT_PROTOCOL_CHARSET, HTTP.UTF_8);

            List<NameValuePair> nvps = new ArrayList<NameValuePair>();

            for (String key : paramMap.keySet()) {
                nvps.add(new BasicNameValuePair(key, paramMap.get(key)));
            }

            httpPost.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
            return sendHttpPost(httpPost, httpclient);
        } finally {
            httpclient.close();
        }
    }

    /**
     * 发送HTTP POST请求
     */
    private static String sendHttpPost(HttpPost httpPost, CloseableHttpClient httpclient) throws Exception {
        httpPost.setConfig(requestConfig);
        CloseableHttpResponse response = httpclient.execute(httpPost);

        try {
            HttpEntity entity = response.getEntity();
            return EntityUtils.toString(entity, Charset.forName("UTF-8"));
        } finally {
            response.close();
        }
    }

    public static Map<String, String> parseTradeInfo(String tradeInfo) throws Exception {
        tradeInfo = URLDecoder.decode(tradeInfo, "UTF-8");
        Map<String, String> tradeMap = new HashMap<String, String>();
        String[] paramPairs = tradeInfo.split("\\&\\+\\&");
        for (String paramPair : paramPairs) {
            String[] param = paramPair.split("\\=");
            tradeMap.put(param[0].trim(), param[1].trim());
        }
        return tradeMap;
    }

    /**
     * @param payPortalOrder
     * @return
     * @throws Exception
     */
    public static boolean writePointMppay(PayPortalOrder payPortalOrder, Map<String, Object> paraMap) {
        paraMap.put("error_code", "POINT MPPAY FAIL");
        paraMap.put("error_msg", "积分扣减失败");
        Integer point = payPortalOrder.getPoint();
        String lenovoId = payPortalOrder.getLenovoId();
        String orderMainCode = payPortalOrder.getOutTradeNo();
        try {
            long id = payPortalOrder.getId();
            logger.info("调用扣减积分 start lenovoId=[" + lenovoId + "],point=[" + point + "],orderMainCode=[" + orderMainCode + "]");
            if (PeakConstant.SHOPID_HUISHANG.equals(payPortalOrder.getShopId()) && point > 0) {
                MemPointsClient memPointsClient = MemPointsClient.getInstance();
                Map map = new HashMap();
                map.put("bask_work_order", id);
                map.put("orderMainCode", orderMainCode);
                map.put("lenovoId", lenovoId);
                map.put("pay_infos", "HS 收银台结算");
                String detailJson = JacksonUtil.toJson(map);
                //扣减积分：MPPAY  ，返回积分：MPPLUS
                MemPointsWriteResult memPointsResult = memPointsClient.write("MPPAY", lenovoId, "", point, detailJson);
                logger.info("调用扣减积分 finish lenovoId=[" + lenovoId + "],orderMainCode=[" + orderMainCode + "],point=[" + point + "],memPointsResult=[" + memPointsResult.getCode() + "]");
                if ("00000".equals(memPointsResult.getCode())) { //调用积分成功
                    return true;
                }
            }
        } catch (Exception e) {
            logger.error("调用扣减积分 扣减接口返回结果 lenovoId=[" + lenovoId + "],orderMainCode=[" + orderMainCode + "],point=[" + point + "]", e);
            return false;
        }
        return false;
    }

    /**
     * MD5加密算法
     *
     * @param aData
     * @return
     * @throws SecurityException
     */
    public static String MD5Encode(String aData) throws SecurityException {
        String resultString = null;

        try {
            MessageDigest e = MessageDigest.getInstance("MD5");
            resultString = bytes2HexString(e.digest(aData.getBytes("UTF-8")));
        } catch (Exception e) {
            logger.info("MD5 Encode Error:Error Cause By :" + e);
        }
        return resultString;
    }

    public static String bytes2HexString(byte[] b) {
        String ret = "";

        for (int i = 0; i < b.length; ++i) {
            String hex = Integer.toHexString(b[i] & 255);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            ret = ret + hex.toUpperCase();
        }
        return ret;
    }

    /**
     * Json转Map
     *
     * @param jsonString
     * @return
     */
    public static Map<String, String> jsonToMap(String jsonString)
            throws JSONException {
        JSONObject jsonObject = JSONObject.fromObject(jsonString);
        Map<String, String> result = new HashMap<String, String>();
        Iterator iterator = jsonObject.keys();
        String key = null;
        String value = null;
        while (iterator.hasNext()) {
            key = String.valueOf(iterator.next());
            value = String.valueOf(jsonObject.get(key));
            result.put(key, value);
        }
        return result;
    }

    /**
     * 通联支付签名
     *
     * @return
     */
    public static String getAllinPaySign(Map<String, String> paraMap) {
        StringBuffer sb = new StringBuffer();
        String signMsg = null;
        try {
            for (Map.Entry<String, String> entry : paraMap.entrySet()) {
                sb.append("&" + entry.getKey()).append("=").append(entry.getValue());
            }
            sb.append("&");
            signMsg = LePayUtil.MD5Encode(sb.toString());
        } catch (Exception e) {
            logger.info("getAllinPaySign Error:Error Cause By :" + e);
        }
        return signMsg;
    }

    /**
     * 校验订单状态，防止重复通知
     *
     * @param payOrder payOrder
     * @return boolean
     */
    public static boolean isPaidPayOrder(PayOrder payOrder) {
        if (null != payOrder.getMerchant_flag() && null != payOrder.getTrade_state() && payOrder.getMerchant_flag() == 1 && payOrder.getTrade_state() == 1) {
            return true;
        }
        return false;
    }

    /**
     * 字典排序拼接参数
     *
     * @param map 待签名参数集合
     * @return 签名字符串明文
     */
    public static String jointParams(Map<String, String> map) {
        StringBuffer sb = new StringBuffer();
        List<String> list = new ArrayList<String>();

        for (Map.Entry<String, String> entry : map.entrySet()) {
            list.add(entry.getKey() + "=" + entry.getValue());
        }
        String[] parameters = list.toArray(new String[list.size()]);
        // 参数按字典排序
        Arrays.sort(parameters);
        // 遍历拼接
        for (String s : parameters) {
            sb.append(s + "&");
        }
        return sb.deleteCharAt(sb.length() - 1).toString();
    }

    /**
     * 正则替换所有特殊字符
     *
     * @param orgStr
     * @return
     */
    public static String replaceSpecStr(String orgStr){
        orgStr.replaceAll(" ","");
        if (null!=orgStr&&!"".equals(orgStr.trim())) {
            String regEx="[\\s~·`!！@#￥$%^……&*（()）\\-——\\-_=+【\\[\\]】｛{}｝\\|、\\\\；;：:‘'“”\"，,《<。.》>、/？?]";
            Pattern p = Pattern.compile(regEx);
            Matcher m = p.matcher(orgStr);
            return m.replaceAll("");
        }
        return orgStr;
    }

    public static <T> RemoteResult<T> getRemoteResult(RemoteResult<T> remoteResult, T t, boolean status, String resultCode, String resultMsg) {
        remoteResult.setT(t);
        remoteResult.setResultCode(resultCode);
        remoteResult.setResultMsg(resultMsg);
        remoteResult.setSuccess(status);
        return remoteResult;
    }

    /**
     * 获取返回页面
     *
     * @param shopId
     * @param terminal
     * @param isSuccess
     * @return
     */
    public static String getReturnView(String shopId, String terminal, boolean isSuccess) {
        String viewName = null;
        if (isSuccess) {
            if (PeakConstant.SHOPID_LENOVO.equals(shopId)) {
                if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                    viewName = "syncback/b2c_pc_succ";
                } else {
                    viewName = "syncback/b2c_wap_success";
                }
            } else if (PeakConstant.SHOPID_THINK.equals(shopId)) {
                Map<String, Object> urlMap = PropertiesHelper.loadToMap("ali_pay.properties");
                if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                    viewName = (String) urlMap.get("THINK_PC_SUCC");
                } else {
                    viewName = (String) urlMap.get("THINK_WAP_SUCC");
                }
            } else if (PeakConstant.SHOPID_EPP.equals(shopId)) {
                if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                    viewName = "syncback/epp_pc_succ";
                } else {
                    viewName = "syncback/epp_wap_success";
                }
            } else if (PeakConstant.SHOPID_SMB.equals(shopId)) {
                if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                    viewName = "syncback/smb_pc_succ";
                } else {
                    viewName = "syncback/b2c_wap_success";
                }
            }
        } else {
            if (PeakConstant.SHOPID_LENOVO.equals(shopId)) {
                if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                    viewName = "syncback/b2c_pc_fail";
                } else {
                    viewName = "syncback/b2c_wap_error";
                }
            } else if (PeakConstant.SHOPID_THINK.equals(shopId)) {
                Map<String, Object> urlMap = PropertiesHelper.loadToMap("ali_pay.properties");
                if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                    viewName = (String) urlMap.get("THINK_PC_ERROR");
                } else {
                    viewName = (String) urlMap.get("THINK_WAP_ERROR");
                }
            } else if (PeakConstant.SHOPID_EPP.equals(shopId)) {
                if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                    viewName = "syncback/epp_pc_fail";
                } else {
                    viewName = "syncback/epp_wap_error";
                }
            } else if (PeakConstant.SHOPID_SMB.equals(shopId)) {
                if (PeakConstant.TERMINAL_PC.equals(terminal)) {
                    viewName = "syncback/smb_pc_fail";
                } else {
                    viewName = "syncback/b2c_wap_error";
                }
            }
        }
        return viewName;
    }

    public static String convertPayment(String payment) {
        String orderPayment = "31";
        if ("12".equals(payment)) {
            orderPayment = "31";
        } else if ("13".equals(payment)) {
            orderPayment = "32";
        } else if ("16".equals(payment)) {
            orderPayment = "33";
        } else if ("17".equals(payment)) {
            orderPayment = "34";
        } else if ("18".equals(payment)) {
            orderPayment = "35";
        }
        return orderPayment;
    }

    /**
     * 转换时间时区
     *
     * @param convertString  需要转的时间字符串
     * @param format         格式话字符串 例如d-MMM-yyyy HH:mm (z)
     * @param sourceTimeZone 源时间时区
     * @param targetTimeZone 目标时间时区
     * @return
     * @throws ParseException
     */
    public static Date converDateGMTfromTZ(String convertString, String format, String sourceTimeZone, String targetTimeZone) throws ParseException {
        Date date = null;
        if (isEmpty(sourceTimeZone)) {
            sourceTimeZone = DEFAULT_TIMEZONE;
        }
        if (isEmpty(targetTimeZone)) {
            targetTimeZone = DEFAULT_TIMEZONE;
        }
        if (isEmpty(format)) {
            format = DATE_TIME_FORMAT;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        //获取传入的时间值
        Long time = new Date(sdf.parse(convertString).getTime()).getTime();
        //获取源时区时间相对的GMT时间
        Long sourceRelativelyGMT = time - TimeZone.getTimeZone(sourceTimeZone).getRawOffset();
        //GMT时间+目标时间时区的偏移量获取目标时间
        Long targetTime = sourceRelativelyGMT + TimeZone.getTimeZone(targetTimeZone).getRawOffset();
        date = new Date(targetTime);
        return date;

    }

    /**
     * Check empty string
     * <pre>
     *   null: true
     *   "": true
     *   " ":true
     * </>
     *
     * @param value
     * @return
     */
    public static boolean isEmpty(String value) {
        boolean emptyFlg = false;
        if (null == value || value.trim().length() <= 0) {
            emptyFlg = true;
        }
        return emptyFlg;
    }

    /**
     * 解析规律字符串成Map
     * @param srcStr
     * @param regx1
     * @param regx2
     * @return
     */
    public static Map<String,String> parseStrToMap(String srcStr, String regx1, String regx2){
        Map<String,String> map = new HashMap<String, String>();
        String[] pairs = srcStr.split(regx1);
        String k = "";
        String v = "";
        for (String string : pairs) {
            String[] pair = string.split(regx2);
            if (pair.length>1){
                map.put(pair[0],pair[1]);
            }else {
                map.put(pair[0],null);
            }
        }
        return map;
    }
}
