package com.lenovo.m2.buy.promotion.admin.common.pay.util;

/**
 * 乐支付静态常量
 * Created by tianchuyang on 2017/1/3.
 */
public class LePayConstant {

    // 交易类型
    public static final Integer ACCOUNT_TYPE_NONE = 0;  // NONE
    public static final Integer ACCOUNT_TYPE_B2C = 1;  // B2C
    public static final Integer ACCOUNT_TYPE_B2B = 2;  // B2B
    public static final Integer ACCOUNT_TYPE_OTHER = 3;  // C2C
    // 卡种
    public static final Integer CARD_TYPE_DEBIT = 1;  // 借记卡
    public static final Integer CARD_TYPE_CREDIT = 2;  // 信用卡
    // 手续费类型
    public static final Integer FEE_TYPE_RATE = 1;  // 手续费率(%)
    public static final Integer FEE_TYPE_CNY = 2;   // 手续费(元)
    // 数据状态
    public static final Integer DATA_STATUS_INVALID = 0;  // 无效
    public static final Integer DATA_STATUS_AVAILABLE = 1;  // 有效
    // 无限额
    public static final Integer NO_QUOTA = 0;  // 无限额
    // B2C、B2B标识
    // 联动优势支付
    public static final String UMPAY_B2C = "B2CBANK";
    public static final String UMPAY_B2B = "B2BBANK";
    // 通联支付
    public static final String ALLINPAY_B2C_D = "1"; // B2C借记卡
    public static final String ALLINPAY_B2B = "4";   // B2B
    public static final String ALLINPAY_B2C_C = "11"; // B2C信用卡
    // 平安支付
    public static final String PINGAN_B2C = "1000000009"; //1000000008
    public static final String PINGAN_B2B_B = "1000000009"; //1000000008
    public static final String PINGAN_B2B = "1000000009"; //1000000001

    // 直连标识
    public static final String DIRECT_UMPAY = "02";  // 联动优势

    // 是否启用测试支付
    public static final String IS_TEST_PAY = "1";  // 测试支付
    public static final String IS_REAL_PAY = "0";  // 真实支付

    // 接口版本号
    public static final String UMPAY_VERSION = "4.0";
    public static final String ALLINPAY_VERSION = "v1.0";

    // 交易状态标识
    public static final String TRADE_SUCC_UMPAY = "TRADE_SUCCESS";
    public static final String TRADE_SUCC_ALLINPAY = "1";
    public static final String TRADE_SUCC_PINGAN = "01";

    // 订单类型
    public static final String ORDER_TYPE_CREDIT = "15"; // 信用订单
    // 小程序LenovoId
    public static final String LENOVO_ID_WX_APPLET = "10";
}
