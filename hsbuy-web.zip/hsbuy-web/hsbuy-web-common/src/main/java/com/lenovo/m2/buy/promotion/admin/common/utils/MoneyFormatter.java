package com.lenovo.m2.buy.promotion.admin.common.utils;

import com.lenovo.m2.arch.framework.domain.Money;


/**
 * Created by lihc5 on 2016/12/22.
 */
public class MoneyFormatter {

    public  static String  format(Money money){
        return  money.getAmount().toString();
    }

}
